// ===================== ZENKO: CHAPTER BREAK — playable concept =====================
// Unofficial Encore Studio concept. Characters, manga, logo and art © Zenko (@Zenko_NFT).
const WIN = { x: 46, y: 350, w: 988, h: 1300, s: 1.3 };
const cv = document.getElementById('c');
const ctx = cv.getContext('2d');
let DPR = 1, SC = 1, OX = 0, OY = 0, CW = 0, CH = 0;
function resize() {
  DPR = Math.min(2, window.devicePixelRatio || 1);
  CW = Math.max(1, Math.round(innerWidth * DPR)); CH = Math.max(1, Math.round(innerHeight * DPR));
  cv.width = CW; cv.height = CH;
  SC = Math.min(CW / W, CH / H); OX = (CW - W * SC) / 2; OY = (CH - H * SC) / 2;
}
addEventListener('resize', resize); resize();
function toLogical(e) { const r = cv.getBoundingClientRect(); return [((e.clientX - r.left) * (CW / r.width) - OX) / SC, ((e.clientY - r.top) * (CH / r.height) - OY) / SC]; }
const rand = (a, b) => a + Math.random() * (b - a);
const distSeg = (px, py, ax, ay, bx, by) => { const vx = bx - ax, vy = by - ay, L2 = vx * vx + vy * vy; let t = L2 ? ((px - ax) * vx + (py - ay) * vy) / L2 : 0; t = clamp(t); return Math.hypot(px - ax - vx * t, py - ay - vy * t); };
function inPoly(poly, x, y) { for (let i = 0; i < poly.length; i++) { const a = poly[i], b = poly[(i + 1) % poly.length]; if ((b[0] - a[0]) * (y - a[1]) - (b[1] - a[1]) * (x - a[0]) < 0) return false; } return true; }
function bboxOf(p) { let a = 1e9, b = 1e9, c = -1e9, d = -1e9; for (const [x, y] of p) { a = Math.min(a, x); b = Math.min(b, y); c = Math.max(c, x); d = Math.max(d, y); } return [a, b, c, d]; }

// ---------------- world ----------------
const PANELS = [
  { id: 'P1', kind: 'story', poly: [[24, 24], [736, 24], [736, 300], [24, 336]] },
  { id: 'P2', kind: 'fight', poly: [[24, 350], [736, 314], [736, 770], [24, 730]] },
  { id: 'P3', kind: 'fight', poly: [[24, 744], [736, 784], [736, 1230], [24, 1250]] },
  { id: 'P4', kind: 'lock', poly: [[24, 1264], [736, 1244], [736, 1420], [24, 1420]] },
  { id: 'P5a', kind: 'fork', poly: [[24, 1434], [370, 1434], [340, 1880], [24, 1880]], route: 'ALLEY', reward: '+1 CARD · SWARM', pct: 39 },
  { id: 'P5b', kind: 'fork', poly: [[384, 1434], [736, 1434], [736, 1880], [354, 1880]], route: 'ROOFTOP', reward: '+RESONANCE · BRUTES', pct: 61 },
  { id: 'P6', kind: 'fight', poly: [[24, 1894], [736, 1894], [736, 2360], [24, 2400]] },
  { id: 'P7', kind: 'boss', poly: [[24, 2414], [736, 2374], [736, 3180], [24, 3180]] },
];
const PM = Object.fromEntries(PANELS.map((p) => [p.id, p]));
const INSETS = [
  { poly: [[24, 350], [290, 337], [250, 730], [24, 730]], hero: 'shonen' },
  { poly: [[490, 771], [736, 784], [736, 1230], [540, 1236]], hero: 'shojo' },
];
const BOSS_INSET = [[40, 2992], [262, 3002], [262, 3164], [40, 3164]];
const EYE_DEF = [
  { poly: [[64, 2452], [300, 2440], [300, 2622], [64, 2632]], c: [182, 2537] },
  { poly: [[470, 2960], [704, 2950], [704, 3144], [470, 3154]], c: [587, 3052] },
];
const BOSS_SPOTS = [[230, 2700], [540, 2660], [380, 2930], [610, 2850], [170, 2860], [450, 2560]];
const STAGES = [
  { id: 'story', panel: 'P1', cam: [380, 470, 1.0] },
  { id: 'p2', panel: 'P2', cam: [380, 560, 1.12], waves: [['wisp', 'wisp', 'wisp'], ['brute', 'wisp']], bounds: [330, 395, 700, 700], rift: [515, 545] },
  { id: 'p3', panel: 'P3', cam: [380, 1000, 1.12], waves: [['brute'], ['wisp', 'wisp', 'brute']], bounds: [80, 835, 450, 1170], rift: [260, 1000] },
  { id: 'lock', panel: 'P4', cam: [380, 1300, 1.05] },
  { id: 'fork', panel: 'P5', cam: [380, 1660, 1.0] },
  { id: 'p6', panel: 'P6', cam: [380, 2150, 1.1], bounds: [90, 1965, 670, 2320], rift: [380, 2140] },
  { id: 'boss', panel: 'P7', cam: [380, 2700, 0.98], bounds: [90, 2470, 680, 3120] },
];
const ROUTE_WAVES = { ALLEY: [['wisp', 'wisp', 'wisp', 'wisp'], ['wisp', 'wisp', 'wisp', 'wisp', 'wisp']], ROOFTOP: [['brute', 'wisp'], ['brute', 'brute']] };
const ENEMY = {
  wisp: { r: 30, hp: 55, speed: 75, tele: 1.7, every: [4.6, 7.0], first: [2.6, 4.2] },
  brute: { r: 52, hp: 240, speed: 42, tele: 1.3, every: [3.3, 4.6], first: [2.2, 3.1] },
};
const CARD = {
  claw: { title: 'RESONANCE CLAW', short: 'CLAW', sub: 'SHONEN · HITS ALL', art: 'cardClaw', cost: 50 },
  kunai: { title: 'KUNAI RAIN', short: 'KUNAI', sub: 'SHOJO · MULTI', art: 'cardKunai', cost: 40 },
  phase: { title: 'NERO PHASE', short: 'PHASE', sub: 'NERO · STUN ALL', art: 'heroNero', frame: 'purple', cost: 60 },
  splash: { title: 'SPLASH PAGE', short: 'FINISH', sub: 'FINISHER', art: 'p7', frame: 'gold', cost: 0 },
};
const DECK = ['claw', 'kunai', 'phase'];
const HEROES = ['shonen', 'shojo', 'nero'];
const HERO_INFO = { shonen: ['SHONEN', 'SWIPE'], shojo: ['SHOJO', 'TAP'], nero: ['NERO', 'DRAG'] };
const BOARD = [['holder_01', 27410], ['holder_12', 25900], ['holder_07', 24380], ['holder_33', 22750], ['holder_04', 21300], ['holder_21', 19880], ['holder_09', 18400], ['holder_15', 16920], ['holder_28', 15100]];

let G;
function newGame() {
  G = {
    mode: 'title', modeT: 0, rt: G ? G.rt : 0, gt: 0, playTime: 0, hitstop: 0,
    stage: 0, stageT: 0, st: 'intro', wave: -1, waveDelay: 0, clearT: 0, lockHp: 100, shatterT: null,
    hero: 'shonen', heroSwapT: -9, tagged: { shonen: true },
    hp: 5, maxHp: 5, combo: 0, comboT: 0, maxCombo: 0, score: 0, res: 0, lastHitRT: -9,
    nero: { active: false, x: 0, y: 0, tx: 0, ty: 0, vx: 0, vy: 0, energy: 100, appearT: -9, pid: null, lockAcc: 0 },
    enemies: [], fx: [], strokes: [], kunai: [], big: [], timers: [], rifts: [],
    panels: Object.fromEntries(PANELS.map((p) => [p.id, { restoreT: p.kind === 'story' ? -99 : null }])),
    route: null, forkAt: 0, boss: null,
    hand: DECK.map((k) => ({ kind: k })), deckI: 0, refill: [],
    drag: null, pinch: null, pointers: new Map(),
    stats: { parries: 0, perfect: 0, cards: 0, continues: 0, kills: 0 },
    cam: { cx: 380, cy: 470, z: 1 }, camT: { cx: 380, cy: 470, z: 1 }, shake: 0, shx: 0, shy: 0, invertT: -9, hurtT: -9,
    hints: {}, caption: null, prompt: null, toast: null, cutin: null, slowmo: 1, uid: 1, best: loadBest(), copied: -9,
  };
}
function loadBest() { try { return +localStorage.getItem('zenko-chapter-break-best') || 0; } catch (e) { return 0; } }
function saveBest(v) { try { localStorage.setItem('zenko-chapter-break-best', String(v)); } catch (e) { /* storage unavailable */ } }

// ---------------- camera ----------------
function w2s(x, y) { const c = G.cam; return [WIN.x + WIN.w / 2 + (x - c.cx) * c.z * WIN.s + G.shx, WIN.y + WIN.h / 2 + (y - c.cy) * c.z * WIN.s + G.shy]; }
function s2w(x, y) { const c = G.cam; return [c.cx + (x - WIN.x - WIN.w / 2) / (c.z * WIN.s), c.cy + (y - WIN.y - WIN.h / 2) / (c.z * WIN.s)]; }
const inWin = (x, y) => x >= WIN.x && x <= WIN.x + WIN.w && y >= WIN.y && y <= WIN.y + WIN.h;
function updateCam(dt) {
  const k = 1 - Math.exp(-dt * 3.6); const c = G.cam, t = G.camT;
  c.cx = lerp(c.cx, t.cx, k); c.cy = lerp(c.cy, t.cy, k); c.z = lerp(c.z, t.z, k);
  const half = 380 / c.z; c.cx = clamp(c.cx, half, 760 - half);
  G.shake *= Math.exp(-dt * 10);
  G.shx = (noise1(G.rt * 38) - 0.5) * 2 * G.shake; G.shy = (noise1(G.rt * 38 + 9) - 0.5) * 2 * G.shake;
}

// ---------------- messaging ----------------
function caption(big, small, dur = 4) { G.caption = { big, small, t0: G.rt, t1: G.rt + dur }; }
function prompt(text, at, dur = 2.5) { G.prompt = { text, at, t0: G.rt, t1: G.rt + dur }; }
function toast(text) { G.toast = { text, t0: G.rt }; }
function fxText(s, x, y, size, color, o = {}) { G.fx.push({ type: 'sfx', s, x, y, size, color, t0: G.gt, life: o.life || 0.7, rot: o.rot ?? -0.12, outer: o.outer }); }
function fxNum(v, x, y, color = '#fff', size = 34) { G.fx.push({ type: 'num', v, x, y, color, size, t0: G.gt }); }
function fxBurst(x, y, n = 14, big = 1) { G.fx.push({ type: 'burst', x, y, n, big, t0: G.gt, seed: Math.random() * 99 }); }
function fxLabel(s, x, y, size = 32, color = '#fff') { G.fx.push({ type: 'label', s, x, y, size, color, t0: G.gt }); }

// ---------------- scoring ----------------
function registerHit(dmg, x, y, o = {}) {
  G.combo++; G.comboT = 3; G.maxCombo = Math.max(G.maxCombo, G.combo); G.lastHitRT = G.rt;
  G.score += Math.round(dmg * (1 + Math.min(G.combo, 60) * 0.03)) + (o.bonus || 0);
  G.res = Math.min(100, G.res + (o.res ?? 2.5));
  if (o.num !== false && dmg > 0) fxNum(Math.round(dmg), x + rand(-10, 10), y - 30, o.color || '#fff', o.size || 34);
}
function playerHit(x, y) {
  if (G.mode !== 'play') return;
  G.hp--; G.hurtT = G.rt; G.shake = Math.max(G.shake, 20); G.combo = 0;
  fxText('ドンッ', x, y - 60, 70, '#fff', { outer: '#d6303a', life: 0.6 });
  if (G.hp <= 0) { G.mode = 'over'; G.modeT = 0; G.nero.active = false; G.drag = null; }
}

// ---------------- stages ----------------
function startStage(i) {
  G.stage = i; G.stageT = 0; G.st = 'intro'; G.wave = -1; G.waveDelay = 0;
  const S = STAGES[i]; G.camT = { cx: S.cam[0], cy: S.cam[1], z: S.cam[2] };
  if (S.id === 'p2') { caption('SWIPE TO SLASH.', 'Drag across the anomalies with Shonen.', 5); }
  if (S.id === 'lock') { G.lockHp = 100; caption('TAG IN NERO.', 'Tap his card, then hold & drag through the lock.', 6); prompt('ONLY NERO CAN PASS!', [430, 1225], 3); }
  if (S.id === 'fork') { caption('PICK THE PLOT FORK.', 'Tap a route. Holder polls shape the story.', 6); }
  if (S.id === 'p6') { if (G.res < 55) G.res = 60; G.hand.forEach((c, k) => { if (!c) { G.hand[k] = { kind: nextDeck() }; } }); caption('DRAG A CARD TO CAST.', 'Cards cost Resonance. Drop one on the page.', 6); }
  if (S.id === 'boss') { setupBoss(); caption('BREAK THE REDACTOR.', 'Hit its eyes when they open. Parry the ! with Shojo.', 6); }
}
function wavesFor(S) { return S.id === 'p6' ? ROUTE_WAVES[G.route || 'ROOFTOP'] : S.waves; }
function nextWave(S) {
  G.wave++; const list = wavesFor(S)[G.wave]; const [rx, ry] = S.rift;
  G.rifts.push({ x: rx, y: ry, t0: G.gt, t1: null });
  list.forEach((kind, k) => spawnEnemy(kind, rx, ry, S.bounds, k * 0.14 + 0.25, k));
}
function spawnEnemy(kind, fx, fy, b, delay, k = 0) {
  const d = ENEMY[kind];
  const e = { id: G.uid++, kind, r: d.r, hp: d.hp, max: d.hp, x: fx, y: fy, from: [fx, fy], tx: rand(b[0] + d.r, b[2] - d.r), ty: rand(b[1] + d.r, b[3] - d.r), b,
    spawnT: G.gt + delay, emerge: 0, atkT: rand(d.first[0], d.first[1]) + k * 0.55, tele: null, stun: 0, flashT: -9, lastSlash: -9, neroAcc: 0, kx: 0, ky: 0, ph: Math.random() * 9, wx: 0, wy: 0 };
  G.enemies.push(e); return e;
}
function updateStage(dt) {
  const S = STAGES[G.stage]; G.stageT += dt;
  if (S.id === 'story') { if (G.stageT > 3.6) startStage(1); return; }
  if (S.id === 'lock') {
    if (G.hero === 'nero' && !G.hints.neroDrag) { G.hints.neroDrag = true; caption('HOLD & DRAG THROUGH THE LOCK.', 'Nero phases through panel walls.', 5); }
    if (G.st === 'clear' && G.stageT - G.clearT > 1.5) startStage(G.stage + 1);
    return;
  }
  if (S.id === 'fork') { if (G.route && G.stageT - G.forkAt > 1.6) startStage(G.stage + 1); return; }
  if (S.id === 'boss') { updateBoss(dt); return; }
  // fights
  if (G.st === 'intro') { if (G.stageT > 0.6) { G.st = 'active'; nextWave(S); } return; }
  if (G.st === 'active' && G.enemies.length === 0) {
    if (G.wave < wavesFor(S).length - 1) { G.waveDelay += dt; if (G.waveDelay > 0.75) { G.waveDelay = 0; nextWave(S); } }
    else clearPanel(S);
  }
  if (G.st === 'clear' && G.stageT - G.clearT > 1.5) startStage(G.stage + 1);
}
function clearPanel(S) {
  G.st = 'clear'; G.clearT = G.stageT; G.panels[S.panel].restoreT = G.gt; G.score += 1000;
  for (const r of G.rifts) if (r.t1 == null) r.t1 = G.gt;
  const [x0, y0, x1, y1] = bboxOf(PM[S.panel].poly); fxLabel('PANEL RESTORED +1000', (x0 + x1) / 2, (y0 + y1) / 2 + 40, 34, '#fff');
}
function nextDeck() { const k = DECK[G.deckI % DECK.length]; G.deckI++; return k; }

// ---------------- enemies ----------------
function updateEnemies(dt) {
  for (const e of G.enemies) {
    const d = ENEMY[e.kind];
    if (G.gt < e.spawnT) continue;
    e.emerge = Math.min(1, e.emerge + dt / 0.45);
    if (e.emerge < 1) { const u = eOut(e.emerge); e.x = lerp(e.from[0], e.tx, u); e.y = lerp(e.from[1], e.ty, u); continue; }
    e.kx *= Math.exp(-dt * 10); e.ky *= Math.exp(-dt * 10);
    if (e.stun > 0) { e.stun -= dt; continue; }
    if (!e.tele) {
      const dx = e.tx - e.x, dy = e.ty - e.y, L = Math.hypot(dx, dy);
      if (L < 12) { e.tx = rand(e.b[0] + e.r, e.b[2] - e.r); e.ty = rand(e.b[1] + e.r, e.b[3] - e.r); }
      else { e.x += (dx / L) * d.speed * dt; e.y += (dy / L) * d.speed * dt; }
      e.atkT -= dt;
      if (e.atkT <= 0) {
        let dur = d.tele;
        if (G.stage === 2 && e.kind === 'brute' && !G.hints.parried) { dur = 3.2; G.parryTut = e.id; }
        e.tele = { t: 0, dur };
      }
    } else {
      e.tele.t += dt;
      if (e.tele.t >= e.tele.dur) { e.tele = null; e.atkT = rand(d.every[0], d.every[1]); e.kx = 0; playerHit(e.x, e.y); if (G.parryTut === e.id) G.parryTut = null; }
    }
    e.wx = Math.sin(G.gt * 1.4 + e.ph) * 10; e.wy = Math.cos(G.gt * 1.1 + e.ph * 1.7) * 8;
  }
  // parry tutorial: slow time until the player tags Shojo and parries
  const tut = G.parryTut && G.enemies.find((q) => q.id === G.parryTut && q.tele);
  if (tut) {
    if (!G.hints.parryCap) { G.hints.parryCap = true; caption('TAP SHOJO, THEN TAP THE !', 'Parry the attack before the ring closes.', 6); }
    if (G.hero === 'shojo' && !G.hints.parryCap2) { G.hints.parryCap2 = true; caption('TAP THE ! TO PARRY.', 'Pop the attack with her bubble.', 5); }
    G.slowmo = G.hero === 'shojo' ? 0.6 : 0.25;
  } else G.slowmo = 1;
}
const epos = (e) => [e.x + e.wx + e.kx, e.y + e.wy + e.ky];
function damageEnemy(e, dmg, src) {
  if (e.emerge < 1 || e.hp <= 0) return;
  e.hp -= dmg; e.flashT = G.gt;
  const [x, y] = epos(e); const dir = x > 380 ? 1 : -1; e.kx += dir * (src === 'card' ? 30 : 16); e.ky -= 6;
  registerHit(dmg, x, y);
  if (e.hp <= 0) killEnemy(e, src);
}
function killEnemy(e, src) {
  const [x, y] = epos(e);
  G.enemies = G.enemies.filter((q) => q !== e); G.stats.kills++;
  G.score += e.kind === 'brute' ? 300 : 100; G.res = Math.min(100, G.res + 6);
  fxBurst(x, y, e.kind === 'brute' ? 22 : 14, e.kind === 'brute' ? 1.5 : 1);
  const S = { claw: ['ザシュッ', C.coral], kunai: ['シュッ', C.sakura], nero: ['ドンッ', C.gold], card: ['ザンッ', C.coral] }[src] || ['ザシュッ', C.coral];
  fxText(S[0], x + 10, y - 70, e.kind === 'brute' ? 80 : 60, S[1]);
  if (e.kind === 'brute') { G.hitstop = 0.06; G.invertT = G.rt; G.shake = Math.max(G.shake, 12); }
  if (G.parryTut === e.id) G.parryTut = null;
}
function tryParry(wx, wy) {
  let best = null, bd = 1e9;
  for (const e of G.enemies) { if (!e.tele) continue; const [x, y] = epos(e); const d = Math.hypot(x - wx, y - wy); if (d < e.r + 70 && d < bd) { bd = d; best = e; } }
  const b = G.boss;
  if (b && b.alive && b.tele) { const d = Math.hypot(b.tele.x - wx, b.tele.y - wy); if (d < 100 && d < bd) { bd = d; best = 'boss'; } }
  if (!best) return false;
  let perfect, x, y;
  if (best === 'boss') { perfect = b.tele.t / b.tele.dur > 0.55; x = b.tele.x; y = b.tele.y; b.tele = null; b.stun = perfect ? 3.0 : 2.2; b.atkT = rand(3.4, 4.8); damageBoss(perfect ? 120 : 70, x, y); }
  else { perfect = best.tele.t / best.tele.dur > 0.55; [x, y] = epos(best); best.tele = null; best.stun = perfect ? 2.8 : 2.0; best.atkT = rand(ENEMY[best.kind].every[0], ENEMY[best.kind].every[1]) + best.stun; damageEnemy(best, perfect ? 30 : 18, 'kunai'); if (G.parryTut === best.id) G.parryTut = null; }
  G.stats.parries++; if (perfect) G.stats.perfect++;
  G.hints.parried = true; G.res = Math.min(100, G.res + 18); G.score += perfect ? 800 : 500;
  G.fx.push({ type: 'pop', x, y, t0: G.gt });
  fxText('ポンッ', x - 40, y - 90, 60, C.sakura);
  fxLabel(perfect ? 'PERFECT PARRY' : 'PARRY', x, y + 110, 34, '#fff');
  G.hitstop = 0.07; G.invertT = G.rt; G.shake = Math.max(G.shake, 9);
  return true;
}

// ---------------- heroes ----------------
function setHero(h) {
  if (G.hero === h) return;
  if (h !== 'nero') G.nero.active = false;
  G.hero = h; G.heroSwapT = G.rt;
  if (!G.tagged[h]) { G.tagged[h] = true; G.cutin = { kind: h, t0: G.rt }; }
}
function slashSeg(ax, ay, bx, by) {
  for (const e of G.enemies) {
    if (e.emerge < 1) continue; const [x, y] = epos(e);
    if (distSeg(x, y, ax, ay, bx, by) < e.r + 18 && G.gt - e.lastSlash > 0.13) { e.lastSlash = G.gt; damageEnemy(e, e.kind === 'brute' ? 30 : 34, 'claw'); }
  }
  const b = G.boss;
  if (b && b.alive && b.risen) {
    for (const eye of b.eyes) if (eye.state === 'open' && distSeg(eye.c[0], eye.c[1], ax, ay, bx, by) < 80) hitEye(eye);
    if (distSeg(b.x, b.y, ax, ay, bx, by) < b.R * 0.9 && G.gt - b.lastSlash > 0.12) { b.lastSlash = G.gt; damageBoss(26, (ax + bx) / 2, (ay + by) / 2); }
  }
  if (STAGES[G.stage].id === 'lock' && G.st !== 'clear' && (inPoly(PM.P4.poly, ax, ay) || inPoly(PM.P4.poly, bx, by)) && (!G.toast || G.rt - G.toast.t0 > 1.5)) toast('ONLY NERO CAN BREAK THE LOCK');
}
function throwKunai(tx, ty) {
  const [fx, fy] = s2w(WIN.x + 70, WIN.y + WIN.h - 40);
  G.kunai.push({ fx, fy, tx, ty, t0: G.gt, dur: 0.09, done: false, rain: false });
}
function resolveKunai(k) {
  k.done = true;
  let best = null, bd = 1e9;
  for (const e of G.enemies) { if (e.emerge < 1) continue; const [x, y] = epos(e); const d = Math.hypot(x - k.tx, y - k.ty); if (d < e.r + 46 && d < bd) { bd = d; best = e; } }
  if (best) { damageEnemy(best, k.rain ? 42 : 40, k.rain ? 'card' : 'kunai'); k.hitId = best.id; return; }
  const b = G.boss;
  if (b && b.alive && b.risen) {
    for (const eye of b.eyes) if (eye.state === 'open' && Math.hypot(eye.c[0] - k.tx, eye.c[1] - k.ty) < 100) { hitEye(eye); return; }
    if (Math.hypot(b.x - k.tx, b.y - k.ty) < b.R) { damageBoss(32, k.tx, k.ty); return; }
  }
  k.stuck = true;
}
function updateNero(dt) {
  const n = G.nero;
  if (n.active) {
    const px = n.x, py = n.y; const k = 1 - Math.exp(-dt * 16);
    n.x = lerp(n.x, n.tx, k); n.y = lerp(n.y, n.ty, k); n.vx = (n.x - px) / Math.max(dt, 1e-3); n.vy = (n.y - py) / Math.max(dt, 1e-3);
    n.energy -= 24 * dt;
    if (n.energy <= 0) { n.energy = 0; n.active = false; toast('NERO NEEDS TO RECHARGE'); }
    for (const e of G.enemies) {
      if (e.emerge < 1) continue; const [x, y] = epos(e);
      if (Math.hypot(x - n.x, y - n.y) < e.r + 44) { e.neroAcc += 130 * dt; if (e.neroAcc >= 22) { const d = e.neroAcc; e.neroAcc = 0; damageEnemy(e, Math.round(d), 'nero'); } }
    }
    const b = G.boss;
    if (b && b.alive && b.risen) {
      for (const eye of b.eyes) if (eye.state === 'open' && Math.hypot(eye.c[0] - n.x, eye.c[1] - n.y) < 90) hitEye(eye);
      if (Math.hypot(b.x - n.x, b.y - n.y) < b.R) { b.neroAcc += 90 * dt; if (b.neroAcc >= 24) { const d = b.neroAcc; b.neroAcc = 0; damageBoss(Math.round(d), n.x, n.y); } }
    }
    if (STAGES[G.stage].id === 'lock' && G.st !== 'clear') {
      const [x0, y0, x1, y1] = bboxOf(PM.P4.poly);
      if (n.x > x0 && n.x < x1 && n.y > y0 - 30 && n.y < y1 + 30) {
        G.lockHp -= 46 * dt; n.lockAcc += dt; G.shake = Math.max(G.shake, 3);
        if (n.lockAcc > 0.35) { n.lockAcc = 0; fxBurst(n.x, n.y, 8, 0.8); registerHit(16, n.x, n.y, { res: 1.5 }); }
        if (G.lockHp <= 0) shatterLock();
      }
    }
  } else n.energy = Math.min(100, n.energy + 20 * dt);
}
function shatterLock() {
  G.lockHp = 0; G.shatterT = G.gt; G.st = 'clear'; G.clearT = G.stageT; G.panels.P4.restoreT = G.gt + 0.08; G.score += 1000;
  G.shake = 16; G.invertT = G.rt; G.hitstop = 0.06; fxText('パリンッ', 470, 1250, 84, C.gold, { life: 0.8 });
  fxLabel('ROUTE OPEN +1000', 380, 1390, 34, '#fff');
}

// ---------------- cards ----------------
function tryCast(slot) {
  const c = G.hand[slot]; if (!c) return;
  const d = CARD[c.kind];
  if (G.res < d.cost) { toast(`NEED ${d.cost} RESONANCE`); return; }
  G.res -= d.cost; G.hand[slot] = null; G.stats.cards++; G.hints.card = true;
  if (c.kind !== 'splash') G.refill.push({ slot, t: G.rt + 3.2 });
  cast(c.kind);
}
function currentBox() { const S = STAGES[G.stage]; const pid = S.id === 'fork' ? 'P5b' : S.panel; return bboxOf(PM[pid].poly); }
function after(dt, fn) { G.timers.push({ t: G.gt + dt, fn }); }
function cast(kind) {
  const [x0, y0, x1, y1] = currentBox(); const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
  if (kind === 'claw') {
    G.big.push({ type: 'claw', t0: G.gt, lines: [{ a: [x0 + 30, y0 + 40], b: [x1 - 30, y1 - 40] }, { a: [x1 - 30, y0 + 50], b: [x0 + 30, y1 - 30] }, { a: [x0 + 20, cy], b: [x1 - 20, cy - 10] }] });
    fxText('ザンッ', cx + 140, cy - 150, 110, C.coral, { life: 0.9 }); fxLabel('RESONANCE CLAW', cx, cy + 160, 42);
    after(0.14, () => { for (const e of [...G.enemies]) damageEnemy(e, 140, 'card'); if (G.boss && G.boss.alive) damageBoss(260, G.boss.x, G.boss.y - 80); G.shake = 14; });
  } else if (kind === 'kunai') {
    fxLabel('KUNAI RAIN', cx, cy + 160, 42);
    for (let i = 0; i < 14; i++) after(i * 0.05, () => {
      const tg = []; for (const e of G.enemies) if (e.emerge >= 1) tg.push(epos(e));
      const b = G.boss; if (b && b.alive) { for (const eye of b.eyes) if (eye.state === 'open') tg.push(eye.c); tg.push([b.x + rand(-90, 90), b.y + rand(-90, 60)]); }
      const [tx, ty] = tg.length ? tg[Math.floor(Math.random() * tg.length)] : [rand(x0 + 40, x1 - 40), rand(y0 + 40, y1 - 40)];
      G.kunai.push({ fx: rand(x0, x1), fy: y0 - 120, tx: tx + rand(-6, 6), ty: ty + rand(-6, 6), t0: G.gt, dur: 0.12, done: false, rain: true });
    });
  } else if (kind === 'phase') {
    G.big.push({ type: 'phase', t0: G.gt, a: [x0 - 40, cy + 60], b: [x1 + 40, cy - 60] });
    fxLabel('NERO PHASE', cx, cy + 160, 42);
    after(0.25, () => {
      for (const e of [...G.enemies]) { e.tele = null; e.stun = 2.6; damageEnemy(e, 70, 'nero'); if (G.parryTut === e.id) G.parryTut = null; }
      const b = G.boss; if (b && b.alive) { b.tele = null; b.stun = 3; damageBoss(150, b.x, b.y); }
      G.invertT = G.rt; G.shake = 14; fxText('ドンッ!!', cx + 80, cy - 120, 100, C.gold, { life: 0.9 });
    });
  } else if (kind === 'splash') startFinisher();
}

// ---------------- fork ----------------
function chooseRoute(p) {
  G.route = p.route; G.forkAt = G.stageT; G.panels[p.id].restoreT = G.gt;
  if (p.route === 'ALLEY') { G.hand.forEach((c, k) => { if (!c) G.hand[k] = { kind: nextDeck() }; }); G.res = Math.min(100, G.res + 20); fxLabel('+1 CARD', 190, 1700, 40, '#fff'); }
  else { G.res = Math.min(100, G.res + 50); fxLabel('+50 RESONANCE', 560, 1700, 40, '#fff'); }
  G.caption = null;
}

// ---------------- boss ----------------
function setupBoss() {
  G.boss = { alive: true, risen: false, hp: 2800, max: 2800, x: 380, y: 2790, R: 200, riseT: G.gt, flashT: -9, tele: null, atkT: 3.4, spawnT: 6.0, stun: 0, lastSlash: -9, neroAcc: 0,
    eyes: EYE_DEF.map((d, i) => ({ ...d, state: 'closed', timer: 2.0 + i * 2.6, open: 0, hitT: -9 })), finisher: false };
}
function updateBoss(dt) {
  const b = G.boss; if (!b || !b.alive) return;
  if (!b.risen) { if (G.gt - b.riseT > 1.3) b.risen = true; else return; }
  for (const eye of b.eyes) {
    eye.timer -= dt;
    if (eye.state === 'closed' && eye.timer <= 0) { eye.state = 'open'; eye.timer = 3.0; if (!G.hints.eye) { G.hints.eye = true; prompt('HIT THE OPEN EYE!', [eye.c[0] + (eye.c[0] < 380 ? 120 : -120), eye.c[1] + 150], 2.5); } }
    else if (eye.state === 'open' && eye.timer <= 0) { eye.state = 'closed'; eye.timer = rand(3.4, 5.0); }
    else if (eye.state === 'broken' && eye.timer <= 0) { eye.state = 'closed'; eye.timer = rand(2.0, 3.5); }
    eye.open = lerp(eye.open, eye.state === 'open' ? 1 : 0, 1 - Math.exp(-dt * 10));
  }
  if (b.stun > 0) b.stun -= dt;
  else if (!b.tele) {
    b.atkT -= dt;
    if (b.atkT <= 0) { const [x, y] = BOSS_SPOTS[Math.floor(Math.random() * BOSS_SPOTS.length)]; b.tele = { x, y, t: 0, dur: 1.5 }; if (!G.hints.bossParry) { G.hints.bossParry = true; prompt('SHOJO: TAP THE ! TO PARRY', [x, y - 150], 2.2); } }
  } else {
    b.tele.t += dt;
    if (b.tele.t >= b.tele.dur) { const { x, y } = b.tele; b.tele = null; b.atkT = rand(3.3, 4.6); playerHit(x, y); }
  }
  b.spawnT -= dt;
  if (b.spawnT <= 0) { b.spawnT = 7.5; const n = G.enemies.length; if (n < 3) { const S = STAGES[G.stage]; for (let k = 0; k < Math.min(2, 3 - n); k++) spawnEnemy('wisp', b.x, b.y + 90, S.bounds, k * 0.15, k); } }
}
function hitEye(eye) {
  if (eye.state !== 'open') return;
  eye.state = 'broken'; eye.timer = 7; eye.hitT = G.gt;
  G.res = Math.min(100, G.res + 12); G.hitstop = 0.06; G.invertT = G.rt; G.shake = Math.max(G.shake, 10);
  damageBoss(200, eye.c[0], eye.c[1], { color: C.gold, size: 46 });
  fxText('バキッ', eye.c[0], eye.c[1] - 60, 60, '#fff', { outer: C.coral });
}
function damageBoss(d, x, y, o = {}) {
  const b = G.boss; if (!b || !b.alive) return;
  b.hp -= d; b.flashT = G.gt;
  registerHit(d, x, y, { color: o.color || C.gold, size: o.size || 40 });
  if (!b.finisher && b.hp <= b.max * 0.3) {
    b.finisher = true; G.hand[0] = { kind: 'splash' };
    caption('SPLASH PAGE READY!', 'Drag the gold card onto the page — or pinch.', 8);
    prompt('FINISH IT!', [380, 2520], 3);
  }
  if (b.hp < b.max * 0.05) b.hp = b.max * 0.05;
}
function startFinisher() {
  const b = G.boss; if (!b || !b.alive) return;
  b.alive = false; G.enemies = []; G.nero.active = false; G.drag = null; G.caption = null; G.prompt = null; G.toast = null;
  G.stats.time = G.playTime; G.score += 5000 + Math.max(0, Math.round((240 - G.playTime) * 20)) + G.hp * 400;
  G.mode = 'splash'; G.modeT = 0;
}

// ---------------- input ----------------
function teamSlot(i) { return { x: 46 + i * 140 + 62, y: 1792, w: 124, h: 172 }; }
function handSlot(i) { return { x: 618 + i * 140 + 62, y: 1792, w: 124, h: 172 }; }
const hitSlot = (s, x, y, pad = 8) => Math.abs(x - s.x) < s.w / 2 + pad && Math.abs(y - s.y) < s.h / 2 + pad;
function buttonsFor(mode) {
  if (mode === 'over') return [{ id: 'retry', x: W / 2, y: 1150, w: 520, h: 110, label: 'RETRY THIS PANEL' }];
  if (mode === 'encore') return [{ id: 'again', x: W / 2 - 230, y: 1700, w: 420, h: 104, label: 'PLAY AGAIN' }, { id: 'share', x: W / 2 + 230, y: 1700, w: 420, h: 104, label: 'SHARE ON X', light: true }];
  return [];
}
function onDown(P) {
  const { x, y } = P;
  if (G.mode === 'title') { if (G.modeT > 0.4) { G.mode = 'play'; G.modeT = 0; startStage(0); } return; }
  if (G.mode === 'results' || G.mode === 'board') { if (G.modeT > 1.0) { G.mode = G.mode === 'results' ? 'board' : 'encore'; G.modeT = 0; } return; }
  if (G.mode === 'over' || G.mode === 'encore') {
    for (const bt of buttonsFor(G.mode)) if (Math.abs(x - bt.x) < bt.w / 2 && Math.abs(y - bt.y) < bt.h / 2) pressButton(bt.id);
    return;
  }
  if (G.mode !== 'play') return;
  // pinch (finisher)
  const pts = [...G.pointers.values()];
  if (pts.length === 2 && G.boss && G.boss.finisher && pts.every((q) => inWin(q.x, q.y))) { G.pinch = { d0: Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) }; P.role = 'pinch'; return; }
  for (let i = 0; i < 3; i++) if (hitSlot(teamSlot(i), x, y)) { P.role = 'team'; setHero(HEROES[i]); return; }
  for (let i = 0; i < 3; i++) if (G.hand[i] && hitSlot(handSlot(i), x, y)) { P.role = 'card'; G.drag = { slot: i, x, y, pid: P.id }; return; }
  if (!inWin(x, y)) return;
  P.role = 'page';
  const [wx, wy] = s2w(x, y);
  const S = STAGES[G.stage];
  if (S.id === 'story') { if (G.stageT > 0.8) startStage(1); return; }
  if (S.id === 'fork' && !G.route) { for (const p of [PM.P5a, PM.P5b]) if (inPoly(p.poly, wx, wy)) { chooseRoute(p); return; } return; }
  if (G.hero === 'shonen') { P.stroke = { pts: [{ x: wx, y: wy, t: G.gt }], end: null }; G.strokes.push(P.stroke); if (!G.hints.swiped) G.hints.swiped = true; }
  else if (G.hero === 'shojo') {
    if (G.gt - (G.lastTap || -9) < 0.12) return; G.lastTap = G.gt;
    if (!tryParry(wx, wy)) throwKunai(wx, wy);
    G.fx.push({ type: 'tap', x: wx, y: wy, t0: G.gt });
  } else if (G.hero === 'nero') {
    const n = G.nero;
    if (n.energy < 12) { toast('NERO NEEDS TO RECHARGE'); return; }
    n.active = true; n.x = n.tx = wx; n.y = n.ty = wy; n.appearT = G.gt; n.pid = P.id;
    fxText('ドンッ', wx + 60, wy - 60, 52, C.gold, { life: 0.4 });
  }
}
function onMove(P) {
  if (G.mode !== 'play') return;
  if (G.pinch) {
    const pts = [...G.pointers.values()];
    if (pts.length >= 2 && Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y) - G.pinch.d0 > 140) { G.pinch = null; if (G.boss && G.boss.finisher) startFinisher(); }
    return;
  }
  if (P.role === 'card' && G.drag && G.drag.pid === P.id) { G.drag.x = P.x; G.drag.y = P.y; return; }
  if (P.role !== 'page') return;
  const [wx, wy] = s2w(P.x, P.y);
  if (P.stroke && G.hero === 'shonen') {
    const last = P.stroke.pts[P.stroke.pts.length - 1];
    if (Math.hypot(wx - last.x, wy - last.y) > 3) { slashSeg(last.x, last.y, wx, wy); P.stroke.pts.push({ x: wx, y: wy, t: G.gt }); }
  } else if (G.nero.active && G.nero.pid === P.id) { G.nero.tx = wx; G.nero.ty = wy; }
}
function onUp(P) {
  if (P.role === 'pinch') G.pinch = null;
  if (P.stroke) P.stroke.end = G.gt;
  if (G.nero.pid === P.id) G.nero.active = false;
  if (P.role === 'card' && G.drag && G.drag.pid === P.id) { const d = G.drag; G.drag = null; if (G.mode === 'play' && inWin(d.x, d.y) && d.y < WIN.y + WIN.h - 60) tryCast(d.slot); }
}
function pressButton(id) {
  if (id === 'retry') {
    G.stats.continues++; G.hp = G.maxHp; G.enemies = []; G.kunai = []; G.nero.active = false; G.combo = 0; G.mode = 'play'; G.modeT = 0;
    if (STAGES[G.stage].id === 'boss') { const b = G.boss; b.tele = null; b.atkT = 3; b.spawnT = 6; } else startStage(G.stage);
  } else if (id === 'again') { const best = G.best; newGame(); G.best = best; G.mode = 'play'; startStage(0); }
  else if (id === 'share') {
    const txt = shareText();
    try { navigator.clipboard && navigator.clipboard.writeText(txt); } catch (e) { /* clipboard unavailable */ }
    G.copied = G.rt;
    try { window.open('https://x.com/intent/post?text=' + encodeURIComponent(txt), '_blank', 'noopener'); } catch (e) { /* popup blocked */ }
  }
}
function fmtTime(s) { const m = Math.floor(s / 60), r = s - m * 60; return `${m}:${r.toFixed(1).padStart(4, '0')}`; }
function rankOf() { const s = G.stats; return s.continues === 0 && G.hp >= 3 && s.parries >= 2 ? 'S' : s.continues === 0 ? 'A' : s.continues <= 1 ? 'B' : 'C'; }
function shareText() { return `Cleared Chapter 01 of ZENKO: CHAPTER BREAK. Rank ${rankOf()} · ${fmtTime(G.stats.time || 0)} · max combo ${G.maxCombo} · ${G.route || 'ROOFTOP'} route · ${G.score.toLocaleString('en-US')} pts. #ZENKO #ChapterBreak`; }
cv.addEventListener('pointerdown', (e) => { e.preventDefault(); try { cv.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ } const [x, y] = toLogical(e); const P = { id: e.pointerId, x, y, role: null, stroke: null }; G.pointers.set(e.pointerId, P); onDown(P); });
cv.addEventListener('pointermove', (e) => { const P = G.pointers.get(e.pointerId); if (!P) return; e.preventDefault(); const [x, y] = toLogical(e); P.x = x; P.y = y; onMove(P); });
const up = (e) => { const P = G.pointers.get(e.pointerId); if (!P) return; onUp(P); G.pointers.delete(e.pointerId); };
cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up); cv.addEventListener('lostpointercapture', up);
addEventListener('keydown', (e) => { if (G.mode === 'play' && e.key >= '1' && e.key <= '3') setHero(HEROES[+e.key - 1]); });
document.addEventListener('visibilitychange', () => { G._last = performance.now(); });

// ---------------- update ----------------
function update(dt) {
  G.rt += dt; G.modeT += dt;
  if (G.mode === 'play') {
    let ts = G.slowmo;
    if (G.cutin && G.rt - G.cutin.t0 < 0.8) ts = Math.min(ts, 0.15); else G.cutin = null;
    if (G.hitstop > 0) { G.hitstop -= dt; ts = 0; }
    const gd = dt * ts; G.gt += gd; G.playTime += gd;
    G.comboT -= gd; if (G.comboT <= 0) G.combo = 0;
    for (const tm of [...G.timers]) if (G.gt >= tm.t) { G.timers.splice(G.timers.indexOf(tm), 1); tm.fn(); }
    updateStage(gd); updateEnemies(gd); updateNero(gd);
    for (const k of G.kunai) if (!k.done && G.gt - k.t0 >= k.dur) resolveKunai(k);
    G.kunai = G.kunai.filter((k) => !k.done || G.gt - k.t0 < (k.stuck ? 1.2 : 0.5));
    for (const r of G.refill) if (G.rt >= r.t && !G.hand[r.slot]) { G.hand[r.slot] = { kind: nextDeck() }; r.used = true; }
    G.refill = G.refill.filter((r) => !r.used && G.rt < r.t + 0.5);
  } else if (G.mode === 'splash') {
    if (G.modeT > 2.5) { G.mode = 'cleared'; G.modeT = 0; G.panels.P7.restoreT = G.gt; }
  } else if (G.mode === 'cleared') {
    G.gt += dt; if (G.modeT > 2.2) { G.mode = 'results'; G.modeT = 0; if (G.score > G.best) { G.best = G.score; saveBest(G.best); } }
  }
  G.fx = G.fx.filter((f) => G.gt - f.t0 < 1.4);
  G.strokes = G.strokes.filter((s) => s.end == null || G.gt - s.end < 0.4);
  G.big = G.big.filter((b) => G.gt - b.t0 < 1.0);
  G.rifts = G.rifts.filter((r) => r.t1 == null || G.gt - r.t1 < 0.6);
  updateCam(dt);
}

// ---------------- drawing: world ----------------
function drawWorld(g, final = false) {
  g.fillStyle = C.paper; g.fillRect(-200, -200, 1160, 3600);
  for (const p of PANELS) drawPanel(g, p);
  for (const ins of INSETS) drawInset(g, ins.poly, ins.hero, false);
  if (!final) {
    drawRifts(g); drawPollChip(g);
    if (G.boss && (G.boss.alive || G.mode === 'splash')) { drawBoss(g); for (const eye of G.boss.eyes) drawEye(g, eye); drawInset(g, BOSS_INSET, G.hero, true); }
    for (const e of G.enemies) drawEnemy(g, e);
    for (const e of G.enemies) if (e.tele) { const [x, y] = epos(e); drawTele(g, x, y - e.r * 0.15, e.tele, e.r); }
    if (G.boss && G.boss.alive && G.boss.tele) drawTele(g, G.boss.tele.x, G.boss.tele.y, G.boss.tele, 60);
    drawKunai(g); drawStrokes(g); drawBig(g); drawNeroLive(g); drawShards(g); drawFX(g); drawPromptBubble(g);
  }
  g.save(); g.globalCompositeOperation = 'multiply'; g.globalAlpha = 0.4; g.fillStyle = g.createPattern(ART.grain, 'repeat'); g.fillRect(0, 0, 760, 3200); g.restore();
}
function restoreAmt(p) {
  if (p.kind === 'story') return 1;
  const r = G.panels[p.id].restoreT; return r == null ? 0 : eOut(inv(r, r + 0.6, G.gt));
}
function drawPanel(g, p) {
  const [x0, y0, x1, y1] = bboxOf(p.poly);
  g.save(); polyPath(g, p.poly); g.clip();
  g.fillStyle = '#f5f2ec'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  if (p.kind === 'lock' && restoreAmt(p) <= 0) drawLock(g, p, x0, y0, x1, y1);
  else {
    const rp = restoreAmt(p);
    const unread = p.kind === 'fork' && G.route && G.route !== p.route;
    if (rp < 1 && !unread) {
      cover(g, ART.corrupt[p.id], x0, y0, x1, y1, 1.05 + 0.015 * Math.sin(G.rt * 3 + y0));
      const k = Math.floor(G.rt * 18);
      for (let i = 0; i < 5; i++) { const yy = y0 + hash(k * 13 + i + y0) * (y1 - y0), hh = 2 + hash(k * 7 + i) * 9; g.fillStyle = i % 2 ? 'rgba(244,87,94,0.45)' : 'rgba(255,255,255,0.18)'; g.fillRect(x0, yy, x1 - x0, hh); }
    }
    if (rp > 0 || unread) {
      g.save();
      if (rp < 1 && !unread) { const yy = lerp(y0 - 40, y1 + 40, rp); g.beginPath(); g.rect(x0, y0, x1 - x0, yy - y0); g.clip(); }
      cover(g, ART.clean[p.id], x0, y0, x1, y1, p.kind === 'story' ? 1.0 : 1.04);
      if (unread) { g.fillStyle = 'rgba(20,16,22,0.62)'; g.fillRect(x0, y0, x1 - x0, y1 - y0); }
      g.restore();
      if (rp > 0 && rp < 1 && !unread) { const yy = lerp(y0 - 40, y1 + 40, rp); g.save(); g.globalAlpha = 0.6; g.fillStyle = g.createPattern(ART.halftone, 'repeat'); g.fillRect(x0, yy - 30, x1 - x0, 60); g.restore(); g.fillStyle = 'rgba(255,255,255,0.8)'; g.fillRect(x0, yy - 3, x1 - x0, 6); }
    }
    if (p.kind === 'story') drawNarration(g);
    if (p.kind === 'fork') drawForkUI(g, p, x0, y0, x1, y1, unread);
    const r = G.panels[p.id].restoreT;
    if (p.kind !== 'story' && r != null && !unread && G.gt > r + 0.35) {
      const a = inv(r + 0.35, r + 0.5, G.gt), k = lerp(2, 1, eOut(a));
      g.save(); g.globalAlpha = a; g.translate(x1 - 120, y0 + 64 + (p.id === 'P7' ? 40 : 0)); g.rotate(-0.12); g.scale(k, k);
      rrect(g, -86, -24, 172, 48, 6); g.lineWidth = 5; g.strokeStyle = '#d6303a'; g.stroke();
      text(g, 'RESTORED', 0, 10, { font: FONT.dela, size: 24, color: '#d6303a', align: 'center', ls: 2 }); g.restore();
    }
  }
  g.restore();
  if (p.kind === 'lock' && G.shatterT != null && G.gt - G.shatterT < 0.35) return;
  g.save(); polyPath(g, p.poly); g.lineJoin = 'miter'; g.lineWidth = 6; g.strokeStyle = C.ink; g.stroke(); g.restore();
}
function drawNarration(g) {
  const st = G.mode === 'title' ? 0 : (G.stage === 0 ? G.stageT : 9);
  const box = (x, y, w, h, str, o, a) => { if (a <= 0) return; g.save(); g.globalAlpha = a; g.translate(0, (1 - a) * 10); g.fillStyle = '#fff'; g.fillRect(x, y, w, h); g.lineWidth = 4; g.strokeStyle = C.ink; g.strokeRect(x, y, w, h); text(g, str, x + 16, y + h / 2 + o.size * 0.36, o); g.restore(); };
  box(44, 44, 330, 50, 'KUROKAWA · 02:14 AM', { font: FONT.mono, size: 20, color: C.ink, ls: 2 }, inv(0.1, 0.4, st));
  box(330, 150, 386, 56, 'The rift is rewriting the manga.', { font: FONT.disp, weight: 600, size: 22, color: C.ink }, inv(0.7, 1.0, st));
}
function drawLock(g, p, x0, y0, x1, y1) {
  g.fillStyle = '#140a0f'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  g.save(); g.globalAlpha = 0.5;
  for (let i = -10; i < 30; i++) { g.fillStyle = i % 2 ? C.coral : '#000'; g.beginPath(); const xx = x0 + i * 40 + (G.rt * 30) % 80; g.moveTo(xx, y1); g.lineTo(xx + 40, y1); g.lineTo(xx + 140, y0); g.lineTo(xx + 100, y0); g.fill(); }
  g.restore();
  g.fillStyle = '#060406'; g.fillRect(x0, (y0 + y1) / 2 - 34, x1 - x0, 68);
  text(g, 'LOCKED BY THE RIFT', 380, (y0 + y1) / 2 + 9, { font: FONT.dela, size: 30, color: '#fff', align: 'center', ls: 3 });
  g.save(); g.strokeStyle = '#8a7d84'; g.lineWidth = 6;
  for (let i = 0; i < 14; i++) { g.beginPath(); g.ellipse(60 + i * 50, y0 + 26, 22, 10, 0, 0, 7); g.stroke(); g.beginPath(); g.ellipse(85 + i * 50, y1 - 22, 22, 10, 0, 0, 7); g.stroke(); }
  g.restore();
  // cracks grow as Nero breaks it
  const dmg = 1 - G.lockHp / 100;
  if (dmg > 0) {
    g.save(); g.strokeStyle = C.gold; g.lineWidth = 5; g.shadowColor = C.gold; g.shadowBlur = 16;
    const n = Math.floor(dmg * 14) + 1;
    for (let i = 0; i < n; i++) { const cx = 80 + hash(i * 3.1) * 600, cy = y0 + 20 + hash(i * 7.3) * (y1 - y0 - 40); g.beginPath(); g.moveTo(cx, cy); for (let k = 0; k < 4; k++) g.lineTo(cx + (hash(i * 11 + k) - 0.5) * 120 * (k + 1) * 0.5, cy + (hash(i * 13 + k) - 0.5) * 60 * (k + 1) * 0.5); g.stroke(); }
    g.restore();
    rrect(g, 230, y1 - 14, 300, 10, 5); g.fillStyle = 'rgba(0,0,0,0.6)'; g.fill(); rrect(g, 230, y1 - 14, 300 * (1 - dmg), 10, 5); g.fillStyle = C.gold; g.fill();
  }
}
function drawShards(g) {
  if (G.shatterT == null) return; const age = G.gt - G.shatterT; if (age < 0 || age > 0.9) return;
  const k = 1 - age / 0.9;
  ART.shards.forEach((tri, i) => {
    const cx = (tri[0][0] + tri[1][0] + tri[2][0]) / 3, cy = (tri[0][1] + tri[1][1] + tri[2][1]) / 3;
    const dx = cx - 430, dy = cy - 1340, L = Math.hypot(dx, dy) || 1, sp = 260 + 380 * hash(i * 3.7);
    g.save(); g.translate(cx + (dx / L) * sp * age, cy + (dy / L) * sp * age + 900 * age * age); g.rotate((hash(i * 9.1) - 0.5) * 8 * age); g.globalAlpha = k;
    g.beginPath(); tri.forEach(([x, y], j) => (j ? g.lineTo(x - cx, y - cy) : g.moveTo(x - cx, y - cy))); g.closePath();
    g.fillStyle = i % 3 ? '#140a0f' : C.coral; g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); g.restore();
  });
}
function drawForkUI(g, p, x0, y0, x1, y1, unread) {
  if (G.stage < 4) return;
  const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
  if (unread) { text(g, p.route, cx, cy - 8, { font: FONT.dela, size: 40, color: '#bdb6c4', align: 'center' }); text(g, 'UNREAD', cx, cy + 34, { font: FONT.mono, size: 22, color: '#bdb6c4', align: 'center', ls: 4 }); return; }
  const chosenAlpha = G.route === p.route ? 1 - inv(G.forkAt + 0.3, G.forkAt + 0.7, G.stageT + (G.stage > 4 ? 99 : 0)) : 1;
  const a = inv(0.1, 0.4, G.stage > 4 ? 9 : G.stageT) * chosenAlpha; if (a <= 0) return;
  const pulse = !G.route ? 1 + 0.04 * Math.sin(G.rt * 6 + (p.route === 'ALLEY' ? 0 : 2)) : 1;
  g.save(); g.globalAlpha = a; g.translate(cx, cy); g.scale(pulse, pulse); g.translate(-cx, -cy);
  text(g, p.route, cx, cy - 34, { font: FONT.dela, size: 46, color: '#fff', align: 'center', stroke: 12, strokeColor: C.ink });
  text(g, p.reward, cx, cy + 6, { font: FONT.mono, size: 18, color: '#fff', align: 'center', ls: 1, stroke: 6, strokeColor: C.ink });
  const fill = eOut(inv(0.2, 1.0, G.stage > 4 ? 9 : G.stageT)) * p.pct / 100; const bw = 230, bx = cx - bw / 2, by = cy + 30;
  rrect(g, bx, by, bw, 26, 13); g.fillStyle = 'rgba(0,0,0,0.6)'; g.fill(); g.lineWidth = 3; g.strokeStyle = '#fff'; g.stroke();
  g.save(); rrect(g, bx, by, bw * fill, 26, 13); g.clip(); g.fillStyle = p.route === 'ROOFTOP' ? C.coral : '#bdb6c4'; g.fillRect(bx, by, bw, 26); g.restore();
  text(g, `${Math.round(fill * 100)}% OF HOLDERS`, cx, by + 60, { font: FONT.dela, size: 22, color: '#fff', align: 'center', stroke: 8, strokeColor: C.ink });
  if (!G.route) text(g, 'TAP TO READ', cx, by + 110, { font: FONT.mono, size: 20, color: '#fff', align: 'center', ls: 3, stroke: 6, strokeColor: C.ink, alpha: 0.6 + 0.4 * Math.sin(G.rt * 5) });
  g.restore();
}
function drawPollChip(g) {
  if (STAGES[G.stage].id !== 'fork' || G.route) return; const a = inv(0.1, 0.4, G.stageT); if (a <= 0) return;
  g.save(); g.globalAlpha = a; rrect(g, 210, 1448, 340, 44, 22); g.fillStyle = C.ink; g.fill(); g.lineWidth = 3; g.strokeStyle = '#fff'; g.stroke();
  text(g, 'HOLDER POLL · PLOT FORK', 380, 1477, { font: FONT.mono, size: 18, color: '#fff', align: 'center', ls: 2 }); g.restore();
}
function drawRifts(g) {
  // the first tear in panel 1
  const t0 = 1.2, s = G.stage === 0 ? G.stageT : 9; const u = eOut(inv(t0, t0 + 0.5, s));
  const close = G.panels.P2.restoreT != null ? 1 - inv(G.panels.P2.restoreT, G.panels.P2.restoreT + 0.5, G.gt) : 1;
  if (u > 0 && close > 0) {
    g.save(); g.globalAlpha = close;
    const pts = []; for (let i = 0; i <= 16; i++) { const t = i / 16; pts.push([lerp(120, 660, t), lerp(296, 262, t) + (i % 2 ? -12 : 12) * Math.sin(t * Math.PI)]); }
    const n = Math.max(2, Math.round(pts.length * u));
    g.shadowColor = C.coral; g.shadowBlur = 30 * (0.7 + 0.3 * Math.sin(G.rt * 8)); g.lineCap = 'round'; g.lineJoin = 'round';
    g.strokeStyle = '#12060c'; g.lineWidth = 20; g.beginPath(); pts.slice(0, n).forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.stroke();
    g.shadowBlur = 0; g.strokeStyle = C.coral; g.lineWidth = 5; g.stroke();
    for (let i = 0; i < 7; i++) { const x = 160 + i * 74, L = 30 + 50 * hash(i) * u; g.strokeStyle = 'rgba(214,48,58,0.8)'; g.lineWidth = 5; g.beginPath(); g.moveTo(x, 280 - i * 3); g.lineTo(x, 280 - i * 3 + L); g.stroke(); }
    g.restore();
  }
  for (const r of G.rifts) {
    const a = eBack(inv(r.t0, r.t0 + 0.3, G.gt)) * (r.t1 == null ? 1 : 1 - inv(r.t1, r.t1 + 0.5, G.gt)); if (a <= 0.01) continue;
    g.save(); g.translate(r.x, r.y); g.rotate(-0.4); g.scale(a, a); g.shadowColor = C.coral; g.shadowBlur = 30;
    g.beginPath(); g.ellipse(0, 0, 70, 16, 0, 0, 7); g.fillStyle = '#12060c'; g.fill(); g.shadowBlur = 0; g.lineWidth = 5; g.strokeStyle = C.coral; g.stroke(); g.restore();
  }
}
function drawEnemy(g, e) {
  if (G.gt < e.spawnT) return;
  const [x, y] = epos(e);
  const tele = e.tele ? e.tele.t / e.tele.dur : 0;
  const jit = tele > 0 ? (noise1(G.rt * 60 + e.id) - 0.5) * 6 * tele : 0;
  const a = { id: e.id, x: x + jit, y, vx: (e.tx - e.x) || 1, vy: (e.ty - e.y) + 30, r: e.r * (1 + 0.12 * tele) };
  drawWisp(g, a, G.rt, eBack(e.emerge));
  if (e.kind === 'brute') {
    g.save(); g.translate(x + jit, y); g.scale(eBack(e.emerge) * (1 + 0.12 * tele), eBack(e.emerge) * (1 + 0.12 * tele)); g.fillStyle = '#2b1d22'; g.strokeStyle = C.ink; g.lineWidth = 4;
    for (const sx of [-1, 1]) { g.beginPath(); g.moveTo(sx * e.r * 0.35, -e.r * 0.8); g.lineTo(sx * e.r * 0.85, -e.r * 1.55); g.lineTo(sx * e.r * 0.7, -e.r * 0.6); g.closePath(); g.fill(); g.stroke(); }
    g.fillStyle = '#fff'; g.beginPath(); for (let i = 0; i <= 8; i++) g.lineTo(-e.r * 0.45 + i * e.r * 0.1125, e.r * 0.42 + (i % 2 ? 10 : 0)); g.lineTo(e.r * 0.45, e.r * 0.3); g.lineTo(-e.r * 0.45, e.r * 0.3); g.closePath(); g.fill(); g.stroke();
    g.restore();
  }
  if (G.gt - e.flashT < 0.07) { g.fillStyle = 'rgba(255,255,255,0.85)'; g.beginPath(); g.arc(x, y, e.r * 1.05, 0, 7); g.fill(); }
  if (e.stun > 0) for (let i = 0; i < 3; i++) { const an = G.rt * 5 + i * 2.1; star4(g, x + Math.cos(an) * e.r * 1.1, y - e.r * 1.3 + Math.sin(an) * 10, 10, C.gold); }
  if (e.hp < e.max && e.emerge >= 1) { const w = e.r * 1.8; rrect(g, x - w / 2, y + e.r + 12, w, 8, 4); g.fillStyle = 'rgba(0,0,0,0.6)'; g.fill(); rrect(g, x - w / 2, y + e.r + 12, w * clamp(e.hp / e.max), 8, 4); g.fillStyle = C.coral; g.fill(); }
}
function drawTele(g, x, y, T, r) {
  const u = T.t / T.dur, pre = clamp(T.t / 0.12);
  const ringR = lerp(r * 2.8 + 40, r + 16, u);
  const sz = r > 45 ? 1 : 0.75;
  g.save(); g.translate(x, y - r * 0.9 - 40 * sz); g.scale(eBack(pre) * sz, eBack(pre) * sz);
  g.beginPath(); for (let i = 0; i < 18; i++) { const an = (i / 18) * Math.PI * 2, rr = i % 2 ? 40 : 54; g.lineTo(Math.cos(an) * rr, Math.sin(an) * rr * 0.85); } g.closePath();
  g.fillStyle = u > 0.7 && Math.floor(G.rt * 16) % 2 ? '#fff' : '#d6303a'; g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
  text(g, '!', 0, 21, { font: FONT.dela, size: 58, color: u > 0.7 && Math.floor(G.rt * 16) % 2 ? '#d6303a' : '#fff', align: 'center' });
  g.restore();
  g.save(); g.lineWidth = 6; g.strokeStyle = `rgba(214,48,58,${0.5 + 0.5 * u})`; g.setLineDash([14, 8]); g.lineDashOffset = -G.rt * 60; g.beginPath(); g.arc(x, y, ringR, 0, 7); g.stroke(); g.restore();
  g.save(); g.lineWidth = 3; g.strokeStyle = C.ink; g.beginPath(); g.arc(x, y, r + 16, 0, 7); g.stroke(); g.restore();
}
function drawKunai(g) {
  for (const k of G.kunai) {
    const age = G.gt - k.t0, u = clamp(age / k.dur);
    let x = lerp(k.fx, k.tx, u), y = lerp(k.fy, k.ty, u) - Math.sin(u * Math.PI) * 40;
    if (k.done && k.hitId) { const e = G.enemies.find((q) => q.id === k.hitId); if (!e) continue; [x, y] = epos(e); x += 12; y -= 6; }
    const ang = Math.atan2(k.ty - k.fy, k.tx - k.fx); const kh = 86, kw = kh * ART.kunai.width / ART.kunai.height;
    g.save(); if (k.done) g.globalAlpha = 1 - clamp((age - k.dur) / (k.stuck ? 1.1 : 0.4));
    g.translate(x, y); g.rotate(ang + Math.PI / 2); g.drawImage(ART.kunai, -kw / 2, -kh * 0.2, kw, kh); g.restore();
    if (u < 1) { g.save(); g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = 3; g.beginPath(); g.moveTo(lerp(k.fx, k.tx, Math.max(0, u - 0.4)), lerp(k.fy, k.ty, Math.max(0, u - 0.4))); g.lineTo(x, y); g.stroke(); g.restore(); }
  }
}
function drawStrokes(g) {
  for (const s of G.strokes) {
    const pts = s.pts.filter((p) => G.gt - p.t < 0.32); if (pts.length < 2) continue;
    const fade = s.end == null ? 1 : 1 - clamp((G.gt - s.end) / 0.4);
    for (const off of [-22, 0, 22]) for (const pass of [0, 1, 2]) {
      g.save(); g.globalAlpha = fade; g.lineCap = 'round'; g.lineJoin = 'round';
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], b = pts[i]; const dx = b.x - a.x, dy = b.y - a.y, L = Math.hypot(dx, dy) || 1; const nx = -dy / L * off, ny = dx / L * off;
        const life = 1 - clamp((G.gt - b.t) / 0.32); const w = (pass === 0 ? 20 : pass === 1 ? 12 : 4) * life;
        if (w < 0.5) continue; g.lineWidth = w; g.strokeStyle = pass === 0 ? C.ink : pass === 1 ? C.coral : '#fff';
        g.beginPath(); g.moveTo(a.x + nx, a.y + ny); g.lineTo(b.x + nx, b.y + ny); g.stroke();
      }
      g.restore();
    }
  }
}
function drawBig(g) {
  for (const b of G.big) {
    const age = G.gt - b.t0;
    if (b.type === 'claw') { b.lines.forEach((ln, i) => drawClaws(g, { t: b.t0 + i * 0.06, d: 0.16, a: ln.a, b: ln.b }, G.gt, 2.4)); if (age < 0.25) { const [x0, y0, x1, y1] = currentBox(); const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; const R = lerp(20, 520, eOut(age / 0.25)); g.save(); g.globalAlpha = 1 - age / 0.25; const gr = g.createRadialGradient(cx, cy, 10, cx, cy, R); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(244,87,94,0)'); g.fillStyle = gr; g.beginPath(); g.arc(cx, cy, R, 0, 7); g.fill(); g.restore(); } }
    if (b.type === 'phase') {
      const u = eIO(clamp(age / 0.45)); const x = lerp(b.a[0], b.b[0], u), y = lerp(b.a[1], b.b[1], u);
      for (let k = 0; k < 16; k++) { const uu = u - k * 0.03; if (uu < 0) break; g.fillStyle = `rgba(242,180,60,${0.5 * (1 - k / 16)})`; g.beginPath(); g.arc(lerp(b.a[0], b.b[0], uu), lerp(b.a[1], b.b[1], uu), 46, 0, 7); g.fill(); }
      if (age < 0.6) drawNero(g, { id: 77, x, y, vx: 1, vy: -0.2, r: 54 * (1 - inv(0.45, 0.6, age)) }, G.rt, 1);
    }
  }
}
function drawNeroLive(g) {
  const n = G.nero; if (!n.active) return;
  for (let k = 0; k < 8; k++) { g.fillStyle = `rgba(242,180,60,${0.35 * (1 - k / 8)})`; g.beginPath(); g.arc(n.x - n.vx * k * 0.012, n.y - n.vy * k * 0.012, 40 * (1 - k / 10), 0, 7); g.fill(); }
  drawNero(g, { id: 99, x: n.x, y: n.y, vx: Math.abs(n.vx) > 5 ? n.vx : -1, vy: n.vy, r: 46 * eBack(clamp((G.gt - n.appearT) / 0.2)) }, G.rt, 1);
}
function drawFX(g) {
  for (const f of G.fx) {
    const age = G.gt - f.t0;
    if (f.type === 'sfx') sfx(g, f.s, f.x, f.y, f.size, age * 60, { life: f.life * 60, rot: f.rot, color: f.color, outer: f.outer });
    else if (f.type === 'num') text(g, String(f.v), f.x, f.y - age * 80, { font: FONT.dela, size: f.size, color: f.color, align: 'center', stroke: 9, strokeColor: C.ink, alpha: 1 - inv(0.5, 0.85, age) });
    else if (f.type === 'label') { const k = age < 0.12 ? lerp(1.4, 1, age / 0.12) : 1; g.save(); g.translate(f.x, f.y); g.scale(k, k); text(g, f.s, 0, 0, { font: FONT.dela, size: f.size, color: f.color, align: 'center', stroke: 11, strokeColor: C.ink, alpha: 1 - inv(0.9, 1.3, age) }); g.restore(); }
    else if (f.type === 'burst') { if (age > 0.6) continue; for (let i = 0; i < f.n; i++) { const an = hash(f.seed + i) * 7, sp = (60 + 160 * hash(i * 2 + f.seed)) * eOut(age / 0.5) * f.big; g.fillStyle = i % 4 === 0 ? C.coral : C.ink; g.globalAlpha = 1 - inv(0.3, 0.6, age); g.beginPath(); g.arc(f.x + Math.cos(an) * sp, f.y + Math.sin(an) * sp, Math.max(0.5, (5 + 9 * hash(i + f.seed)) * (1 - age)), 0, 7); g.fill(); g.globalAlpha = 1; } }
    else if (f.type === 'pop') { if (age > 0.7) continue; const R = lerp(30, 150, eOut(age / 0.35)); g.save(); g.globalAlpha = 1 - inv(0.25, 0.7, age); const gr = g.createRadialGradient(f.x - R * 0.3, f.y - R * 0.3, R * 0.1, f.x, f.y, R); gr.addColorStop(0, 'rgba(255,220,236,0.85)'); gr.addColorStop(0.7, 'rgba(239,155,204,0.6)'); gr.addColorStop(1, 'rgba(214,96,150,0.7)'); g.fillStyle = gr; g.beginPath(); g.arc(f.x, f.y, R, 0, 7); g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke(); g.restore(); }
    else if (f.type === 'tap') { if (age > 0.3) continue; g.save(); g.strokeStyle = `rgba(255,255,255,${1 - age / 0.3})`; g.lineWidth = 4; g.beginPath(); g.arc(f.x, f.y, 14 + age * 160, 0, 7); g.stroke(); g.restore(); }
  }
}
function drawPromptBubble(g) {
  const p = G.prompt; if (!p) return;
  const a = inv(p.t0, p.t0 + 0.12, G.rt) * (1 - inv(p.t1 - 0.2, p.t1, G.rt)); if (a <= 0) return;
  const [x, y] = p.at; const k = eBack(inv(p.t0, p.t0 + 0.2, G.rt));
  g.save(); g.translate(x, y); g.scale(k, k); g.globalAlpha = a;
  g.font = `30px ${FONT.dela}`; const w = g.measureText(p.text).width + 54, h = 64;
  g.beginPath(); g.ellipse(0, 0, w / 2 + 10, h / 2 + 8, 0, 0, 7); g.moveTo(-20, h / 2); g.lineTo(-44, h / 2 + 36); g.lineTo(6, h / 2 + 4); g.closePath();
  g.fillStyle = '#fff'; g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
  text(g, p.text, 0, 11, { font: FONT.dela, size: 30, color: C.ink, align: 'center' }); g.restore();
}
const heroArt = (h) => (h === 'shojo' ? ART.heroShojo : h === 'nero' ? ART.heroNero : ART.heroShonen);
function drawInset(g, poly, h, live) {
  const [x0, y0, x1, y1] = bboxOf(poly);
  const sw = live ? G.rt - G.heroSwapT : 9; const flip = sw < 0.25 ? Math.abs(Math.cos((sw / 0.25) * Math.PI)) : 1;
  g.save(); polyPath(g, poly); g.lineWidth = 16; g.strokeStyle = '#fff'; g.stroke();
  g.save(); polyPath(g, poly); g.clip();
  g.fillStyle = h === 'shojo' ? C.navy : h === 'nero' ? C.coral : '#2a2030'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  const cx = (x0 + x1) / 2; g.translate(cx, 0); g.scale(flip, 1); g.translate(-cx, 0);
  cover(g, heroArt(h), x0, y0, x1, y1, 1.02);
  g.restore(); polyPath(g, poly); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke(); g.restore();
}
function drawBoss(g) {
  const b = G.boss; const u = eOut(inv(b.riseT, b.riseT + 1.2, G.gt)); const vt = G.rt;
  const R = b.R * lerp(0.55, 1, u) * (1 + 0.02 * Math.sin(vt * 2.2)); const x = b.x, y = b.y + (1 - u) * 300;
  g.save(); polyPath(g, PM.P7.poly); g.clip();
  [[182, 2537], [587, 3052], [60, 2800], [720, 2700], [380, 2420], [690, 3150], [110, 3100]].forEach(([tx, ty], i) => {
    const w = Math.sin(vt * 2 + i) * 40;
    g.beginPath(); g.moveTo(x, y); g.bezierCurveTo(x + (tx - x) * 0.3 + w, y + (ty - y) * 0.1 - w, x + (tx - x) * 0.7 - w, y + (ty - y) * 0.8 + w, lerp(x, tx, u), lerp(y, ty, u));
    g.lineCap = 'round'; g.lineWidth = 30; g.strokeStyle = C.ink; g.stroke(); g.lineWidth = 12; g.strokeStyle = '#5a1624'; g.stroke(); g.lineWidth = 4; g.strokeStyle = C.coral; g.stroke();
  });
  for (let pass = 0; pass < 2; pass++) for (let i = 0; i < 13; i++) {
    const an = -Math.PI / 2 + (i - 6) * 0.22 + Math.sin(vt * 2 + i) * 0.05, L = R * (0.45 + 0.4 * noise1(vt * 3 + i));
    const b0 = [x + Math.cos(an - 0.1) * R * 0.9, y + Math.sin(an - 0.1) * R * 0.9], b1 = [x + Math.cos(an + 0.1) * R * 0.9, y + Math.sin(an + 0.1) * R * 0.9], tip = [x + Math.cos(an) * (R + L), y + Math.sin(an) * (R + L) - 20];
    g.beginPath(); g.moveTo(...b0); g.quadraticCurveTo(x + Math.cos(an - 0.15) * (R + L * 0.6), y + Math.sin(an - 0.15) * (R + L * 0.6), ...tip); g.quadraticCurveTo(x + Math.cos(an + 0.15) * (R + L * 0.4), y + Math.sin(an + 0.15) * (R + L * 0.4), ...b1); g.closePath();
    if (pass === 0) { g.lineWidth = 8; g.strokeStyle = C.ink; g.stroke(); } else { g.fillStyle = i % 3 ? C.coral : '#ff9a8f'; g.fill(); }
  }
  g.beginPath(); for (let i = 0; i <= 40; i++) { const th = (i / 40) * Math.PI * 2, rr = R * (1 + 0.06 * Math.sin(th * 4 + vt * 3) + 0.04 * Math.sin(th * 7 - vt * 2)); i ? g.lineTo(x + Math.cos(th) * rr, y + Math.sin(th) * rr) : g.moveTo(x + Math.cos(th) * rr, y + Math.sin(th) * rr); }
  g.closePath(); const gr = g.createRadialGradient(x - R * 0.3, y - R * 0.4, R * 0.1, x, y, R); gr.addColorStop(0, '#4a2238'); gr.addColorStop(0.6, '#1c0f18'); gr.addColorStop(1, '#0b070a');
  g.fillStyle = gr; g.fill(); g.lineWidth = 8; g.strokeStyle = C.ink; g.stroke();
  const look = Math.atan2(3080 - y, 150 - x);
  [[0, -20, 58], [-92, -70, 32], [96, -82, 36], [-120, 40, 24], [128, 30, 26]].forEach(([ex, ey, er], i) => {
    const blink = b.stun > 0 ? 0.15 : (Math.sin(vt * 1.3 + i * 2) > 0.985 ? 0.15 : 1);
    g.save(); g.translate(x + ex * R / 200, y + ey * R / 200); const rr = er * R / 200;
    g.beginPath(); g.moveTo(-rr, 0); g.quadraticCurveTo(0, -rr * 0.75 * blink, rr, 0); g.quadraticCurveTo(0, rr * 0.6 * blink, -rr, 0); g.closePath();
    g.fillStyle = C.gold; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
    g.fillStyle = C.ink; g.beginPath(); g.ellipse(Math.cos(look) * rr * 0.25, Math.sin(look) * rr * 0.1, rr * 0.12, rr * 0.5 * blink, 0, 0, 7); g.fill();
    g.restore();
  });
  g.save(); g.translate(x, y + R * 0.45); g.beginPath(); g.moveTo(-R * 0.45, 0); for (let i = 0; i <= 12; i++) g.lineTo(-R * 0.45 + i * R * 0.075, i % 2 ? R * 0.14 : 0); g.lineTo(R * 0.45, 0); g.quadraticCurveTo(0, R * 0.32, -R * 0.45, 0); g.closePath();
  g.fillStyle = '#5a1624'; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke(); g.restore();
  for (let i = 0; i < 4; i++) { const an = vt * 0.7 + i * 1.57; g.save(); g.translate(x + Math.cos(an) * R * 1.35, y + Math.sin(an) * R * 0.95); g.rotate(an * 0.3); g.fillStyle = '#060406'; g.fillRect(-70, -13, 140, 26); g.strokeStyle = '#fff'; g.lineWidth = 2; g.strokeRect(-70, -13, 140, 26); g.restore(); }
  if (G.gt - b.flashT < 0.07) { g.fillStyle = 'rgba(255,255,255,0.5)'; g.beginPath(); g.arc(x, y, R * 1.05, 0, 7); g.fill(); }
  if (b.stun > 0) for (let i = 0; i < 4; i++) { const an = vt * 4 + i * 1.6; star4(g, x + Math.cos(an) * R * 0.7, y - R * 1.05 + Math.sin(an) * 14, 16, C.gold); }
  g.restore();
}
function drawEye(g, eye) {
  const b = G.boss; const a = eBack(inv(b.riseT + 0.5, b.riseT + 0.8, G.gt)); if (a <= 0) return;
  const [x0, y0, x1, y1] = bboxOf(eye.poly); const [cx, cy] = eye.c;
  g.save(); g.translate(cx, cy); g.scale(a, a); g.translate(-cx, -cy);
  polyPath(g, eye.poly); g.lineWidth = 16; g.strokeStyle = eye.state === 'open' ? C.gold : '#fff'; g.stroke();
  g.save(); polyPath(g, eye.poly); g.clip(); g.fillStyle = '#12070c'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  for (let i = 0; i < 8; i++) { g.strokeStyle = 'rgba(214,48,58,0.6)'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(i) * 200, cy + Math.sin(i * 1.3) * 120); g.stroke(); }
  const rr = 82, open = eye.state === 'broken' ? 0.12 : Math.max(0.08, eye.open);
  g.save(); g.translate(cx, cy);
  g.beginPath(); g.moveTo(-rr, 0); g.quadraticCurveTo(0, -rr * 0.8 * open, rr, 0); g.quadraticCurveTo(0, rr * 0.65 * open, -rr, 0); g.closePath();
  g.fillStyle = C.gold; g.fill(); g.lineWidth = 6; g.strokeStyle = C.ink; g.stroke();
  if (open < 0.3 && eye.state !== 'broken') { g.strokeStyle = C.gold; g.lineWidth = 9; g.lineCap = 'round'; g.beginPath(); g.moveTo(-rr, 0); g.quadraticCurveTo(0, 26, rr, 0); g.stroke(); g.lineWidth = 5; for (let i = -3; i <= 3; i++) { const lx = i * 22, ly = 13 - Math.abs(i) * 2.2; g.beginPath(); g.moveTo(lx, ly); g.lineTo(lx * 1.15, ly + 20); g.stroke(); } }
  if (eye.state === 'broken') { g.strokeStyle = C.coral; g.lineWidth = 7; g.beginPath(); g.moveTo(-60, -40); g.lineTo(60, 40); g.moveTo(60, -40); g.lineTo(-60, 40); g.stroke(); }
  else if (open > 0.3) { g.fillStyle = C.ink; g.beginPath(); g.ellipse(Math.sin(G.rt * 2) * 10, 0, 10, rr * 0.5 * open, 0, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(-22, -16 * open, 9, 0, 7); g.fill(); }
  g.restore(); g.restore();
  if (eye.state === 'open') { g.save(); g.lineWidth = 5; g.strokeStyle = `rgba(242,180,60,${0.5 + 0.5 * Math.sin(G.rt * 10)})`; g.setLineDash([10, 8]); g.beginPath(); g.arc(cx, cy, 104 + 6 * Math.sin(G.rt * 8), 0, 7); g.stroke(); g.restore(); text(g, 'WEAK POINT', cx, y0 - 14, { font: FONT.mono, size: 18, color: '#fff', align: 'center', ls: 2, stroke: 6, strokeColor: C.ink }); }
  polyPath(g, eye.poly); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
  g.restore();
}

// ---------------- drawing: HUD ----------------
function drawHUD(g) {
  const lw = 220, lh = lw * IMG.logoL.height / IMG.logoL.width;
  g.drawImage(IMG.logoL, 50, 60, lw, lh);
  text(g, 'CHAPTER BREAK', 54, 60 + lh + 40, { font: FONT.dela, size: 30, color: C.coral, ls: 2 });
  text(g, 'KUROKAWA · CHAPTER 01', 56, 60 + lh + 72, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
  text(g, 'COMBO', 1026, 92, { font: FONT.mono, size: 18, color: '#bdb6c4', ls: 3, align: 'right' });
  const pk = G.rt - G.lastHitRT < 0.12 ? lerp(1.25, 1, (G.rt - G.lastHitRT) / 0.12) : 1;
  g.save(); g.translate(1030, 186); g.scale(pk, pk); text(g, String(G.combo).padStart(2, '0'), 0, 0, { font: FONT.dela, size: 92, color: G.combo >= 10 ? C.coral : C.paper, align: 'right' }); g.restore();
  text(g, G.score.toLocaleString('en-US'), 1026, 236, { font: FONT.dela, size: 32, color: C.paper, align: 'right' });
  for (let i = 0; i < G.maxHp; i++) { const lost = i >= G.hp; const jl = lost && i === G.hp && G.rt - G.hurtT < 0.4; drawDrop(g, 74 + i * 50, 300, 16, lost, jl ? (G.rt - G.hurtT) / 0.4 : 1); }
  text(g, 'RESONANCE', 340, 288, { font: FONT.mono, size: 15, color: '#bdb6c4', ls: 3 });
  text(g, `${Math.floor(G.res)}`, 1020, 288, { font: FONT.dela, size: 18, color: G.res >= 100 ? C.coral : '#fff', align: 'right' });
  drawMeter(g, 340, 298, 680, 18, G.res / 100, G.rt);
  for (const c of [40, 50, 60]) { g.fillStyle = 'rgba(255,255,255,0.55)'; g.fillRect(340 + 680 * c / 100 - 1, 294, 2, 26); }
  // boss bar
  const b = G.boss;
  if (b && (b.alive || G.mode === 'splash') && STAGES[G.stage].id === 'boss') {
    const a = inv(b.riseT + 0.4, b.riseT + 0.8, G.gt), hp = clamp(b.hp / b.max), x = WIN.x + 40, w = WIN.w - 80, y = WIN.y + 34;
    g.save(); g.globalAlpha = a;
    text(g, 'THE REDACTOR', x, y + 4, { font: FONT.dela, size: 34, color: '#fff', stroke: 9, strokeColor: C.ink });
    text(g, b.finisher ? 'FINISH IT!' : 'BOSS · RIFT ANOMALY', x + w, y + 2, { font: FONT.mono, size: 18, color: b.finisher ? C.gold : '#fff', align: 'right', ls: 2, stroke: 6, strokeColor: C.ink });
    rrect(g, x, y + 16, w, 22, 6); g.fillStyle = 'rgba(10,6,10,0.85)'; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
    g.save(); rrect(g, x + 3, y + 19, (w - 6) * hp, 16, 4); g.clip(); const gr = g.createLinearGradient(x, 0, x + w, 0); gr.addColorStop(0, '#8e1f3a'); gr.addColorStop(1, b.finisher ? C.gold : C.coral); g.fillStyle = gr; g.fillRect(x, y + 16, w, 22); g.restore();
    g.restore();
  }
  // team
  text(g, 'TEAM · TAP TO TAG', 46, 1690, { font: FONT.mono, size: 15, color: '#8b8291', ls: 2 });
  text(g, 'HAND · DRAG TO CAST', 618, 1690, { font: FONT.mono, size: 15, color: '#8b8291', ls: 2 });
  const needHero = STAGES[G.stage].id === 'lock' && G.st !== 'clear' ? 'nero' : (G.parryTut ? 'shojo' : null);
  HEROES.forEach((h, i) => {
    const sl = teamSlot(i), on = h === G.hero, sw = G.rt - G.heroSwapT;
    const k = on ? 1 + 0.06 * eOut(clamp(sw / 0.2)) : 0.94;
    if (needHero === h && !on) glow(g, sl, C.gold);
    g.save(); g.translate(sl.x, sl.y); g.scale(k, k); if (on) { g.shadowColor = C.coral; g.shadowBlur = 30; } g.globalAlpha *= on ? 1 : 0.6;
    drawCardFront(g, -sl.w / 2, -sl.h / 2, sl.w, sl.h, { art: heroArt(h), frame: h === 'nero' ? 'purple' : 'coral' }); g.restore();
    text(g, `${i + 1} · ${HERO_INFO[h][1]}`, sl.x, sl.y + sl.h / 2 + 30, { font: FONT.mono, size: 16, color: on ? C.coral : '#8b8291', align: 'center', ls: 2 });
    if (h === 'nero') { const e = G.nero.energy / 100; rrect(g, sl.x - 46, sl.y + sl.h / 2 - 20, 92, 8, 4); g.fillStyle = 'rgba(0,0,0,0.6)'; g.fill(); rrect(g, sl.x - 46, sl.y + sl.h / 2 - 20, 92 * e, 8, 4); g.fillStyle = C.gold; g.fill(); }
  });
  // hand
  for (let i = 0; i < 3; i++) {
    const c = G.hand[i], sl = handSlot(i);
    if (!c) { rrect(g, sl.x - sl.w / 2, sl.y - sl.h / 2, sl.w, sl.h, 10); g.setLineDash([8, 8]); g.lineWidth = 2; g.strokeStyle = '#4a3f52'; g.stroke(); g.setLineDash([]); const r = G.refill.find((q) => q.slot === i); if (r) text(g, 'DRAWING…', sl.x, sl.y + 6, { font: FONT.mono, size: 14, color: '#8b8291', align: 'center' }); continue; }
    if (G.drag && G.drag.slot === i) continue;
    const d = CARD[c.kind], ok = G.res >= d.cost;
    if (ok && (c.kind === 'splash' || (STAGES[G.stage].id === 'p6' && !G.hints.card))) glow(g, sl, c.kind === 'splash' ? C.gold : C.coral);
    g.save(); g.translate(sl.x, sl.y); g.rotate((i - 1) * 0.05); g.globalAlpha *= ok ? 1 : 0.45;
    drawCardFront(g, -sl.w / 2, -sl.h / 2, sl.w, sl.h, { art: ART[d.art], frame: d.frame, holo: G.rt * 0.3 + i * 0.2 }); g.restore();
    g.beginPath(); g.arc(sl.x + sl.w / 2 - 8, sl.y - sl.h / 2 + 8, 22, 0, 7); g.fillStyle = ok ? C.ink : '#3a2f40'; g.fill(); g.lineWidth = 3; g.strokeStyle = ok ? '#fff' : '#6d6274'; g.stroke();
    text(g, d.cost ? String(d.cost) : '★', sl.x + sl.w / 2 - 8, sl.y - sl.h / 2 + 16, { font: FONT.dela, size: 18, color: '#fff', align: 'center' });
    text(g, d.short, sl.x, sl.y + sl.h / 2 + 30, { font: FONT.mono, size: 16, color: ok ? '#fff' : '#8b8291', align: 'center', ls: 2 });
  }
  if (G.drag) {
    const c = G.hand[G.drag.slot]; if (c) { const d = CARD[c.kind], sl = handSlot(0), k = 1.25;
      if (inWin(G.drag.x, G.drag.y)) { g.save(); g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = 6; g.setLineDash([16, 10]); g.strokeRect(WIN.x + 10, WIN.y + 10, WIN.w - 20, WIN.h - 20); g.restore(); }
      g.save(); g.translate(G.drag.x, G.drag.y - 30); g.rotate(-0.08); drawCardFront(g, -sl.w * k / 2, -sl.h * k / 2, sl.w * k, sl.h * k, { art: ART[d.art], frame: d.frame, holo: G.rt * 0.6, title: d.title }); g.restore(); }
  }
}
function glow(g, sl, col) { g.save(); g.shadowColor = col; g.shadowBlur = 30 + 14 * Math.sin(G.rt * 7); rrect(g, sl.x - sl.w / 2 - 6, sl.y - sl.h / 2 - 6, sl.w + 12, sl.h + 12, 14); g.lineWidth = 6; g.strokeStyle = col; g.stroke(); g.restore(); }
function drawCaption(g) {
  const c = G.caption; if (!c) return;
  const u = inv(c.t0, c.t0 + 0.25, G.rt) * (1 - inv(c.t1 - 0.3, c.t1, G.rt)); if (u <= 0) return;
  g.save(); g.globalAlpha = u; g.translate(0, (1 - eOut(u)) * 20);
  text(g, c.big, W / 2, 1584, { font: FONT.dela, size: 46, color: '#fff', align: 'center', stroke: 12, strokeColor: C.ink });
  if (c.small) text(g, c.small, W / 2, 1626, { font: FONT.mono, size: 22, color: '#efe8f2', align: 'center', ls: 0.5, stroke: 7, strokeColor: C.ink });
  g.restore();
}
function drawToast(g) {
  const t = G.toast; if (!t) return; const age = G.rt - t.t0; if (age > 1.4) return;
  const a = inv(0, 0.1, age) * (1 - inv(1.1, 1.4, age));
  g.save(); g.globalAlpha = a; g.font = `26px ${FONT.dela}`; const w = g.measureText(t.text).width + 60;
  rrect(g, W / 2 - w / 2, 420, w, 60, 30); g.fillStyle = 'rgba(11,9,12,0.9)'; g.fill(); g.lineWidth = 3; g.strokeStyle = C.coral; g.stroke();
  text(g, t.text, W / 2, 460, { font: FONT.dela, size: 26, color: '#fff', align: 'center' }); g.restore();
}
function drawHurt(g) {
  const age = G.rt - G.hurtT; if (age > 0.6) return; const a = 1 - age / 0.6;
  g.save(); const vg = g.createRadialGradient(W / 2, H / 2, 300, W / 2, H / 2, 1100); vg.addColorStop(0, 'rgba(214,48,58,0)'); vg.addColorStop(1, `rgba(214,48,58,${0.6 * a})`); g.fillStyle = vg; g.fillRect(0, 0, W, H);
  g.globalAlpha = a; g.strokeStyle = C.ink; g.lineCap = 'round';
  for (let i = 0; i < 3; i++) { g.lineWidth = 26 - i * 6; g.beginPath(); g.moveTo(WIN.x + 100 + i * 60, WIN.y + 300 + i * 40); g.lineTo(WIN.x + WIN.w - 140 + i * 30, WIN.y + 700 + i * 50); g.stroke(); }
  g.restore();
}

// ---------------- scenes ----------------
function drawGameScene(g) {
  drawBackdrop(g, G.rt);
  g.save(); g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 50; g.shadowOffsetY = 18; g.fillStyle = C.paper; g.fillRect(WIN.x, WIN.y, WIN.w, WIN.h); g.restore();
  g.save(); g.beginPath(); g.rect(WIN.x, WIN.y, WIN.w, WIN.h); g.clip();
  const c = G.cam; g.translate(WIN.x + WIN.w / 2 + G.shx, WIN.y + WIN.h / 2 + G.shy); g.scale(c.z * WIN.s, c.z * WIN.s); g.translate(-c.cx, -c.cy);
  drawWorld(g); g.restore();
  drawHUD(g); drawCaption(g); drawToast(g); drawHurt(g);
  if (G.rt - G.invertT < 0.04) invertCanvas(g);
  if (G.cutin) drawCutIn(g, clamp((G.rt - G.cutin.t0) / 0.8), G.cutin.kind);
}
function drawTitle(g) {
  const u = G.modeT;
  drawRedHalftone(g, G.rt, 0.3);
  const lw = 820, lh = lw * IMG.logoL.height / IMG.logoL.width, k = lerp(1.15, 1, eOut(inv(0, 0.6, u)));
  g.save(); g.translate(W / 2, 420); g.scale(k, k); g.globalAlpha = inv(0, 0.3, u); g.drawImage(IMG.logoL, -lw / 2, -lh / 2, lw, lh); g.restore();
  g.save(); g.globalAlpha = inv(0.3, 0.6, u); sfxText(g, 'CHAPTER  BREAK', W / 2, 420 + lh / 2 + 90, 74, 4); g.restore();
  text(g, 'SWIPE. TAP. DRAG. BREAK THE PAGE.', W / 2, 420 + lh / 2 + 190, { font: FONT.disp, weight: 600, size: 40, color: '#fff', align: 'center', alpha: inv(0.5, 0.8, u) });
  text(g, 'The rift is rewriting Zenko’s manga. Fight down the chapter', W / 2, 420 + lh / 2 + 250, { font: FONT.disp, weight: 500, size: 30, color: '#f2d6d4', align: 'center', alpha: inv(0.6, 0.9, u) });
  text(g, 'panel by panel and restore every page.', W / 2, 420 + lh / 2 + 292, { font: FONT.disp, weight: 500, size: 30, color: '#f2d6d4', align: 'center', alpha: inv(0.6, 0.9, u) });
  HEROES.forEach((h, i) => {
    const a = eBack(inv(0.6 + i * 0.12, 1.0 + i * 0.12, u)); if (a <= 0) return;
    const x = W / 2 + (i - 1) * 300, y = 1260 + Math.abs(i - 1) * 20, w = 230, hh = 322;
    g.save(); g.translate(x, y + (1 - a) * 200); g.rotate((i - 1) * 0.08); drawCardFront(g, -w / 2, -hh / 2, w, hh, { art: heroArt(h), frame: h === 'nero' ? 'purple' : 'coral', title: HERO_INFO[h][0], sub: ['VANGUARD', 'CATALYST', 'ANOMALY'][i], holo: G.rt * 0.3 + i * 0.3 }); g.restore();
    text(g, ['SWIPE TO SLASH', 'TAP · PARRY', 'HOLD & DRAG'][i], x, y + hh / 2 + 56, { font: FONT.mono, size: 22, color: '#fff', align: 'center', ls: 2, alpha: a });
  });
  const pulse = 0.55 + 0.45 * Math.sin(G.rt * 4);
  g.save(); g.globalAlpha = inv(1.2, 1.5, u) * pulse; sfxText(g, 'TAP TO START', W / 2, 1650, 56, 3); g.restore();
  g.save(); g.globalAlpha = inv(1.2, 1.5, u);
  text(g, 'A GAME CONCEPT BY', W / 2, 1770, { font: FONT.mono, size: 18, color: '#d9c2c4', align: 'center', ls: 5 });
  const ew = 230, eh = ew * IMG.encWord.height / IMG.encWord.width; g.drawImage(IMG.encWord, W / 2 - ew / 2, 1790, ew, eh);
  text(g, 'Unofficial concept · not affiliated with or endorsed by Zenko', W / 2, 1890, { font: FONT.ui, size: 18, color: '#b49ea2', align: 'center' });
  g.restore();
}
function drawOver(g) {
  drawGameScene(g);
  const a = inv(0, 0.3, G.modeT);
  g.save(); g.globalAlpha = a * 0.82; g.fillStyle = '#0b080d'; g.fillRect(0, 0, W, H); g.restore();
  g.save(); g.globalAlpha = a;
  sfxText(g, 'THE INK RAN DRY.', W / 2, 860, 76, 2);
  text(g, 'The rift redacted this panel.', W / 2, 960, { font: FONT.disp, weight: 500, size: 34, color: '#fff', align: 'center' });
  drawButtons(g);
  g.restore();
}
function drawButtons(g) {
  for (const bt of buttonsFor(G.mode)) {
    rrect(g, bt.x - bt.w / 2, bt.y - bt.h / 2, bt.w, bt.h, bt.h / 2); g.fillStyle = bt.light ? '#fff' : C.coral; g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
    text(g, bt.label, bt.x, bt.y + 13, { font: FONT.dela, size: 34, color: bt.light ? '#111' : '#fff', align: 'center' });
  }
}
function drawSplashScene(g) {
  drawGameScene(g);
  const age = G.modeT;
  const [px0, py0] = w2s(24, 2374), [px1, py1] = w2s(736, 3180);
  const ex = eOut(inv(0, 0.18, age));
  const rx0 = lerp(px0, 0, ex), ry0 = lerp(py0, 0, ex), rx1 = lerp(px1, W, ex), ry1 = lerp(py1, H, ex);
  g.save(); g.beginPath(); g.rect(rx0, ry0, rx1 - rx0, ry1 - ry0); g.clip();
  g.fillStyle = '#120a0e'; g.fillRect(0, 0, W, H);
  cover(g, ART.splash, rx0, ry0, rx1, ry1, 1.18 - 0.1 * eOut(inv(0, 1.5, age)), 140, 0);
  speedLines(g, (rx0 + rx1) / 2, (ry0 + ry1) / 2, Math.min(W, H) * 0.25, Math.max(W, H), 120, 71, 0.55, C.ink, 1.3);
  speedLines(g, (rx0 + rx1) / 2, (ry0 + ry1) / 2, Math.min(W, H) * 0.3, Math.max(W, H), 60, 72, 0.4, '#fff', 1);
  for (let i = 0; i < 40; i++) { const an = hash(i * 3.3) * 7, sp = (200 + 900 * hash(i * 1.7)) * eOut(age / 1.2); g.fillStyle = i % 5 === 0 ? C.coral : C.ink; g.globalAlpha = 1 - inv(0.8, 1.5, age); g.beginPath(); g.arc(W / 2 + Math.cos(an) * sp, H / 2 + Math.sin(an) * sp * 0.7, Math.max(1, (10 + 26 * hash(i)) * (1 - age * 0.4)), 0, 7); g.fill(); }
  g.globalAlpha = 1; g.lineWidth = 18; g.strokeStyle = C.ink; g.strokeRect(rx0 + 9, ry0 + 9, rx1 - rx0 - 18, ry1 - ry0 - 18); g.lineWidth = 6; g.strokeStyle = '#fff'; g.strokeRect(rx0 + 24, ry0 + 24, rx1 - rx0 - 48, ry1 - ry0 - 48);
  g.restore();
  if (ex >= 1) {
    sfx(g, 'ドンッ!!', W * 0.62, H * 0.2, 150, (age - 0.18) * 60, { life: 200, rot: -0.1, color: C.coral });
    g.save(); g.globalAlpha = inv(0.25, 0.4, age); sfxText(g, 'SPLASH  PAGE', W / 2, H * 0.82, 92, 4); g.restore();
    text(g, 'FINISHER · SHONEN', W / 2, H * 0.82 + 80, { font: FONT.mono, size: 26, color: '#fff', align: 'center', ls: 6, stroke: 8, strokeColor: C.ink, alpha: inv(0.35, 0.5, age) });
  }
  if (age < 0.05) invertCanvas(g);
  if (age > 2.3) { g.fillStyle = `rgba(255,255,255,${inv(2.3, 2.5, age)})`; g.fillRect(0, 0, W, H); }
}
function drawClearedScene(g) {
  G.camT = { cx: 380, cy: 2760, z: 0.98 };
  drawGameScene(g);
  const age = G.modeT; const cx = WIN.x + WIN.w / 2, cy = WIN.y + WIN.h * 0.42;
  if (age < 0.25) { g.fillStyle = `rgba(255,255,255,${1 - age / 0.25})`; g.fillRect(0, 0, W, H); }
  const k = lerp(2.2, 1, eOut(inv(0.3, 0.48, age)));
  g.save(); g.translate(cx, cy); g.rotate(-0.1); g.scale(k, k); g.globalAlpha = inv(0.3, 0.4, age);
  rrect(g, -430, -70, 860, 140, 10); g.fillStyle = 'rgba(255,255,255,0.92)'; g.fill(); g.lineWidth = 10; g.strokeStyle = '#d6303a'; g.stroke();
  text(g, 'CHAPTER CLEARED', 0, 24, { font: FONT.dela, size: 58, color: '#d6303a', align: 'center', ls: 1 }); g.restore();
}
function drawStrip(g, x, y, w, h, scroll) {
  const k = w / 760, worldH = 3194 * k;
  g.save(); g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 40; g.fillStyle = C.paper; g.fillRect(x, y, w, h); g.restore();
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.translate(x, y - scroll * Math.max(0, worldH - h)); g.scale(k, k); drawWorld(g, true); g.restore();
}
function drawResults(g) {
  const u = G.modeT; drawRedHalftone(g, G.rt, 0.42);
  drawStrip(g, 250, 70, 580, 900, eIO(inv(0.3, 5.0, u)));
  const tx = 90, ty = 1110;
  text(g, 'CHAPTER 01', tx, ty, { font: FONT.mono, size: 24, color: '#f2c2bf', ls: 5, alpha: inv(0.1, 0.4, u) });
  text(g, 'CLEARED.', tx - 4, ty + 100, { font: FONT.dela, size: 100, color: '#fff', alpha: inv(0.2, 0.5, u) });
  const stats = [['TIME', fmtTime(G.stats.time || 0)], ['MAX COMBO', String(G.maxCombo)], ['PARRIES', `${G.stats.parries} (${G.stats.perfect} perfect)`], ['ROUTE', G.route || '—'], ['CARDS CAST', String(G.stats.cards)], ['CONTINUES', String(G.stats.continues)]];
  stats.forEach(([l, v], i) => {
    const a = eOut(inv(0.5 + i * 0.1, 0.8 + i * 0.1, u)), col = i % 2, row = Math.floor(i / 2);
    const sx = tx + col * 470, sy = ty + 200 + row * 110;
    g.save(); g.globalAlpha = a; g.translate((1 - a) * 30, 0);
    text(g, l, sx, sy, { font: FONT.mono, size: 18, color: '#d9c2c4', ls: 3 }); text(g, v, sx, sy + 52, { font: FONT.dela, size: v.length > 10 ? 34 : 44, color: '#fff' }); g.restore();
  });
  text(g, 'SCORE', tx, ty + 560, { font: FONT.mono, size: 18, color: '#d9c2c4', ls: 3, alpha: inv(1.1, 1.4, u) });
  text(g, G.score.toLocaleString('en-US'), tx, ty + 630, { font: FONT.dela, size: 72, color: C.gold, alpha: inv(1.1, 1.4, u) });
  if (G.score >= G.best) text(g, 'NEW BEST', tx + 520, ty + 626, { font: FONT.dela, size: 30, color: C.coral, alpha: inv(1.3, 1.5, u) * (0.6 + 0.4 * Math.sin(G.rt * 6)) });
  const rk = lerp(2.2, 1, eOut(inv(1.4, 1.6, u)));
  g.save(); g.translate(900, 1190); g.rotate(0.14); g.scale(rk, rk); g.globalAlpha = inv(1.4, 1.5, u);
  g.beginPath(); g.arc(0, 0, 100, 0, 7); g.fillStyle = '#d6303a'; g.fill(); g.lineWidth = 8; g.strokeStyle = '#fff'; g.stroke();
  text(g, 'RANK', 0, -54, { font: FONT.mono, size: 18, color: '#fff', align: 'center', ls: 4 }); text(g, rankOf(), 0, 46, { font: FONT.dela, size: 120, color: '#fff', align: 'center' }); g.restore();
  g.save(); g.globalAlpha = inv(1.8, 2.1, u) * (0.6 + 0.4 * Math.sin(G.rt * 4)); text(g, 'TAP TO CONTINUE', W / 2, 1880, { font: FONT.mono, size: 22, color: '#fff', align: 'center', ls: 4 }); g.restore();
}
function drawBoard(g) {
  const u = G.modeT; drawBackdrop(g, G.rt, 0.82);
  const pw = 960, ph = 1180, px = (W - pw) / 2, py = 240;
  g.save(); g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 40; rrect(g, px, py, pw, ph, 28); g.fillStyle = C.card; g.fill(); g.shadowColor = 'transparent';
  g.beginPath(); g.moveTo(px + 76, py + 16); g.lineTo(px + pw - 16, py + 16); g.lineTo(px + pw - 16, py + ph - 16); g.lineTo(px + 16, py + ph - 16); g.lineTo(px + 16, py + 76); g.closePath(); g.fillStyle = '#121014'; g.fill(); g.restore();
  text(g, 'WL LEADERBOARD', px + 90, py + 92, { font: FONT.dela, size: 44, color: '#fff' });
  text(g, 'SAMPLE HOLDERS · CHAPTER 01', px + 92, py + 130, { font: FONT.mono, size: 18, color: C.card, ls: 3 });
  const rows = BOARD.map(([nm, s]) => ({ nm, s })); rows.push({ nm: 'you', s: G.score, you: true });
  if (G.best > G.score) rows.push({ nm: 'your best', s: G.best, best: true });
  rows.sort((a, b) => b.s - a.s);
  rows.slice(0, 11).forEach((r, i) => {
    const ry = py + 210 + i * 86; const a = eOut(inv(0.05 + i * 0.05, 0.35 + i * 0.05, u));
    g.save(); g.globalAlpha = a; g.translate((1 - a) * 60, 0);
    if (r.you) { rrect(g, px + 50, ry - 54, pw - 100, 76, 12); g.fillStyle = 'rgba(228,103,98,0.25)'; g.fill(); g.strokeStyle = C.card; g.lineWidth = 3; g.stroke(); }
    text(g, String(i + 1).padStart(2, '0'), px + 80, ry, { font: FONT.dela, size: 36, color: r.you ? C.coral : '#8b8291' });
    text(g, r.you ? 'YOU' : r.nm, px + 170, ry, { font: FONT.mono, size: 30, color: r.you ? '#fff' : r.best ? C.gold : '#d8d2dc' });
    text(g, r.s.toLocaleString('en-US'), px + pw - 80, ry, { font: FONT.dela, size: 34, color: r.you ? '#fff' : '#d8d2dc', align: 'right' });
    g.restore();
  });
  text(g, 'Bots can like a post.', W / 2, py + ph + 110, { font: FONT.disp, weight: 600, size: 54, color: '#fff', align: 'center', alpha: inv(0.8, 1.1, u) });
  text(g, 'They can’t clear a chapter.', W / 2, py + ph + 180, { font: FONT.disp, weight: 600, size: 54, color: C.coral, align: 'center', alpha: inv(1.1, 1.4, u) });
  text(g, 'Concept feature · sample handles · no allocation implied', W / 2, py + ph + 240, { font: FONT.mono, size: 20, color: '#8b8291', align: 'center', alpha: inv(0.8, 1.1, u) });
  g.save(); g.globalAlpha = inv(1.4, 1.7, u) * (0.6 + 0.4 * Math.sin(G.rt * 4)); text(g, 'TAP TO CONTINUE', W / 2, 1880, { font: FONT.mono, size: 22, color: '#fff', align: 'center', ls: 4 }); g.restore();
}
function drawEncore(g) {
  sceneEncore(g, G.modeT, { t0: 0, t1: 1e9 });
  g.save(); g.globalAlpha = inv(1.4, 1.7, G.modeT); drawButtons(g); g.restore();
  if (G.rt - G.copied < 2) text(g, 'Result copied · opening X…', W / 2, 1610, { font: FONT.mono, size: 20, color: '#fff', align: 'center', alpha: 1 - inv(1.5, 2, G.rt - G.copied) });
}

// ---------------- main loop ----------------
function frame(now) {
  const dt = Math.min(0.05, Math.max(0, (now - (G._last || now)) / 1000)); G._last = now;
  update(dt);
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#0b080d'; ctx.fillRect(0, 0, CW, CH);
  if (OX > 2 || OY > 2) { ctx.save(); ctx.globalAlpha = 0.35; cover(ctx, ART.bannerBg, 0, 0, CW, CH, 1.05); ctx.restore(); ctx.fillStyle = 'rgba(11,8,13,0.72)'; ctx.fillRect(0, 0, CW, CH); }
  ctx.setTransform(SC, 0, 0, SC, OX, OY);
  ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, H); ctx.clip();
  if (G.mode === 'title') drawTitle(ctx);
  else if (G.mode === 'play') drawGameScene(ctx);
  else if (G.mode === 'over') drawOver(ctx);
  else if (G.mode === 'splash') drawSplashScene(ctx);
  else if (G.mode === 'cleared') drawClearedScene(ctx);
  else if (G.mode === 'results') drawResults(ctx);
  else if (G.mode === 'board') drawBoard(ctx);
  else if (G.mode === 'encore') drawEncore(ctx);
  ctx.restore();
  requestAnimationFrame(frame);
}
function loadingScreen(msg) {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#0b080d'; ctx.fillRect(0, 0, CW, CH);
  ctx.fillStyle = '#F4575E'; ctx.font = `${Math.round(28 * DPR)}px sans-serif`; ctx.textAlign = 'center'; ctx.fillText(msg, CW / 2, CH / 2);
}
async function boot() {
  loadingScreen('LOADING ZENKO: CHAPTER BREAK…');
  await Promise.all(Object.entries(ASSETS).map(([k, src]) => new Promise((res, rej) => { const im = new Image(); im.onload = () => { IMG[k] = im; res(); }; im.onerror = () => rej(new Error('asset ' + k)); im.src = src; })));
  ART.bannerBg = IMG.bannerBg; ART.neroHead = IMG.neroHead; ART.kunai = IMG.kunai;
  for (const k of ['heroShonen', 'heroShojo', 'heroNero', 'cutShonen', 'cutShojo', 'cutNero', 'cardClaw', 'cardKunai', 'splash', 'p7']) ART[k] = IMG[k];
  ART.halftone = makeHalftone(); ART.grain = makeGrain(); ART.shards = makeShards();
  ART.clean = { P1: IMG.p1, P2: IMG.p2, P3: IMG.p3, P4: IMG.cutNero, P5a: IMG.p5a, P5b: IMG.p5b, P6: IMG.p6, P7: IMG.p7 };
  ART.corrupt = {}; for (const [k, im] of Object.entries(ART.clean)) ART.corrupt[k] = corrupt(im, k.length * 7 + k.charCodeAt(1));
  try { await Promise.all([document.fonts.load(`40px ${FONT.dela}`, 'ザシュッバキッドンパリンポゴ封 CHAPTER BREAK 0123456789'), document.fonts.load(`600 40px ${FONT.disp}`, 'Aa'), document.fonts.load(`500 40px ${FONT.disp}`, 'Aa'), document.fonts.load(`700 40px ${FONT.ui}`, 'Aa'), document.fonts.load(`40px ${FONT.mono}`, 'Aa')]); } catch (e) { /* fall back to system fonts */ }
  newGame(); G.mode = 'title'; G.modeT = 0;
  window.__G = () => G; window.__w2s = w2s; window.__slots = { teamSlot, handSlot, WIN };
  window.ready = true;
  requestAnimationFrame(frame);
}
boot().catch((e) => { window.initError = String(e && e.stack || e); loadingScreen('Could not load the game: ' + e.message); });
