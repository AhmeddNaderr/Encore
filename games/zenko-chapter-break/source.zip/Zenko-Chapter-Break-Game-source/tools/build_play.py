"""Build the playable ZENKO: CHAPTER BREAK as one self-contained HTML file.

python build_play.py <scratch_root> <out.html>
- crops + compresses the official Zenko art into data URIs
- embeds Dela Gothic One (needed subsets), Inter, JetBrains Mono (all OFL) as base64
- extracts shared drawing helpers from game/render.js + game/chapter.js
- appends game/play.js
"""
import base64
import io
import re
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(sys.argv[1])
OUT = Path(sys.argv[2])
RAW, ASSETS = ROOT / 'raw', ROOT / 'assets'
FONTS = ROOT / 'npmfonts/node_modules/@fontsource'


def uri(im, fmt='JPEG', q=82):
    buf = io.BytesIO()
    if fmt == 'JPEG':
        im.convert('RGB').save(buf, 'JPEG', quality=q, optimize=True, progressive=True)
        mime = 'image/jpeg'
    else:
        im.save(buf, 'PNG', optimize=True)
        mime = 'image/png'
    return f'data:{mime};base64,' + base64.b64encode(buf.getvalue()).decode()


def crop(path, rect, max_side, gray=False):
    im = Image.open(path)
    im = im.crop(rect)
    s = min(1.0, max_side / max(im.size))
    if s < 1:
        im = im.resize((round(im.width * s), round(im.height * s)), Image.LANCZOS)
    if gray:
        im = im.convert('L').convert('RGB')
    return im


banner, manga = RAW / 'x-HX5dbiwaoAAvHvH.png', RAW / 'article-HX5f-NMaAAAOjhL.png'
shojoF, neroF = RAW / 'x-HXVarTyasAEhHsN.png', RAW / 'x-HXf342bbgAACWJr.png'
katanaF, scytheF = RAW / 'x-HXae84Ta4AALN3w.png', RAW / 'x-HXklmjraIAAWuqX.png'
A = {}
A['bannerBg'] = uri(crop(banner, (0, 0, 1250, 1000), 1000))
A['heroShonen'] = uri(crop(banner, (1380, 0, 2280, 1000), 560))
A['cutShonen'] = uri(crop(banner, (1380, 120, 2200, 520), 1200))
A['splash'] = uri(crop(banner, (1180, 0, 2600, 1000), 1400))
A['cardClaw'] = uri(crop(banner, (440, 260, 1260, 1000), 460))
A['p5b'] = uri(crop(banner, (2360, 160, 3000, 1000), 640))
A['p7'] = uri(crop(banner, (1420, 20, 2080, 600), 760))
A['p1'] = uri(crop(manga, (40, 0, 1180, 640), 900, gray=True))
A['p5a'] = uri(crop(manga, (840, 700, 1500, 1230), 640, gray=True))
A['p6'] = uri(crop(shojoF, (380, 420, 1500, 1420), 800))
A['heroShojo'] = uri(crop(shojoF, (300, 300, 1700, 1900), 560))
A['cutShojo'] = uri(crop(shojoF, (480, 640, 1450, 1180), 1200))
A['cardKunai'] = uri(crop(shojoF, (140, 560, 640, 1480), 460))
A['cutNero'] = uri(crop(neroF, (560, 760, 1700, 1300), 1200))
A['heroNero'] = uri(crop(neroF, (450, 350, 1850, 1950), 560))
A['p2'] = uri(crop(katanaF, (520, 520, 1480, 1420), 800))
A['p3'] = uri(crop(scytheF, (560, 440, 1560, 1440), 800))
# Nero's head (cutout, faded below the jaw) and the kunai, from the background-removed art
head = Image.open(ASSETS / 'nero.png').convert('RGBA').crop((400, 300, 1260, 1160)).resize((400, 400), Image.LANCZOS)
a = np.asarray(head).astype(np.float32)
fade = np.clip((np.arange(400) - 254) / (362 - 254), 0, 1)[:, None]
a[..., 3] *= (1 - fade)
A['neroHead'] = uri(Image.fromarray(a.astype(np.uint8), 'RGBA'), 'PNG')
A['kunai'] = uri(Image.open(ASSETS / 'shojo.png').convert('RGBA').crop((105, 450, 300, 1020)).resize((150, 438), Image.LANCZOS), 'PNG')
for key, name, w in (('logoL', 'zenko-logo-light.png', 820), ('logoCB', 'zenko-logo-cardback.png', 520), ('encWord', 'encore-wordmark.png', 900)):
    im = Image.open(ASSETS / name).convert('RGBA'); im = im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
    A[key] = uri(im, 'PNG')
A['cardback'] = uri(Image.open(ASSETS / 'cardback-texture.png'), 'JPEG', 85)

# ---- fonts ----
def b64(p):
    return base64.b64encode(p.read_bytes()).decode()


css = []
dela_css = (FONTS / 'dela-gothic-one/400.css').read_text()
need = set('ザシュッバキッドンパリンポゴ封')
faces = []
for block in re.findall(r'@font-face\s*\{(.*?)\}', dela_css, re.S):
    f = re.search(r'url\(\./files/([^)]+\.woff2)\)', block).group(1)
    rng = re.search(r'unicode-range:\s*([^;]+);', block).group(1)
    cps = []
    for r in rng.split(','):
        r = r.strip()[2:]
        lo, hi = (r.split('-') + [r])[:2] if '-' in r else (r, r)
        cps.append((int(lo, 16), int(hi, 16)))
    if 'latin' in f and 'ext' not in f:
        latin = (f, rng)
    elif any(any(lo <= ord(ch) <= hi for lo, hi in cps) for ch in need):
        faces.append((f, rng))
for f, rng in faces + [latin]:  # latin declared last so it wins for ASCII
    css.append(f"@font-face{{font-family:'Dela Gothic One';font-style:normal;font-weight:400;font-display:block;src:url(data:font/woff2;base64,{b64(FONTS / 'dela-gothic-one/files' / f)}) format('woff2');unicode-range:{rng};}}")
for w in (400, 500, 600, 700):
    css.append(f"@font-face{{font-family:'Inter';font-style:normal;font-weight:{w};font-display:block;src:url(data:font/woff2;base64,{b64(FONTS / f'inter/files/inter-latin-{w}-normal.woff2')}) format('woff2');}}")
for w in (400, 700):
    css.append(f"@font-face{{font-family:'JetBrains Mono';font-style:normal;font-weight:{w};font-display:block;src:url(data:font/woff2;base64,{b64(FONTS / f'jetbrains-mono/files/jetbrains-mono-latin-{w}-normal.woff2')}) format('woff2');}}")

# ---- shared helpers ----
def extract(src, name):
    m = re.search(r'^function %s\(' % re.escape(name), src, re.M)
    if not m:
        raise SystemExit('missing ' + name)
    i = m.end() - 1; depth = 0
    while True:
        c = src[i]
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0:
                break
        i += 1
    j = src.index('{', i); depth = 0; k = j
    while True:
        c = src[k]
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                break
        k += 1
    return src[m.start():k + 1]


render = (ROOT / 'game/render.js').read_text()
chapter = (ROOT / 'game/chapter.js').read_text()
helpers = [extract(render, n) for n in ['makeHalftone', 'makeGrain', 'polyPath', 'cover', 'rrect', 'text', 'wrap', 'measure', 'sfx', 'speedLines', 'star4',
                                         'cardShape', 'drawCardFront', 'drawCardBack', 'drawCard', 'drawHanko', 'drawWisp', 'drawNero', 'halftoneLayer',
                                         'drawRedHalftone', 'drawBackdrop', 'drawCutIn', 'invertCanvas', 'sfxText', 'drawMeter', 'drawDrop', 'mascotPath',
                                         'drawMascot', 'sceneEncore']]
helpers += [extract(chapter, n) for n in ['corrupt', 'makeShards', 'clawPath', 'taper', 'drawClaws']]
body = '\n\n'.join(helpers)
patches = [
    ("const frame = o.frame === 'purple' ? C.purple : C.card;", "const frame = o.frame === 'purple' ? C.purple : o.frame === 'gold' ? C.gold : C.card;"),
    ("if (o.title) text(g, o.title, ax + a * 0.4, ty + h * 0.07, { font: FONT.dela, size: Math.round(w * 0.105), color: '#fff' });",
     "if (o.title) { let fs = Math.round(w * 0.105); g.save(); g.font = `${fs}px ${FONT.dela}`; const tw = g.measureText(o.title).width; g.restore(); if (tw > aw - a * 0.8) fs = Math.floor(fs * (aw - a * 0.8) / tw); text(g, o.title, ax + a * 0.4, ty + h * 0.07, { font: FONT.dela, size: fs, color: '#fff' }); }"),
    ("big: 'RESONANCE  BURST', lbl: 'SHONEN · VANGUARD'", "big: 'TAG  IN: SHONEN', lbl: 'VANGUARD · SWIPE TO SLASH'"),
    ("big: 'KUNAI  PIN', lbl: 'SHOJO · CATALYST'", "big: 'TAG  IN: SHOJO', lbl: 'CATALYST · TAP TO THROW & PARRY'"),
    ("lbl: 'NERO · THE ANOMALY · LEGENDARY'", "lbl: 'THE ANOMALY · HOLD & DRAG THROUGH WALLS'"),
    ("'ZENKO: PANEL CUT · A GAME CONCEPT BY ENCORE STUDIO'", "'ZENKO: CHAPTER BREAK · A GAME CONCEPT BY ENCORE STUDIO'"),
]
for x, y in patches:
    if x not in body:
        raise SystemExit('patch target missing: ' + x[:70])
    body = body.replace(x, y)

header = r"""'use strict';
const W = 1080, H = 1920, VERT = true;
const C = {
  ink: '#0b090c', paper: '#f3f0ea', paper2: '#e9e5dc', coral: '#F4575E', card: '#E46762', purple: '#E46EFF',
  haze: '#403748', haze2: '#665A72', navy: '#344771', sakura: '#EF9BCC', gold: '#F2B43C', fur: '#383240',
  encRed: '#E24A51', encGrey: '#a1a0a2', encMono: '#6b6b6d',
};
const FONT = { dela: '"Dela Gothic One"', disp: 'Inter', ui: 'Inter', mono: '"JetBrains Mono"' };
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const inv = (a, b, v) => clamp((v - a) / (b - a));
const eOut = (t) => 1 - Math.pow(1 - clamp(t), 3);
const eIn = (t) => Math.pow(clamp(t), 3);
const eIO = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
const eBack = (t) => { t = clamp(t); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const noise1 = (x) => { const i = Math.floor(x), f = x - i; const u = f * f * (3 - 2 * f); return lerp(hash(i), hash(i + 1), u); };
const IMG = {}; const ART = {}; let HT_CANVAS = null;
"""
js = header + '\nconst ASSETS = ' + __import__('json').dumps(A) + ';\n\n' + body + '\n\n' + (ROOT / 'game/play.js').read_text()
html = f"""<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#0b080d">
<title>Zenko: Chapter Break</title>
<style>{''.join(css)}
html,body{{margin:0;height:100%;background:#0b080d;overflow:hidden;overscroll-behavior:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}}
canvas{{display:block;position:fixed;inset:0;width:100vw;height:100vh;height:100dvh;touch-action:none}}
</style></head>
<body><canvas id="c" aria-label="Zenko: Chapter Break, a playable game concept"></canvas>
<script>
{js}
</script>
</body></html>
"""
OUT.parent.mkdir(parents=True, exist_ok=True)
OUT.write_text(html)
print(OUT, f'{OUT.stat().st_size / 1e6:.2f} MB', 'assets', len(A), 'dela faces', len(faces) + 1)
