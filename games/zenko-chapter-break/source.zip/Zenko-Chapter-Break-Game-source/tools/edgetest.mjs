// Edge cases: game over + retry, real two-finger pinch finisher (touch), desktop letterbox, closed eyes.
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const [file, out] = process.argv.slice(2);
const browser = await chromium.launch();
const errors = [];
// --- phone with touch ---
const ctxp = await browser.newContext({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2.625, hasTouch: true, isMobile: true });
const page = await ctxp.newPage();
page.on('pageerror', (e) => errors.push(e.message));
await page.goto('file://' + path.resolve(file)); await page.waitForFunction(() => window.ready);
const toClient = (lx, ly) => page.evaluate(([x, y]) => { const r = cv.getBoundingClientRect(); return [(x * SC + OX) * (r.width / CW) + r.left, (y * SC + OY) * (r.height / CH) + r.top]; }, [lx, ly]);
await page.waitForTimeout(800);
let [x, y] = await toClient(540, 1650); await page.touchscreen.tap(x, y); await page.waitForTimeout(400);
// jump to p3, force a hit with 1 hp -> game over
await page.evaluate(() => { const G = window.__G(); G.hp = 1; startStage(2); });
await page.waitForFunction(() => window.__G().mode === 'over', null, { timeout: 20000 });
await page.waitForTimeout(700); await page.screenshot({ path: out + '/edge-gameover.png' });
[x, y] = await toClient(540, 1150); await page.touchscreen.tap(x, y); await page.waitForTimeout(300);
console.log('after retry', JSON.stringify(await page.evaluate(() => { const G = window.__G(); return { mode: G.mode, hp: G.hp, stage: G.stage, continues: G.stats.continues }; })));
// jump to boss, make finisher ready, then pinch with two real touch points
await page.evaluate(() => { const G = window.__G(); G.hero = 'shojo'; startStage(6); G.boss.riseT -= 2; });
await page.waitForTimeout(600);
await page.evaluate(() => { const G = window.__G(); damageBoss(G.boss.max * 0.75, 380, 2790); });
await page.waitForTimeout(500); await page.screenshot({ path: out + '/edge-boss-closed-eyes.png' });
const cdp = await ctxp.newCDPSession(page);
const [c1x, c1y] = await toClient(500, 1000), [c2x, c2y] = await toClient(580, 1080);
await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: c1x, y: c1y, id: 1 }, { x: c2x, y: c2y, id: 2 }] });
for (let i = 1; i <= 10; i++) { const d = i * 12; await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [{ x: c1x - d, y: c1y - d, id: 1 }, { x: c2x + d, y: c2y + d, id: 2 }] }); await page.waitForTimeout(16); }
await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
await page.waitForTimeout(500);
console.log('after pinch mode:', await page.evaluate(() => window.__G().mode));
await page.screenshot({ path: out + '/edge-pinch-splash.png' });
// --- desktop letterbox ---
const pd = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
pd.on('pageerror', (e) => errors.push(e.message));
await pd.goto('file://' + path.resolve(file)); await pd.waitForFunction(() => window.ready); await pd.waitForTimeout(1800);
await pd.screenshot({ path: out + '/edge-desktop-title.png' });
await pd.mouse.click(720, 780); await pd.waitForTimeout(400); await pd.evaluate(() => startStage(1)); await pd.waitForTimeout(2500);
await pd.screenshot({ path: out + '/edge-desktop-play.png' });
console.log('errors:', errors.length ? errors : 'none');
await browser.close();
