// Plays ZENKO: CHAPTER BREAK end to end with real pointer input and screenshots each beat.
// node playtest.mjs <index.html> <outDir> [width height dpr]
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const [file, outDir, vw = '540', vh = '960', dpr = '2'] = process.argv.slice(2);
fs.mkdirSync(outDir, { recursive: true });
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: +vw, height: +vh }, deviceScaleFactor: +dpr });
const errors = [];
page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
await page.goto('file://' + path.resolve(file));
await page.waitForFunction(() => window.ready || window.initError, null, { timeout: 60000 });
const initErr = await page.evaluate(() => window.initError);
if (initErr) { console.log('INIT ERROR', initErr); process.exit(1); }

const sleep = (ms) => page.waitForTimeout(ms);
const toClient = (lx, ly) => page.evaluate(([x, y]) => { const r = cv.getBoundingClientRect(); return [(x * SC + OX) * (r.width / CW) + r.left, (y * SC + OY) * (r.height / CH) + r.top]; }, [lx, ly]);
const w2c = async (wx, wy) => { const [lx, ly] = await page.evaluate(([x, y]) => window.__w2s(x, y), [wx, wy]); return toClient(lx, ly); };
const state = () => page.evaluate(() => { const G = window.__G(); return { mode: G.mode, stage: G.stage, st: G.st, hero: G.hero, hp: G.hp, res: Math.round(G.res), combo: G.combo, score: G.score, route: G.route, lockHp: G.lockHp,
  hand: G.hand.map((c) => c && c.kind), enemies: G.enemies.filter((e) => e.emerge >= 1).map((e) => ({ x: e.x + e.wx + e.kx, y: e.y + e.wy + e.ky, tele: !!e.tele, kind: e.kind })),
  boss: G.boss && { hp: Math.round(G.boss.hp), alive: G.boss.alive, risen: G.boss.risen, tele: G.boss.tele && { x: G.boss.tele.x, y: G.boss.tele.y }, eyes: G.boss.eyes.map((e) => ({ c: e.c, state: e.state })), finisher: G.boss.finisher }, nero: G.nero.energy }; });
async function tapL(lx, ly) { const [x, y] = await toClient(lx, ly); await page.mouse.move(x, y); await page.mouse.down(); await page.mouse.up(); }
async function tapW(wx, wy) { const [x, y] = await w2c(wx, wy); await page.mouse.move(x, y); await page.mouse.down(); await page.mouse.up(); }
async function swipeW(pts) { let [x, y] = await w2c(...pts[0]); await page.mouse.move(x, y); await page.mouse.down(); for (const p of pts.slice(1)) { [x, y] = await w2c(...p); await page.mouse.move(x, y, { steps: 6 }); } await page.mouse.up(); }
async function hero(i) { const s = await page.evaluate((k) => window.__slots.teamSlot(k), i); await tapL(s.x, s.y); }
async function dragCard(i) { const s = await page.evaluate((k) => window.__slots.handSlot(k), i); let [x, y] = await toClient(s.x, s.y); await page.mouse.move(x, y); await page.mouse.down(); [x, y] = await toClient(540, 1000); await page.mouse.move(x, y, { steps: 12 }); await page.mouse.up(); }
let shotN = 0; const shots = new Set();
async function shot(name, once = true) { if (once && shots.has(name)) return; shots.add(name); await page.screenshot({ path: path.join(outDir, `${String(++shotN).padStart(2, '0')}-${name}.png`) }); }
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

await sleep(1800); await shot('title');
await tapL(540, 1650); await sleep(1500); await shot('story');
const t0 = Date.now(); let lastStage = -1, s;
while (Date.now() - t0 < 360000) {
  s = await state();
  if (s.stage !== lastStage || s.mode !== 'play') { if (s.stage !== lastStage) log('stage', s.stage, 'hp', s.hp, 'score', s.score); lastStage = s.stage; }
  if (s.mode === 'over') { log('GAME OVER at stage', s.stage); await shot('gameover'); await tapL(540, 1150); await sleep(300); continue; }
  if (s.mode !== 'play') break;
  const sid = ['story', 'p2', 'p3', 'lock', 'fork', 'p6', 'boss'][s.stage];
  if (sid === 'story') { await sleep(200); continue; }
  if (sid === 'lock') {
    if (s.lockHp >= 100) await shot('lock-start');
    if (s.hero !== 'nero') { await hero(2); await sleep(900); await shot('nero-cutin'); }
    if (s.lockHp > 0) { await swipeW([[60, 1330], [700, 1320], [80, 1345], [700, 1335]]); await shot('nero-drag'); await sleep(150); continue; }
    await sleep(300); continue;
  }
  if (sid === 'fork') { await sleep(700); await shot('fork'); if (!s.route) await tapW(560, 1650); await sleep(500); await shot('fork-chosen'); await sleep(800); continue; }
  // telegraphs first: parry with Shojo
  const tele = s.enemies.find((e) => e.tele) || (s.boss && s.boss.alive && s.boss.tele);
  if (tele) {
    if (s.hero !== 'shojo') { await hero(1); await sleep(sid === 'p3' ? 900 : 120); }
    await shot('parry-telegraph'); await tapW(tele.x, tele.y + (s.enemies.includes(tele) ? 0 : 0)); await sleep(120); await shot('parry'); continue;
  }
  if (sid === 'p6' && s.hand[0] && s.res >= 50 && s.enemies.length) { await shot('p6-before-card'); await dragCard(s.hand.findIndex((k) => k)); await sleep(200); await shot('card-cast'); continue; }
  if (sid === 'boss') {
    if (!s.boss || !s.boss.risen) { await sleep(300); await shot('boss-intro'); continue; }
    if (s.boss.finisher && s.hand[0] === 'splash') { await shot('splash-ready'); await dragCard(0); await sleep(400); break; }
    const eye = s.boss.eyes.find((e) => e.state === 'open');
    if (eye) { if (s.hero !== 'shojo') await hero(1); await tapW(eye.c[0], eye.c[1]); await shot('eye-hit'); await sleep(120); continue; }
    if (s.res >= 60 && s.hand.some((k) => k && k !== 'splash')) { await dragCard(s.hand.findIndex((k) => k && k !== 'splash')); await sleep(150); continue; }
    if (s.enemies.length) { const e = s.enemies[0]; if (s.hero !== 'shojo') await hero(1); await tapW(e.x, e.y); await sleep(130); continue; }
    if (s.hero !== 'shonen') { await hero(0); await sleep(80); }
    await swipeW([[200, 2650], [560, 2900], [200, 2930], [560, 2640]]); await shot('boss-swipe'); await sleep(60); continue;
  }
  // regular fights: Shonen swipes in p2, Shojo kunai elsewhere
  if (!s.enemies.length) { await sleep(150); continue; }
  const e = s.enemies[0];
  if (sid === 'p2') { if (s.hero !== 'shonen') await hero(0); await swipeW([[e.x - 120, e.y - 60], [e.x + 120, e.y + 60]]); await shot('swipe'); await sleep(90); }
  else { if (s.hero !== 'shojo') { await hero(1); await sleep(900); } await tapW(e.x, e.y); await shot('kunai'); await sleep(150); }
}
log('loop end', JSON.stringify({ mode: s.mode, stage: s.stage, hp: s.hp, score: s.score }));
await sleep(900); await shot('splash');
await sleep(2400); await shot('cleared');
await page.waitForFunction(() => window.__G().mode === 'results', null, { timeout: 15000 }).catch(() => log('no results mode'));
await sleep(2600); await shot('results');
await tapL(540, 1880); await sleep(2000); await shot('board');
await tapL(540, 1880); await sleep(2200); await shot('encore');
const fin = await page.evaluate(() => { const G = window.__G(); return { mode: G.mode, score: G.score, time: G.stats.time, combo: G.maxCombo, parries: G.stats.parries, cards: G.stats.cards, continues: G.stats.continues, hp: G.hp }; });
log('FINAL', JSON.stringify(fin));
log('ERRORS', errors.length ? errors.join('\n') : 'none');
await browser.close();
