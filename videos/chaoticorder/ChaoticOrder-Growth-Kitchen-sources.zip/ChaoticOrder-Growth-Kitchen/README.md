# Chaotic Order · The Growth Kitchen (source package)

Unofficial concept by Encore Studio. All partner names, handles and figures are sample data.

- `build/index.html` is the whole video as a deterministic web page. Open it with `?t=12.3` to view any second, or call `seek(t)` in the console.
- `build/scenes.js` holds the screens and the sample data; `build/app.js` is the timeline (camera, cursor, counters); `build/style.css` the look.
- `build/assets/` holds Chaotic Order's own art (from chaoticorder.fun and the X profile). `build/fonts/` holds Lilita One and Nunito (SIL Open Font License).
- `render.js <startFrame> <endFrame> <out.mp4> 60` captures frames with Playwright and encodes them with ffmpeg.
- `audio.py out/score.wav` synthesises the original score and sound effects (numpy + scipy, no samples).
- `stills.js <dir>` exports the still images.
