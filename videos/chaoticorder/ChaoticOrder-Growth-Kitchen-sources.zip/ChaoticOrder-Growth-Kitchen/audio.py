# Original score + sound effects for the Chaotic Order "Growth Kitchen" concept video.
# Everything is synthesised here from oscillators and noise: no samples, loops or third-party audio.
import numpy as np, scipy.signal as sg, wave, sys

SR = 48000; DUR = 64.0; N = int(SR * DUR); BEAT = 0.5; STEP = BEAT / 4
rng = np.random.default_rng(11)
TAIL = SR * 4
def bus(): return np.zeros((N + TAIL, 2))
def tt(d): return np.arange(int(d * SR)) / SR
def mtof(m): return 440.0 * 2 ** ((m - 69) / 12)
def add(dst, sig, t, gain=1.0, pan=0.0):
    i = int(round(t * SR))
    if i < 0: sig = sig[-i:]; i = 0
    n = min(len(sig), len(dst) - i)
    if n <= 0: return
    if sig.ndim == 2: dst[i:i + n] += sig[:n] * gain; return
    a = (pan + 1) * np.pi / 4
    dst[i:i + n, 0] += sig[:n] * gain * np.cos(a) * 1.414
    dst[i:i + n, 1] += sig[:n] * gain * np.sin(a) * 1.414
def fade(sig, a=0.002, r=0.01):
    na, nr = int(a * SR), int(r * SR)
    sig = sig.copy()
    if na: sig[:na] *= np.linspace(0, 1, na)
    if nr: sig[-nr:] *= np.linspace(1, 0, nr)
    return sig
def filt(x, kind, fc, order=2):
    sos = sg.butter(order, fc, kind, fs=SR, output='sos')
    return sg.sosfilt(sos, x)
def noise(d): return rng.standard_normal(int(d * SR))

# ---------------- instruments ----------------
def marimba(m, d=0.6, bright=1.0):
    f = mtof(m); t = tt(d)
    s = np.sin(2 * np.pi * f * t) * np.exp(-t * 8) + 0.34 * bright * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 24) + 0.1 * bright * np.sin(2 * np.pi * 9.2 * f * t) * np.exp(-t * 46)
    return fade(s, 0.002, 0.03)
def pluck(m, d=0.3):
    f = mtof(m); t = tt(d); s = np.zeros_like(t)
    for k in range(1, 9):
        if k * f < 9000: s += np.sin(2 * np.pi * k * f * t) / k * np.exp(-t * (7 + 4.5 * k))
    return fade(s, 0.002, 0.02)
def bass(m, d=0.3):
    f = mtof(m); t = tt(d)
    s = np.sin(2 * np.pi * f * t + 0.9 * np.sin(2 * np.pi * f * t) * np.exp(-t * 9)) + 0.25 * np.sin(4 * np.pi * f * t) * np.exp(-t * 12)
    return fade(s * np.exp(-t * 2.2), 0.004, 0.035)
def kick():
    t = tt(0.36); f = 46 + 120 * np.exp(-t * 30)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 8)
    s[:140] += filt(noise(140 / SR), 'low', 3000) * np.linspace(0.5, 0, 140)
    return fade(s, 0.0005, 0.03)
def clap():
    d = 0.22; t = tt(d); n = filt(noise(d), 'band', [900, 3800])
    e = np.zeros_like(t)
    for o in (0, 0.011, 0.023): e += np.where(t >= o, np.exp(-(t - o) * 130), 0)
    e = e * 0.6 + np.where(t >= 0.03, np.exp(-(t - 0.03) * 26), 0)
    return fade(n * e, 0.0005, 0.02)
def snare(v=1.0):
    d = 0.18; t = tt(d)
    s = filt(noise(d), 'high', 1400) * np.exp(-t * 32) + 0.6 * np.sin(2 * np.pi * 195 * t) * np.exp(-t * 40)
    return fade(s * v, 0.0005, 0.02)
def hat(op=False):
    d = 0.22 if op else 0.06; t = tt(d)
    return fade(filt(noise(d), 'high', 7200) * np.exp(-t * (17 if op else 95)), 0.0005, 0.01)
def snap():
    d = 0.09; t = tt(d)
    return fade(filt(noise(d), 'band', [1700, 4200]) * np.exp(-t * 110) + 0.3 * np.sin(2 * np.pi * 2300 * t) * np.exp(-t * 160), 0.0005, 0.01)
def pad(midis, d):
    t = tt(d + 0.5); L = np.zeros_like(t); R = np.zeros_like(t)
    for m in midis:
        f = mtof(m)
        for det, side in ((-0.006, 0), (0.0, 2), (0.007, 1)):
            w = sg.sawtooth(2 * np.pi * f * (1 + det) * t + rng.uniform(0, 6.28))
            if side in (0, 2): L += w
            if side in (1, 2): R += w
    e = np.minimum(1, t / 0.12) * np.minimum(1, np.maximum(0, (d + 0.5 - t) / 0.5))
    return np.stack([filt(L, 'low', 1300) * e, filt(R, 'low', 1300) * e], 1)
def lead(m, d):
    f = mtof(m); t = tt(d + 0.08); vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t) * np.minimum(1, t / 0.2)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    s = sg.sawtooth(ph, 0.5) + 0.22 * sg.square(ph) + 0.3 * np.sin(2 * ph)
    e = np.minimum(1, t / 0.012) * np.exp(-t * 2.2) * np.minimum(1, np.maximum(0, (d + 0.08 - t) / 0.07))
    return filt(s * e, 'low', 3400)
def bell(m=91, d=2.0, bright=1.0):
    f = mtof(m); t = tt(d); s = np.zeros_like(t)
    for r, a, dc in ((1, 1, 2.6), (2.756, 0.55 * bright, 4.2), (5.404, 0.3 * bright, 6.5), (8.933, 0.16 * bright, 9)):
        if r * f < 20000: s += a * np.sin(2 * np.pi * r * f * t) * np.exp(-t * dc)
    s[:200] += filt(noise(200 / SR), 'high', 3000) * np.linspace(0.6, 0, 200)
    return fade(s, 0.0005, 0.1)

# ---------------- sound effects ----------------
def whoosh(d=0.6, up=True, lo=250, hi=7000):
    n = noise(d); t = tt(d); out = np.zeros_like(t); K = 7
    for k in range(K):
        fc = lo * (hi / lo) ** (k / (K - 1)); c = (k / (K - 1)) if up else 1 - k / (K - 1)
        out += filt(n, 'band', [fc * 0.75, min(fc * 1.3, 20000)]) * np.exp(-((t / d - (0.15 + 0.7 * c)) ** 2) / 0.03)
    return fade(out, 0.01, 0.02)
def pop(f=700, d=0.13):
    t = tt(d); fr = f * (1 + 0.7 * np.exp(-t * 60))
    return fade(np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 42), 0.001, 0.01)
def tick(f=2600):
    t = tt(0.035)
    return np.sin(2 * np.pi * f * t) * np.exp(-t * 190) + 0.5 * filt(noise(0.035), 'high', 4000) * np.exp(-t * 380)
def click():
    s = np.zeros(int(0.09 * SR)); a = filt(noise(0.008), 'band', [1800, 5200]) * np.linspace(1, 0, int(0.008 * SR))
    s[:len(a)] += a; o = int(0.055 * SR); s[o:o + len(a)] += a * 0.6
    return s
def thud(d=0.4, f0=110):
    t = tt(d); f = 44 + (f0 - 44) * np.exp(-t * 20)
    return fade(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 11) + 0.5 * filt(noise(d), 'low', 900) * np.exp(-t * 40), 0.0005, 0.03)
def slap():
    d = 0.14; t = tt(d)
    return fade(filt(noise(d), 'band', [350, 2600]) * np.exp(-t * 52) + 0.5 * np.sin(2 * np.pi * 85 * t) * np.exp(-t * 34), 0.0005, 0.02)
def riser(d):
    t = tt(d); x = t / d
    f = 180 * (9 ** x)
    return fade((filt(noise(d), 'high', 2500) * 0.6 + 0.5 * np.sin(2 * np.pi * np.cumsum(f) / SR)) * x ** 2, 0.01, 0.01)
def bling(m, d=0.8):
    f = mtof(m); t = tt(d)
    s = (np.sin(2 * np.pi * f * t) + 0.4 * np.sin(4 * np.pi * f * t) + 0.2 * np.sin(6 * np.pi * f * t)) * np.exp(-t * 6.5) * (1 + 0.25 * np.sin(2 * np.pi * 13 * t))
    return fade(s, 0.001, 0.05)
def blip():
    a = pop(880, 0.08); b = pop(1320, 0.1); s = np.zeros(int(0.2 * SR)); s[:len(a)] += a; o = int(0.07 * SR); s[o:o + len(b)] += b
    return s
def crash(d=1.8):
    t = tt(d)
    return fade(filt(noise(d), 'high', 4200) * np.exp(-t * 2.6), 0.001, 0.1)

# ---------------- arrangement ----------------
drums, bassb, music, padb, sfx = bus(), bus(), bus(), bus(), bus()
kicks = []
CH = {'C': (36, [60, 64, 67]), 'Am': (33, [57, 60, 64]), 'F': (41, [60, 65, 69]), 'G': (43, [59, 62, 67]), 'Em': (40, [59, 64, 67])}
def K(t, g=0.95): add(drums, kick(), t, g); kicks.append(t)
def fill(t0, beats=2):
    n = beats * 4
    for i in range(n): add(drums, snare(), t0 + i * STEP, 0.16 + 0.34 * i / n, (-0.3 + 0.6 * i / n))
    add(sfx, whoosh(beats * BEAT, True), t0, 0.22)
def bar(tb, ch, drums_on=True, light=False, bass_on=True, riff=True, arp=False, lvl=1.0, half=None):
    root, tri = CH[ch]
    add(padb, pad(tri, 2.0), tb, 0.055 * lvl)
    X = [tri[0] + 12, tri[1] + 12, tri[2] + 12, tri[0] + 24, tri[1] + 24]
    if riff:
        for s, ix, v in ((0, 0, 1), (3, 2, .8), (6, 3, .9), (8, 2, .75), (11, 4, .9), (14, 2, .7)):
            add(music, marimba(X[ix]), tb + s * STEP, 0.3 * v * lvl, -0.25 + 0.1 * ix)
    if arp:
        for s in range(16):
            add(music, pluck(X[[0, 1, 2, 3, 2, 1, 4, 2][s % 8]] - (12 if s % 8 in (0, 5) else 0)), tb + s * STEP, 0.13 * (1.0 if s % 4 == 0 else 0.7), 0.45 if s % 2 else -0.45)
    if bass_on:
        r2 = CH[half][0] if half else root
        for s, m, d in ((0, root, 0.34), (3, root, 0.2), (6, root + 12, 0.16), (8, r2, 0.34), (11, r2 + 7, 0.2), (14, r2, 0.2)):
            add(bassb, bass(m, d), tb + s * STEP, 0.5)
    if drums_on:
        for s in (0, 4, 8, 12): K(tb + s * STEP)
        if not light: K(tb + 10 * STEP, 0.5)
        for s in (4, 12): add(drums, clap(), tb + s * STEP, 0.42, 0.05)
        for s in range(16):
            off = s % 4 == 2
            add(drums, hat(), tb + s * STEP, 0.15 if off else 0.055, 0.3 if s % 2 else -0.2)
    else:
        for s in (4, 12): add(drums, snap(), tb + s * STEP, 0.4, 0.1)
        for s in (2, 6, 10, 14): add(drums, hat(), tb + s * STEP, 0.07, 0.3)
MEL = [[(0, 76, 2), (2, 79, 2), (4, 81, 3), (8, 79, 2), (10, 76, 2), (12, 74, 4)], [(0, 72, 2), (2, 74, 2), (4, 76, 3), (8, 79, 3), (12, 76, 4)]]
def melody(tb, which, g=0.15, tr=0):
    for s, m, d in MEL[which]: add(music, lead(m + tr, d * STEP), tb + s * STEP, g, 0.12)

# intro: chaos (0-3s)
for i in range(6): K(i * BEAT, 0.85)
for i in range(24):
    t = i * STEP; add(drums, hat(), t, 0.07 + 0.1 * i / 24, 0.3 if i % 2 else -0.3)
    add(music, marimba([69, 72, 76, 81][i % 4] + (i // 8), 0.25), t, 0.2 + 0.12 * i / 24, 0.5 if i % 2 else -0.5)
for i in range(12): add(bassb, bass(33 + (i // 4), 0.2), i * 0.25, 0.42)
for i in range(16): add(drums, snare(), 2.0 + i * STEP / 2 * 1.0 if i < 8 else 2.5 + (i - 8) * STEP / 2, 0.1 + 0.3 * i / 16, 0)
add(sfx, riser(1.5), 1.5, 0.3)
# order (3-6s)
add(padb, pad(CH['C'][1], 1.9), 4.0, 0.045); add(padb, pad(CH['G'][1], 1.0), 5.0, 0.05)
for t, m, d in ((3.0, 36, 0.8), (4.0, 36, 0.3), (4.5, 40, 0.3), (5.0, 41, 0.3), (5.5, 43, 0.4)): add(bassb, bass(m, d), t, 0.5)
for t in (3.5, 4.5, 5.5): add(drums, snap(), t, 0.42, 0.1)
for i, (t, m) in enumerate(((4.0, 72), (4.25, 76), (4.5, 79), (4.75, 84), (5.0, 79), (5.25, 83), (5.5, 86))): add(music, marimba(m), t, 0.3, -0.3 + 0.1 * i)
fill(5.0, 2)
# sections
A = ['C', 'Am', 'F', 'G', 'C', 'Am', 'F']
for i, ch in enumerate(A): bar(6 + 2 * i, ch, half='G' if i == 6 else None)
add(drums, crash(), 6.0, 0.16); fill(19.0, 2)
B = ['F', 'G', 'Em', 'Am', 'F', 'G']
for i, ch in enumerate(B): bar(20 + 2 * i, ch); melody(20 + 2 * i, i % 2)
add(drums, crash(), 20.0, 0.16); fill(31.0, 2)
C = ['C', 'Am', 'F', 'G', 'C', 'G']
for i, ch in enumerate(C):
    bar(32 + 2 * i, ch, drums_on=i >= 2, bass_on=True, lvl=1.0)
    if i >= 2: melody(32 + 2 * i, i % 2, 0.14)
add(drums, crash(), 36.0, 0.14); fill(35.5, 1); fill(43.0, 2)
D = ['Am', 'F', 'C', 'G', 'Am', 'G']
for i, ch in enumerate(D):
    bar(44 + 2 * i, ch, arp=True, riff=i >= 3)
    if i >= 2: melody(44 + 2 * i, i % 2, 0.13)
add(drums, crash(), 44.0, 0.16); fill(55.0, 2)
O = ['C', 'F', 'G']
for i, ch in enumerate(O): bar(56 + 2 * i, ch, arp=True); melody(56 + 2 * i, i % 2, 0.16, 12 if i == 2 else 0)
add(drums, crash(), 56.0, 0.2); fill(61.0, 2)
# final hit
K(62.0, 1.0); add(drums, crash(3.0), 62.0, 0.26); add(drums, clap(), 62.0, 0.4)
add(bassb, bass(36, 1.6), 62.0, 0.6); add(padb, pad([60, 64, 67, 72], 1.6), 62.0, 0.07)
for i, m in enumerate((72, 76, 79, 84, 88, 91)): add(music, marimba(m, 1.2), 62.0 + i * 0.045, 0.3, -0.4 + 0.16 * i)
add(sfx, bell(91, 2.4), 62.0, 0.2)

# ---------------- sound effects on the picture ----------------
def S(sig, t, g=0.3, pan=0.0): add(sfx, sig, t, g, pan)
# intro
S(thud(), 0.02, 0.5)
for i in range(4, 14): S(slap(), -0.88 + 0.24 * i, 0.3, -0.6 + 1.2 * ((i * 5) % 7) / 6)
S(whoosh(0.5, True), 2.9, 0.4); S(bell(91, 2.4), 3.0, 0.5); S(bell(96, 2.0), 3.0, 0.2); S(thud(0.5, 140), 3.0, 0.5)
S(tick(1500), 3.42, 0.3)
for i in range(4): S(slap(), 3.6 + 0.2 * i, 0.26, -0.6 + 0.4 * i); S(pop(520 + 90 * i), 3.62 + 0.2 * i, 0.16, -0.6 + 0.4 * i)
S(whoosh(0.7, True), 5.32, 0.4)
PENTA = [72, 74, 76, 79, 81, 84, 86, 88, 91, 93, 96]
# S1 collab CRM (starts 6.0)
S(whoosh(0.5, False), 6.0, 0.25)
for n in range(13): S(tick(1900 + 60 * n), 7.25 + 0.1 * n, 0.1, -0.5 + n / 12)
S(click(), 10.5, 0.5); S(whoosh(1.3, True, 300, 2500), 10.6, 0.1)
S(bell(91, 1.8), 12.0, 0.36); S(pop(600), 12.0, 0.4); S(bling(96), 12.05, 0.12); S(thud(0.25, 90), 12.0, 0.3)
S(click(), 12.8, 0.45); S(whoosh(0.45, False), 12.98, 0.24, 0.4)
for i in range(4): S(tick(2200), 13.45 + 0.1 * i, 0.12, 0.4)
for i, m in enumerate((84, 86, 88, 91)): S(pop(mtof(m)), 14.5 + 0.5 * i, 0.3, 0.3); S(bling(m, 0.5), 14.5 + 0.5 * i, 0.08, 0.3)
S(click(), 17.0, 0.5)
for i in range(7): S(tick(1400 + 150 * i), 17.03 + 0.028 * i, 0.16, 0.3)
S(bell(96, 1.2), 17.14, 0.16); S(whoosh(0.45, True), 17.72, 0.16, 0.4); S(whoosh(0.4, True), 19.64, 0.3)
# S2 KOL desk (starts 20.0)
S(whoosh(0.5, False), 20.0, 0.25)
for k in range(7): S(tick(2000 + 70 * k), 21.1 + 0.1 * k, 0.11, -0.3)
S(click(), 23.5, 0.5); S(whoosh(0.6, True, 400, 3000), 23.5, 0.16, -0.2)
for k in range(7): S(tick(1700 + 90 * k), 23.62 + 0.06 * k, 0.09, -0.2)
S(click(), 25.0, 0.5); S(pop(660), 25.02, 0.3)
for i, m in enumerate((79, 84, 76, 83)): S(pop(mtof(m) / 2), 25.5 + 0.25 * i, 0.26, 0.35); S(bling(m, 0.4), 25.85 + 0.25 * i, 0.05, 0.35)
S(whoosh(0.9, False, 300, 2000), 27.4, 0.08)
S(click(), 29.0, 0.5); S(thud(0.3, 130), 29.02, 0.5, 0.2); S(slap(), 29.02, 0.3, 0.2); S(bell(93, 1.4), 29.1, 0.2); S(pop(700), 29.18, 0.2)
S(whoosh(0.4, True), 31.64, 0.3)
# S3 campaigns (starts 32.0)
S(whoosh(0.5, False), 32.0, 0.25)
for k in range(10): S(pop(mtof(PENTA[k]) / 2), 33.0 + 0.25 * k, 0.24, -0.5 + k / 10); S(tick(2400), 33.0 + 0.25 * k, 0.07)
S(thud(0.25, 120), 35.5, 0.35, 0.3); S(bell(96, 1.0), 35.52, 0.14, 0.3)
S(whoosh(1.1, True, 400, 2200), 35.6, 0.07)
S(click(), 38.0, 0.5); S(pop(620), 38.02, 0.3)
for i, m in enumerate((88, 91, 96)): S(bling(m, 0.9), 39.0 + 0.25 * i, 0.26, 0.3); S(pop(mtof(m) / 2), 39.0 + 0.25 * i, 0.16, 0.3)
S(bell(98, 1.0), 39.9, 0.14, 0.3); S(pop(900), 39.9, 0.2, 0.3)
for k in range(5): S(pop(mtof(PENTA[7 - k]) / 2), 40.9 + 0.3 * k, 0.24, 0.3); S(tick(2200), 40.9 + 0.3 * k, 0.07, 0.3)
S(thud(0.3, 130), 42.5, 0.5, 0.3); S(slap(), 42.5, 0.3, 0.3); S(whoosh(0.4, True), 43.64, 0.3)
# S4 discord (starts 44.0)
S(whoosh(0.5, False), 44.0, 0.25)
for k in range(8): S(tick(1800 + 50 * k), 44.5 + 0.1 * k, 0.07, -0.5)
for i in range(4): S(pop(560 + 80 * i), 45.3 + 0.12 * i, 0.2, -0.2 + 0.15 * i)
S(click(), 47.0, 0.5); S(bling(91, 0.9), 47.03, 0.2); S(bling(96, 0.9), 47.11, 0.16); S(blip(), 47.2, 0.2)
S(pop(880), 48.0, 0.3, 0.6); S(bling(93, 0.5), 48.0, 0.1, 0.6)
S(click(), 49.5, 0.5); S(whoosh(0.35, True, 500, 3000), 49.5, 0.12)
S(bell(91, 2.2), 50.0, 0.42); S(bell(98, 1.6), 50.0, 0.14); S(thud(0.3, 120), 50.0, 0.4)
for i in range(4): S(blip(), 51.0 + 0.75 * i, 0.2, -0.2)
S(click(), 52.0, 0.5); S(bell(96, 1.2), 52.02, 0.26, -0.1); S(bell(96, 1.0), 52.2, 0.16, -0.1)
S(whoosh(0.4, True), 55.64, 0.3)
# outro (starts 56.0)
for t, g in ((56.32, 0.5), (56.6, 0.25), (56.74, 0.12)): S(thud(0.3, 110), t, g)
S(thud(0.4, 140), 57.5, 0.5); S(slap(), 57.5, 0.3); S(bell(91, 1.6), 57.55, 0.14)
for i, m in enumerate((84, 86, 88, 91)): S(pop(mtof(m) / 2), 58.5 + 0.25 * i, 0.3, -0.45 + 0.3 * i); S(bling(m, 0.5), 58.5 + 0.25 * i, 0.07, -0.45 + 0.3 * i)
S(thud(0.4, 140), 60.0, 0.45); S(slap(), 60.0, 0.26)

# ---------------- mix ----------------
t_all = np.arange(N + TAIL) / SR
duck = np.ones(N + TAIL)
for k in kicks:
    i = int(k * SR); n = int(0.3 * SR); duck[i:i + n] = np.minimum(duck[i:i + n], 1 - 0.5 * np.exp(-np.arange(n) / SR * 11))
padb *= duck[:, None]; bassb *= (0.5 + 0.5 * duck)[:, None]
def reverb(x, d=1.5, wet=0.2, dark=5500):
    t = tt(d); out = np.zeros_like(x)
    for c in range(2):
        ir = filt(rng.standard_normal(len(t)), 'low', dark) * np.exp(-t * 4.2) * np.minimum(1, t / 0.012); ir /= np.sqrt((ir ** 2).sum())
        out[:, c] = sg.fftconvolve(x[:, c], ir)[:len(x)]
    return x + wet * out
mix = drums * 0.5 + bassb * 0.62 + reverb(music * 1.25 + padb * 1.1, 1.6, 0.26) + reverb(sfx, 1.3, 0.3) * 0.72
mix = sg.sosfilt(sg.butter(2, 28, 'high', fs=SR, output='sos'), mix, axis=0)
mix = mix[:N]
e = np.ones(N); nf = int(1.6 * SR); e[-nf:] = np.cos(np.linspace(0, np.pi / 2, nf)) ** 2
mix *= e[:, None]
for nm, b in (('drums', drums), ('bass', bassb), ('music', music), ('pad', padb), ('sfx', sfx)):
    print(nm, 'rms %.1f dB peak %.2f' % (20 * np.log10(np.sqrt((b[:N] ** 2).mean()) + 1e-9), np.abs(b).max()))
ref = np.percentile(np.abs(mix), 99.7)
print('pre-limit 99.7pct', ref, 'max', np.abs(mix).max())
mix = np.tanh(mix / ref * 0.8) / 0.8
mix *= 10 ** (-1.5 / 20) / np.abs(mix).max()
out = sys.argv[1] if len(sys.argv) > 1 else 'out/score.wav'
with wave.open(out, 'wb') as w:
    w.setnchannels(2); w.setsampwidth(3); w.setframerate(SR)
    q = np.clip(mix * (2 ** 23 - 1), -2 ** 23, 2 ** 23 - 1).astype('<i4')
    w.writeframes(np.ascontiguousarray(q.reshape(-1).view(np.uint8).reshape(-1, 4)[:, :3]).tobytes())
print('wrote', out, 'peak', np.abs(mix).max(), 'rms dB', 20 * np.log10(np.sqrt((mix ** 2).mean())))
