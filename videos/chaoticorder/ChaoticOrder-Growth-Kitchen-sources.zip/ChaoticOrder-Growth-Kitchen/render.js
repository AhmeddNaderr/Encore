// usage: node render.js <startFrame> <endFrame> <out.mp4> [fps]
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const path = require('path');
(async () => {
  const [a, b, out, fpsArg] = process.argv.slice(2);
  const fps = +(fpsArg || 60), start = +a, end = +b;
  const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-c:v', 'png', '-framerate', String(fps), '-i', '-',
    '-vf', 'scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p', '-c:v', 'libx264', '-preset', 'slow', '-crf', '13',
    '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv', '-g', String(fps), out], { stdio: ['pipe', 'inherit', 'inherit'] });
  const done = new Promise(r => ff.on('close', r));
  const br = await chromium.launch({ args: ['--disable-lcd-text', '--font-render-hinting=none'] });
  const p = await br.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  p.on('pageerror', e => { console.error('PAGEERROR', e.message); process.exit(1); });
  await p.goto('file://' + path.resolve(__dirname, 'build/index.html'));
  await p.evaluate(() => window.ready);
  const t0 = Date.now();
  for (let f = start; f < end; f++) {
    await p.evaluate(t => window.seek(t), f / fps);
    const buf = await p.screenshot({ type: 'png' });
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if ((f - start) % 120 === 0) console.log(`${out}: frame ${f} (${((Date.now() - t0) / 1000).toFixed(0)}s)`);
  }
  ff.stdin.end(); await done; await br.close();
  console.log(`${out}: done ${end - start} frames in ${((Date.now() - t0) / 1000).toFixed(0)}s`);
})();
