// usage: node shot.js out_dir t1 t2 ...
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const [outDir, ...ts] = process.argv.slice(2);
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  p.on('console', m => console.log('console:', m.text()));
  p.on('pageerror', e => console.log('PAGEERROR:', e.message));
  await p.goto('file://' + path.resolve(__dirname, 'build/index.html'));
  await p.evaluate(() => window.ready);
  for (const t of ts) {
    await p.evaluate(tt => window.seek(tt), +t);
    await p.screenshot({ path: path.join(outDir, `t${(+t).toFixed(2).padStart(5, '0')}.jpg`), type: 'jpeg', quality: 80 });
  }
  await b.close();
})();
