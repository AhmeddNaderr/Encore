const { chromium } = require('playwright'); const path = require('path');
const shots = [['00-hook-chaos', 2.6], ['01-stations', 4.7], ['02-collab-crm-pipeline', 19.2], ['03-collab-crm-ticket', 16.6], ['04-kol-desk', 31.2], ['05-campaigns', 43.2], ['06-discord-pick-your-chef', 47.6], ['07-discord-order-up', 54.6], ['08-end-card', 63.5]];
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 2 });
  await p.goto('file://' + path.resolve(__dirname, 'build/index.html')); await p.evaluate(() => window.ready);
  for (const [n, t] of shots) { await p.evaluate(tt => window.seek(tt), t); await p.screenshot({ path: path.join(process.argv[2], n + '.jpg'), type: 'jpeg', quality: 90 }); }
  await b.close();
})();
