# Cloverheads · Same Roots — sources archive

This is the source companion to the two separately delivered final films. The user explicitly reauthorized GitHub artifact delivery to `AhmeddNaderr/Encore` after an earlier cancellation. The original full local package is unchanged.

**Quality status: NOT FULLY PASSED.** Preserve the limitations and strict scores in `quality_report.md`; upload authorization does not change them.

## Included

- All research and source evidence from the original delivery ZIP, including `research_brief.md`, the `research/` snapshots and source URLs.
- `art_bible.md`, all canonical `art/raw/` originals, the reference board, side-by-side comparison, palette, inventory, attribution and font licenses.
- Fifteen concepts, developed concept selection, storyboard, master prompt, review notes and quality report.
- Playable `prototype/index.html`, editable JS/JSON modules, tests, capture/build tools and final validation records.
- All four music/final mix WAVs, all synthesized effects, composition/mix events and audio source/license records.
- `DM-description.txt` is proposed pitch text only; it has not been sent.

No essential prototype artwork, font or audio dependency is omitted. The small original research clips under `art/raw/` remain because they are evidence, rather than duplicate final exports. Duplicate source-name aliases remain to preserve provenance and existing references.

## Excluded from this sources ZIP

Only these three files were removed from the full local delivery ZIP:

| Original archive path | Bytes | Reason / location |
|---|---:|---|
| `video/clover_concept_main.mp4` | 29,092,704 | Separate repository file: `videos/cloverdotfamily/Cloverheads-Same-Roots-main.mp4`. |
| `video/clover_concept_15s.mp4` | 10,026,780 | Separate repository file: `videos/cloverdotfamily/Cloverheads-Same-Roots-15s.mp4`. |
| `audio/source/GeneralUser-GS.sf2` | 32,319,396 | Unmodified upstream instrument bank; restore from the pinned official URL below only when re-rendering the score. |

The separate final videos are available from [the repository delivery folder](https://github.com/AhmeddNaderr/Encore/tree/HEAD/videos/cloverdotfamily). To satisfy original validation filenames, place the main file at `video/clover_concept_main.mp4` and the short file at `video/clover_concept_15s.mp4`.

The original full delivery ZIP already omitted large working takes, intermediate exports and some historical diagnostic files. References to `video/takes/` or `final-validation-v1.json` describe that original workspace evidence; those files are not in this companion ZIP. Seeded take definitions/events, review stills, current final validation, and reproduction tools remain included.

## Restore the instrument bank for score synthesis

Existing WAVs and the playable prototype work without the sound bank. To rerun `audio/compose_score.py`, download the exact upstream bank to `audio/source/GeneralUser-GS.sf2`:

https://raw.githubusercontent.com/mrbumpy409/GeneralUser-GS/684543d5e5efaef08d02be50dcda8d552478fa60/GeneralUser-GS.sf2

Expected bytes: `32319396`. Expected SHA-256:

```
9575028c7a1f589f5770fccc8cff2734566af40cd26ed836944e9a5152688cfe
```

Original upstream license, README, repository response and commit record remain under `audio/source/`. The score script also requires Python, NumPy, SciPy and `libfluidsynth.so.3`. Rendering films from the included final mixes does not require score synthesis.

## Checksums and packaging checks

`DELIVERY-MANIFEST.json` lists every archived file other than itself with exact byte counts and SHA-256 hashes, plus the three exclusions. It replaces the full-package manifest to describe this sources archive accurately.

- Engine: 9 checks passed.
- Browser smoke checks: 7 passed in landscape and 7 in portrait, including loaded fonts, real input, deterministic repeated render and no browser/asset errors.
- Text sources scanned for private key markers and common GitHub/OpenAI/AWS credential signatures; no matches. No credential filenames were found.
- Final ZIP tested for CRC/decompression integrity and manifest hashes; compressed size is below 95 MiB.

The README, progress log and quality report carry the latest delivery authorization. Historical review limitations remain unchanged.
