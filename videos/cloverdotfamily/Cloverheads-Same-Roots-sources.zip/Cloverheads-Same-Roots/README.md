# Cloverheads · Same Roots

An unofficial Encore Studio game concept, built from Clover’s original portraits and illustrated Valley. One little light must visit every different friend to bloom a shared clover. This is a capture prototype and pitch film, not an announced Clover game or mint-allocation system.

## Deliverables

- `video/clover_concept_main.mp4` — 42-second landscape film, 1920×1080, 60fps.
- `video/clover_concept_15s.mp4` — 15-second portrait X cut, 1080×1920, 60fps.
- `prototype/index.html` — single-file HTML/JS canvas application; separately sourced artwork, fonts and audio stay under `art/` and `audio/`.
- `research_brief.md` — opened sources, factual claims and research limitations.
- `art_bible.md`, `art/reference_board.png`, `art/side_by_side.png`, `art/palette.json` — locked identity, exact source comparisons and measured palette.
- `concepts.md` — fifteen ideas, five developed/scored concepts and selection rationale.
- `storyboard.md` — actual capture times, motion graphics and edit plan.
- `quality_report.md`, `review_notes.md` — evidence, strict gate status and remaining weaknesses.
- `DM-description.txt` — two-line proposed pitch text. It has not been sent.
- `AUDIO-SOURCES.md` — original score, instrument license and effect provenance.

## Play locally

From this folder, run `python -m http.server 8000`, then open the local `prototype/index.html` path through that server. The app makes no account connection or external post. Press Space or tap to start; then tap anywhere when the turning root faces an **unlit** friend. Include all four without repeating. M toggles optional sound. The leaderboard uses sample handles; it grants no allocation. The Share on X control prepares text for the player, without posting it.

Landscape and portrait layouts respond to the browser dimensions. All gameplay, title and edit code is inside `prototype/index.html`. Editable source modules remain alongside it; rebuild the HTML after source changes with `python tools/build_prototype.py`.

## Reproduce the films

Requires Python, FFmpeg, Node, Playwright and Chromium. No game backend is needed.

1. `node prototype/engine-checks.cjs`
2. `python tools/build_prototype.py`
3. `node tools/checks.cjs`
4. `node tools/capture.cjs video --mode main --duration 42 --fps 60 --width 1920 --height 1080 --audio audio/clover-main-mix.wav --out video/clover_concept_main.mp4`
5. `node tools/capture.cjs video --mode short --duration 15 --fps 60 --width 1080 --height 1920 --audio audio/clover-15s-mix.wav --out video/clover_concept_15s.mp4`

The deterministic skilled driver calls the same evaluated tap function as real input. It does not inject points or wins. Three seeds, a real mistake/recovery take and timing events are retained in `research/takes.json` and `video/takes/`.

## Sources and limitations

Official art remains Clover’s. Source URLs, returned sizes, hashes and exact filenames are in `art/sources.csv`. Fonts carry their original OFL licenses. The music is an original gentle composition rendered with GeneralUser GS; its license permits commercial music creation. No AI-generated replacement character or image-to-video footage is used.

Only five public X posts were available from the logged-out timeline; the requested 100-post/reply audit was not achieved. The website and newer mint announcement conflict; mint promises are excluded. Proposed character effects are game design inspired by official descriptions, not claimed existing lore. The bots caption is a player challenge rather than a bot-proof claim, because this prototype itself permits scripted capture.

The user subsequently authorized GitHub file delivery in AhmeddNaderr/Encore. These are review files, not a founder-approved public launch. No social post, DM or project contact was made. Read the quality report before treating the cut as approved.

The ZIP contains the requested deliverables, original assets, audio/source licenses and reproducible application/capture tools. Heavy working review screenshots and duplicate intermediate renders are omitted; the reference board, three-frame side-by-side and final corrected frame are included. All diagnostics remain in the workspace project.

## Sources archive contents

This sources ZIP keeps the playable prototype and its artwork, fonts, WAV music and effects, research, design documents, and capture tools. The two finished MP4s are separate repository downloads. The upstream GeneralUser GS sound bank is omitted; its license, pinned source URL and exact SHA-256 are recorded in `ARCHIVE-CONTENTS.md`. See that file for the full inclusion/exclusion list and restore instructions. Historical workspace-only review takes mentioned above are not bundled; the deterministic take definitions/events are in `research/takes.json`.
