# Official art asset inventory

Collected on 2026-10-21 UTC using public official URLs with a browser User-Agent. All stored files are original downloaded bytes. Every file has a source URL, public reference URL, content type, byte count, SHA-256 digest, dimensions where applicable, and access date in `sources.csv`.

## Actual coverage

**29 downloaded files; 28 unique byte contents; 42,883,710 bytes (~40.9 MiB).** All downloads returned HTTP 200. This does not reach 30 distinct artworks; no additional files were fabricated or counted from generated variants.

| Group | Files |
|---|---:|
| Canonical character PNGs | 12 |
| Website environment PNGs | 3 |
| Brand assets / favicon / profile and banner | 6 |
| Official X announcement artworks | 4 |
| Official video thumbnail | 1 |
| Homepage film poster | 1 |
| Official introduction videos | 2 |
| Total | 29 |

`raw/home-clover-original.png` and `raw/card-clover-original.png` have identical content, downloaded from two separately referenced official website URLs. They count as two source files but one unique artwork.

## Character originals

All twelve are **1254 × 1254 RGBA PNGs with real transparency** (alpha channel range 0–255). Their exact names, taglines, categories, and biographies were found in the official gallery code, https://clover.family/cloverheads/app.js?v=flow-demo-9. The original filenames retain the project IDs.

| Canonical character | File | Category |
|---|---|---|
| The Listener | `raw/01-forest-hoodie.png` | earthy |
| Opal Bloom | `raw/19-velvet-cape.png` | dreamy |
| Rain Walker | `raw/04-yellow-raincoat.png` | earthy |
| Retro Bot | `raw/23-space-suit.png` | wild |
| Knit Wanderer | `raw/14-patchwork-cardigan.png` | earthy |
| Nocturne | `raw/10-cropped-leather.png` | wild |
| Porcelain Garden | `raw/31-artist-smock.png` | dreamy |
| Stained Glass | `raw/26-ceremonial-coat.png` | dreamy |
| The Thinker | `raw/06-cream-turtleneck.png` | earthy |
| Ink Poet | `raw/21-quilted-kimono.png` | dreamy |
| Liquid Chrome | `raw/24-tech-shell.png` | wild |
| Paper Dreamer | `raw/29-poncho.png` | wild |

## Environments

Each file is 1672 × 941 RGB PNG, with no alpha channel.

| File | Reference |
|---|---|
| `raw/clover-valley.png` | Main collection HTML image and OpenGraph image; https://clover.family/cloverheads/assets/world/clover-valley.png |
| `raw/kings-study.png` | Study scene in collection HTML; https://clover.family/cloverheads/assets/world/kings-study.png |
| `raw/greenhouse.png` | Background image in official `style.css?v=single-card-10`; https://clover.family/cloverheads/assets/greenhouse.png |

The publicly imported https://clover.family/cloverheads/world.mjs was opened and inspected. It contains no additional external artwork file references. The public card module https://clover.family/cloverheads/pass-card.mjs?v=single-card-10 referenced `assets/brand/clover-original.png`, which was downloaded. The public quest module `live-quest.mjs?v=card-flow-15` contained no additional artwork references.

## X images and video

Assets are referenced in the public project profile https://x.com/cloverdotfamily and its saved timeline JSON. Exact CDN source URLs are recorded in `sources.csv`.

| File | Dimensions / duration | Official post or profile |
|---|---|---|
| `raw/x-profile-400x400.jpg` | 400 × 400 | Project profile; largest rendition explicitly referenced in captured HTML |
| `raw/x-banner-1500x500.jpg` | 1500 × 500 | Project profile; largest rendition explicitly referenced in captured HTML |
| `raw/x-HVEX49MXkAA4AYw.jpg` | 1199 × 675 | Cloverheads announcement, https://x.com/cloverdotfamily/status/2112496434981355626 |
| `raw/x-HVBNOJCXMAAisES.jpg` | 1199 × 675 | Roadmap, https://x.com/cloverdotfamily/status/2112273785751527773 |
| `raw/x-HVASlp8XUAAo4hj.jpg` | 1199 × 675 | Riggles collaboration, https://x.com/cloverdotfamily/status/2112208679462400002 |
| `raw/x-HUiOHltXYAAHpgk.jpg` | 1199 × 675 | Collection partnerships, https://x.com/cloverdotfamily/status/2110093386829205948 |
| `raw/x-lk7rqzBZF0fsEbQ9.jpg` | 1080 × 1080 | Intro video thumbnail, https://x.com/cloverdotfamily/status/2103950119099941208 |
| `raw/x-clover-introduction-1080.mp4` | 1080 × 1080; 18.048 seconds | Highest explicitly referenced MP4 variant of the same intro post |

The four announcement images use their exact `media_url_https` JPEG links returned by the public timeline. The server returned 1199 × 675 bytes; this inventory records actual decoded dimensions rather than the larger dimensions sometimes present in X metadata. Captured X post pages mark announcement imagery “Made with AI”; use these as official project artwork without claiming they were hand-drawn.

## Homepage and brand files

| File | Dimensions / duration | Source role |
|---|---|---|
| `raw/favicon.svg` | Vector | Official Cloverheads favicon |
| `raw/home-clover-avatar.png` | 1254 × 1254 RGB | Homepage favicon / metadata asset |
| `raw/home-clover-original.png` | 1536 × 1024 RGBA | Homepage brand image; actual transparency, alpha 0–254 |
| `raw/card-clover-original.png` | 1536 × 1024 RGBA | Visitor-card brand image, identical bytes to homepage original |
| `raw/home-clover-short-cover.png` | 1080 × 1080 RGBA | Homepage film poster; alpha channel is fully opaque |
| `raw/home-clover-short.mp4` | 1080 × 1080; 18.000 seconds | Homepage “Meet Clover” introduction |

## Verification and limits

- PNG/JPEG files decoded successfully using Pillow for size and channel inspection. MP4 dimensions and durations were read with ffprobe.
- Source CSV and downloaded raw-file counts agree at 29. Each file has a byte count and SHA-256 for subsequent integrity checking.
- No character reinterpretation or image editing occurred during extraction. The root agent owns visual inspection, palette analysis, contact sheets, and any eventual game composition.
- This is the available corpus from the inspected public pages; it is not a claim of exhaustive access to all project art or historical X media.
