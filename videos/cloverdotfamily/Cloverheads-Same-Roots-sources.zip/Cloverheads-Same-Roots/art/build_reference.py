from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
import json,collections
R=Path(__file__).resolve().parent
chars=json.load(open(R.parent/'research/characters.json'))
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def F(n,b=False):return ImageFont.truetype(bold if b else font,n)
board=Image.new('RGB',(1920,1470),'#f3f0df');d=ImageDraw.Draw(board)
d.text((50,30),'CLOVERHEADS / CANONICAL ART',font=F(36,True),fill='#244431')
d.text((50,80),'Official source pixels. Keep the silhouette, face, leaf veins and costume unchanged.',font=F(20),fill='#64735c')
pixels=[]
for i,h in enumerate(chars):
 im=Image.open(R/'raw'/(h['id']+'.png')).convert('RGBA')
 small=im.copy();small.thumbnail((128,128));pixels.extend([(r,g,b) for r,g,b,a in small.getdata() if a>240])
 x=50+(i%6)*310;y=145+(i//6)*390
 tile=Image.new('RGBA',(290,305),h['color']);img=im.copy();img.thumbnail((290,290));tile.alpha_composite(img,((290-img.width)//2,305-img.height));board.paste(tile,(x,y))
 d.text((x,y+318),h['name'],font=F(20,True),fill='#244431')
 d.text((x,y+348),h['category'].upper(),font=F(12),fill='#64735c')
# Quantize the actual opaque pixels of all twelve original character images.
strip=Image.new('RGB',(len(pixels),1));strip.putdata(pixels)
q=strip.quantize(colors=10,method=Image.Quantize.MEDIANCUT)
pal=q.getpalette();counts=sorted(q.getcolors(),reverse=True)
colors=[]
for n,idx in counts:
 rgb=tuple(pal[idx*3:idx*3+3]);colors.append({'hex':'#%02x%02x%02x'%rgb,'rgb':rgb,'opaque_pixel_count':n})
(R/'palette.json').write_text(json.dumps({'method':'Median-cut quantization of alpha>240 pixels from 128px samples of all 12 canonical source images','sampled_files':[h['id']+'.png' for h in chars],'colors':colors},indent=2))
for i,c in enumerate(colors):
 x=50+i*183;d.rounded_rectangle((x,970,x+165,1035),radius=10,fill=c['hex']);d.text((x+15,1046),c['hex'],font=F(19),fill='#244431')
for j,name in enumerate(['clover-valley.png','kings-study.png','greenhouse.png']):
 im=Image.open(R/'raw'/name).convert('RGB');im.thumbnail((580,330));x=50+j*620;board.paste(im,(x,1110));d.text((x,1440),name,font=F(16),fill='#244431')
board.save(R/'reference_board.png')
print(json.dumps(colors,indent=2))
