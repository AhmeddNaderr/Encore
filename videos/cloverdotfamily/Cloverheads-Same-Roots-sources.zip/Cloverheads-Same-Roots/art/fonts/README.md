# Packaged typography

Downloaded 2026-10-21 from the official Google Fonts GitHub repository. These are close production matches for the official site's rounded Arial/Trebuchet and Georgia typography; they are not claimed to be the project's original fonts.

- `Nunito-Variable.ttf`: upright, weight 200–1000. Use 400 for body/UI and 700–800 for rounded headings.
- `Lora-Variable.ttf`: upright, weight 400–700. Use 400 for bookish story/detail text.
- `Lora-Italic-Variable.ttf`: italic, weight 400–700. Use 400 for short storybook accents.
- `fonts.css`: local `@font-face` declarations with family names `Clover Nunito` and `Clover Lora`.
- `Nunito-OFL.txt`, `Lora-OFL.txt`: original SIL Open Font License 1.1 files.
- `sources.csv`: original download URLs, repository reference URLs, byte counts, and SHA-256 digests.

Verified TTF readability and variable font axes with fontTools. For canvas/video rendering, load the stylesheet and await `document.fonts.load('700 40px "Clover Nunito"')`, `document.fonts.load('400 40px "Clover Lora"')`, `document.fonts.load('italic 400 40px "Clover Lora"')`, and `document.fonts.ready` before drawing text.

Official upstream directories:

- https://github.com/google/fonts/tree/main/ofl/nunito
- https://github.com/google/fonts/tree/main/ofl/lora

Keep the applicable OFL files with redistributed font files.

## Brand mark inspection

Among the downloaded originals, `../raw/home-clover-original.png` is the transparent brand mark source; `../raw/card-clover-original.png` is byte-identical. It is a 1536 × 1024 sheet containing the main Clover wordmark and two smaller clover symbols, with a soft green glow and transparent background. It is not a single tightly cropped logo.

`../raw/favicon.svg` is a clean scalable official icon, but includes its own opaque cream rounded-square backing. `../raw/home-clover-avatar.png` and the X profile JPEG have opaque backgrounds. No separate tightly cropped transparent wordmark was found among the downloaded original assets. No brand file was edited during this inspection.
