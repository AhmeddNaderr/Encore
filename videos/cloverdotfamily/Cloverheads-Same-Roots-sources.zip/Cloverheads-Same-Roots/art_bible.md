# Cloverheads — locked art bible

## Sources and art audit
Opened all twelve canonical portraits together in `art/reference_board.png`, plus full-resolution The Listener, Rain Walker and Clover Valley. These are official 1254×1254 transparent PNG portraits; the three official environments are 1672×941. The inventory and URL/hash manifest are in `art/asset_inventory.md` and `art/sources.csv`. Twenty-nine downloadable source files were located (one duplicate by hash); the 30+ target was not reached by inventing assets or padding the inventory.

## Visual identity
Painterly dimensional illustration, rather than flat vectors or low-poly 3D. Leaf heads have four heart-shaped lobes, a narrow green stem neck, deep green contour shading, visible veins and brush texture. The leaf head occupies roughly the upper two thirds of the square portrait; clothing fills the lower third. The three-quarter face has half-lidded almond eyes, dark upper eyelids, small angled brows and a restrained smile. Preserve each character's distinct material: real leaf, knitted yarn, paper fold, porcelain, metal or stained glass. Warm light comes principally from the upper right in the principal green portraits; the Valley uses warm backlight, lantern glow and deep forest shadows.

The official world uses storybook rooms, wood, gilt frames, moss, paper and botanical forms. Its UI uses cream paper, forest ink, rounded headings and Georgia-like serif storytelling. Use a deliberate rounded sans / warm book-serif pairing, packaged locally; do not substitute a sci-fi HUD. Build new score/UI typography as a concept layer, without fabricating official logos.

## Measured palette
Median-cut quantization of opaque pixels (alpha > 240) from 128px samples of **all twelve** source portraits. Exact method, sample filenames and counts: `art/palette.json`.

| Hex | Role |
|---|---|
| `#24432a` | Deep forest / dominant leaf shadows |
| `#415d2d` | Main moss green |
| `#667f4e` | Soft foliage midtone |
| `#c9cd9c` | Pale leaf / mist |
| `#f1e6b5` | Warm ivory / highlights |
| `#ecd18d` | Golden glow / success |
| `#aa9976` | Aged paper / warm neutral |
| `#6c5f42` | Wood / muted brass |
| `#513f35` | Dark warm wood |
| `#191a1c` | Eye / deepest contour |

Website UI tokens additionally verified in official CSS: paper `#f3f0df`, ink `#244431`, forest `#244b35`, butter `#eceb9e`. These are CSS evidence, not sampled-image colors.

## Canonical references and invariants
Use the original PNG as the sole canonical reference for each character. Primary cast: The Listener (`01-forest-hoodie.png`), Rain Walker (`04-yellow-raincoat.png`), The Thinker (`06-cream-turtleneck.png`), and Paper Dreamer (`29-poncho.png`). Supporting portraits can use the remaining eight originals. World: `clover-valley.png`; secondary room: `kings-study.png`; plant detail: `greenhouse.png`. Official Clover logo: downloaded original mark / favicon, never a guessed replacement. Encore logo: original supplied silver six-column mark, used at the end.

Never change the four-leaf silhouette, eye arrangement, brow/expression, vein patterns, costume, material, or character-specific pale leaf. Preserve original alpha and source aspect ratio. Small head nods and torso breathing may use cut-out layers from the same pixels. Keep deformation restrained; squash the reaction framing/glow before warping the face.

## Forbidden
No replacement 3D model, generic fantasy character, new AI face, extra limbs, anime-eye redesign, pixel art, neon cyberpunk palette, random costume, financial reward promise, or partner logo as invented game canon. Do not treat a generic stock illustration as a project prop. New interface curves, particles and score indicators are UI/effects, not claimed collection art.

## Gate A status
**PASS / source fidelity evidence opened.** Phase4 produced `art/side_by_side.png`: actual source0.733/3.550/14.000 game frames beside the original Listener/Rain Walker/Thinker portraits. Opened and checked the four-lobe silhouette, pale leaf, eyes, veins, costume and material; independent reviewer awarded art9. No drift or replacement face observed. This art pass does not pass the separate overall quality gate.
