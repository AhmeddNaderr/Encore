"""Original Clover score and synthesized effects. Reproducible, no sampled tracks.
GeneralUser GS musical instruments: official license retained in source/.
"""
from pathlib import Path
import ctypes as C, math, json, wave
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
ROOT=Path(__file__).resolve().parent
SR=48000
lib=C.CDLL('libfluidsynth.so.3')
def bind(name, rest, args):
 f=getattr(lib,name);f.restype=rest;f.argtypes=args;return f
ptr=C.c_void_p;I=C.c_int;F=C.c_float;D=C.c_double;S=C.c_char_p
newset=bind('new_fluid_settings',ptr,[])
num=bind('fluid_settings_setnum',I,[ptr,S,D]);integer=bind('fluid_settings_setint',I,[ptr,S,I])
newsynth=bind('new_fluid_synth',ptr,[ptr]);load=bind('fluid_synth_sfload',I,[ptr,S,I])
program=bind('fluid_synth_program_change',I,[ptr,I,I]);cc=bind('fluid_synth_cc',I,[ptr,I,I,I])
on=bind('fluid_synth_noteon',I,[ptr,I,I,I]);off=bind('fluid_synth_noteoff',I,[ptr,I,I])
write=bind('fluid_synth_write_float',I,[ptr,I,ptr,I,I,ptr,I,I]);delete=bind('delete_fluid_synth',None,[ptr]);delset=bind('delete_fluid_settings',None,[ptr])
def wav(path,y):
 y=np.asarray(y); y=np.clip(y,-.98,.98)
 with wave.open(str(path),'wb') as w:
  w.setnchannels(1 if y.ndim==1 else y.shape[1]);w.setsampwidth(2);w.setframerate(SR);w.writeframes((y*32767).astype('<i2').tobytes())
def render(events,duration):
 st=newset();num(st,b'synth.sample-rate',SR);num(st,b'synth.gain',.53)
 num(st,b'synth.reverb.room-size',.73);num(st,b'synth.reverb.damp',.45);num(st,b'synth.reverb.width',80);num(st,b'synth.reverb.level',.29)
 integer(st,b'synth.chorus.active',0);sy=newsynth(st);load(sy,str(ROOT/'source/GeneralUser-GS.sf2').encode(),1)
 # Music instruments: harp, grand piano, flute, celesta, soft strings.
 for ch,pr,pan,vol in [(0,46,44,77),(1,0,76,51),(2,73,67,64),(3,8,87,54),(4,48,61,38)]:
  program(sy,ch,pr);cc(sy,ch,10,pan);cc(sy,ch,7,vol);cc(sy,ch,91,38)
 schedule=[]
 for t,ch,p,d,v in events:
  schedule.append((max(0,round(t*SR)),1,ch,p,v));schedule.append((max(0,round((t+d)*SR)),0,ch,p,0))
 schedule.sort();N=round(duration*SR);out=np.zeros((N,2),dtype=np.float32);last=0
 for frame,typ,ch,p,v in schedule+[(N,2,0,0,0)]:
  frame=min(N,frame)
  if frame>last:
   n=frame-last;a=np.empty(n,dtype=np.float32);b=np.empty(n,dtype=np.float32)
   write(sy,n,a.ctypes.data,0,1,b.ctypes.data,0,1);out[last:frame,0]=a;out[last:frame,1]=b;last=frame
  if typ==1:on(sy,ch,p,v)
  elif typ==0:off(sy,ch,p)
  if last>=N:break
 delete(sy);delset(st)
 # Gentle fade and broad natural stereo warmth.
 out*=np.minimum(np.arange(N)/(.10*SR),1)[:,None]
 out*=np.minimum(np.arange(N)[::-1]/(1.35*SR),1)[:,None]
 return out

BEAT=5/6;BAR=BEAT*3
chords=[([43,50,55,59,62,69],55),([42,50,57,62,66,69],54),([40,47,52,55,59,66],52),([36,43,48,52,55,62],48),([45,52,57,60,64,67],57),([38,45,50,55,57,64],50),([47,50,55,59,62,67],55),([36,43,48,52,55,62],48),([40,47,52,55,59,66],52),([36,43,48,52,55,62],48),([43,50,55,59,62,69],55),([38,45,50,54,57,64],50),([36,43,48,52,55,62],48),([38,45,50,54,57,64],50),([43,50,55,59,62,69],55),([43,50,55,59,62,67],55)]
melodies={2:[(0,74,1),(1,71,.7),(2,69,.8)],3:[(0,67,1.5),(2,64,.7)],4:[(.25,69,.6),(1,72,.6),(2,71,.8)],5:[(0,69,1.7)],6:[(0,71,.75),(1,74,.75),(2,76,.8)],7:[(0,74,1),(1.5,71,.8)],8:[(0,79,1),(1.25,78,.6),(2,76,.8)],9:[(0,74,.75),(1,72,.7),(2,71,.8)],10:[(0,71,1),(1.5,69,1)],11:[(0,69,1.5),(2,66,.7)],12:[(0,67,1),(1,72,.8),(2,71,.8)],13:[(0,69,1),(1,66,.75),(2,69,.7)],14:[(0,71,1),(1,74,.8),(2,79,.9)],15:[(0,79,1.8)]}
def score(indices,duration,short=False):
 ev=[]
 for bar,idx in enumerate(indices):
  notes,base=chords[idx];start=bar*BAR+.12
  if bar<len(indices)-1:
   ar=[notes[0]+12,notes[2],notes[3],notes[4],notes[2],notes[5]]
   for k,p in enumerate(ar):ev.append((start+k*BEAT/2,0,p,BEAT*.88,[43,34,39,41,34,39][k]))
  else:
   for k,p in enumerate([notes[0]+12,notes[2],notes[3],notes[4],notes[5]]):ev.append((start+k*.055,0,p,2.5,48-k*2))
  for j,p in enumerate([notes[0],notes[2],notes[4]]):ev.append((start+j*.035,1,p,2.15,35 if j==0 else 29))
  # Strings breathe gently into later harmony, with no percussion build.
  if (bar>=4 and not short) or (short and bar>=2):
   for p in [notes[2],notes[3],notes[4]]:ev.append((start+.08,4,p,2.2,28 if bar<12 else 33))
  if not short and idx in melodies:
   for b,p,d in melodies[idx]:ev.append((start+b*BEAT,2,p,d*BEAT,48 if idx<8 else 52))
  if short:
   motif={0:[(0,74,.8),(1,71,.8),(2,69,.8)],1:[(0,67,1.6)],2:[(0,72,1),(1.5,71,.8)],3:[(0,69,1),(1.5,66,.8)],4:[(0,67,1.9)]}
   for b,p,d in motif.get(bar,[]):ev.append((start+b*BEAT,2,p,d*BEAT,49))
  if bar in [0,1,6,7,10,14] or (short and bar in [0,2,4]):
   for delay,p in [(.11,notes[4]+12),(.47,notes[3]+12),(.92,notes[2]+12)]:ev.append((start+delay,3,p,1.15,37 if bar<12 else 43))
 return render(ev,duration),ev
main,ev=score(list(range(16)),42)
# Normalize both cue edits to a gentle integrated music bed; final SFX mix follows event timings.
peak=float(np.abs(main).max()); gain=.40/max(peak,.00001);main*=gain
wav(ROOT/'music-42s.wav',main)
short,se=score([0,3,4,13,15],15,True);short*=gain;wav(ROOT/'music-15s.wav',short)
(ROOT/'composition-events.json').write_text(json.dumps({'tempo_bpm':72,'meter':'3/4','key':'G major','main_duration':42,'main_notes':ev,'short_notes':se},indent=2))

rng=np.random.default_rng(223)
def tone(freq,dur,harm=(1,.30,.10),decay=3.5):
 t=np.arange(int(SR*dur))/SR;y=np.zeros_like(t)
 for k,a in enumerate(harm,1):y+=a*np.sin(2*np.pi*freq*k*t+.13*k)*np.exp(-decay*t*(1+.3*(k-1)))
 y*=np.minimum(t/.012,1)*np.minimum((dur-t)/.10,1);return y

def reverb(y,decay=.7):
 z=np.zeros(len(y)+int(SR*.45));z[:len(y)]=y
 for d,g in [(.053,.12),(.087,.08),(.137,.06),(.221,.04)]:
  ix=int(d*SR);z[ix:ix+len(y)]+=y*g
 return z

def effect(name,y,level):
 y=reverb(y);y*=level/max(np.abs(y).max(),.001);wav(ROOT/'sfx'/name,y)
# Physically soft, round plucked notes with inharmonic finger transient.
t=np.arange(int(.24*SR))/SR
pluck=tone(783.991,.24,(1,.24,.065),18)+rng.normal(0,.006,len(t))*np.exp(-90*t)
effect('tap-soft.wav',pluck,.22)
effect('tap-warm.wav',tone(659.255,.32,(1,.28,.07),13),.19)
# Short pass chime, two airy tones; avoids piercing glass tones.
y=np.zeros(int(1.1*SR))
for d,f,a in [(0,1046.5,1),(.13,1567.98,.55)]:
 q=tone(f,.78,(1,.1,.015),5)*a;ix=int(d*SR);y[ix:ix+len(q)]+=q
effect('firefly-pass.wav',y,.23)
# Full-clover bloom: gently swelling G add9, moving upward through small lights.
y=np.zeros(int(2.7*SR));tt=np.arange(len(y))/SR
for i,f in enumerate([392,493.883,587.33,783.991,1174.66]):
 onset=i*.105;q=tone(f,2.7-onset,(1,.14,.03),2.2);ix=int(onset*SR);y[ix:ix+len(q)]+=q*.42
cloud=sum(np.sin(2*np.pi*f*tt) for f in [196,246.942,293.665,391.995])*.05
cloud*=np.sin(np.clip(tt/2.7,0,1)*np.pi)**2
y+=cloud
effect('clover-bloom.wav',y,.34)
# UI leaf/paper movement, quiet tactile feedback, never a buzz or alarm.
noise=rng.normal(0,1,int(.36*SR));noise=sosfilt(butter(2,[800,3400],fs=SR,btype='bandpass',output='sos'),noise)
noise*=np.sin(np.linspace(0,np.pi,len(noise)))**3*.03
effect('ui-leaf.wav',noise,.045)
effect('ui-open.wav',tone(440,.38,(1,.12,.02),9)+tone(659.255,.38,(1,.08,.01),12)*.45,.12)
print(json.dumps({'main_peak_dbfs':20*math.log10(np.max(np.abs(main))),'short_peak_dbfs':20*math.log10(np.max(np.abs(short))),'stereo':True,'sample_rate':SR,'main_duration':len(main)/SR,'short_duration':len(short)/SR},indent=2))
