"""Map source-engine event times through the locked trailer edit, without guessing actions."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
edit=json.loads((PROJECT/'prototype/edit.json').read_text())
takes=json.loads((PROJECT/'research/takes.json').read_text())
mapping={'arrival':'firefly-pass','bloom':'clover-bloom','miss':'tap-warm','tap':'tap-soft'}
gains={'arrival':.26,'bloom':.48,'miss':.65,'tap':.65}
pan={0:-.24,1:.24,2:.24,3:-.24}
result={}
for name,key in [('main','42'),('short','15')]:
 events=[]
 for shot_index,shot in enumerate(edit[name]):
  if shot['type']!='gameplay':continue
  lo=shot['source'];hi=lo+shot['end']-shot['start']
  for event in takes[shot['take']]['events']:
   if event['type'] not in mapping:continue
   if event['type']=='tap' and not event.get('accepted'):continue
   if not lo<=event['time']<hi:continue
   t=shot['start']+event['time']-lo
   gain=gains[event['type']]
   if event['type']=='bloom' and t<1:gain=.74
   events.append({'time':round(t,6),'sound':mapping[event['type']],'gain':gain,'pan':pan.get(event.get('target'),0),'origin':'engine','source_type':event['type'],'source_time':event['time'],'take':shot['take'],'source_event_id':event['id'],'shot_index':shot_index})
 ui=[(25,'ui-open',.66,'leaderboard'),(27,'firefly-pass',.32,'rank'),(29,'clover-bloom',.35,'result'),(32,'ui-open',.56,'share'),(35,'ui-leaf',.85,'family'),(38,'clover-bloom',.42,'end')] if name=='main' else [(9,'ui-open',.66,'leaderboard'),(10.4,'firefly-pass',.32,'rank'),(11.25,'ui-open',.56,'share'),(13,'clover-bloom',.42,'end')]
 for t,s,g,label in ui:events.append({'time':t,'sound':s,'gain':g,'pan':0,'origin':'ui','label':label})
 result[key]=sorted(events,key=lambda e:e['time'])
(ROOT/'trailer-events.json').write_text(json.dumps(result,indent=2))
for dur,events in result.items():
 print(dur,'seconds:',len(events),'events;',len([e for e in events if e['origin']=='engine']),'mapped engine events')
 print('Bloom times:',[e['time'] for e in events if e['sound']=='clover-bloom'])
