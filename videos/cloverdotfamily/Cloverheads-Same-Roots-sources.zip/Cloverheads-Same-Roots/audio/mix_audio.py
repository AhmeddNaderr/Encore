"""Mix storybook music with explicit timeline events and master both trailer edits.
Usage: python mix_audio.py [timeline.json]
Timeline format: {"42":[{"time":4.2,"sound":"tap-soft","gain":0.6,"pan":-0.2}],"15":[...]}
All event placements remain visible in mix-events.json. Sound files are original.
"""
from pathlib import Path
import wave,json,sys,subprocess,math,shutil
import numpy as np
ROOT=Path(__file__).resolve().parent
SR=48000

def read(p):
 with wave.open(str(p)) as w:
  assert w.getframerate()==SR and w.getsampwidth()==2
  y=np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(np.float64)/32768
  return y.reshape(-1,w.getnchannels())

def write(p,y):
 with wave.open(str(p),'wb') as w:
  w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes(np.clip(y*32767,-32768,32767).astype('<i2').tobytes())

def run(args):
 p=subprocess.run(['ffmpeg','-y','-hide_banner',*args],capture_output=True,text=True,check=True)
 return p.stderr

def master(src,dst):
 filt='loudnorm=I=-18:TP=-1.5:LRA=9:print_format=json'
 log=run(['-i',str(src),'-af',filt,'-f','null','-'])
 m=json.loads(log[log.rfind('{'):log.rfind('}')+1])
 filt2='loudnorm=I=-18:TP=-1.5:LRA=9:measured_I={input_i}:measured_TP={input_tp}:measured_LRA={input_lra}:measured_thresh={input_thresh}:offset={target_offset}:linear=true:print_format=json'.format(**m)
 log=run(['-i',str(src),'-af',filt2,'-ar',str(SR),'-c:a','pcm_s24le',str(dst)])
 stats=json.loads(log[log.rfind('{'):log.rfind('}')+1])
 run(['-loglevel','error','-i',str(dst),'-c:a','aac','-b:a','256k',str(dst.with_suffix('.m4a'))])
 return stats

events=json.loads(Path(sys.argv[1]).read_text()) if len(sys.argv)>1 else {'42':[],'15':[]}
report={}
for dur in [42,15]:
 music=read(ROOT/f'music-{dur}s.wav');out=music.copy();gain=np.ones(len(music))
 for event in events.get(str(dur),[]):
  t=float(event['time']);name=event['sound'];assert name in ['tap-soft','tap-warm','firefly-pass','clover-bloom','ui-leaf','ui-open']
  sound=read(ROOT/'sfx'/f'{name}.wav')[:,0]*float(event.get('gain',1))
  pan=max(-1,min(1,float(event.get('pan',0))))
  stereo=np.stack([sound*math.cos((pan+1)*math.pi/4),sound*math.sin((pan+1)*math.pi/4)],axis=1)
  start=round(t*SR);end=min(len(out),start+len(stereo))
  if start>=0 and start<end:out[start:end]+=stereo[:end-start]
  # An understated 1.8 dB dip allows a bloom to breathe over the score.
  if name=='clover-bloom':
   tt=np.arange(len(gain))/SR;envelope=np.clip((tt-t+.08)/.2,0,1)*np.clip((t+2.6-tt)/.6,0,1)
   gain*=10**(-1.8/20*envelope)
 out+=music*(gain-1)[:,None]
 # Fade the complete mix, including any effect tail crossing the short end card.
 out*=np.minimum(np.arange(len(out))/(.035*SR),1)[:,None]
 out*=np.minimum(np.arange(len(out))[::-1]/(.85*SR),1)[:,None]
 write(ROOT/f'premix-{dur}s.wav',out)
 report[str(dur)]=master(ROOT/f'premix-{dur}s.wav',ROOT/f'final-mix-{dur}s.wav')
for dur,name in [(42,'clover-main-mix'),(15,'clover-15s-mix')]:
 for ext in ['wav','m4a']:shutil.copyfile(ROOT/f'final-mix-{dur}s.{ext}',ROOT/f'{name}.{ext}')
(ROOT/'mix-events.json').write_text(json.dumps(events,indent=2))
(ROOT/'final-mix-loudness.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
