# Phase 3 — Cloverheads game concepts

All mechanics below are proposed Encore concept design. They are not claims about official abilities, roadmap, or mint rewards. Lore grounding comes from the opened sources in `research_brief.md`; the primary art constraint is the four original transparent busts and official Clover Valley image.

## Fifteen one-line ideas

1. **Leaf Brawl — reject.** You spar to become Clover Valley's champion while changing leaf traits; a generic fighter invents conflict absent from the welcoming family lore.
2. **Valley Dash — reject.** You run to collect fireflies while wearing different family outfits; an endless runner makes the family only a costume.
3. **Clover Match — reject.** You match leaves to grow the Valley while swapping colours; a match-3 reskin does not use different stories or curiosities.
4. **King's Climb — reject.** You jump to reach the King's study while collecting invitations; a generic platformer also needs unavailable full-body poses.
5. **Flappy Firefly — reject.** You flap to cross the Valley while avoiding branches; the official guiding-light motif alone does not distinguish the mechanic.
6. **Curiosity Sort — reject after review.** You notice each firefly's symbol to send it to a matching family member while requests accelerate; four-bin sorting still works with unrelated portraits.
7. **Same Roots.** You pass one little light through every family member to bloom a shared clover while one rotating root makes timing and visiting different people matter.
8. **Curiosity Relay.** You pass a little light through two complementary curiosities to finish a story while the next recipient changes on every return to the shared root.
9. **Four-Leaf Chorus.** You listen and pass a phrase among four different voices to light the Valley while every new voice changes the shared rhythm.
10. **Fold the Forecast.** You fold a route for Rain Walker to gather rainy-day stories while Paper Dreamer's single crease changes all four leaf paths together.
11. **Family Storyweaver.** You link each family member's small discovery to complete the King's storybook while a single thread must include every different story.
12. **Borrowed Light.** You share a limited glow to keep the family visible while each friend's curiosity consumes and returns light at a different rate.
13. **A Detail Worth Keeping.** You notice tiny changes across family portraits to restore a shared memory while the Thinker's question changes which detail matters.
14. **Scenic Root.** You take the scenic route to collect Knit Wanderer's stories while every detour must return to the family's common stem.
15. **Invitation Chorus.** You welcome differently curious visitors into a four-leaf gathering while the seating must let each neighbour share a story neither already knows.

The first five are intentionally discarded. Six is discarded despite easy buildability. Thirteen risks becoming a conventional spot-the-difference game; fourteen and fifteen need additional illustrated locations or visitors to explain themselves quickly.

## Five developed cards

### 1. Same Roots — selected

**Rule:** Tap when the turning root faces an unlit friend; pass the same little light through all four friends exactly once to bloom their shared clover.

**30-second loop:** Begin with one light at the centre and four empty leaf indicators. A clearly drawn gold root arm turns between the four canonical portraits. Tap/click/Space when it lines up with an unvisited portrait's opening. The light follows a curved root outward, the portrait gives a restrained nod, its leaf fills, and that same light returns to the centre. Repeat with the remaining different friends. Four distinct visits create a large four-leaf bloom and begin a faster relay. A mistimed tap or repeat drains only the unfinished bloom; the timer and score continue. At 30 seconds, show score, best bloom streak, sample rank and share card. Restart is one tap.

**Lore fit:** Four familiar leaf shapes literally meet at one common stem, and progress requires including every different story. Fireflies are the guiding little lights. Character personalities influence the next pass, using the official Listener, Rain Walker, Thinker and Paper Dreamer portraits. Sharing with everyone is the action, rather than a generic contest dressed in their artwork.

**Score:** 100 per valid visit; +50 for a precise centre-of-opening tap; +400 for completing all four distinct members. Consecutive completed blooms build a multiplier, capped at ×3. A miss resets the unfinished four-leaf set and multiplier, preserving earned score. The final score alone sets the illustrative leaderboard rank.

**Share moment:** A completed clover formed from the four untouched portrait crops surrounds “4 stories. 1 shared root.” The result card records score, blooms and best streak, with the player's most-visited character. Sample WL leaderboard is clearly a concept and grants no allocation.

**Originality limit:** The timing input has familiar arcade roots. The distinctive combination is a persistent shared light, mandatory inclusion of four different members, a common stem that visibly blooms, and curiosity effects that change the next handoff. Four coloured bins would erase that combination, which is why the sorting version was rejected.

### 2. Curiosity Relay

**Rule:** Route each light through an ordered pair of different family members before returning it to the common root.

**30-second loop:** A two-portrait request appears; tap the first recipient as the root faces them, then the second as the light returns. Each completed pair adds one story. Requests overlap and rotate; a wrong recipient tangles that story. Complete pairs until time expires, then restart.

**Lore fit:** A little light becomes a shared experience because different curiosities contribute in sequence. All four appearances and personality names remain canonical; the pairing rules are new design.

**Score:** 200 per pair, 100 extra for a new pairing, and a family bonus when all four members have contributed during the current chain.

**Share moment:** A small illustrated “story recipe” records the player's strongest duo and longest chain.

**Weakness:** A first-time viewer must read an order and track two destinations. At trailer speed the pair requests compete with the portraits and moving light; this loses the five-second clarity gate.

### 3. Four-Leaf Chorus

**Rule:** Pass the Listener's pulse to every different family voice without dropping the common beat.

**30-second loop:** Hear and see a four-step phrase, tap the matching portrait windows as the pulse travels through the root, then repeat a longer variation. A missed beat dims the phrase; the next phrase begins immediately. End on longest family chorus and restart.

**Lore fit:** The Listener shares songs, and a family becomes a chorus through different contributions. Visual pulse rings carry all timing information with the sound off.

**Score:** Correct-beat streak, precision and four-voice phrase completions.

**Share moment:** A four-leaf waveform card plays back the player's best short phrase.

**Weakness:** The core is recognisably a rhythm game. A convincing original soundtrack and musical result sharing would also consume the available build time.

### 4. Fold the Forecast

**Rule:** Fold one shared clover path to carry Rain Walker's rainy-day light home while keeping every leaf connected.

**30-second loop:** A rainy path enters the centre; drag a crease to fold two connected root segments together. The light moves continuously, so the next crease must be ready before it arrives. Deliver a light, receive a harder route, fail when a crease disconnects a leaf, restart instantly.

**Lore fit:** Paper Dreamer's folded imagination changes a world Rain Walker is happy to explore. Four connected leaf paths preserve the shared-root motif.

**Score:** Delivered lights, fewest folds and unbroken connection streak.

**Share moment:** A replayable gold route unfolds from a paper clover around the two portraits.

**Weakness:** The project has a paper character, not a verified folding-world mechanic. The fold geometry needs new environment art or unusually polished procedural rendering; legibility and five-day reliability are poor.

### 5. Family Storyweaver

**Rule:** Draw one unbroken shared thread through different curiosities to complete a page of the King's storybook.

**30-second loop:** Four family portraits reveal short visual story cues. Drag a thread between them, including each once while avoiding crossed root strands. The finished page turns into a denser arrangement. Crossed threads erase that page's current chain; the timer keeps running. Show completed pages and restart.

**Lore fit:** The official storybook, Knit Wanderer's collected stories and the family slogan all support a shared narrative. The one thread gives common roots a mechanical purpose.

**Score:** Completed pages, distinct contributors and thread efficiency.

**Share moment:** A miniature storybook page displays the player's final thread and featured family members.

**Weakness:** It trends toward a familiar connect-the-dots puzzle, and its quieter drawing action is less strong for a three-second gameplay hook.

## Comparison

Scores are design judgements before prototype evidence, not claims of a passed final quality gate. Ten means exceptional with no major unresolved concern; seven means credible but with a stated limitation.

| Concept | Lore fit | Originality | 5s clarity | Replay | Share | Trailer | 5-day build | Total /70 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **Same Roots** | **9** | **7** | **9** | **8** | **8** | **9** | **9** | **59** |
| Curiosity Relay | 9 | 8 | 6 | 8 | 8 | 8 | 8 | 55 |
| Four-Leaf Chorus | 8 | 6 | 8 | 8 | 8 | 8 | 7 | 53 |
| Fold the Forecast | 8 | 8 | 6 | 8 | 8 | 8 | 6 | 52 |
| Family Storyweaver | 9 | 7 | 7 | 7 | 8 | 7 | 8 | 53 |

Same Roots clears 56/70 and has no fit/originality/clarity score below seven. Its originality receives seven, reflecting the familiar timing foundation; the family inclusion and shared-light loop must remain visible in the build to retain that score. Its clarity score assumes the root pointer, open destination, and already-lit leaves are unambiguous; prototype review may lower it.

## Winner — three-line reason

**Same Roots** makes “same roots, different stories” the win condition: one light must include all four different family members.
One timed tap creates readable moving-light arcs, exact-art character reactions and a full-clover celebration without needing unavailable full-body animation.
The single central mechanism supports a polished browser slice, stronger timing under pressure, a family-shaped score card, and both landscape and portrait framing.

## Phase 4 implementation contract

- **One input:** pointer/touch press anywhere on the playfield or Space. A small visible tap pulse marks each actual input. Ignore presses while a light is travelling; do not queue hidden actions. Result screen buttons have separate ordinary UI hit targets.
- **Layout:** four original transparent busts at four clover lobes around one common root; official Valley behind them. The same state machine reflows for 1920×1080 and 1080×1920. Preserve all original faces, clothes, alpha and aspect ratios.
- **States:** `ready → atRoot → outbound → portraitReaction → returning → atRoot`; fourth unique visit returns into `bloom → atRoot`. A bad tap uses `miss → atRoot`. At 30 seconds, finish an already-triggered animation for at most 0.7 seconds without awarding events triggered after zero, then `results`.
- **Root timing:** the gold arm rotates continuously, starting around 105°/s and rising toward 155°/s over the round. Four destination openings are centred on portrait bearings. Begin with ±22° acceptance; precise hits are ±7°. Keep openings visibly drawn and do not shrink below ±17°. If motion easing alters travel duration, scoring still uses game time, never frame count.
- **Tap evaluation:** atRoot only; choose the nearest portrait bearing. A tap outside its opening is a miss. A tap aimed at a member already present in `visitedMask` is a repeat miss. A valid tap sends the same light to that portrait and adds its bit. The leaf indicator visibly fills on arrival. All four bits complete the bloom on return and reset the mask for the next shared light.
- **Travel:** roughly 0.28 seconds outward, 0.10-second nod, 0.25 seconds returning. The visible path stays attached to the common root and the chosen portrait's lobe. Only one game-critical light is active; decorative fireflies remain smaller and dimmer.
- **Personality effects, automatic:** Listener slows the next root turn by 15%; Rain Walker widens the next acceptance window by 3°; Thinker briefly brightens the next unvisited opening in the direction of rotation; Paper Dreamer folds the return curve into a shorter 0.18-second return and grants a small visible speed bonus of 50. Keep these secondary to the single tap rule. These are concept abilities inspired by descriptions, never represented as existing canon. If any effect reduces readability, remove the effect rather than add a second control.
- **Failure:** a 0.18-second warm amber dim/pulse, current mask and multiplier reset, score retained, no violent hit or combat framing. Time continues. The next light is ready immediately after the pulse.
- **Score contract:** valid visit +100; precise +50; Paper Dreamer speed bonus +50; completed bloom +400. Apply the current multiplier to these gains. Start ×1, increase by one after every completed bloom up to ×3, reset to ×1 on miss. Store score, bloom count, precise hits, longest bloom streak, visits per member and elapsed time.
- **Readable UI:** score, 30-second countdown, four-leaf progress, multiplier; compact action text “Tap. Light every leaf once.” Keep all glyphs and circles clearly part of the UI/effects, not invented collection props.
- **Capture API suggestion:** expose deterministic `reset(seed)`, `tap()`, `step(dt)`, and a read-only snapshot with angle, state, active light, visitedMask, score, timeRemaining, openings and effects. Scripted capture must call the same `tap()` evaluated by real input and must not inject scores or fabricated wins.
- **Results:** illustrative top-ten WL leaderboard using `holder_01` style handles, clearly labelled sample / concept; share card and Share on X control. Do not imply an official mint allocation or send/post any message during production.

**Phase 3 decision:** complete. Phase 4 can begin. Art Gate A and Play Gate B remain FAIL until real prototype evidence is opened and recorded.
