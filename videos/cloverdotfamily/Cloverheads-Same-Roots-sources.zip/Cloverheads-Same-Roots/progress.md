# Clover game concept production

Active brief: user-supplied game-concept-master-prompt.md, for @cloverdotfamily.

## Status
- Phase 1 research: SAVED in research_brief.md. Official profile, five accessible posts, sites and character lore reviewed; 100-post coverage unavailable and documented.
- Phase 2 extraction/art bible: SAVED. 29 original source files (28 unique); 12 reference portraits and three environments inspected. Pixel-sampled palette and reference board saved. Gate A remains FAIL until actual prototype frames exist.
- Phase 3 concepts: SAVED in concepts.md. SAME ROOTS selected: 59/70 design score, originality 7/10 with stated limits.
- Phase 4 prototype/capture: SAVED. Actual input engine passes 9 checks, browser smoke passes 7, three recorded takes and frame/codec evidence saved. Native export is 60fps; live software test averages 58.07fps.
- Phase 5 storyboard: SAVED, 42s main /15s portrait cut with actual take times.
- Phase 6 inserts: COMPLETE; no AI inserts, preserve official artwork.
- Phase 7 edit/export: COMPLETE. Both final MP4s exported; exact duration/frame count/codec/audio/BT709/faststart/full decode checks pass. GitHub upload is canceled.
- Gate A art: PASS after opened source/frame comparison and independent art score 9. Evidence art/side_by_side.png plus gate-a-evidence/.
- Gate B recording: PASS after layout/timing fixes, three real engine-driven takes, 480-frame decode and no adjacent whole-frame freezes. Final film still needs separate review. Live software rendering can drop frames; capture remains exact 60fps.
- Final strict quality gate: NOT FULLY PASSED after five review loops. Finished files delivered with explicit originality/hook/founder7 and perceptual-motion-review limitations; no passing grade invented.

## Decisions
- This is a new Clover project; preserve the unfinished StonkRobbers files separately.
- Follow the supplied phased brief. Make a playable slice only to capture genuine gameplay for the requested videos.
- Official artwork must remain on-model; no unrelated 3D character replacement.
- Publish no messages and contact nobody. Deliver files only.
- Treat project bio financial/token statements as project claims, not independently verified outcomes.

## Failures and limitations
- Python requests is not installed in this runtime; public fetches work with standard-library urllib.
- Full 100-post/reply availability has not yet been established. Do not claim complete coverage without evidence.

## Open questions
- Character identity locked to official art; timing mechanic selected. Real prototype frames, motion and final quality still require review.

## Review iterations
1. Initial build: exact art, but unclear timing and bottom names overlapped footer.
2. Clarified timing, lit/unlit states, enlarged light; fixed landing of light at portrait during reaction.
3. Clean medallion crops, filled central clover, active TAP NOW cue, stronger shared bloom and personality feedback.
4. Raised Rain Walker badge clear of HUD. Independent revision scores: art9, clarity8, layout8, polish8; final motion grade remains unverified by continuous playback.

## Delivery steering
- User requested GitHub upload, then explicitly canceled that last message. Do not upload/push/publish Clover files to GitHub. Continue producing local deliverable files.

5. Final-cut UI review: removed an unsupported arrow glyph, moved captions clear of art, used an opaque result/leaderboard background, and replaced overlapping row motion with a clean score/rank tally. Adapted bots copy into a player challenge rather than claiming this scripted-capture prototype is bot-proof.

## Final evidence
- Main42s1080p60:2520frames; short15svertical1080p60:900frames. Both full decode passed.
- Caption defect at main28s fixed via isolated25–29render; decoded final frame opened and independently confirmed.
- Actual landscape+portrait result buttons, leaderboard, clipboard and restart passed16 checks with no outbound navigation.
- All artifacts remain local. No GitHub push or external message occurred.

## Latest delivery authorization
- User explicitly requested GitHub upload and download links after the prior cancellation. Upload final MP4s and a sources archive to AhmeddNaderr/Encore. This supersedes the earlier local-only instruction for artifact delivery; no social contact or posting to the project.
