'use strict';
const assert = require('node:assert/strict');
const { newGame, CHARACTERS, distance } = require('./engine.js');
const checks = [];
function check(name, run) { run(); checks.push(name); }
function advanceUntil(game, predicate, limit = 10) {
  for (let t = 0; t < limit; t += 1 / 600) {
    if (predicate(game.snapshot())) return;
    game.step(1 / 600);
  }
  assert.fail('condition did not arrive: ' + game.state);
}
function hit(game, index) {
  advanceUntil(game, s => s.state === 'atRoot' && distance(s.angle, CHARACTERS[index].bearing) < .3);
  const result = game.tap(); assert.equal(result.accepted, true); assert.equal(result.precise, true);
  return result;
}
function idle(game) { advanceUntil(game, s => s.state === 'atRoot'); }
check('out-of-window tap pulses and resets only unfinished progress', () => {
  const g = newGame(1); g.start(); hit(g, 0); idle(g);
  const before = g.score; assert.equal(g.visitedMask, 1);
  advanceUntil(g, s => Math.min(...s.openings.map(o => distance(s.angle, o.bearing))) > 30);
  assert.equal(g.tap().outcome, 'miss');
  assert.equal(g.state, 'miss'); assert.equal(g.visitedMask, 0); assert.equal(g.multiplier, 1);
  assert.equal(g.score, before); g.step(.18); assert.equal(g.state, 'atRoot');
});
check('bits fill on arrival and travelling presses are ignored', () => {
  const g = newGame(2); g.start(); hit(g, 1);
  assert.equal(g.visitedMask, 0); assert.equal(g.state, 'outbound');
  const score = g.score; assert.equal(g.tap().outcome, 'ignored'); assert.equal(g.score, score);
  g.step(.279); assert.equal(g.visitedMask, 0);
  g.step(.001); assert.equal(g.visitedMask, 2); assert.equal(g.state, 'portraitReaction');
  assert.equal(g.effects.windowBonus, 3);
});
check('repeating an already lit friend clears mask and preserves earned score', () => {
  const g = newGame('repeat'); g.start(); hit(g, 0); idle(g);
  const score = g.score;
  advanceUntil(g, s => s.state === 'atRoot' && distance(s.angle, CHARACTERS[0].bearing) < .3);
  assert.equal(g.tap().outcome, 'repeat'); assert.equal(g.visitedMask, 0);
  assert.equal(g.score, score); assert.equal(g.bloomStreak, 0); assert.equal(g.effects.slowFactor, 1);
});
check('four unique visits bloom, award 1050, and raise the next multiplier', () => {
  const g = newGame(5); g.start();
  for (let i = 0; i < 4; i++) { hit(g, i); idle(g); }
  assert.equal(g.score, 1050); assert.equal(g.blooms, 1); assert.equal(g.multiplier, 2);
  assert.equal(g.bestStreak, 1); assert.equal(g.visitedMask, 0); assert.deepEqual(g.visits, [1, 1, 1, 1]);
  hit(g, 3); assert.equal(g.score, 1450);
  g.step(.38); assert.equal(g.state, 'returning'); assert.equal(g.stateDuration, .18);
});
check('Listener slows only the next turn and Thinker points to an unvisited opening', () => {
  const g = newGame('effects'); g.start(); hit(g, 0); idle(g);
  assert.equal(g.snapshot().angularSpeed, g.baseSpeed * .85);
  hit(g, 2); idle(g);
  const s = g.snapshot(); assert.notEqual(s.effects.hintTarget, null);
  assert.equal(!!(s.visitedMask & (1 << s.effects.hintTarget)), false);
});
check('timeout completes a triggered light within .7s and never awards after zero', () => {
  let g;
  for (let seed = 0; seed < 200; seed++) {
    const candidate = newGame(seed); candidate.start(); candidate.step(29.85);
    if (Math.min(...candidate.snapshot().openings.map(o => distance(candidate.angle, o.bearing))) < 15) { g = candidate; break; }
  }
  assert.ok(g); assert.equal(g.tap().accepted, true); const score = g.score;
  g.step(2); assert.equal(g.state, 'results'); assert.ok(g.elapsed <= 30.7);
  assert.equal(g.score, score); assert.equal(g.timeRemaining, 0);
  assert.ok(g.events.filter(e => e.type === 'score').every(e => e.time < 30));
  const snap = g.snapshot(); g.tap(); g.step(10); assert.equal(g.score, snap.score);
});
check('autoplay uses real taps and reproduces a seed without persistent state', () => {
  const g = newGame('take-a'); g.autoplay(31, { skill: 100 });
  assert.equal(g.state, 'results'); assert.ok(g.blooms >= 2); assert.ok(g.score > 2000);
  assert.equal(g.totalTaps, g.validTaps); assert.equal(g.misses, 0);
  const first = g.snapshot(), events = JSON.stringify(g.events);
  g.reset('take-a'); g.autoplay(31, { skill: 100 });
  assert.deepEqual(g.snapshot(), first); assert.equal(JSON.stringify(g.events), events);
  assert.deepEqual(newGame('take-a').snapshot(), newGame('take-a').snapshot());
  assert.ok(Object.isFrozen(first)); assert.ok(Object.isFrozen(first.openings[0]));
});
check('scripted imperfect take creates ordinary evaluated misses', () => {
  const g = newGame('take-c'); g.autoplay(31, { skill: 1, missEvery: 7 });
  assert.equal(g.state, 'results'); assert.ok(g.misses > 0); assert.ok(g.blooms > 0);
  assert.equal(g.events.filter(e => e.type === 'tap').length, g.totalTaps);
  assert.ok(g.events.filter(e => e.type === 'miss').every(e => e.reason === 'miss'));
});
check('time integration is independent of frame size', () => {
  const a = newGame('clock'), b = newGame('clock'); a.start(); b.start(); a.step(10);
  for (let i = 0; i < 600; i++) b.step(1 / 60);
  assert.ok(distance(a.angle, b.angle) < 1e-7); assert.ok(Math.abs(a.elapsed - b.elapsed) < 1e-7);
  assert.throws(() => a.step(NaN), RangeError);
});
console.log('PASS ' + checks.length + ' Same Roots engine checks');
checks.forEach(name => console.log('  ✓ ' + name));
