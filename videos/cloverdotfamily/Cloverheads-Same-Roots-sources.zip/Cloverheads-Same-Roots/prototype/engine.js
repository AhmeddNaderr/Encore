/* Same Roots — deterministic, DOM-free simulation. All public times are seconds. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SameRoots = api;
})(typeof window !== 'undefined' ? window : typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const CHARACTERS = Object.freeze([
    Object.freeze({ index: 0, name: 'Listener', bearing: -135, effect: 'A gentler next turn' }),
    Object.freeze({ index: 1, name: 'Rain Walker', bearing: -45, effect: 'A wider next opening' }),
    Object.freeze({ index: 2, name: 'Thinker', bearing: 45, effect: 'A little hint ahead' }),
    Object.freeze({ index: 3, name: 'Paper Dreamer', bearing: 135, effect: 'A shorter way home · +50' })
  ]);
  const DURATION = 30;
  const PHASE_DURATION = Object.freeze({ outbound: .28, portraitReaction: .10, returning: .25, bloom: .38, miss: .18 });
  const EPS = 1e-9;
  const wrap = a => ((a + 180) % 360 + 360) % 360 - 180;
  const distance = (a, b) => Math.abs(wrap(a - b));
  function hashSeed(seed) {
    const s = String(seed == null ? 1 : seed); let h = 2166136261;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0 || 1;
  }
  function freezeTree(o) {
    if (o && typeof o === 'object') { Object.keys(o).forEach(k => freezeTree(o[k])); Object.freeze(o); }
    return o;
  }
  class Game {
    constructor(seed) { this.reset(seed == null ? 1 : seed); }
    reset(seed) {
      this.seed = seed == null ? 1 : seed;
      this._randomState = hashSeed(this.seed);
      this.angle = wrap(this._random() * 360);
      this.state = 'ready'; this.elapsed = 0; this.stateAge = 0; this.stateDuration = 0;
      this.visitedMask = 0; this.score = 0; this.multiplier = 1; this.blooms = 0;
      this.preciseHits = 0; this.bloomStreak = 0; this.bestStreak = 0;
      this.visits = [0, 0, 0, 0]; this.misses = 0; this.totalTaps = 0; this.validTaps = 0;
      this.target = null; this.lastTarget = null; this.lastTap = null;
      this.effects = { slowFactor: 1, windowBonus: 0, hintTarget: null, source: null };
      this.events = []; this._eventID = 0; this._timedOut = false;
      this._autoTurn = null; this._autoTurns = 0;
      this._emit('ready'); return this;
    }
    _random() {
      let x = this._randomState; x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
      this._randomState = x >>> 0; return this._randomState / 4294967296;
    }
    get timeRemaining() { return Math.max(0, DURATION - this.elapsed); }
    get baseSpeed() { return 105 + 50 * Math.min(DURATION, this.elapsed) / DURATION; }
    get acceptanceWindow() { return 22 - 5 * Math.min(DURATION, this.elapsed) / DURATION + this.effects.windowBonus; }
    _emit(type, detail) { const e = Object.assign({ id: ++this._eventID, type, time: this.elapsed }, detail); this.events.push(e); return e; }
    drainEvents() { return this.events.splice(0); }
    start() {
      if (this.state !== 'ready') return false;
      this._setState('atRoot'); this._emit('start'); return true;
    }
    _setState(state, duration) {
      this.state = state; this.stateAge = 0; this.stateDuration = duration || PHASE_DURATION[state] || 0;
      this._emit('state', { state, target: this.target });
      if (state === 'atRoot') { this._autoTurn = null; this._chooseHint(); }
    }
    _chooseHint() {
      if (this.effects.source !== 2) return;
      let best = Infinity, index = null;
      CHARACTERS.forEach(c => {
        if (this.visitedMask & (1 << c.index)) return;
        const ahead = ((c.bearing - this.angle) % 360 + 360) % 360;
        if (ahead < best) { best = ahead; index = c.index; }
      });
      this.effects.hintTarget = index;
    }
    _award(points, reason, target) {
      if (this.elapsed >= DURATION - EPS) return 0;
      const amount = points * this.multiplier; this.score += amount;
      this._emit('score', { amount, reason, target, score: this.score, multiplier: this.multiplier }); return amount;
    }
    tap() {
      this.totalTaps++;
      if (this.state !== 'atRoot' || this.elapsed >= DURATION - EPS) {
        const result = { outcome: 'ignored', accepted: false, state: this.state };
        this.lastTap = Object.assign({ time: this.elapsed, angle: this.angle }, result);
        this._emit('tap', this.lastTap); return result;
      }
      let target = 0, error = Infinity;
      CHARACTERS.forEach(c => { const d = distance(this.angle, c.bearing); if (d < error) { target = c.index; error = d; } });
      const repeat = !!(this.visitedMask & (1 << target));
      const valid = error <= this.acceptanceWindow + EPS && !repeat;
      const precise = valid && error <= 7 + EPS;
      const result = { outcome: valid ? 'hit' : repeat && error <= this.acceptanceWindow + EPS ? 'repeat' : 'miss', accepted: valid, target, error, precise };
      this.lastTap = Object.assign({ time: this.elapsed, angle: this.angle }, result);
      this._emit('tap', this.lastTap);
      this.effects = { slowFactor: 1, windowBonus: 0, hintTarget: null, source: null };
      if (!valid) {
        this.misses++; this.visitedMask = 0; this.multiplier = 1; this.bloomStreak = 0;
        this.target = null; this._emit('miss', { reason: result.outcome, target }); this._setState('miss'); return result;
      }
      this.target = target; this.lastTarget = target; this.validTaps++;
      if (precise) this.preciseHits++;
      this._award(100 + (precise ? 50 : 0), precise ? 'precise' : 'visit', target);
      if (target === 3) this._award(50, 'paperBonus', target);
      this._emit('depart', { target, precise }); this._setState('outbound'); return result;
    }
    _arrive() {
      this.visitedMask |= 1 << this.target; this.visits[this.target]++;
      this.effects.source = this.target;
      if (this.target === 0) this.effects.slowFactor = .85;
      if (this.target === 1) this.effects.windowBonus = 3;
      this._emit('arrival', { target: this.target, visitedMask: this.visitedMask });
      this._emit('effect', { target: this.target, label: CHARACTERS[this.target].effect });
      this._setState('portraitReaction');
    }
    _advancePhase() {
      switch (this.state) {
        case 'outbound': this._arrive(); break;
        case 'portraitReaction': this._setState('returning', this.target === 3 ? .18 : .25); break;
        case 'returning':
          this._emit('return', { target: this.target }); this.target = null;
          if (this.visitedMask === 15 && !this._timedOut) {
            this._award(400, 'bloom'); this.blooms++; this.bloomStreak++;
            this.bestStreak = Math.max(this.bestStreak, this.bloomStreak);
            this.multiplier = Math.min(3, this.multiplier + 1);
            this._emit('bloom', { blooms: this.blooms, streak: this.bloomStreak, multiplier: this.multiplier });
            this._setState('bloom');
          } else if (this._timedOut) this._finish();
          else this._setState('atRoot');
          break;
        case 'bloom': this.visitedMask = 0; if (this._timedOut) this._finish(); else this._setState('atRoot'); break;
        case 'miss': if (this._timedOut) this._finish(); else this._setState('atRoot'); break;
      }
    }
    _finish() {
      if (this.state === 'results') return;
      this.target = null; this._setState('results');
      this._emit('results', { score: this.score, blooms: this.blooms, bestStreak: this.bestStreak });
    }
    step(dt) {
      if (!Number.isFinite(dt) || dt < 0) throw new RangeError('step(dt) requires non-negative finite seconds');
      if (this.state === 'ready' || this.state === 'results') return this.snapshot();
      let left = dt;
      while (left > EPS && this.state !== 'results') {
        if (!this._timedOut && this.elapsed >= DURATION - EPS) {
          this.elapsed = DURATION; this._timedOut = true; this._emit('timeout');
          if (this.state === 'atRoot') { this._finish(); break; }
        }
        if (this._timedOut && this.elapsed >= DURATION + .7 - EPS) { this.elapsed = DURATION + .7; this._finish(); break; }
        let part = left;
        if (!this._timedOut) part = Math.min(part, DURATION - this.elapsed);
        else part = Math.min(part, DURATION + .7 - this.elapsed);
        if (this.stateDuration) part = Math.min(part, this.stateDuration - this.stateAge);
        if (part > EPS) {
          const start = Math.min(DURATION, this.elapsed), end = Math.min(DURATION, this.elapsed + part);
          let rotation = 105 * (end - start) + 25 / DURATION * (end * end - start * start);
          if (this.elapsed + part > DURATION) rotation += 155 * (this.elapsed + part - Math.max(DURATION, this.elapsed));
          if (this.state === 'atRoot') rotation *= this.effects.slowFactor;
          this.angle = wrap(this.angle + rotation); this.elapsed += part; this.stateAge += part; left -= part;
        }
        // Deadline wins ties: a bloom cannot be awarded at or after 30.000 seconds.
        if (!this._timedOut && this.elapsed >= DURATION - EPS) {
          this.elapsed = DURATION; this._timedOut = true; this._emit('timeout');
          if (this.state === 'atRoot') { this._finish(); break; }
        }
        if (this.stateDuration && this.stateAge >= this.stateDuration - EPS) this._advancePhase();
        else if (part <= EPS) break;
      }
      return this.snapshot();
    }
    autoplay(dt, options) {
      if (!Number.isFinite(dt) || dt < 0) throw new RangeError('autoplay(dt) requires non-negative finite seconds');
      const o = options || {}, rawSkill = o.skill == null ? 1 : o.skill;
      const skill = Math.max(0, Math.min(1, rawSkill > 1 ? rawSkill / 100 : rawSkill));
      const missEvery = Math.max(0, Math.floor(o.missEvery || 0));
      if (this.state === 'ready') this.start();
      let left = dt;
      while (left > EPS && this.state !== 'results') {
        if (this.state === 'atRoot') {
          if (this._autoTurn === null) {
            this._autoTurns++;
            this._autoTurn = (missEvery && this._autoTurns % missEvery === 0) || this._random() > skill ? 'miss' : 'hit';
          }
          let nearest = Infinity;
          CHARACTERS.forEach(c => { nearest = Math.min(nearest, distance(this.angle, c.bearing)); });
          if (this._autoTurn === 'miss' && nearest > this.acceptanceWindow + 2) this.tap();
          else if (this._autoTurn === 'hit') {
            const c = CHARACTERS.find(c => !(this.visitedMask & 1 << c.index) && distance(this.angle, c.bearing) <= 2);
            if (c) this.tap();
          }
        }
        const part = Math.min(left, 1 / 120); this.step(part); left -= part;
      }
      return this.snapshot();
    }
    snapshot() {
      const active = this.target == null ? null : { target: this.target, phase: this.state, progress: this.stateDuration ? Math.min(1, this.stateAge / this.stateDuration) : 0 };
      const maxVisits = Math.max.apply(null, this.visits), favorite = maxVisits ? this.visits.indexOf(maxVisits) : null;
      return freezeTree({ seed: this.seed, state: this.state, angle: this.angle, elapsed: this.elapsed,
        duration: DURATION, timeRemaining: this.timeRemaining, stateAge: this.stateAge, stateDuration: this.stateDuration,
        activeLight: active, target: this.target, lastTarget: this.lastTarget, visitedMask: this.visitedMask,
        score: this.score, multiplier: this.multiplier, blooms: this.blooms, preciseHits: this.preciseHits,
        bloomStreak: this.bloomStreak, bestStreak: this.bestStreak, longestBloomStreak: this.bestStreak,
        visits: this.visits.slice(), visitsPerMember: this.visits.slice(), favorite, misses: this.misses,
        totalTaps: this.totalTaps, validTaps: this.validTaps, baseSpeed: this.baseSpeed,
        angularSpeed: this.baseSpeed * (this.state === 'atRoot' ? this.effects.slowFactor : 1),
        acceptanceWindow: this.acceptanceWindow, preciseWindow: 7, timedOut: this._timedOut,
        openings: CHARACTERS.map(c => ({ index: c.index, bearing: c.bearing, halfWidth: this.acceptanceWindow,
          preciseWidth: 7, visited: !!(this.visitedMask & 1 << c.index), hinted: this.effects.hintTarget === c.index })),
        effects: Object.assign({}, this.effects), lastTap: this.lastTap && Object.assign({}, this.lastTap) });
    }
  }
  return Object.freeze({ Game, newGame: seed => new Game(seed), CHARACTERS, DURATION, PHASE_DURATION, wrap, distance });
});
