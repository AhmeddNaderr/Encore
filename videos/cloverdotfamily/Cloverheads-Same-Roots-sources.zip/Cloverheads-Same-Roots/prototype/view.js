'use strict';
(async()=>{
const canvas=document.getElementById('game'),c=canvas.getContext('2d',{alpha:false});
let W=innerWidth,H=innerHeight,portrait=H>W;canvas.width=W;canvas.height=H;
const PW=portrait?1080:1920,PH=portrait?1920:1080,S=Math.min(W/PW,H/PH);
const TAU=Math.PI*2,PI=Math.PI,clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),ease=x=>{x=clamp(x);return x*x*(3-2*x)},lerp=(a,b,t)=>a+(b-a)*t;
const names=['The Listener','Rain Walker','The Thinker','Paper Dreamer'];
const files=['01-forest-hoodie','04-yellow-raincoat','06-cream-turtleneck','29-poncho'];
const palette={ivory:'#f1e6b5',gold:'#ecd18d',forest:'#24432a',moss:'#415d2d',sage:'#c9cd9c',paper:'#f3f0df'};
const assets={};
async function load(key,url){const im=new Image();im.src=url;await im.decode();assets[key]=im;}
await Promise.all([...files.map((f,i)=>load('char'+i,'../art/raw/'+f+'.png')),load('valley','../art/raw/clover-valley.png'),load('study','../art/raw/kings-study.png'),load('brand','../art/raw/home-clover-original.png'),load('favicon','../art/raw/favicon.svg'),load('encore','../art/encore-reference-endcard.png')]);
await Promise.all([document.fonts.load('800 40px "Clover Nunito"'),document.fonts.load('500 40px "Clover Lora"'),document.fonts.load('italic 40px "Clover Lora"')]);await document.fonts.ready;
const sprites=files.map((_,i)=>{const out=document.createElement('canvas');out.width=out.height=640;out.getContext('2d').drawImage(assets['char'+i],0,0,640,640);return out});
const bg=document.createElement('canvas');bg.width=PW+100;bg.height=PH+100;
{const b=bg.getContext('2d');const im=assets.valley,r=Math.max(bg.width/im.width,bg.height/im.height);b.filter='blur(2px)';b.drawImage(im,(bg.width-im.width*r)/2,(bg.height-im.height*r)/2,im.width*r,im.height*r);b.filter='none';const gr=b.createLinearGradient(0,0,0,bg.height);gr.addColorStop(0,'#0b211b9c');gr.addColorStop(.45,'#0a201985');gr.addColorStop(1,'#061b18e6');b.fillStyle=gr;b.fillRect(0,0,bg.width,bg.height);}
const glow=document.createElement('canvas');glow.width=glow.height=256;{const g=glow.getContext('2d'),gr=g.createRadialGradient(128,128,0,128,128,128);gr.addColorStop(0,'#fff8c9ed');gr.addColorStop(.12,'#ffe9a8aa');gr.addColorStop(.4,'#eac97935');gr.addColorStop(1,'#eac97900');g.fillStyle=gr;g.fillRect(0,0,256,256);}
let game=SameRoots.newGame(17),liveClock=0,last=performance.now(),paused=false,recording=false,liveEvents=[],lastSoundId=0,soundEnabled=true,resultView='card',copiedResult=false;const soundFiles={tap:'tap-soft',arrival:'firefly-pass',bloom:'clover-bloom',miss:'tap-warm',start:'ui-open'};function sound(type){if(!soundEnabled||!soundFiles[type])return;const a=new Audio('../audio/sfx/'+soundFiles[type]+'.wav');a.volume=type==='bloom'?.55:.30;a.play().catch(()=>{})}const music=new Audio('../audio/music-42s.wav');music.loop=true;music.volume=.20;music.preload='none';
const takes=[];
function buildTake(seed,missEvery=0){const g=SameRoots.newGame(seed),frames=[],events=[];for(let f=0;f<=32*60;f++){if(f)g.autoplay(1/60,{skill:1,missEvery});else g.start();frames.push(g.snapshot());}events.push(...g.events);return {frames,events};}
for(let i=0;i<3;i++)takes.push(buildTake(17+i*11,i===2?9:0));
function frameOf(take,t){return take.frames[Math.round(clamp(t,0,32)*60)]||take.frames.at(-1)}
function rr(x,y,w,h,r=16,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill()}if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke()}}
function text(s,x,y,size=24,color=palette.ivory,font='Clover Nunito',weight='600',align='left'){c.font=`${weight} ${size}px "${font}"`;c.textAlign=align;c.textBaseline='middle';c.fillStyle=color;c.fillText(s,x,y)}
function label(s,x,y,size=16,color=palette.sage,align='left'){c.save();c.letterSpacing='2.4px';text(s,x,y,size,color,'Clover Nunito','800',align);c.restore()}
function line(x1,y1,x2,y2,color,width=1){c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.strokeStyle=color;c.lineWidth=width;c.stroke()}
function spark(x,y,r=12,a=1){c.save();c.globalAlpha=a;c.drawImage(glow,x-r*4,y-r*4,r*8,r*8);c.fillStyle='#fff9db';c.beginPath();c.arc(x,y,Math.max(1.6,r*.18),0,TAU);c.fill();c.restore()}
function cover(im,x,y,w,h){let r=Math.max(w/im.width,h/im.height);c.save();c.beginPath();c.rect(x,y,w,h);c.clip();c.drawImage(im,x+(w-im.width*r)/2,y+(h-im.height*r)/2,im.width*r,im.height*r);c.restore()}
function clover(x,y,size,mask=15,alpha=1){c.save();c.translate(x,y);c.globalAlpha=alpha;for(let i=0;i<4;i++){c.save();c.rotate(-PI*.75+i*PI/2);c.scale(size,size);c.beginPath();c.moveTo(0,0);c.bezierCurveTo(-.38,-.04,-.54,-.32,-.32,-.43);c.bezierCurveTo(-.19,-.51,-.055,-.42,0,-.34);c.bezierCurveTo(.12,-.54,.4,-.48,.4,-.25);c.bezierCurveTo(.4,-.1,.12,0,0,0);c.fillStyle=mask&(1<<i)?palette.gold:'#44654b';c.fill();c.strokeStyle='#f1e6b543';c.lineWidth=.009;c.stroke();c.restore()}c.restore()}

const officialLeafPaths=[new Path2D('M30 30C6 30 9 9 20 12 26 0 40 8 30 30Z'),new Path2D('M34 30C34 6 55 9 52 20 64 26 56 40 34 30Z'),new Path2D('M34 34C58 34 55 55 44 52 38 64 24 56 34 34Z'),new Path2D('M30 34C30 58 9 55 12 44 0 38 8 24 30 34Z')];
function drawRootProgress(x,y,size,mask){c.save();c.translate(x-size/2,y-size/2);c.scale(size/64,size/64);for(let i=0;i<4;i++){c.fillStyle=mask&(1<<i)?'#f3d999':'#527045';c.fill(officialLeafPaths[i]);c.strokeStyle=mask&(1<<i)?'#fff0b9':'#859a6866';c.lineWidth=.5;c.stroke(officialLeafPaths[i])}c.restore()}
function layout(){return portrait?{cx:540,cy:960,rx:282,ry:370,size:295,heads:[[258,590],[822,590],[822,1330],[258,1330]]}:{cx:960,cy:525,rx:410,ry:245,size:300,heads:[[550,280],[1370,280],[1370,750],[550,750]]}}
function drawCharacter(i,x,y,size,t,reaction=0,lit=false){
 c.save();c.translate(x,y);c.beginPath();c.ellipse(0,3,size*.57,size*.57,0,0,TAU);c.clip();const a=.008*Math.sin(t*1.8+i)+.036*Math.sin(reaction*13)*Math.exp(-reaction*5)*(reaction>0?1:0);const squash=1+.018*Math.sin(t*1.7+i);
 c.drawImage(glow,-size*.8,-size*.75,size*1.6,size*1.6);c.globalAlpha=lit?.9:.35;c.fillStyle=lit?'#ecd18d35':'#a4b97a20';c.beginPath();c.ellipse(0,size*.43,size*.43,size*.075,0,0,TAU);c.fill();c.globalAlpha=1;
 c.save();c.translate(-size/2,-size*.43);c.scale(1,squash);c.save();c.beginPath();c.rect(0,size*.69,size,size*.31);c.clip();c.drawImage(sprites[i],0,0,size,size);c.restore();
 c.save();c.translate(size*.5,size*.72);c.rotate(a);c.translate(-size*.5,-size*.72);c.beginPath();c.rect(-size*.1,-size*.1,size*1.2,size*.83);c.clip();c.drawImage(sprites[i],0,0,size,size);c.restore();c.restore();
 c.restore();
}
function pathFor(L,i,returning=false){const p=L.heads[i],sx=p[0]>L.cx?1:-1,sy=p[1]>L.cy?1:-1;return [[L.cx,L.cy],[L.cx+sx*(returning?235:130),L.cy+sy*(returning?55:130)],[p[0]-sx*(returning?20:150),p[1]-sy*(returning?120:30)],[p[0],p[1]-L.size*.04]]}
function bez(P,u){let v=1-u;return [v*v*v*P[0][0]+3*v*v*u*P[1][0]+3*v*u*u*P[2][0]+u*u*u*P[3][0],v*v*v*P[0][1]+3*v*v*u*P[1][1]+3*v*u*u*P[2][1]+u*u*u*P[3][1]]}
function path(P,color,width=2){c.beginPath();c.moveTo(...P[0]);c.bezierCurveTo(...P[1],...P[2],...P[3]);c.strokeStyle=color;c.lineWidth=width;c.lineCap='round';c.stroke()}
function evAge(events,type,time,target=null){for(let i=events.length-1;i>=0;i--){const e=events[i];if(e.time>time+.002)continue;if(e.type===type&&(target===null||e.target===target))return time-e.time}return 999}
function mainBoard(s,t,events,{zoom=1,overlay=null,brand=true}={}){
 c.drawImage(bg,-50+Math.sin(t*.14)*7,-50+Math.cos(t*.1)*5);const L=layout(),mask=s.state==='bloom'?15:(s.visitedMask||0);
 for(let i=0;i<35;i++){let x=(i*213.713+t*(10+i%4*3))%(PW+90)-45,y=140+(i*127.23)%(PH-240)+Math.sin(t*.6+i)*18;spark(x,y,1.7+(i%3)*.4,.12+.14*Math.sin(i+t*.3)**2)}
 const bloomAge=evAge(events,'bloom',t),arrivalAge=evAge(events,'arrival',t);const jolt=arrivalAge<.13?(1-arrivalAge/.13)*3:0;const bloomZoom=bloomAge<.6?1+.018*Math.sin(PI*bloomAge/.6):1;c.save();c.translate(L.cx+Math.sin(t*91)*jolt,L.cy+Math.cos(t*83)*jolt);c.scale(zoom*bloomZoom,zoom*bloomZoom);c.translate(-L.cx,-L.cy);
 const radius=portrait?120:122;
 // Every lobe is connected to the same root; lit routes stay visibly gold.
 for(let i=0;i<4;i++){
  const P=pathFor(L,i);path(P,'#071d17bb',12);path(P,mask&(1<<i)?'#f0d995e8':'#9eb77c43',mask&(1<<i)?5:2);
  const p=L.heads[i];const err=Math.abs(((s.angle-(-135+90*i)+540)%360)-180);const hot=s.state==='atRoot'&&!(mask&(1<<i))&&err<(s.openings?.[i]?.halfWidth||22);c.save();c.translate(p[0],p[1]);c.beginPath();c.ellipse(0,3,L.size*.57,L.size*.57,0,0,TAU);c.fillStyle='#0e2a21a0';c.fill();c.strokeStyle=hot?'#fff0b8':mask&(1<<i)?'#e4ce8bb3':'#a9bc8860';c.lineWidth=hot?5:mask&(1<<i)?2.5:1;c.stroke();c.restore();
 }
 // The four timing windows echo four actual portrait bearings.
 c.beginPath();c.arc(L.cx,L.cy,radius,0,TAU);c.strokeStyle='#c1cc9a35';c.lineWidth=1;c.stroke();
 for(let i=0;i<4;i++){let a=(-135+90*i)*PI/180,w=(s.openings?.[i]?.halfWidth||22)*PI/180;c.beginPath();c.arc(L.cx,L.cy,radius,a-w,a+w);const err=Math.abs(((s.angle-(-135+90*i)+540)%360)-180),hot=s.state==='atRoot'&&!(mask&(1<<i))&&err<(s.openings?.[i]?.halfWidth||22);c.strokeStyle=hot?'#fff5bd':mask&(1<<i)?'#6c7b5677':'#ecd18da6';c.lineWidth=hot?14:8;c.lineCap='round';c.stroke();}
 for(let i=0;i<4;i++){
  const [x,y]=L.heads[i],age=Math.min(evAge(events,'visit',t,i),evAge(events,'arrival',t,i));
  drawCharacter(i,x,y,L.size,t,age,!!(mask&(1<<i)));
  text(names[i],x,y+L.size*.655,portrait?28:26,mask&(1<<i)?'#fff5c8':palette.ivory,'Clover Lora','500','center');
  const bits=['A SONG TO SHARE','RAIN IS AN ADVENTURE','NOTICES THE LITTLE THINGS','A DIFFERENT IDEA'];if(brand)label(bits[i],x,y+L.size*.76,portrait?12:11,'#c9cd9ca8','center');
  if(mask&(1<<i)){const bx=x+(portrait?83:95),by=y-L.size*.31;rr(bx-40,by-18,80,36,18,'#ecd18d','#f7e5ad');text('✓ LIT',bx,by,16,'#244431','Clover Nunito','900','center')}else{const bx=x+(portrait?83:95),by=y-L.size*.31;rr(bx-44,by-17,88,34,17,'#132c23de','#c9cd9c77');const err=Math.abs(((s.angle-(-135+90*i)+540)%360)-180),hot=s.state==='atRoot'&&err<(s.openings?.[i]?.halfWidth||22);text(hot?'TAP NOW':'UNLIT',bx,by,13,hot?'#fff5b5':'#e0e4c4','Clover Nunito','800','center')}
 }
 // Original project icon, with rotating light arm as gameplay UI.
 c.save();c.translate(L.cx,L.cy);c.fillStyle='#123527f4';c.beginPath();c.arc(0,0,81,0,TAU);c.fill();c.strokeStyle='#d5bb778c';c.lineWidth=2;c.stroke();
 c.save();c.globalAlpha=s.state==='atRoot'||s.state==='ready'?1:.3;c.rotate((s.angle||0)*PI/180);line(0,0,radius-15,0,'#fff0ad',4);spark(radius-15,0,9,1);c.restore();
 drawRootProgress(0,0,118,mask);c.restore();
 const light=s.activeLight;
 if(light){const ret=light.phase==='returning'||s.state==='returning';let P=pathFor(L,light.target,ret);let u=light.phase==='portraitReaction'?1:clamp(light.progress||0);if(ret)u=1-u;const p=bez(P,ease(u));for(let j=7;j>=1;j--){const q=bez(P,ease(clamp(u+(ret?1:-1)*j*.016)));spark(q[0],q[1],4-j*.25,(1-j/8)*.6)}spark(p[0],p[1],25,1);c.save();c.translate(p[0],p[1]);c.fillStyle='#fff6c7';c.beginPath();c.ellipse(-9,-5,10,3.8,Math.sin(t*42)*.8,0,TAU);c.ellipse(9,-5,10,3.8,-Math.sin(t*42)*.8,0,TAU);c.fill();c.beginPath();c.arc(0,0,7,0,TAU);c.fillStyle='#fff9df';c.fill();c.restore()}else spark(L.cx,L.cy,10,.8);
 // Actual tap and bloom effects, derived only from engine events.
 for(const e of events){const age=t-e.time;if(age<0||age>1.8)continue;
  if(['tap','validTap','launch'].includes(e.type)){c.beginPath();c.arc(L.cx,L.cy,35+age*95,0,TAU);c.strokeStyle=`rgba(255,240,179,${Math.max(0,1-age*2)*.7})`;c.lineWidth=2;c.stroke()}
  if(e.type==='bloom'){
   const a=Math.exp(-age*2);c.save();c.globalAlpha=a*.65;c.drawImage(glow,L.cx-410,L.cy-410,820,820);c.restore();for(let i=0;i<4;i++){const P=pathFor(L,i,true),u=1-clamp(age/.5),p=bez(P,u);if(age<.5){path(P,'#ead09199',4);spark(p[0],p[1],22,a)}}for(let k=0;k<55;k++){let angle=k*2.39996,rr=age*(150+k%7*13);spark(L.cx+Math.cos(angle)*rr,L.cy+Math.sin(angle)*rr,4+(k%3),a*.85)}
   c.save();c.globalAlpha=clamp(1-age/1.7);drawRootProgress(L.cx,L.cy,118+130*Math.sin(PI*clamp(age/.9)),15);c.restore();
  }
 }
 c.restore();
 // Quiet game typography, with room for the original art.
 if(portrait){if(brand){label('CLOVERHEADS',64,75,19);text('Same Roots',64,142,64,palette.ivory,'Clover Lora','500')}rr(65,215,950,112,28,'#10281dde','#d3d7ac66');label('SCORE',100,246,15);text(String(s.score||0).padStart(5,'0'),100,290,40);label('BLOOMS',472,246,15);text(String(s.blooms||0).padStart(2,'0'),472,290,40);label('TIME',830,246,15);text(String(Math.ceil(s.timeRemaining??30)).padStart(2,'0'),830,290,40);
 }else{if(brand){c.drawImage(assets.favicon,70,54,38,38);label('CLOVERHEADS',124,74,15);text('Same Roots',70,137,52,palette.ivory,'Clover Lora','500')}rr(1350,50,500,104,28,'#10281dcf','#d3d7ac55');label('SCORE',1382,77,12);text(String(s.score||0).padStart(5,'0'),1382,119,34);label('BLOOMS',1600,77,12);text(String(s.blooms||0).padStart(2,'0'),1600,119,34);label('TIME',1751,77,12);text(String(Math.ceil(s.timeRemaining??30)).padStart(2,'0'),1751,119,34)}
 const progress=[0,1,2,3].filter(i=>mask&(1<<i)).length;
 label(s.state==='bloom'?'ONE FAMILY BLOOM':`${progress} / 4  FRIENDS LIT`,L.cx,L.cy+160,portrait?15:13,palette.sage,'center');
 if((s.multiplier||1)>1)text(`×${s.multiplier} FAMILY STREAK`,L.cx,L.cy+195,portrait?22:19,palette.gold,'Clover Nunito','800','center');
 const ba=evAge(events,'bloom',t);if(ba<1.5){const p=ease(ba/.16)*(1-ease((ba-1.1)/.4));c.save();c.globalAlpha=p;text('Together, we bloom.',L.cx,portrait?1625:259,portrait?46:40,palette.gold,'Clover Lora','500','center');c.restore()}
 let recentEffect=null;for(let i=events.length-1;i>=0;i--){if(events[i].time<=t&&events[i].type==='effect'){recentEffect=events[i];break}}if(recentEffect&&t-recentEffect.time<.95&&ba>1.5){const cues=['A gentler next turn','A wider next opening','A little hint ahead','A shorter way home'];const yy=L.cy-175;c.save();c.globalAlpha=1-ease((t-recentEffect.time-.6)/.35);label(names[recentEffect.target].toUpperCase(),L.cx,yy-23,11,palette.sage,'center');text(cues[recentEffect.target],L.cx,yy+8,portrait?24:22,palette.gold,'Clover Lora','500','center');c.restore()}
 const my=portrait?1763:1020;
 rr(PW/2-(portrait?415:340),my-34,portrait?830:680,68,34,'#10271ede','#a7ba7b55');text(s.state==='ready'?'Tap to wake the little light.':'Tap when the root faces an unlit friend.',PW/2,my,portrait?27:24,palette.ivory,'Clover Nunito','600','center');
 label('CONCEPT BY ENCORE STUDIO',portrait?PW/2:PW-70,portrait?1850:1020,portrait?14:11,'#e2ddb6aa',portrait?'center':'right');
 if(overlay){c.save();const oy=portrait?390:77;rr(PW/2-(portrait?480:380),oy-(portrait?50:38),portrait?960:760,portrait?100:76,24,'#10271ee8','#d8c08580');text(overlay,PW/2,oy,portrait?37:36,palette.ivory,'Clover Lora','500','center');c.restore()}
}
function getResult(take){const s=take.frames.at(-1);return {score:s.score||0,blooms:s.blooms||0,streak:s.bestBloomStreak||s.longestBloomStreak||s.bestStreak||0}}
const sampleScores=[23500,21800,19750,17650,15800,14350,12600,11200,9700];
function ranking(result){const rows=sampleScores.map((score,i)=>({name:`holder_${String(i+1).padStart(2,'0')}`,score,you:false}));rows.push({name:'holder_you',score:result.score,you:true});return rows.sort((a,b)=>b.score-a.score)}
function leaderboard(result,t=0){
 const bw=portrait?910:1140,bh=portrait?1420:850,x=(PW-bw)/2,y=(PH-bh)/2;rr(x,y,bw,bh,34,'#f3f0dff8','#ecd18d');
 label('THE PORTRAIT GROVE',x+55,y+45,15,'#64735c');text('A little skill. A place together.',x+55,y+101,portrait?35:42,'#244431','Clover Lora','500');
 label('WL LEADERBOARD · SAMPLE',x+55,y+160,14,'#64735c');const rows=ranking(result),rh=portrait?96:51,start=y+220,travel=ease(t/1.2);const animatedScore=recording?frameOf(takes[1],8+22*travel).score:result.score;label('RANK 10 → '+String(ranking({score:animatedScore}).findIndex(r=>r.you)+1).padStart(2,'0'),x+bw-55,y+160,portrait?17:14,'#64735c','right');
 for(let i=0;i<10;i++){let row=rows[i],yy=start+i*rh;const delay=i*.025,alpha=ease((t-delay)/.25);c.save();c.globalAlpha=alpha;if(row.you)rr(x+35,yy-rh*.4,bw-70,rh*.85,12,'#dbe2bc');text(String(i+1).padStart(2,'0'),x+63,yy,portrait?28:23,'#64735c');text(row.name,x+155,yy,portrait?31:24,row.you?'#244431':'#52634b','Clover Nunito',row.you?'900':'600');text((row.you?animatedScore:row.score).toLocaleString('en-US'),x+bw-65,yy,portrait?32:25,'#244431','Clover Nunito','800','right');c.restore()}
 text('Concept scores · illustrative holders · no mint allocation',PW/2,y+bh-35,portrait?18:16,'#64735c','Clover Nunito','500','center');
}
function resultCard(result,t=0,share=false){
 const bw=portrait?910:950,bh=portrait?1160:800,x=(PW-bw)/2,y=(PH-bh)/2;
 rr(x,y,bw,bh,36,'#f3f0dffb','#d6c187');label('CLOVERHEADS / YOUR SHARED ROOT',x+55,y+48,portrait?15:13,'#64735c');
 text('Four stories. One family.',PW/2,y+110,portrait?45:45,'#244431','Clover Lora','500','center');
 const yy=y+(portrait?350:290),s=portrait?205:180;for(let i=0;i<4;i++){let xx=PW/2+(i-1.5)*(portrait?205:185);c.drawImage(sprites[i],xx-s/2,yy-s/2,s,s)}
 label('YOUR SCORE',PW/2,y+(portrait?550:440),16,'#64735c','center');text(result.score.toLocaleString('en-US'),PW/2,y+(portrait?645:515),portrait?106:84,'#244431','Clover Lora','500','center');
 text(`${result.blooms} FAMILY BLOOMS   ·   ${ranking(result).findIndex(r=>r.you)+1}/10 SAMPLE RANK`,PW/2,y+(portrait?750:595),portrait?22:18,'#64735c','Clover Nunito','800','center');
 const by=y+bh-120;rr(PW/2-240,by,480,66,33,'#244431');text(share?'✓  Result ready to share':copiedResult&&!recording?'Result text copied':'Share on X',PW/2,by+33,26,palette.paper,'Clover Nunito','800','center');if(recording)text('Play again  ↻',PW/2,y+bh-25,19,'#64735c','Clover Nunito','700','center');else{text('WL leaderboard',PW/2-180,y+bh-25,19,'#64735c','Clover Nunito','700','center');text('Play again',PW/2+180,y+bh-25,19,'#64735c','Clover Nunito','700','center')}
}
function shareScene(result,t){
 // This is a motion-graphic post mock-up. No external account or service is used.
 const a=ease(t/.7);if(!portrait){c.save();c.translate(-230*a,0);c.scale(1-.14*a,1-.14*a);c.translate(PW*.07*a,PH*.07*a);resultCard(result,t,true);c.restore();
 const x=1245+100*(1-a),y=240;rr(x,y,570,590,30,'#f7f7effc','#d4d8c6');text('𝕏',x+35,y+46,37,'#17271a','Clover Nunito','800');text('holder_you',x+95,y+44,23,'#244431','Clover Nunito','900');label('POST PREVIEW',x+35,y+105,12,'#64735c');text('Found my kind of head.',x+35,y+165,28,'#244431','Clover Lora','500');text('One light. Four different stories.',x+35,y+211,23,'#52634b');clover(x+285,y+360,195,15,1);text(`${result.score.toLocaleString()} · SAME ROOTS`,x+285,y+500,24,'#244431','Clover Nunito','800','center');
 }else{c.save();c.translate(PW/2,PH/2-55*a);c.scale(1-.10*a,1-.10*a);c.translate(-PW/2,-PH/2);resultCard(result,t,true);c.restore();const py=1570+150*(1-a);rr(100,py,880,175,25,'#f3f0dff2');text('𝕏  holder_you',145,py+40,24,'#244431','Clover Nunito','800');text('Found my kind of head. Four stories. One family.',145,py+105,25,'#244431','Clover Lora','500')}
}

function familyCard(t){c.drawImage(bg,-50+Math.sin(t*.2)*6,-50);c.fillStyle='#0b201ab5';c.fillRect(0,0,PW,PH);label('CLOVERHEADS / SAME ROOTS',PW/2,portrait?230:120,portrait?20:18,palette.sage,'center');text('Same roots.',PW/2,portrait?410:270,portrait?80:84,palette.ivory,'Clover Lora','500','center');text('Different stories.',PW/2,portrait?510:365,portrait?75:78,palette.gold,'Clover Lora','500','center');for(let i=0;i<4;i++){const x=portrait?(i%2?790:290):420+i*360,y=portrait?(i<2?850:1330):690;drawCharacter(i,x,y,portrait?340:300,t,0,true);text(names[i],x,y+(portrait?225:210),portrait?28:24,palette.ivory,'Clover Lora','500','center')}label('CONCEPT BY ENCORE STUDIO',PW/2,portrait?1770:1005,portrait?16:14,palette.sage,'center')}
function logoEncore(x,y,w){c.drawImage(assets.encore,819,154,290,200,x,y,w,w*200/290)}
function endCard(t,short=false){
 c.fillStyle='#000000';c.fillRect(0,0,PW,PH);const f=ease(t/.45);c.save();c.globalAlpha=f;
 const by=portrait?400:135;rr(PW/2-(portrait?450:365),by-25,portrait?900:730,portrait?295:245,30,palette.paper);c.drawImage(assets.brand,155,240,1230,365,PW/2-(portrait?405:330),by,portrait?810:660,(portrait?810:660)*365/1230);
 label('CLOVERHEADS',PW/2,portrait?720:390,portrait?22:17,palette.sage,'center');text('Same Roots',PW/2,portrait?840:485,portrait?108:94,palette.ivory,'Clover Lora','500','center');
 label('A GAME CONCEPT BY',PW/2,portrait?1040:620,portrait?19:15,'#dadcc7','center');logoEncore(PW/2-70,portrait?1135:685,140);
 label('ENCORE STUDIO',PW/2,portrait?1295:820,portrait?23:20,'#eeeddf','center');
 text('One crew for your whole launch.',PW/2,portrait?1420:905,portrait?32:29,'#eeeddf','Clover Nunito','600','center');
 text('encorestudio.xyz  ·  @EncoreStudiohq',PW/2,portrait?1500:966,portrait?26:23,'#b9bdab','Clover Nunito','600','center');
 if(!short)text('Book a free 30-min call',PW/2,portrait?1560:1005,portrait?22:20,'#b9bdab','Clover Nunito','600','center');
 label('UNOFFICIAL CONCEPT · ORIGINAL CLOVER ART',PW/2,portrait?1740:1050,portrait?12:10,'#828e7d','center');c.restore();
}
function beginFrame(){c.setTransform(1,0,0,1,0,0);c.fillStyle='#10251b';c.fillRect(0,0,W,H);c.setTransform(S,0,0,S,(W-PW*S)/2,(H-PH*S)/2)}
function renderGameplay(t,take=0,options={}){const tr=takes[take],s=frameOf(tr,t);mainBoard(s,t,tr.events,options);return s}
// Film edit stays declarative and is finalized only after the playable capture gate.
let edit={main:[],short:[]};
function film(t,mode){const isShort=mode==='short';const shots=edit[mode]||[];const sh=shots.find(s=>t>=s.start&&t<s.end);const result=getResult(takes[1]);
 if(!sh){renderGameplay(t,0);return}
 if(sh.type==='end'){endCard(t-sh.start,isShort);return}if(sh.type==='family'){familyCard(t-sh.start);return}
 let gt=(sh.source||0)+t-sh.start;if(sh.type==='gameplay')renderGameplay(gt,sh.take||0,{zoom:sh.zoom||1,overlay:sh.overlay||null,brand:sh.brand!==false});else{c.drawImage(bg,-50+Math.sin(t*.14)*7,-50);c.fillStyle='#0a2019a0';c.fillRect(0,0,PW,PH)}
 if(sh.type==='leaderboard'){c.fillStyle='#091e18a6';c.fillRect(0,0,PW,PH);leaderboard(result,t-sh.start);if(!isShort&&t-sh.start>2){rr(PW/2-390,PH-137,780,117,30,'#10271ef5','#c9cd9c44');text('Bots can like a post.',PW/2,PH-95,portrait?27:25,palette.ivory,'Clover Nunito','700','center');text('Can you bring every story together?',PW/2,PH-55,portrait?27:25,palette.gold,'Clover Lora','500','center')}}
 if(sh.type==='result'){c.fillStyle='#0b201ab0';c.fillRect(0,0,PW,PH);resultCard(result,t-sh.start)}
 if(sh.type==='share'){c.fillStyle='#0b201ac0';c.fillRect(0,0,PW,PH);shareScene(result,t-sh.start)}
}
window.setEdit=data=>edit=data;
window.renderAt=(t,{mode='gameplay'}={})=>{recording=true;paused=true;beginFrame();if(mode==='main'||mode==='short')film(t,mode);else renderGameplay(t,mode==='takeB'?1:mode==='takeC'?2:0);return {time:t,mode,width:W,height:H}};
window.advanceLive=seconds=>{game.step(seconds);liveClock+=seconds};window.getResultView=()=>resultView;window.getState=()=>game.snapshot();window.debugState=window.getState;
window.getTakeInfo=()=>takes.map(t=>({result:getResult(t),events:t.events}));window.setGameStateSeed=seed=>{game=SameRoots.newGame(seed);liveClock=0;recording=false;paused=false};
async function copyResult(){const s=game.snapshot(),txt=`SAME ROOTS — ${s.score} points, ${s.blooms} family blooms. Four stories. One family. Cloverheads concept by Encore Studio.`;try{await navigator.clipboard.writeText(txt)}catch{}window.lastShareText=txt;copiedResult=true;}
function restartLive(){game.reset(17);game.start();liveClock=0;lastSoundId=0;resultView='card';copiedResult=false;window.lastShareText=null}
function input(e){
 if(e.type==='keydown'&&e.code==='KeyM'){soundEnabled=!soundEnabled;if(!soundEnabled)music.pause();else if(!paused)music.play().catch(()=>{});return}
 if(e.type==='keydown'&&e.code!=='Space'&&e.code!=='Enter')return;
 e.preventDefault();recording=false;paused=false;const st=game.snapshot();
 if(st.state==='results'){
  if(e.type==='keydown'){restartLive();return}
  if(resultView==='leaderboard'){resultView='card';return}
  const x=(e.clientX-(W-PW*S)/2)/S,y=(e.clientY-(H-PH*S)/2)/S,bh=portrait?1160:800,top=(PH-bh)/2;
  if(y>=top+bh-125&&y<=top+bh-50&&Math.abs(x-PW/2)<245){copyResult();return}
  if(y>top+bh-50&&y<top+bh+8){if(x<PW/2)resultView='leaderboard';else restartLive()}
  return;
 }
 if(st.state==='ready'){game.start();music.play().catch(()=>{})}else game.tap();
}
canvas.addEventListener('pointerdown',input);window.addEventListener('keydown',input);canvas.focus();
function loop(now){let dt=clamp((now-last)/1000,0,.04);last=now;if(!paused){game.step(dt);liveClock+=dt;beginFrame();const s=game.snapshot();mainBoard(s,liveClock,game.events);for(const e of game.events){if(e.id>lastSoundId){sound(e.type);lastSoundId=e.id}}if(s.state==='results'){c.drawImage(bg,-50,-50);c.fillStyle='#0b201ab0';c.fillRect(0,0,PW,PH);const r={score:s.score,blooms:s.blooms,streak:s.bestStreak||0};if(resultView==='leaderboard'){leaderboard(r,2);text('Tap to return to your card',PW/2,PH-60,portrait?26:22,palette.ivory,'Clover Nunito','700','center')}else resultCard(r,1)}}requestAnimationFrame(loop)}
try{const r=await fetch('edit.json');if(r.ok)edit=await r.json()}catch{}
window.ready=true;window.prototypeInfo={version:'1.0',logicalWidth:PW,logicalHeight:PH,fontFamilies:['Clover Nunito','Clover Lora'],takeCount:takes.length};requestAnimationFrame(loop);
console.log('CLOVER_READY',JSON.stringify(window.prototypeInfo));
})();
