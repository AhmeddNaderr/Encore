import {inviteView} from './invite-state.js?v=invite-card';
import {rememberRetry,retrySeconds,responseId} from './task-retry.js?v=retry-countdown';
'use strict';
const dialog = document.getElementById('film-dialog');
const video = document.getElementById('clover-film');
for (const button of document.querySelectorAll('[data-film]')) {
  button.addEventListener('click', () => {
    dialog.showModal();
    video.play().catch(() => {});
  });
}
document.getElementById('close-film').addEventListener('click', () => dialog.close());
dialog.addEventListener('close', () => video.pause());
dialog.addEventListener('click', event => {
  if (event.target !== dialog) return;
  const bounds = dialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
});

const card=document.getElementById('apply');
const tasks=document.getElementById('invite-tasks');
const dashboard=document.getElementById('invite-dashboard');
const referralInput=document.getElementById('referral-link');
const people=document.getElementById('invited-people');
const peopleMessage=document.getElementById('invited-message');
let invitationsPage=1;
let loadVersion=0;
let sessionData=null;
let loginOutcome=new URL(location.href).searchParams.get('x');
const signIn=document.getElementById('x-sign-in'),signOut=document.getElementById('x-sign-out'),taskForm=document.getElementById('task-form');
const taskNames=['follow','like','response'],nextChecks={};
let checkingTask=null,pendingReturn=null,leftPage=false,responseExpanded=false,cooldownTimer,returnTimer=null;
function stopReturnTimer(){
  if(returnTimer!==null&&pendingReturn)document.getElementById(pendingReturn+'-status').textContent='Use ↻ to check again.';
  clearTimeout(returnTimer);returnTimer=null;
}
function cancelReturnCheck(){stopReturnTimer();pendingReturn=null;leftPage=false;}
function paintTasks(){
  const now=Date.now(),responseUrl=document.getElementById('response-url').value;
  const waiting=Object.fromEntries(taskNames.map(task=>[task,retrySeconds(nextChecks,task,responseUrl,now)]));
  const enabled=Boolean(sessionData?.authenticated&&sessionData.applicationsOpen&&sessionData.campaign);
  for(const task of taskNames){
    const done=sessionData?.checks?.[task]==='verified';
    const action=document.getElementById(task+'-task'),badge=document.querySelector(`[data-complete="${task}"]`),check=document.querySelector(`[data-check="${task}"]`);
    action.hidden=done;action.setAttribute('aria-disabled',String(!enabled||Boolean(checkingTask)));action.tabIndex=enabled&&!checkingTask?0:-1;
    badge.hidden=!done;
    if(check){
      const busy=checkingTask===task,cooling=waiting[task]>0;
      check.hidden=done;check.disabled=!enabled||Boolean(checkingTask)||cooling;check.textContent=busy?'…':cooling?`${waiting[task]}s`:'↻';check.classList.toggle('is-waiting',cooling);
      const label=busy?`Checking ${task} with X…`:!sessionData?.applicationsOpen?'Verification opens with our announcement':!enabled?'Sign in with X to verify':checkingTask?'Another task is being checked':cooling?`Check ${task} again in ${waiting[task]} seconds`:`Verify ${task} with X`;
      check.title=label;check.setAttribute('aria-label',label);check.setAttribute('aria-busy',String(busy));
    }
    document.querySelector(`[data-task-row="${task}"]`).classList.toggle('is-complete',done);
  }
  const responseDone=sessionData?.checks?.response==='verified';
  document.getElementById('response-toggle').hidden=!enabled||responseDone||responseExpanded;
  document.getElementById('response-toggle').setAttribute('aria-expanded',String(responseExpanded));
  taskForm.hidden=!enabled||responseDone||!responseExpanded;
  const verify=document.getElementById('verify-tasks');verify.disabled=!enabled||Boolean(checkingTask)||waiting.response>0;verify.textContent=checkingTask==='response'?'…':waiting.response?`${waiting.response}s`:'Check';
  verify.setAttribute('aria-label',waiting.response?`Check response again in ${waiting.response} seconds`:'Check your reply or quote');
  document.getElementById('response-url').disabled=!enabled||Boolean(checkingTask);
  clearTimeout(cooldownTimer);
  // One clock snapshot per paint avoids a disabled button without a wake-up.
  // The countdown only updates the UI; it never makes API calls.
  if(Object.values(waiting).some(seconds=>seconds>0))cooldownTimer=setTimeout(paintTasks,250);
}
function updateAuth(data){
  if(sessionData?.handle!==data.handle||!data.authenticated){cancelReturnCheck();responseExpanded=false;for(const key of Object.keys(nextChecks))delete nextChecks[key];document.getElementById('response-url').value='';for(const task of taskNames)document.getElementById(task+'-status').textContent='';}
  sessionData=data;signIn.hidden=Boolean(data.authenticated);signIn.disabled=!data.applicationsOpen;
  signOut.hidden=!data.authenticated;
  document.getElementById('signed-in-badge').hidden=!data.authenticated;
  const handle=document.getElementById('signed-in-as');handle.hidden=!data.authenticated;handle.textContent=data.authenticated?'@'+data.handle:'';
  const status=document.getElementById('registration-status');
  document.querySelector('#invite-tasks .status-label').textContent=data.preview?'LOCAL PREVIEW · SAMPLE DATA':data.test?'X CONNECTION TEST':data.applicationsOpen?'APPLICATIONS OPEN':'APPLICATIONS OPEN SOON';
  if(data.authenticated){
    status.textContent=data.test?'X sign-in is working. Tasks open with our announcement. This test does not create an application.':'Complete each step to join the early list and unlock your invite link.';
    if(data.campaign){
      document.getElementById('follow-task').href=data.campaign.profileUrl;
      document.getElementById('like-task').href=data.campaign.postUrl;
      const postId=responseId(data.campaign.postUrl);
      const composer=new URL('https://x.com/intent/post');
      if(postId)composer.searchParams.set('url',data.campaign.profileUrl.replace(/\/$/,'')+'/status/'+postId);
      document.getElementById('response-task').href=postId?composer.href:data.campaign.postUrl;
    }
  }else{status.textContent=data.applicationsOpen?'Sign in with X to start your early-access application.':'Applications aren’t open yet. You’ll be able to apply here when they begin.';}
  paintTasks();
}
const dateLabel=value=>Number.isSafeInteger(value)&&value>=0?new Intl.DateTimeFormat('en',{month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit',timeZone:'UTC'}).format(value)+' UTC':'Not yet';
function displayTasks() {
  tasks.hidden=false;dashboard.hidden=true;card.classList.remove('is-dashboard');
  card.setAttribute('aria-labelledby','invite-title');
  referralInput.value='';people.replaceChildren();
}
function displayPeople(invitations) {
  people.replaceChildren();
  if(!invitations || !Array.isArray(invitations.rows))throw new Error('Missing invitation details');
  invitationsPage=invitations.page;
  document.getElementById('invited-total').textContent=String(invitations.total);
  peopleMessage.hidden=invitations.rows.length>0;
  peopleMessage.textContent='No invitations yet. Share your link to invite someone.';
  for(const person of invitations.rows) {
    const li=document.createElement('li'),details=document.createElement('details'),summary=document.createElement('summary');
    const name=document.createElement('span'),status=document.createElement('span');
    name.className='invite-person-name';name.textContent='@'+person.handle;
    status.className='invite-person-status'+(person.credited?'':' is-pending');
    status.textContent=person.credited?'Verified · +1':'Pending';
    summary.append(name,status);details.append(summary);
    const info=document.createElement('dl');info.className='invite-person-details';
    for(const [label,value] of [['Joined',dateLabel(person.joinedAt)],['Tasks verified',dateLabel(person.verifiedAt)],['Referral credit',person.credited?'1 point awarded':'Not awarded']]) {
      const row=document.createElement('div'),term=document.createElement('dt'),definition=document.createElement('dd');
      term.textContent=label;definition.textContent=value;row.append(term,definition);info.append(row);
    }
    details.append(info);li.append(details);people.append(li);
  }
  document.getElementById('invite-pagination').hidden=invitations.pages<=1;
  document.getElementById('invites-page').textContent=`${invitations.page} / ${invitations.pages}`;
  document.getElementById('invites-previous').disabled=invitations.page<=1;
  document.getElementById('invites-next').disabled=invitations.page>=invitations.pages;
}
async function loadInvitationCard(page=1) {
  const version=++loadVersion;
  document.getElementById('invite-load-error').hidden=!['failed','cancelled'].includes(loginOutcome);
  document.getElementById('invites-retry').hidden=true;
  try {
    const response=await fetch('/api/invite/me?invitesPage='+page,{credentials:'same-origin',cache:'no-store',signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw new Error('Unavailable');
    const data=await response.json();
    if(version!==loadVersion)return;
    updateAuth(data);
    if(inviteView(data)!=='dashboard'){displayTasks();return;}
    const applicant=data.applicant;
    if(!/^[a-f0-9]{24}$/.test(applicant.referralCode))throw new Error('Invalid referral');
    displayPeople(applicant.invitations);
    document.getElementById('my-points').textContent=String(applicant.points);
    document.getElementById('my-pending').textContent=String(applicant.pending);
    const link=new URL('/',location.origin);link.searchParams.set('ref',applicant.referralCode);referralInput.value=link.href;
    document.getElementById('dashboard-status').textContent=data.preview===true?'LOCAL PREVIEW · SAMPLE DATA':'TASKS VERIFIED';
    const focusedTask=tasks.contains(document.activeElement);
    tasks.hidden=true;dashboard.hidden=false;card.classList.add('is-dashboard');card.setAttribute('aria-labelledby','dashboard-title');
    if(focusedTask){const title=document.getElementById('dashboard-title');title.tabIndex=-1;title.focus();}
  } catch {
    if(version!==loadVersion)return;
    updateAuth({authenticated:false,applicationsOpen:false});displayTasks();
    if(dashboard.hidden)document.getElementById('invite-load-error').hidden=false;
    else {
      peopleMessage.hidden=false;peopleMessage.textContent='We couldn’t refresh your invitations. Try again.';
      document.getElementById('invites-retry').hidden=false;
    }
  }
}
document.getElementById('copy-referral').addEventListener('click',async()=>{
  if(dashboard.hidden||!referralInput.value)return;
  try {await navigator.clipboard.writeText(referralInput.value);document.getElementById('copy-status').textContent='Link copied. Ready to share.';}
  catch {referralInput.focus();referralInput.select();document.getElementById('copy-status').textContent='Select and copy your link above.';}
});
document.getElementById('invites-previous').addEventListener('click',()=>loadInvitationCard(invitationsPage-1));
document.getElementById('invites-next').addEventListener('click',()=>loadInvitationCard(invitationsPage+1));
document.getElementById('invites-retry').addEventListener('click',()=>loadInvitationCard(invitationsPage));
document.getElementById('invite-retry').addEventListener('click',()=>loadInvitationCard(invitationsPage));
signIn.addEventListener('click',()=>{
  if(signIn.disabled)return;
  loginOutcome=null;
  const url=new URL('/auth/x',location.origin),ref=new URL(location.href).searchParams.get('ref');
  if(/^[a-f0-9]{24}$/.test(ref??''))url.searchParams.set('ref',ref);
  location.assign(url.href);
});
signOut.addEventListener('click',async()=>{
  cancelReturnCheck();
  signOut.disabled=true;++loadVersion;
  try{const res=await fetch('/api/invite/logout',{method:'POST',headers:{'X-CSRF-Token':sessionData?.csrf??''}});if(!res.ok&&res.status!==401)throw 0;sessionData=null;displayTasks();await loadInvitationCard();}
  catch{document.getElementById('invite-load-error').hidden=false;}
  finally{signOut.disabled=false;}
});
function openResponse(){responseExpanded=true;paintTasks();document.getElementById('response-url').focus();}
document.getElementById('response-toggle').addEventListener('click',openResponse);
for(const task of taskNames){
  document.getElementById(task+'-task').addEventListener('click',event=>{
    if(!sessionData?.authenticated||!sessionData.applicationsOpen||checkingTask){event.preventDefault();return;}
    cancelReturnCheck();
    if(task==='response'){openResponse();}
    else{pendingReturn=task;document.getElementById(task+'-status').textContent='We’ll check shortly after you return. Use ↻ to check again.';}
    paintTasks();
  });
}
for(const button of document.querySelectorAll('[data-check]'))button.addEventListener('click',()=>checkTask(button.dataset.check));
// Give X time to update after the user returns. Focus and visibility events
// share one timer; leaving again or checking manually cancels that timer.
function leaveForTask(){stopReturnTimer();if(pendingReturn)leftPage=true;}
window.addEventListener('blur',leaveForTask);
function checkOnReturn(){
  if(!pendingReturn||!leftPage||document.hidden||checkingTask||returnTimer!==null)return;
  const task=pendingReturn;
  document.getElementById(task+'-status').textContent='We’ll check in 5 seconds, giving X time to update.';
  returnTimer=setTimeout(()=>{
    returnTimer=null;
    if(pendingReturn!==task||document.hidden)return;
    document.getElementById(task+'-status').textContent='Use ↻ to check again when ready.';
    checkTask(task);
  },5000);
}
window.addEventListener('focus',()=>{paintTasks();checkOnReturn();});
document.addEventListener('visibilitychange',()=>{if(document.hidden){leaveForTask();}else{paintTasks();checkOnReturn();}});
document.getElementById('response-url').addEventListener('input',paintTasks);
taskForm.addEventListener('submit',event=>{event.preventDefault();checkTask('response');});
async function checkTask(task){
  cancelReturnCheck();
  const responseUrl=document.getElementById('response-url').value;
  if(!sessionData?.authenticated||!sessionData.applicationsOpen||checkingTask||retrySeconds(nextChecks,task,responseUrl,Date.now())>0)return;
  const message=document.getElementById(task+'-status');checkingTask=task;message.textContent='Checking with X…';paintTasks();
  const current=++loadVersion;
  try{
    const input={task,...(task==='response'?{responseUrl}:{})};
    const res=await fetch('/api/invite/verify',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':sessionData.csrf},body:JSON.stringify(input),signal:AbortSignal.timeout(45000)});
    const data=await res.json();if(current!==loadVersion)return;
    rememberRetry(nextChecks,task,responseUrl,data,Date.now());
    if(!res.ok){if(res.status===401){await loadInvitationCard();if(sessionData?.authenticated)message.textContent='Your X session has expired. Sign out, then sign in again.';return;}throw new Error(data.error||'Unable to check this task. Please try again.');}
    sessionData.checks=data.checks;
    if(data.verified){await loadInvitationCard();return;}
    message.textContent=data.checks?.[task]==='verified'?'':task==='response'?'Not confirmed. Paste your reply or quote of our announcement. A different post link can be checked right away.':task==='like'&&data.moreLikes?'Not found yet. Like our announcement, then use ↻ when the countdown ends.':'Not confirmed yet. Complete this task on X, then use ↻ when the countdown ends.';
    for(const other of taskNames)if(data.checks?.[other]==='verified')document.getElementById(other+'-status').textContent='';
  }catch(error){if(current===loadVersion)message.textContent=error.name==='TimeoutError'?'X took too long. Please try again shortly.':error.message||'Verification is temporarily unavailable.';}
  finally{checkingTask=null;paintTasks();}
}
const outcome=new URL(location.href).searchParams.get('x');
if(outcome){const clean=new URL(location.href);clean.searchParams.delete('x');history.replaceState(null,'',clean);if(outcome==='failed'||outcome==='cancelled'){document.getElementById('invite-load-error').hidden=false;document.getElementById('invite-load-error').firstChild.textContent=outcome==='failed'?'X sign-in could not be completed. Please sign in again. ':'X sign-in was cancelled. ';}}
loadInvitationCard();
