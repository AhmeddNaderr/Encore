import {initWorld} from './world.mjs';
'use strict';
const heads=[
 {id:'01-forest-hoodie',name:'The Listener',category:'earthy',tag:'A good song. A quiet afternoon.',color:'#b9c9a7',description:'Headphones on, world off. Finds a little magic in the everyday and always has a song to share.'},
 {id:'19-velvet-cape',name:'Opal Bloom',category:'dreamy',tag:'Never quite the same in the light.',color:'#d4c6d9',description:'A daydream dressed in velvet. A little iridescent, a little mysterious, and entirely in their own world.'},
 {id:'04-yellow-raincoat',name:'Rain Walker',category:'earthy',tag:'A little rain never hurt.',color:'#dbe0ad',description:'Sees a grey sky and calls it an adventure. The forecast is always a good excuse to head outside.'},
 {id:'23-space-suit',name:'Retro Bot',category:'wild',tag:'Built for somewhere beyond.',color:'#b5c6cd',description:'Old-school charm, far-out plans. A curious little explorer with a whole universe of places to be.'},
 {id:'14-patchwork-cardigan',name:'Knit Wanderer',category:'earthy',tag:'Comfortably one of a kind.',color:'#dcc5b0',description:'Different threads, one warm heart. Collects stories, takes the scenic route, and makes everyone feel a little more at home.'},
 {id:'10-cropped-leather',name:'Nocturne',category:'wild',tag:'A little better after dark.',color:'#babacf',description:'The night-owl of the family. Quiet confidence, a leather jacket, and a soft spot for the unexpected.'},
 {id:'31-artist-smock',name:'Porcelain Garden',category:'dreamy',tag:'A delicate sort of imagination.',color:'#c6d6d3',description:'A fine china daydream with paint on the sleeves. Sees a blank page as an invitation to make something new.'},
 {id:'26-ceremonial-coat',name:'Stained Glass',category:'dreamy',tag:'Every colour has a story.',color:'#dcd3b6',description:'A small kaleidoscope of personality. Turns even an ordinary moment into something worth looking at twice.'},
 {id:'06-cream-turtleneck',name:'The Thinker',category:'earthy',tag:'Probably wondering what if.',color:'#c9ceaf',description:'A cosy knit, a pair of glasses, and a head full of questions. Usually the one who notices what everybody else missed.'},
 {id:'21-quilted-kimono',name:'Ink Poet',category:'dreamy',tag:'A thought worth keeping.',color:'#c4c8bd',description:'Finds beauty in a quiet line and a small detail. A thoughtful soul with a story slowly coming into focus.'},
 {id:'24-tech-shell',name:'Liquid Chrome',category:'wild',tag:'Reflecting a different future.',color:'#bacbc4',description:'Always looking ahead. A bright, metallic personality with a knack for finding a new angle on everything.'},
 {id:'29-poncho',name:'Paper Dreamer',category:'wild',tag:'Folded from a different idea.',color:'#dfc7b6',description:'A little imagination goes a long way. A paper-hearted wanderer wearing a world of possibilities.'}
];
const $=id=>document.getElementById(id),storageKey='cloverheads-favourite-v1';
let filter='all',expanded=false,activeHead=0,favourite=null;
const dialogFocus=new Map();
try{const saved=localStorage.getItem(storageKey);if(heads.some(h=>h.id===saved))favourite=saved}catch{}
const categoryLabel={earthy:'DOWN TO EARTH',dreamy:'DREAM A LITTLE',wild:'WILD AT HEART'};
function renderGallery(){
 const all=heads.filter(h=>filter==='all'||h.category===filter),visible=expanded?all:all.slice(0,8),grid=$('head-grid');grid.replaceChildren();
 for(const h of visible){const b=document.createElement('button');b.className='head-card';b.dataset.head=h.id;b.setAttribute('aria-label','Meet '+h.name);
  const frame=document.createElement('span');frame.className='head-frame';frame.style.background=h.color;
  const number=document.createElement('span');number.className='head-number';number.textContent='FIELD STUDY / '+String(heads.indexOf(h)+1).padStart(2,'0');
  const image=document.createElement('img');image.src=`assets/heads/${h.id}.png`;image.alt=h.name+' Cloverhead';image.width=1254;image.height=1254;image.loading='lazy';image.decoding='async';frame.append(number,image);
  if(favourite===h.id){const heart=document.createElement('span');heart.className='head-heart';heart.textContent='♥';heart.setAttribute('aria-label','Your favourite');frame.append(heart)}
  const label=document.createElement('span');label.className='head-card-label';label.textContent=h.name;const arrow=document.createElement('span');arrow.textContent='↗';label.append(arrow);
  const caption=document.createElement('span');caption.className='head-caption';caption.textContent=h.tag;b.append(frame,label,caption);grid.append(b);
 }
 $('gallery-count').textContent=visible.length+' characters to meet';$('more-heads').hidden=all.length<=8;$('more-heads').firstChild.textContent=expanded?'A little less for now ':'Meet more heads ';$('more-heads').querySelector('span').textContent=expanded?'↑':'↓';
 const selected=heads.find(h=>h.id===favourite);$('favourite-note').hidden=!selected;$('favourite-note').textContent=selected?'Your kind of head: '+selected.name+' ♡':'';
}
export function openDialog(dialog){if(dialog.open)return;dialogFocus.set(dialog,document.activeElement);dialog.showModal();document.body.classList.add('dialog-open');dialog.querySelector('.close')?.focus()}
function closeDialog(dialog){dialog.close()}
for(const d of document.querySelectorAll('dialog')){d.addEventListener('close',()=>{document.body.classList.toggle('dialog-open',!!document.querySelector('dialog[open]'));const target=dialogFocus.get(d);dialogFocus.delete(d);if(target?.isConnected&&(!target.closest('dialog')||target.closest('dialog').open))target.focus()});d.addEventListener('click',e=>{if(e.target===d){const b=d.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)closeDialog(d)}})}
function showHead(id,open=true){const n=heads.findIndex(h=>h.id===id);if(n<0)return;activeHead=n;const h=heads[n];$('head-dialog-image').src=`assets/heads/${h.id}.png`;$('head-dialog-image').alt=h.name+' — '+h.tag;$('head-dialog-art').style.background=h.color;$('head-dialog-title').textContent=h.name;$('head-dialog-category').textContent=categoryLabel[h.category];$('head-dialog-description').textContent=h.description;$('head-position').textContent=String(n+1).padStart(2,'0')+' / '+String(heads.length).padStart(2,'0');$('selection-status').textContent=favourite===h.id?'Your favourite, saved on this device.':'';if(open)openDialog($('head-dialog'))}
document.addEventListener('click',e=>{const close=e.target.closest('[data-close]');if(close){closeDialog(close.closest('dialog'));return}const apply=e.target.closest('[data-apply]');if(apply){openDialog($('apply-dialog'));return}const head=e.target.closest('[data-head]');if(head)showHead(head.dataset.head)});
for(const b of document.querySelectorAll('[data-filter]'))b.addEventListener('click',()=>{filter=b.dataset.filter;expanded=false;for(const other of document.querySelectorAll('[data-filter]')){other.classList.toggle('active',other===b);other.setAttribute('aria-pressed',String(other===b))}renderGallery()});
$('more-heads').addEventListener('click',()=>{expanded=!expanded;renderGallery()});
$('previous-head').addEventListener('click',()=>showHead(heads[(activeHead+heads.length-1)%heads.length].id,false));$('next-head').addEventListener('click',()=>showHead(heads[(activeHead+1)%heads.length].id,false));
$('head-dialog').addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();showHead(heads[(activeHead+heads.length+(e.key==='ArrowLeft'?-1:1))%heads.length].id,false)}});
$('pick-favourite').addEventListener('click',()=>{favourite=heads[activeHead].id;try{localStorage.setItem(storageKey,favourite);$('selection-status').textContent='Saved. This head feels like you. ♡'}catch{$('selection-status').textContent='Selected for this visit. Browser storage is unavailable.'}renderGallery()});
$('privacy-open').addEventListener('click',()=>openDialog($('privacy-dialog')));$('clear-favourite').addEventListener('click',()=>{favourite=null;try{localStorage.removeItem(storageKey)}catch{}renderGallery();$('privacy-status').textContent='Your saved favourite has been cleared.'});
if($('year'))$('year').textContent=new Date().getFullYear();
renderGallery();

initWorld({openDialog});
