import {openDialog} from './app.js?v=flow-demo-9';
import {initPassCard} from './pass-card.mjs?v=single-card-10';
import {initQuest} from './live-quest.mjs?v=card-flow-15';
import {createApplicationClient} from './application-client.mjs?v=allocation-13';

const client=createApplicationClient();
initPassCard({openDialog,getAccount:()=>client.getState().account,getReferralUrl:()=>client.getState().applicant?.referralLink});
initQuest({openDialog,client});
if(location.hash==='#apply')openDialog(document.getElementById('apply-dialog'));
