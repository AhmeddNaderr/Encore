# Clover / Cloverheads secondary research

Research date: 2026-10-21 UTC. Read-only public research. No sign-in, posts, messages, wallet connection, application, or other state-changing actions.

## Identity and scope

- Official X: https://x.com/cloverdotfamily — opened directly, saved `x_profile.html` / `x_profile.txt`. Bio: “Trading fees fund NFT rewards for holders. Building on Robinhood Chain. 🍀 Early Invite open. Apply for early creator access. By @maxsimaeth”. Links to https://clover.family.
- Official base website: https://clover.family — opened 200; saved `clover.html`. Current title “Clover Early Invite — Tokens and NFT rewards”. Terms/privacy backlink @cloverdotfamily.
- Official collection/world website: https://clover.family/cloverheads — opened 200; saved `cloverheads.html` / `cloverheads.txt`. Title “Cloverheads — Enter Clover Valley”. Official Oct 20 announcement links this same route.
- Clover's token launchpad and the Cloverheads collection are related but distinct. The Cloverheads website explicitly says its early-access programme is separate from Clover's token-launch Early Invite. Do not assign launchpad token economics to a game.

## Latest announcement and factual precedence

Opened full post: https://x.com/cloverdotfamily/status/2112496434981355626 (saved `x_status.html`; 2026-10-20 10:49 UTC).

Exact substantive text:

> Meet Cloverheads - different styles, different personalities, one community.
>
> Enter Clover Valley, create your personal card, complete the tasks and submit your application.
> 🔗 clover.family/cloverheads
>
> Whitelist applications are now open!
> 🍀 Supply: 888 NFTs
> 🎟️ FREE MINT
> 📅 Mint date: TBA
>
> Communities & collab managers - interested in spots for your community? Our DMs are open. 💌
>
> Applying does not guarantee an allocation.

X labels the attached post image “Made with AI.” That image is still real, official project artwork, but should not be described as hand-drawn or used to claim a human artist.

The current website's storybook still says: “The mint date, price and final supply have not been announced.” Its default application copy also says applications will open with the announcement. These conflict with the newer dated X post. For any current collection claim, attribute 888/free mint/applications open to the Oct 20 post; mint date remains TBA. These facts need not appear in a game concept video.

## Founder / team

- https://x.com/maxsimaeth — opened 200, saved `x_founder.html`. Display name Maxsima; handle @Maxsimaeth. Bio “Building @cloverdotfamily 🍀”.
- https://x.com/Maxsimaeth/status/2104841889769791530 — opened 200, saved `x_founder_post.html` / `.txt`. Dated Sep 29 2026. Says “I’ve been working on my own project, Clover”, and “Clover is a launchpad I’m developing for Robinhood Chain”. This substantiates builder/project attribution. Does not substantiate legal founder status, real-world name, registered company, or team size.
- Full founder post discusses a share of trading fees funding token-specific NFT pools, NFTs sent to holders selected through weighted draws, and an Early Invite. It also says earlier projects did not work out, without naming them. Do not invent history or a track record.
- Additional named team members, character artist, company/legal entity: unknown from opened sources.

## Roadmap / project claims

- Intro post https://x.com/cloverdotfamily/status/2103950119099941208 — opened 200, saved `x_intro.html` / `.txt`, dated Sep 26 2026. “Launch your own token. Choose an NFT collection. Trading fees fund NFT purchases. Weighted draws send them to holders. Building on Robinhood Chain.” These are project claims, not independent evidence of a live deployed protocol.
- Roadmap https://x.com/cloverdotfamily/status/2112273785751527773 — opened 200, saved `x_roadmap.html` / `.txt`, dated Oct 19 2026. “Grow our community and NFT pool. Reveal Cloverheads. Launch the platform & CLOVER. Activate NFT rewards. Open the free mint. Expand across chains. Starting on Robinhood Chain. Building together, one step at a time.” These are future intentions. No game announced in this opened roadmap.
- Homepage describes token launch → collection selection → fees accumulate → automatic NFT purchase when covering floor, costs, reserve → weighted holder selection. Says token balance and holding time shape the odds; balance carries more weight. Explicitly no guaranteed reward.
- Current verified marketplace listing/contract address: not located in opened official website, collection world, current profile, or opened announcements. Mark unknown. No claim that a marketplace does not exist globally.

## Existing interactive experience / overlap to avoid

Source: https://clover.family/cloverheads (opened HTML, full copy saved).

The existing experience calls itself “AN INTERACTIVE WORLD BY CLOVER”. It is an explorable illustrated valley and collection showcase with social onboarding. Official guide explains glowing clickable objects; tree door enters the King's study; quest scroll opens early-access tasks; portraits, book, bell, pond; optional forest sounds; mobile sideways swipe; Explore navigation; Show places labels. It mentions “Some things have a story. Some just like being noticed.”

Named places/interactions confirmed in interface:

- The King's study / the King's door / enter the tree.
- The quest scroll / early-access journey.
- The portrait grove / meet the Cloverheads.
- The storybook / The book of little things.
- The invitation chest / personal card; also “Letters for little wanderers”.
- Valley notices / “Whispers of the valley” / “Pinned under the old oak”.
- Pond: “A moment of stillness” / “Touch the water”.
- Bell: “Ding, a little luck” / “Ring the bell”.
- Firefly jar: “A jar of tiny stars” / “Wake the fireflies”.

Existing world contains a Clover King. Exact dialogue:

> Ah. A new face.
> Come closer, little wanderer. Every head in this valley has a story. Perhaps yours belongs here, too.
> The scroll on my desk will show you how to begin. Or stay a while — there’s plenty to discover.

This supports the King's existence and welcoming role; it does not support invented quests, enemies, wars, villains, powers, factions, currencies, or lore chronology.

No standalone scored/action/puzzle game was identified in the opened sources. Phrase this as “No separate game verified”; do not assert the brand has never built games. A new game proposal should be clearly labeled a fan concept and add a real mechanical loop beyond replaying the existing valley's click-to-read exploration/social tasks.

## Official tone and motifs

Source: https://clover.family/cloverheads.

- Headline: “SOMEWHERE, A LITTLE LUCK IS GROWING.”
- “A little world to wander. A few things to discover.”
- “A little world, waiting.”
- “Follow a little light. See where it takes you.”
- “Same roots. Different stories.”
- “Not every clover grows the same.”
- “Some stay grounded. Some get a little weird.”
- “No payment required. Just a little character.”
- Portrait categories: “Down to earth”, “Dream a little”, “Wild at heart”.
- The collection description: “Cloverheads is a growing NFT character collection by Clover. It begins with one familiar shape, then follows a hundred different curiosities.”

Observed textual tone: gentle, curious, welcoming, whimsical, community/individuality, small discoveries. These are synthesis from the cited copy, not additional canon. The motif set supports clover shape, a valley/tree, warm study, glowing objects/fireflies, pond, bell, portraits, personal visitor card, family/roots, luck. Visual color/material interpretation belongs to the root agent's art inspection.

## Canonical character roster and usable official art URLs

Source opened: https://clover.family/cloverheads/app.js?v=flow-demo-9 (saved `cloverheads_app.js`). This script supplies the visible gallery's names, categories, taglines, descriptions, and image paths; it renders assets at `assets/heads/{id}.png`. Twelve character objects found. These are exact project-supplied names/bios; do not invent alternative names or merge identities. `characters.json` also saved.

| Official name | Category | Official tagline | Official description | Source art URL |
|---|---|---|---|---|
| The Listener | earthy | A good song. A quiet afternoon. | Headphones on, world off. Finds a little magic in the everyday and always has a song to share. | https://clover.family/cloverheads/assets/heads/01-forest-hoodie.png |
| Opal Bloom | dreamy | Never quite the same in the light. | A daydream dressed in velvet. A little iridescent, a little mysterious, and entirely in their own world. | https://clover.family/cloverheads/assets/heads/19-velvet-cape.png |
| Rain Walker | earthy | A little rain never hurt. | Sees a grey sky and calls it an adventure. The forecast is always a good excuse to head outside. | https://clover.family/cloverheads/assets/heads/04-yellow-raincoat.png |
| Retro Bot | wild | Built for somewhere beyond. | Old-school charm, far-out plans. A curious little explorer with a whole universe of places to be. | https://clover.family/cloverheads/assets/heads/23-space-suit.png |
| Knit Wanderer | earthy | Comfortably one of a kind. | Different threads, one warm heart. Collects stories, takes the scenic route, and makes everyone feel a little more at home. | https://clover.family/cloverheads/assets/heads/14-patchwork-cardigan.png |
| Nocturne | wild | A little better after dark. | The night-owl of the family. Quiet confidence, a leather jacket, and a soft spot for the unexpected. | https://clover.family/cloverheads/assets/heads/10-cropped-leather.png |
| Porcelain Garden | dreamy | A delicate sort of imagination. | A fine china daydream with paint on the sleeves. Sees a blank page as an invitation to make something new. | https://clover.family/cloverheads/assets/heads/31-artist-smock.png |
| Stained Glass | dreamy | Every colour has a story. | A small kaleidoscope of personality. Turns even an ordinary moment into something worth looking at twice. | https://clover.family/cloverheads/assets/heads/26-ceremonial-coat.png |
| The Thinker | earthy | Probably wondering what if. | A cosy knit, a pair of glasses, and a head full of questions. Usually the one who notices what everybody else missed. | https://clover.family/cloverheads/assets/heads/06-cream-turtleneck.png |
| Ink Poet | dreamy | A thought worth keeping. | Finds beauty in a quiet line and a small detail. A thoughtful soul with a story slowly coming into focus. | https://clover.family/cloverheads/assets/heads/21-quilted-kimono.png |
| Liquid Chrome | wild | Reflecting a different future. | Always looking ahead. A bright, metallic personality with a knack for finding a new angle on everything. | https://clover.family/cloverheads/assets/heads/24-tech-shell.png |
| Paper Dreamer | wild | Folded from a different idea. | A little imagination goes a long way. A paper-hearted wanderer wearing a world of possibilities. | https://clover.family/cloverheads/assets/heads/29-poncho.png |

The art URLs above are publicly linked by the official page script; this agent has not individually downloaded/viewed each image. Root agent is handling visual inspection and downloaded original art. No inference about gameplay powers should be presented as canonical based on descriptive personality text.

## Source access and limitations

Opened successful official sources: clover.family homepage; /cloverheads; /terms.html; /privacy.html; /app.js?v=early-list; /cloverheads/main.mjs?v=card-flow-15; /cloverheads/app.js?v=flow-demo-9; X project profile; X founder profile; four X permalinks listed above. Local raw captures kept.

X syndication endpoint opened: https://cdn.syndication.twimg.com/tweet-result?id=2112496434981355626&lang=en&token=1; saved `syndication_status.json`. Includes official image URL https://pbs.twimg.com/media/HVEX49MXkAA4AYw.jpg and timestamp, but truncates the long post. Direct X HTML provides complete text.

X oEmbed opened: https://publish.twitter.com/oembed?url=https://twitter.com/cloverdotfamily/status/2112496434981355626 (redirects publish.x.com); saved `oembed_status.json`. Also truncates long text.

Search checks were non-evidentiary: Google challenge/redirect page; Bing unrelated results; Brave quoted handle/domain/founder searches returned sparse or unrelated matches. Search snippets were not used as support for project claims. FxTwitter API 403; website /robots.txt and /sitemap.xml 404. No need for these fallbacks because direct X HTML worked.

Unknowns: exact mint date, deployed contract, official marketplace, legally verified founder identity, broader team, named human artist, deployed gaming roadmap, current protocol operational status, token-to-game utility, game-based rewards. Never fill these gaps with invented claims.

## Coverage limitation

The parent agent independently parsed five unique official posts from the public X timeline. Logged-out `/media` and `/with_replies` provided no additional content; the served timeline explicitly terminated at top and bottom. This research therefore does **not** achieve 100+ post coverage. The available direct profile/announcement pages, founder post, website/world, and public gallery script support the findings above, with this limitation explicitly retained.
