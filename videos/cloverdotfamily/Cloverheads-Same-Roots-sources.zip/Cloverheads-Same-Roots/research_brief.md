# Clover / Cloverheads — research brief

**Identity.** Cloverheads is Clover’s character collection and illustrated world: “Same roots. Different stories.” A family shares a clover-shaped head while expressing distinct curiosities, clothes and personalities.

**World and tone.** Clover Valley contains the Clover King’s study, portrait grove, quest scroll, storybook, invitation chest, pond, bell and fireflies. The tone is gentle, curious, slightly odd and welcoming: “Follow a little light. See where it takes you.” This is not combat lore. The linked parent Clover platform describes token trading fees funding NFT purchases and weighted holder draws; keep that separate from the proposed skill game.

**Five core motifs.** (1) One familiar clover shape, different stories. (2) Small acts of noticing and curiosity. (3) Fireflies as little guiding lights. (4) The King’s storybook, scroll and personal invitation. (5) A family growing together across earthy, dreamy and wild personalities.

**Characters / community interests.** The Listener shares songs; Rain Walker welcomes rain; Knit Wanderer collects stories and makes others feel at home; The Thinker notices overlooked details; Porcelain Garden paints; Ink Poet values quiet lines; Paper Dreamer represents folded imagination. These are official character descriptions, not inferred fan preferences. Public posts emphasize togetherness and new character reveals. Private community preferences and inside jokes: unknown.

**Mint status.** The Oct 20 official announcement says 888 NFTs, free mint, date TBA, applications open, and no allocation guarantee. The website storybook still says date, price and supply unannounced. Use the newer announcement for research, but omit mint promises from the game/trailer. A sample WL leaderboard is a concept feature, not a live allocation mechanism.

**Founder.** Official bio credits @maxsimaeth; his bio says “Building @cloverdotfamily.” Further personal claims are unnecessary for the concept. Team roster: unknown.

**Existing experience / avoid.** The website already offers an interactive valley exploration, character gallery, personal card and application tasks. A new game should not merely recreate that tour. Avoid generic combat/running, token-profit promises, invented factions, changing character faces, and treating this unofficial game as an announced roadmap item.

**Coverage.** Opened the profile, pinned post, four additional public posts, linked Clover and Cloverheads sites, official character data and founder profile. Logged-out media/replies returned no post content; the public timeline ended after five unique posts. A 100-post/reply audit was not possible from the accessible public material. No verified existing competitive score game or official marketplace collection was found; absence is not proof none exists.

**Opened sources:**
- https://x.com/cloverdotfamily
- https://x.com/cloverdotfamily/status/2103950119099941208
- https://x.com/cloverdotfamily/status/2112496434981355626
- https://x.com/cloverdotfamily/status/2112273785751527773
- https://x.com/cloverdotfamily/status/2112208679462400002
- https://x.com/cloverdotfamily/status/2110093386829205948
- https://clover.family/
- https://clover.family/cloverheads/
- https://clover.family/cloverheads/app.js?v=flow-demo-9
- https://x.com/maxsimaeth
