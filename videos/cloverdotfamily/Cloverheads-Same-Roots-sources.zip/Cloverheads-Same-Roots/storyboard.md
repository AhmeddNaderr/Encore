# Same Roots — capture storyboard

42-second main cut, 1920×1080 at 60fps. 15-second X cut, 1080×1920 at 60fps. Every gameplay shot is deterministic capture of the playable slice: the skilled driver calls the same evaluated `tap()` used by pointer/Space input. Three seeds/takes and recorded examples exist; no injected scores. Titles, sample leaderboard and share preview are motion graphics. The project’s exact source art remains intact.

## Main cut

| Time | Screen / source | Motion | Text | Sound |
|---|---|---|---|---|
| 0–3 | Take A, source20.8–23.8: a late-round four-friend bloom | Immediate light handoff, four return streaks, full clover expansion; no opening logo/title | Gameplay score/progress only | Firefly chimes; bloom at0.905 |
| 3–5.5 | Take A, source0.1–2.6: the first timing taps | Root lines up; TAP NOW; the same light visits distinct portraits | “Tap in time. Light all four.” (6 words) | Soft actual-input plucks |
| 5.5–8 | Take A, source2.6–5.1: first full bloom | One shared root fills, four gold leaves, next cycle begins | Ordinary gameplay UI | Bloom at6.41 |
| 8–10 | Take C, source7.45–9.45: an evaluated miss and recovery | An amber failure pulse resets unfinished progress; earned points stay | “Every friend. Only once.” | Warm muted miss, then a successful pass |
| 10–12 | Take A, source10.5–12.5 | Faster family relay and completed bloom | Ordinary gameplay UI and actual personality cue | Actual tap/pass/bloom cues |
| 12–14 | Take B, source14.5–16.5 | Faster root, larger multiplier | Ordinary gameplay UI | Actual cues |
| 14–16.5 | Take B, source17.9–20.4 | Successive precise taps, Paper Dreamer’s shorter return | Actual ability feedback | Short rising plucks |
| 16.5–19 | Take B, source21.3–23.8 | Another fast four-friend return | Ordinary gameplay UI | Bloom at17.155 |
| 19–22 | Take B, source25.5–28.5 | Final pressure, countdown, seventh bloom | Ordinary gameplay UI | Bloom at20.96 |
| 22–25 | Take B, source27–30 | Last earned visits and timeout | Ordinary gameplay UI | Resolved final phrase |
| 25–29 | Sample WL leaderboard, earned Take B result | Earned score tallies; a rank counter climbs from tenth to third among fictional sample rows | “Bots can like a post. Can you bring every story together?” | Gentle UI/rank chimes |
| 29–32 | Actual Take B result:20,400 points /7 blooms /sample rank3 | Card settles; four canonical portraits frame result | Score, sample rank, Share on X | Page/chime |
| 32–35 | Result card flies into an X post **mock-up** | Small card shift, post preview appears; no message is sent | “Found my kind of head. One light. Four different stories.” | Soft UI arrival |
| 35–38 | Four canonical portraits / official Valley, motion graphics | Cut-out breathing, restrained light and background movement | “Same roots. Different stories.” | Quiet family bloom tail |
| 38–42 | Project logo, game name, supplied Encore mark | Near-static legible brand card with short entrance | Cloverheads /Same Roots /Concept by Encore Studio; exact Encore tagline and CTA | Music resolves and fades |

Longer holds are reserved for reading the result, leaderboard and end card. The gameplay section uses short cuts around actual actions. Claim labels remain “concept” and “sample”; no mint/financial outcome is promised.

## 15-second sound-off X cut

| Time | Screen / source | Motion / text | Sound |
|---|---|---|---|
| 0–2 | Take A20.8–22.8 | Immediate shared bloom; no opening title/logo | Bloom |
| 2–5.5 | Take A0.1–3.6 | Alignment → tap → different friend → full root. “Tap in time. Light all four.” | Plucks/pass |
| 5.5–7.7 | Take C7.5–9.7 | A repeat/mistime loses the current chain, then recovery. “Every friend. Only once.” | Muted miss/pass |
| 7.7–9 | Take B27–28.3 | Fast full-family payoff | Bloom |
| 9–11.25 | Sample WL leaderboard | Clearly labelled fictional rows, earned score and rank tally upward | UI chime |
| 11.25–13 | Result/share preview | Real result card + X mock-up; no outbound action | Soft UI |
| 13–15 | Clover/Same Roots + Encore | Legible project/game/concept credit and Encore branding | Resolution |

## Phase 6 — cinematic inserts

No AI inserts are used. The official portraits and environments are already strong; gameplay and motion graphics explain the concept without risking generated character drift. There is no image-to-video tool in this environment. No generated substitute footage is represented as gameplay.
