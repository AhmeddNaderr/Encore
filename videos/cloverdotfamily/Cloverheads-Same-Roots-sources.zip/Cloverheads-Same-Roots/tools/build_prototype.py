from pathlib import Path
import json
P=Path(__file__).resolve().parents[1]
engine=(P/'prototype/engine.js').read_text()
view=(P/'prototype/view.js').read_text()
edit=json.loads((P/'prototype/edit.json').read_text())
view=view.replace("try{const r=await fetch('edit.json');if(r.ok)edit=await r.json()}catch{}",'edit='+json.dumps(edit,separators=(',',':'))+';')
css=(P/'art/fonts/fonts.css').read_text().replace('url("./','url("../art/fonts/')
shell='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cloverheads · Same Roots — Encore concept</title><style>'''+css+'''\nhtml,body{margin:0;width:100%;height:100%;background:#10251b;overflow:hidden}canvas{display:block;width:100%;height:100%;touch-action:none}</style></head><body><canvas id="game" aria-label="Same Roots. Press Space or tap when the turning root faces an unlit friend. Light all four different friends to bloom." tabindex="0"></canvas><script>'''+engine.replace('</script','<\\/script')+'''</script><script>'''+view.replace('</script','<\\/script')+'''</script></body></html>'''
(P/'prototype/index.html').write_text(shell)
print('Built single-file HTML application; artwork, fonts and audio remain separately sourced assets.',len(shell.encode()),'bytes')
