from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
P=Path(__file__).resolve().parents[1];rows=[('0000_733','01-forest-hoodie','00:00.733 · Listener arrival'),('0003_550','04-yellow-raincoat','00:03.550 · complete family'),('0014_000','06-cream-turtleneck','00:14.000 · faster relay')]
board=Image.new('RGB',(1560,1890),'#f3f0df');d=ImageDraw.Draw(board)
f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';F=lambda n:ImageFont.truetype(f,n)
d.text((35,25),'ART FIDELITY / ACTUAL GAMEPLAY vs OFFICIAL SOURCE',font=F(27),fill='#244431')
for i,(stamp,art,title) in enumerate(rows):
 y=95+i*590;d.text((35,y),title,font=F(23),fill='#244431')
 game=Image.open(P/'art/gate-a-evidence'/f'gameplay-{stamp}.png');game=game.resize((960,540),Image.Resampling.LANCZOS);board.paste(game,(25,y+35))
 im=Image.open(P/'art/raw'/f'{art}.png').convert('RGBA');im.thumbnail((530,530));tile=Image.new('RGBA',(530,540),'#c9ceaf');tile.alpha_composite(im,((530-im.width)//2,540-im.height));board.paste(tile.convert('RGB'),(1005,y+35))
board.save(P/'art/side_by_side.png')
