#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const http = require('node:http');
const { spawn } = require('node:child_process');
const { once } = require('node:events');
const { performance } = require('node:perf_hooks');

const PROJECT = path.resolve(__dirname, '..');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.mp4': 'video/mp4' };

function argsFrom(argv) {
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const item = argv[i];
    if (!item.startsWith('--')) { if (!args.command) args.command = item; else throw new Error(`Unexpected argument: ${item}`); continue; }
    const eq = item.indexOf('=');
    const key = item.slice(2, eq < 0 ? undefined : eq);
    if (eq >= 0) args[key] = item.slice(eq + 1);
    else if (argv[i + 1] && !argv[i + 1].startsWith('--')) args[key] = argv[++i];
    else args[key] = true;
  }
  return args;
}

function positive(value, fallback, name, integer = false) {
  const n = value === undefined ? fallback : Number(value);
  if (!Number.isFinite(n) || n <= 0 || (integer && !Number.isInteger(n))) throw new Error(`${name} must be a positive ${integer ? 'integer' : 'number'}`);
  return n;
}

function playwright() {
  const candidates = [process.env.PLAYWRIGHT_MODULE, 'playwright', '/opt/codex/cua_node/lib/node_modules/playwright', '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'];
  for (const name of candidates.filter(Boolean)) { try { return require(name); } catch (error) { if (error.code !== 'MODULE_NOT_FOUND') throw error; } }
  throw new Error('Playwright is unavailable; install it or set PLAYWRIGHT_MODULE.');
}

async function openProject(options = {}) {
  const width = positive(options.width, 1920, 'width', true);
  const height = positive(options.height, 1080, 'height', true);
  const entry = path.join(PROJECT, 'prototype', 'index.html');
  if (!fs.existsSync(entry)) throw new Error(`Prototype not found: ${entry}`);
  const issues = { pageErrors: [], consoleErrors: [], failedRequests: [], badResponses: [] };
  const server = http.createServer(async (req, res) => {
    try {
      const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
      if (pathname === '/favicon.ico') { res.writeHead(204); res.end(); return; }
      const file = path.resolve(PROJECT, `.${pathname === '/' ? '/prototype/index.html' : pathname}`);
      if (file !== PROJECT && !file.startsWith(PROJECT + path.sep)) { res.writeHead(403); res.end(); return; }
      const stat = await fsp.stat(file);
      if (!stat.isFile()) { res.writeHead(404); res.end(); return; }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store', 'Content-Length': stat.size });
      fs.createReadStream(file).pipe(res);
    } catch { res.writeHead(404); res.end(); }
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  let browser;
  try {
    const launch = { headless: true, args: ['--no-sandbox', '--disable-gpu', '--disable-accelerated-2d-canvas', '--hide-scrollbars', '--font-render-hinting=none'] };
    const executable = options.chromium || process.env.CHROMIUM_PATH || (fs.existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
    if (executable) launch.executablePath = executable;
    browser = await playwright().chromium.launch(launch);
    const context = await browser.newContext({ viewport: { width, height }, deviceScaleFactor: 1, colorScheme: 'light', reducedMotion: 'no-preference' });
    const page = await context.newPage();
    page.on('pageerror', error => issues.pageErrors.push(error.message));
    page.on('console', message => { if (message.type() === 'error') issues.consoleErrors.push(message.text()); });
    page.on('requestfailed', req => issues.failedRequests.push({ path: new URL(req.url()).pathname, error: req.failure()?.errorText }));
    page.on('response', response => { if (response.status() >= 400) issues.badResponses.push({ path: new URL(response.url()).pathname, status: response.status() }); });
    await page.goto(`http://127.0.0.1:${server.address().port}/prototype/index.html`, { waitUntil: 'networkidle', timeout: 45000 });
    await page.waitForFunction(() => typeof window.renderAt === 'function' && window.ready !== undefined, undefined, { timeout: 30000 });
    await page.evaluate(async () => {
      let timeout;
      try {
        await Promise.race([
          Promise.all([window.ready, document.fonts.ready]),
          new Promise((resolve, reject) => { timeout = setTimeout(() => reject(new Error('Prototype ready/fonts deadline exceeded')), 45000); })
        ]);
      } finally { clearTimeout(timeout); }
    });
    await page.locator('canvas').first().waitFor({ state: 'visible', timeout: 10000 });
    return { page, browser, issues, width, height, close: async () => { await browser.close(); await new Promise(resolve => server.close(resolve)); } };
  } catch (error) {
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
    throw error;
  }
}

async function renderFrame(page, time, mode) {
  return page.evaluate(async ({ time, mode }) => { await window.renderAt(time, { mode }); }, { time, mode });
}

function assertNoErrors(issues) {
  if (Object.values(issues).some(list => list.length)) throw new Error(`Browser errors: ${JSON.stringify(issues)}`);
}

async function main() {
  const args = argsFrom(process.argv.slice(2));
  if (args.help) {
    process.stdout.write('Usage:\n  node tools/capture.cjs stills --times 0,3,6 --mode main --out video/stills\n  node tools/capture.cjs video --mode gameplay --duration 20 --fps 60 --width 1920 --height 1080 --out video/gameplay.mp4 [--audio music.wav]\n  node tools/capture.cjs video --mode takeB --offset 19 --duration 5 --out video/takes/take-B.mp4\n');
    return;
  }
  const command = args.command || (args.times ? 'stills' : 'video');
  if (!['stills', 'video'].includes(command)) throw new Error('Command must be stills or video');
  const mode = args.mode || 'main';
  if (!['main', 'gameplay', 'short', 'takeB', 'takeC'].includes(mode)) throw new Error('mode must be main, gameplay, short, takeB, or takeC');
  const offset = args.offset === undefined ? 0 : Number(args.offset);
  if (!Number.isFinite(offset) || offset < 0) throw new Error('offset must be a nonnegative number of seconds');
  const width = positive(args.width, 1920, 'width', true);
  const height = positive(args.height, 1080, 'height', true);
  const fps = positive(args.fps, 60, 'fps', true);
  if (command === 'video' && (width % 2 || height % 2)) throw new Error('H.264 output width and height must be even');
  const out = path.resolve(args.out || (command === 'stills' ? path.join(PROJECT, 'video', 'stills') : path.join(PROJECT, 'video', `${mode}.mp4`)));
  const report = { command, mode, offset, width, height, requestedFPS: fps, frameErrors: [], frames: 0, startedAt: new Date().toISOString() };
  const reportPath = command === 'stills' ? path.join(out, 'capture-report.json') : `${out}.report.json`;
  await fsp.mkdir(command === 'stills' ? out : path.dirname(out), { recursive: true });
  let session;
  let encoder;
  let encoderDone;
  let encoderLog = '';
  const start = performance.now();
  try {
    session = await openProject({ width, height, chromium: args.chromium });
    if (command === 'stills') {
      const times = String(args.times || '0,3,6,9,12,15').split(',').map(Number);
      if (!times.length || times.some(t => !Number.isFinite(t) || t < 0)) throw new Error('times must be comma-separated nonnegative seconds');
      report.times = times;
      report.sourceTimes = times.map(time => offset + time);
      report.files = [];
      for (const time of times) {
        try {
          await renderFrame(session.page, offset + time, mode);
          const filename = `${mode}-${time.toFixed(3).replace('.', '_').padStart(8, '0')}.png`;
          await session.page.screenshot({ path: path.join(out, filename), type: 'png', animations: 'disabled' });
          report.files.push(filename);
          report.frames++;
        } catch (error) { report.frameErrors.push({ time, error: error.message }); throw error; }
      }
    } else {
      const duration = positive(args.duration, mode === 'short' ? 15 : 30, 'duration');
      const frames = Math.round(duration * fps);
      report.duration = frames / fps;
      report.expectedFrames = frames;
      const ffargs = ['-hide_banner', '-loglevel', 'warning', '-y', '-f', 'image2pipe', '-vcodec', 'mjpeg', '-framerate', String(fps), '-i', 'pipe:0'];
      if (args.audio) ffargs.push('-i', path.resolve(args.audio));
      ffargs.push('-map', '0:v:0');
      if (args.audio) ffargs.push('-map', '1:a:0', '-c:a', 'aac', '-b:a', '192k', '-af', 'apad');
      ffargs.push('-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p,setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709', '-c:v', 'libx264', '-preset', args.preset || 'medium', '-crf', String(args.crf || 18), '-pix_fmt', 'yuv420p', '-r', String(fps), '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-color_range', 'tv', '-t', String(frames / fps), '-movflags', '+faststart', out);
      encoder = spawn('ffmpeg', ffargs, { stdio: ['pipe', 'ignore', 'pipe'] });
      encoder.stderr.on('data', chunk => { encoderLog = (encoderLog + chunk.toString()).slice(-12000); });
      encoder.stdin.on('error', () => {});
      encoderDone = new Promise((resolve, reject) => { encoder.on('error', reject); encoder.on('close', code => code === 0 ? resolve() : reject(new Error(`FFmpeg exited ${code}: ${encoderLog}`))); });
      // Attach immediately so an early encoder exit does not create an unhandled rejection.
      encoderDone.catch(() => {});
      const captureStart = performance.now();
      for (let frame = 0; frame < frames; frame++) {
        const time = offset + frame / fps;
        try {
          if (encoder.exitCode !== null) throw new Error(`FFmpeg exited early: ${encoderLog}`);
          await renderFrame(session.page, time, mode);
          const jpeg = await session.page.screenshot({ type: 'jpeg', quality: 98, animations: 'disabled' });
          if (!encoder.stdin.write(jpeg)) await once(encoder.stdin, 'drain');
          report.frames++;
          if (frame === 0 || (frame + 1) % (fps * 5) === 0 || frame === frames - 1) process.stdout.write(`${mode}: ${frame + 1}/${frames} frames (${time.toFixed(2)}s timeline)\n`);
        } catch (error) { report.frameErrors.push({ frame, time, error: error.message }); throw error; }
      }
      report.captureSeconds = Number(((performance.now() - captureStart) / 1000).toFixed(3));
      report.captureThroughputFPS = Number((frames / report.captureSeconds).toFixed(3));
      report.encodedFPS = fps;
      encoder.stdin.end();
      await encoderDone;
      report.bytes = (await fsp.stat(out)).size;
    }
    assertNoErrors(session.issues);
    report.success = true;
  } catch (error) {
    report.success = false;
    report.error = error.message;
    if (encoder && encoder.exitCode === null) { encoder.stdin.destroy(); encoder.kill('SIGTERM'); }
    throw error;
  } finally {
    report.elapsedSeconds = Number(((performance.now() - start) / 1000).toFixed(3));
    if (session) { report.browserIssues = session.issues; await session.close(); }
    await fsp.writeFile(reportPath, JSON.stringify(report, null, 2) + '\n');
    process.stdout.write(`Capture report: ${reportPath}\n`);
  }
  process.stdout.write(`Saved ${out}\n`);
}

module.exports = { PROJECT, argsFrom, positive, openProject, renderFrame, assertNoErrors };
if (require.main === module) main().catch(error => { process.stderr.write(`${error.stack || error}\n`); process.exitCode = 1; });
