#!/usr/bin/env node
'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { PROJECT, argsFrom, positive, openProject, assertNoErrors } = require('./capture.cjs');

async function snapshot(page) {
  return page.evaluate(() => {
    const canvas = document.querySelector('canvas');
    let state;
    if (typeof window.getState === 'function') state = window.getState();
    else if (typeof window.debugState === 'function') state = window.debugState();
    else state = window.debugState || window.__debugState || null;
    // A small sampled pixel signature detects a visible response even if no debug API exists.
    const source = canvas.getContext('2d');
    const pixels = source.getImageData(0, 0, canvas.width, canvas.height).data;
    let signature = 2166136261;
    for (let i = 0; i < pixels.length; i += 4096) signature = Math.imul(signature ^ pixels[i], 16777619);
    return { state: state == null ? null : JSON.parse(JSON.stringify(state)), signature: signature >>> 0, canvas: { width: canvas.width, height: canvas.height }, fonts: { status: document.fonts.status, count: document.fonts.size } };
  });
}

async function main() {
  const args = argsFrom(process.argv.slice(2));
  const width = positive(args.width, 1920, 'width', true);
  const height = positive(args.height, 1080, 'height', true);
  const out = path.resolve(args.out || path.join(PROJECT, 'video', 'checks.json'));
  await fs.mkdir(path.dirname(out), { recursive: true });
  const report = { width, height, startedAt: new Date().toISOString(), tests: [] };
  let session;
  const check = (name, passed, details) => { report.tests.push({ name, passed: Boolean(passed), details }); if (!passed) throw new Error(`${name}: ${JSON.stringify(details)}`); };
  try {
    session = await openProject({ width, height, chromium: args.chromium });
    const { page } = session;
    let before = await snapshot(page);
    check('canvas dimensions match viewport', before.canvas.width === width && before.canvas.height === height, before.canvas);
    check('fonts loaded', before.fonts.status === 'loaded', before.fonts);
    const bounds = await page.locator('canvas').first().boundingBox();
    check('canvas fills viewport', Math.abs(bounds.width - width) <= 1 && Math.abs(bounds.height - height) <= 1, bounds);
    await page.keyboard.press('Space');
    await page.waitForTimeout(160);
    const afterSpace = await snapshot(page);
    const spaceHasEngineState = before.state && afterSpace.state && typeof before.state.state === 'string';
    const spaceChanged = spaceHasEngineState
      ? (before.state.state !== afterSpace.state.state || afterSpace.state.totalTaps > before.state.totalTaps)
      : JSON.stringify(before.state) !== JSON.stringify(afterSpace.state) || before.signature !== afterSpace.signature;
    check('real Space input changes state or canvas', spaceChanged, { before: before.state, after: afterSpace.state, signatures: [before.signature, afterSpace.signature] });
    before = afterSpace;
    await page.mouse.click(bounds.x + bounds.width * 0.72, bounds.y + bounds.height * 0.64);
    await page.waitForTimeout(160);
    const afterPointer = await snapshot(page);
    const pointerHasTapCount = before.state && afterPointer.state && typeof before.state.totalTaps === 'number';
    const pointerChanged = pointerHasTapCount
      ? afterPointer.state.totalTaps > before.state.totalTaps
      : JSON.stringify(before.state) !== JSON.stringify(afterPointer.state) || before.signature !== afterPointer.signature;
    check('real pointer input changes state or canvas', pointerChanged, { before: before.state, after: afterPointer.state, signatures: [before.signature, afterPointer.signature] });
    // Verify deterministic export rendering is stable when the same frame is requested twice.
    await page.evaluate(async () => window.renderAt(3, { mode: 'gameplay' }));
    const first = await page.screenshot({ type: 'png', animations: 'disabled' });
    await page.evaluate(async () => window.renderAt(3, { mode: 'gameplay' }));
    const second = await page.screenshot({ type: 'png', animations: 'disabled' });
    check('renderAt produces identical repeated frames', first.equals(second), { time: 3, mode: 'gameplay' });
    assertNoErrors(session.issues);
    check('no browser or asset errors', true, session.issues);
    report.success = true;
  } catch (error) {
    report.success = false;
    report.error = error.message;
    throw error;
  } finally {
    if (session) { report.browserIssues = session.issues; await session.close(); }
    await fs.writeFile(out, JSON.stringify(report, null, 2) + '\n');
    process.stdout.write(`Checks report: ${out}\n`);
  }
  process.stdout.write(`${report.tests.length} checks passed.\n`);
}

main().catch(error => { process.stderr.write(`${error.stack || error}\n`); process.exitCode = 1; });
