from pathlib import Path
import hashlib,json,zipfile,shutil
P=Path(__file__).resolve().parents[1];O=Path('/workspace/shared/downloads');O.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((P/'video/final-validation.json').read_text());assert v['success']
assert v['sourceHashes']['prototype/index.html']==sha(P/'prototype/index.html'),'Source changed after validation'
for e in v['clips']:assert e['sha256']==sha(P/e['file'])
# Keep the report tied to the final corrected files rather than an earlier export.
p=P/'quality_report.md';s=p.read_text();ls=s.splitlines()
clips=v['clips'];sizes=[e['bytes'] for e in clips]
for i,line in enumerate(ls):
 if line.startswith('- Final MP4s:'):
  ls[i]=f'- Final MP4s: main42.000s /1920×1080 /2520frames /{sizes[0]:,}bytes; short15.000s /1080×1920 /900frames /{sizes[1]:,}bytes. Both60fps H.264/yuv420p, limitedBT709, AAC stereo48kHz and faststart; full video+audio decode passed. Exact hashes and checks are in `video/final-validation.json`.'
s='\n'.join(ls)+'\n';s=s.replace('The main25–29 caption section was re-rendered and spliced at exact frame boundaries, preserving the original audio; that corrected final file passed the full validation again.','The main25–29 caption section and opening decorative-trait cleanup were re-rendered and spliced at exact frame boundaries, preserving original audio. Both corrected files passed full validation again.');p.write_text(s)
readme=P/'README.md';s=readme.read_text();s+='\nThe ZIP contains the requested deliverables, original assets, audio/source licenses and reproducible application/capture tools. Heavy working review screenshots and duplicate intermediate renders are omitted; the reference board, three-frame side-by-side and final corrected frame are included. All diagnostics remain in the workspace project.\n';readme.write_text(s)
top={'README.md','research_brief.md','art_bible.md','concepts.md','storyboard.md','quality_report.md','review_notes.md','progress.md','DM-description.txt','AUDIO-SOURCES.md','master_prompt.md'}
def include(p):
 r=p.relative_to(P);parts=r.parts
 if '__pycache__' in parts:return False
 if len(parts)==1:return p.name in top
 if parts[0] in {'prototype','tools','research'}:return p.suffix not in {'.log','.pyc'}
 if parts[0]=='art':
  if parts[1]=='review':return p.name in {'native-performance-final.json','no-freeze-crc.json','results-checks.json'}
  return True
 if parts[0]=='audio':
  if parts[1]=='source':return p.suffix in {'.sf2','.txt','.md','.json'}
  if parts[1]=='sfx':return True
  return p.suffix in {'.py','.json'} or p.name in {'music-42s.wav','music-15s.wav','clover-main-mix.wav','clover-15s-mix.wav'}
 if parts[0]=='video':return p.name in {'clover_concept_main.mp4','clover_concept_15s.mp4','final-validation.json','checks.json'}
 return False
files=sorted(p for p in P.rglob('*') if p.is_file() and include(p))
manifest={'project':'Cloverheads · Same Roots','delivery':'Local files only; GitHub upload canceled','qualityGate':'Not fully passed; see quality_report.md','files':[{'file':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]}
for src,dst in [('clover_concept_main.mp4','Cloverheads-Same-Roots-main.mp4'),('clover_concept_15s.mp4','Cloverheads-Same-Roots-15s.mp4')]:
 shutil.copy2(P/'video'/src,O/dst);assert sha(P/'video'/src)==sha(O/dst)
archive=O/'Cloverheads-Same-Roots-package.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,'Cloverheads-Same-Roots/'+str(p.relative_to(P)))
 z.writestr('Cloverheads-Same-Roots/DELIVERY-MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
out={'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [O/'Cloverheads-Same-Roots-main.mp4',O/'Cloverheads-Same-Roots-15s.mp4',archive]],'packagedFileCount':len(files)+1}
(P/'delivery.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
