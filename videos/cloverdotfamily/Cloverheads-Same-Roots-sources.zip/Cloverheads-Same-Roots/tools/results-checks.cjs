#!/usr/bin/env node
'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const { PROJECT, openProject, assertNoErrors } = require('./capture.cjs');

async function state(page) {
  return page.evaluate(() => {
    const s = window.getState();
    return { state: s.state, elapsed: s.elapsed, score: s.score, totalTaps: s.totalTaps, resultView: window.getResultView(), lastShareText: window.lastShareText || null };
  });
}

async function main() {
  const out = path.join(PROJECT, 'art', 'review', 'interactive-results');
  await fs.mkdir(out, { recursive: true });
  const report = { generatedAt: new Date().toISOString(), orientations: [] };
  for (const spec of [{ name: 'landscape', width: 1920, height: 1080, cardHeight: 800 }, { name: 'portrait', width: 1080, height: 1920, cardHeight: 1160 }]) {
    const result = { ...spec, tests: [], screenshots: [], externalRequests: [], popupCount: 0 };
    let session;
    const check = (name, passed, details) => { result.tests.push({ name, passed: Boolean(passed), details }); if (!passed) throw new Error(`${name}: ${JSON.stringify(details)}`); };
    try {
      session = await openProject(spec);
      const { page } = session;
      const originalURL = page.url();
      const origin = new URL(originalURL).origin;
      await page.context().grantPermissions(['clipboard-read', 'clipboard-write'], { origin });
      page.on('popup', popup => { result.popupCount++; popup.close(); });
      await page.route('**/*', async route => {
        const requestURL = new URL(route.request().url());
        if (['http:', 'https:'].includes(requestURL.protocol) && requestURL.origin !== origin) {
          result.externalRequests.push({ host: requestURL.host, path: requestURL.pathname });
          await route.abort();
        } else await route.continue();
      });
      await page.waitForFunction(() => typeof window.advanceLive === 'function' && typeof window.getResultView === 'function');
      await page.evaluate(() => window.setGameStateSeed(17));
      await page.keyboard.press('Space');
      check('real Space starts game', (await state(page)).state === 'atRoot', await state(page));
      await page.evaluate(() => window.advanceLive(31));
      await page.waitForTimeout(100);
      const completed = await state(page);
      check('31 seconds reaches results card', completed.state === 'results' && completed.resultView === 'card', completed);
      const screenshot = async name => { const file = `${spec.name}-${name}.png`; await page.screenshot({ path: path.join(out, file), type: 'png', animations: 'disabled' }); result.screenshots.push(file); };
      await screenshot('results');
      const footerY = (spec.height - spec.cardHeight) / 2 + spec.cardHeight - 25;
      await page.mouse.click(spec.width / 2 - 180, footerY);
      await page.waitForTimeout(80);
      const leaderboard = await state(page);
      check('left footer opens WL leaderboard', leaderboard.state === 'results' && leaderboard.resultView === 'leaderboard', leaderboard);
      await screenshot('leaderboard');
      await page.mouse.click(25, 25);
      await page.waitForTimeout(80);
      const returned = await state(page);
      check('tap returns leaderboard to result card', returned.state === 'results' && returned.resultView === 'card', returned);
      await page.mouse.click(spec.width / 2, footerY - 62);
      await page.waitForFunction(() => typeof window.lastShareText === 'string' && window.lastShareText.startsWith('SAME ROOTS'));
      const shared = await state(page);
      const clipboard = await page.evaluate(() => navigator.clipboard.readText());
      check('Share copies the actual result text', shared.lastShareText === clipboard && clipboard.includes(`${shared.score} points`) && shared.state === 'results' && shared.resultView === 'card', { state: shared, clipboard });
      check('Share stays local with no outbound navigation', page.url() === originalURL && result.popupCount === 0 && result.externalRequests.length === 0, { samePage: page.url() === originalURL, popupCount: result.popupCount, externalRequests: result.externalRequests });
      await screenshot('shared');
      await page.mouse.click(spec.width / 2 + 180, footerY);
      await page.waitForTimeout(80);
      const restarted = await state(page);
      check('right footer restarts game', restarted.state === 'atRoot' && restarted.elapsed < 1 && restarted.score === 0 && restarted.totalTaps === 0 && restarted.lastShareText === null, restarted);
      await screenshot('restarted');
      assertNoErrors(session.issues);
      check('no browser or asset errors', true, session.issues);
      result.success = true;
    } catch (error) {
      result.success = false;
      result.error = error.stack || error.message;
    } finally {
      if (session) { result.browserIssues = session.issues; await session.close(); }
      report.orientations.push(result);
    }
    process.stdout.write(`${spec.name}: ${result.success ? 'PASS' : 'FAIL'} (${result.tests.filter(t => t.passed).length}/${result.tests.length} checks)\n`);
  }
  report.success = report.orientations.every(item => item.success);
  const file = path.join(out, 'results-checks.json');
  await fs.writeFile(file, JSON.stringify(report, null, 2) + '\n');
  process.stdout.write(`Results checks: ${file}\n`);
  if (!report.success) process.exitCode = 1;
}

main().catch(error => { process.stderr.write(`${error.stack || error}\n`); process.exitCode = 1; });
