from pathlib import Path
import subprocess,json,hashlib,datetime,struct
P=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def faststart(p):
 boxes={}
 with p.open('rb') as f:
  while True:
   pos=f.tell();h=f.read(8)
   if len(h)<8:break
   n,k=struct.unpack('>I4s',h)
   if n==1:n=struct.unpack('>Q',f.read(8))[0]
   if not n:break
   boxes[k.decode(errors='replace')]=pos;f.seek(pos+n)
 return boxes.get('moov',10**15)<boxes.get('mdat',-1)
report={'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revision':'Final local deliverables after isolated main25–29 caption correction; current prototype includes tested interactive result controls. V1 source/decode evidence preserved separately.','clips':[]}
for name,w,h,d,frames in [('clover_concept_main.mp4',1920,1080,42,2520),('clover_concept_15s.mp4',1080,1920,15,900)]:
 p=P/'video'/name
 probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)]))
 v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
 dec=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],capture_output=True,text=True)
 checks={'h264':v['codec_name']=='h264','dimensions':(v['width'],v['height'])==(w,h),'sixtyFPS':v['avg_frame_rate']=='60/1','exactFrames':int(v['nb_read_frames'])==frames,'exactDuration':abs(float(probe['format']['duration'])-d)<.001,'yuv420p':v['pix_fmt']=='yuv420p','limitedBT709':v.get('color_range')=='tv' and all(v.get(k)=='bt709' for k in ['color_space','color_transfer','color_primaries']),'stereo48kAAC':a['codec_name']=='aac' and a['channels']==2 and a['sample_rate']=='48000','faststart':faststart(p),'fullAudioVideoDecode':dec.returncode==0 and not dec.stderr.strip(),'under512MB':p.stat().st_size<512*1024*1024}
 report['clips'].append({'file':'video/'+name,'bytes':p.stat().st_size,'sha256':sha(p),'ffprobe':probe,'decodeError':dec.stderr,'checks':checks,'success':all(checks.values())})
 print(name,p.stat().st_size,'bytes',checks,flush=True)
report['sourceHashes']={str(p.relative_to(P)):sha(p) for p in [P/'prototype/index.html',P/'prototype/engine.js',P/'prototype/view.js',P/'prototype/edit.json',P/'research/export-source/capture-v1.html']}
report['success']=all(c['success'] for c in report['clips'])
(P/'video/final-validation.json').write_text(json.dumps(report,indent=2))
assert report['success'],'Final validation failed'
