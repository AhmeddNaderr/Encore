# Droolies · VERY SMART

An unofficial Encore Studio game concept for **Droolies** (@droolies_rh), built entirely from Droolies' own art. The tagline is "cross-eyed. drooling. very smart." In the game, one eye aims, the other eye wanders "wherever it wants", and you tap where they cross to pop only the *wrong* maths (2+3=6). Get it right and the very-smart pops slurp your drool back up. Pop a correct sum and you're TOO NORMAL. If your drool hits the desk, it's SPLAT. Six in a row and your EYES POP OUT.

## Deliverables
- `video/droolies_concept_main.mp4`: 42 s, 1920×1080, 60 fps
- `video/droolies_concept_15s.mp4`: 15 s, 1080×1920, 60 fps, readable with the sound off
- `prototype/index.html`: playable HTML5 canvas slice, landscape and portrait (assets in `prototype/assets/`)
- `research_brief.md`, `art_bible.md`, `art/reference_board.png`, `art/palette.json`, `art/side_by_side.png`
- `concepts.md`: 15 ideas, 5 scored cards, winner
- `storyboard.md`, `quality_report.md`, `review_notes.md`, `AUDIO-SOURCES.md`
- `DM-description.txt`: a proposed 2-line pitch. It has not been sent.

## Play locally
From the `prototype/` folder, run `python -m http.server 8000` and open `http://localhost:8000/index.html`.
- Move the mouse (or drag) to aim your eye.
- Click, tap or press Space to fire where the two sight-lines cross.
- Press M to toggle sound.

The leaderboard uses sample handles and is not connected to any WL or mint. Share on X only copies text; nothing is posted and the page makes no network requests.

## Reproduce the films
Requires Node, Playwright/Chromium, Python 3 (NumPy, SciPy) and FFmpeg.
1. `node prototype/engine-checks.cjs` (9 checks)
2. `python tools/build_prototype.py`
3. `node audio/cues.cjs`, then `python audio/compose.py`, then `bash tools/master_audio.sh`
4. Serve `prototype/` on port 8765, then run `node capture.cjs main video out.mp4` and `node capture.cjs short video out.mp4`. Mux each with the mastered WAV.
5. `node tools/checks.cjs` (16 browser checks)

The skilled autoplay driver calls the same `tap()` as real input; it never injects points. Takes are defined in `prototype/edit.json`.

## Sources and limits
All character, logo and world art is Droolies' own, from official X media and the droolies.lol link card. URLs and hashes are in `art/sources.csv`. No AI-generated art or video is used. Fonts are Permanent Marker (Apache-2.0), Patrick Hand (OFL), Inter (OFL) and Silkscreen (OFL), packaged locally. Music and SFX are original and synthesized. Read `quality_report.md` for the honest quality status.

Unofficial concept by Encore Studio. Not affiliated with or endorsed by Droolies. Droolies characters and art © Droolies. No post, DM or contact with the project was made.
