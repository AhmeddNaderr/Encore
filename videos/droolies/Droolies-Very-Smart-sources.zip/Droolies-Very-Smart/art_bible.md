# Droolies: locked art bible

## Sources
There are 17 unique official portraits. Twelve come from the droolies.lol link-preview card (1200×675) and five from the X banner (1500×500). Each one was perspective-straightened from its taped polaroid and Lanczos-upscaled to 512². The hero is the official profile picture (400², shown at 2×). Animated reference: two DROOL NEWS GIFs with the blonde anchor. The corner coordinates for every crop are in `art/cut/tiles.json`. URLs and SHA-256 hashes are in `art/sources.csv`. The board is `art/reference_board.png`.

## Style
- Hand-drawn flat colour with paper grain and a print-like speckle. No gradients and no 3D.
- A thick, slightly wobbly near-black ink outline (#1E1C1A), about 2.5% of head width. Line ends are rounded.
- Heads are a **square box** taking roughly the top 60% of the portrait. A tall rectangular nose bar runs from brow to mouth. Ears are small half-circles with a ">" / "<" mark.
- Eyes are white almonds or circles with black pupils turned **inward (cross-eyed)**. Lids are heavy and brows are flat or angled.
- The mouth is small with a pink tongue. A **drool rope** in pale blue (or green for snot) with an ink outline ends in a round droplet. Stubble is a scatter of ink dots, and some characters have blush ovals.
- The body is a simple half-dome of clothing: denim jacket, puffer, striped tee or hoodie.
- Backgrounds are flat pastels (cream, mint, butter yellow, blush, sunburst, stripes, checker) inside cream polaroid frames with ink borders, slightly rotated.
- Type: the logo is a marker hand with a red offset shadow. Notes are a casual handwriting face. The site uses **Permanent Marker** and **Patrick Hand** (Google Fonts, OFL), packaged locally.

## Palette
Pixel-sampled median-cut palette, from `art/palette.json`:

| Hex | Role |
|---|---|
| #473830 / #1E1C1A | Ink outline and contour |
| #eaa08c | Main skin |
| #c47263 | Red caps, berets, blush, nose shadow |
| #f0e2b2 / #eedaa2 | Butter-yellow backgrounds |
| #dce2cd / #d7d8bd | Mint backgrounds |
| #efd9c8 | Blush background |
| #f1e9d5 | Cream paper and polaroid |
| #746c5f / #a8aa89 | Muted cloth and olive |
| #e8c38c | Gold, sunburst |

The site CSS tokens are used for UI: grass `#79AE5F`, chalk lime `#CCFF00`, red `#D6483C`, yellow `#FFD84D`, drool blue `#9BD0F5`, cream `#FBF6E9`, night `#0F120E`.

## Invariants
These never change: the square head; the nose bar; cross-eyed inward pupils; drool or snot; the speckled stubble; ink line weight; the original costume pixels; and the polaroid presentation. All characters in frame are original pixels. Animation is limited to cut-out transforms (bob, squash, tilt) and parametric drool and sight-line effects.

## Forbidden
Glossy 3D, pixel art, anime eyes, AI-generated faces, invented characters, new costumes, neon cyberpunk, financial or auction claims inside the game, and fake partner logos.

## Allowed concept-layer additions
Chalk sight-lines, speech bubbles copied from the art's own bubble style, the drool rope extension (same colour and outline as the art's drool), and vector **Eyes Pop Out** eyeballs. Those eyeballs follow the official trait in `art/cut/art-popeyes-beanie.png` and `art-hardhat-popeyes.png`: a white disc, thick outline, black pupil and red veins. They are UI and effects, not claimed collection art.
