"""VERY SMART - original score and sound effects, synthesized from oscillators and seeded noise (no samples).
Usage: python compose.py  -> writes music-main.wav, music-short.wav, sfx/*.wav, mix-main.wav, mix-short.wav
"""
import json, os, numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

SR = 48000
HERE = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(2026)
BPM = 96.0
BEAT = 60.0 / BPM
BAR = BEAT * 4

def midi(n): return 440.0 * 2 ** ((n - 69) / 12)
NOTE = {'C': 0, 'Db': 1, 'D': 2, 'Eb': 3, 'E': 4, 'F': 5, 'Gb': 6, 'G': 7, 'Ab': 8, 'A': 9, 'Bb': 10, 'B': 11}
def n(s):  # 'F3' -> midi
    name, octv = s[:-1], int(s[-1]); return 12 * (octv + 1) + NOTE[name]

def env(len_s, a=0.004, d=0.3, s=0.0, r=0.05, hold=None):
    N = int(len_s * SR); t = np.arange(N) / SR
    e = np.where(t < a, t / max(a, 1e-6), 1.0)
    if hold is None:
        e = e * np.where(t < a, 1.0, s + (1 - s) * np.exp(-(t - a) / max(d, 1e-6)))
    else:
        dec = s + (1 - s) * np.exp(-(t - a) / max(d, 1e-6))
        rel = np.clip(1 - (t - hold) / r, 0, 1)
        e = e * np.where(t < a, 1.0, dec) * np.where(t > hold, rel, 1.0)
    return e

def lp(x, f, order=2): return sosfilt(butter(order, f / (SR / 2), 'low', output='sos'), x)
def hp(x, f, order=2): return sosfilt(butter(order, f / (SR / 2), 'high', output='sos'), x)
def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo / (SR / 2), hi / (SR / 2)], 'band', output='sos'), x)

# ---------------- instruments ----------------
def kick(v=1.0):
    L = 0.32; t = np.arange(int(L * SR)) / SR
    f = 45 + 95 * np.exp(-t / 0.035); ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t / 0.16) + 0.25 * np.exp(-t / 0.004) * rng.standard_normal(len(t))
    return v * x * 0.9
def snare(v=1.0):
    L = 0.25; t = np.arange(int(L * SR)) / SR
    nz = bp(rng.standard_normal(len(t)), 1400, 7000) * np.exp(-t / 0.07)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.05)
    return v * (0.8 * nz + 0.5 * tone)
def clap(v=1.0):
    L = 0.25; t = np.arange(int(L * SR)) / SR; x = np.zeros(len(t))
    for k, off in enumerate([0, 0.011, 0.022, 0.034]):
        i = int(off * SR); seg = rng.standard_normal(len(t) - i) * np.exp(-np.arange(len(t) - i) / SR / (0.012 if k < 3 else 0.09)); x[i:] += seg
    return v * bp(x, 900, 5000) * 0.5
def hat(v=1.0, open_=False):
    L = 0.3 if open_ else 0.06; t = np.arange(int(L * SR)) / SR
    return v * hp(rng.standard_normal(len(t)), 7500) * np.exp(-t / (0.11 if open_ else 0.018)) * 0.45
def bass(m, L, v=1.0):
    t = np.arange(int(L * SR)) / SR; f = midi(m)
    x = sum((0.9 / h) * np.sin(2 * np.pi * f * h * t) * np.exp(-t / (0.5 / h)) for h in range(1, 6))
    x += 0.15 * np.exp(-t / 0.01) * np.sin(2 * np.pi * f * 8 * t)
    return v * x * env(L, 0.003, 0.6, 0.0) * 0.7
def marimba(m, L, v=1.0):
    t = np.arange(int(L * SR)) / SR; f = midi(m)
    mod = np.sin(2 * np.pi * f * 4.0 * t) * 1.6 * np.exp(-t / 0.05)
    x = np.sin(2 * np.pi * f * t + mod) * np.exp(-t / 0.33) + 0.2 * np.sin(2 * np.pi * f * 10 * t) * np.exp(-t / 0.02)
    return v * x * 0.35
def kazoo(m, L, v=1.0, slide=0.0):
    N = int(L * SR); t = np.arange(N) / SR; f0 = midi(m)
    f = f0 * (1 + 0.012 * np.sin(2 * np.pi * 5.5 * t) * np.clip(t / 0.15, 0, 1)) * 2 ** (slide * t / max(L, 1e-3) / 12)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = sum(((-1) ** h) * np.sin(ph * h) / h for h in range(1, 14))  # saw-ish
    x = np.tanh(2.2 * x) * 0.6
    x = 0.7 * bp(x, 450, 1100, 1) + 0.6 * bp(x, 1100, 2800, 1) + 0.12 * hp(x, 3000)
    return v * x * env(L, 0.02, 0.6, 0.75, 0.06, hold=L - 0.06) * 0.85
def bell(m, L, v=1.0):
    t = np.arange(int(L * SR)) / SR; f = midi(m)
    x = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.9) + 0.5 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t / 0.35) + 0.25 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-t / 0.15)
    return v * x * 0.28
def stab(ms, L, v=1.0):
    t = np.arange(int(L * SR)) / SR; x = np.zeros(len(t))
    for m in ms:
        f = midi(m)
        for d in (-0.004, 0.004):
            ph = 2 * np.pi * f * (1 + d) * t
            x += sum(((-1) ** h) * np.sin(ph * h) / h for h in range(1, 10))
    x = lp(x, 2600) * env(L, 0.008, 0.18, 0.25, 0.08, hold=L - 0.08)
    return v * x * 0.12
def pad(ms, L, v=1.0):
    t = np.arange(int(L * SR)) / SR; x = np.zeros(len(t))
    for m in ms:
        f = midi(m)
        for d in (-0.006, 0.0, 0.006):
            ph = 2 * np.pi * f * (1 + d) * t
            x += sum(((-1) ** h) * np.sin(ph * h) / h for h in range(1, 8))
    x = lp(x, 1800) * env(L, 0.4, 2.0, 0.8, 0.8, hold=L - 0.8)
    return v * x * 0.05

# ---------------- arrangement ----------------
CH = {'F': [n('F3'), n('A3'), n('C4')], 'Dm': [n('D3'), n('F3'), n('A3')], 'Bb': [n('Bb2'), n('D3'), n('F3')], 'C': [n('C3'), n('E3'), n('G3')], 'Gm': [n('G2'), n('Bb2'), n('D3')]}
ROOT = {'F': n('F2'), 'Dm': n('D2'), 'Bb': n('Bb1'), 'C': n('C2'), 'Gm': n('G1')}
PROG = ['F', 'Dm', 'Bb', 'C']

class Track:
    def __init__(self, dur): self.L = np.zeros(int(dur * SR) + SR * 3); self.R = np.zeros_like(self.L)
    def add(self, t, x, pan=0.0, g=1.0):
        i = int(round(t * SR));
        if i < 0: x = x[-i:]; i = 0
        j = min(len(self.L), i + len(x)); x = x[:j - i]
        self.L[i:j] += x * g * np.sqrt(0.5 * (1 - pan)); self.R[i:j] += x * g * np.sqrt(0.5 * (1 + pan))

def swing(beat_pos):  # 8th-note swing
    whole, frac = divmod(beat_pos, 1.0)
    if abs(frac - 0.5) < 1e-6: frac = 0.56
    return (whole + frac) * BEAT

MOTIF = [(0, 'C5', 0.45), (0.5, 'D5', 0.45), (1.0, 'E5', 0.45), (1.5, 'A5', 1.2), (3.0, 'G5', 0.4), (3.5, 'F5', 0.45)]   # "two, plus, three... SIX!"
ANSWER = [(0, 'A4', 0.45), (0.5, 'C5', 0.45), (1.0, 'F5', 0.9), (2.0, 'E5', 0.45), (2.5, 'D5', 0.45), (3.0, 'C5', 0.9)]

def groove(T, bar_i, t0, chord, level=1.0, busy=False, half=False, drums=True, keys=True):
    if drums:
        for b in range(4):
            if half:
                if b == 0: T.add(t0 + swing(b), kick(0.9))
                if b == 2: T.add(t0 + swing(b), snare(0.7), 0.05)
            else:
                if b in (0, 2) or (busy and b == 3): T.add(t0 + swing(b if b != 3 else 3.5), kick(1.0 if b != 3 else 0.6))
                if b in (1, 3): T.add(t0 + swing(b), snare(0.75), 0.05); T.add(t0 + swing(b), clap(0.5), -0.1)
            for h in range(2): T.add(t0 + swing(b + h * 0.5), hat(0.5 if h else 0.35, open_=(busy and b == 3 and h == 1)), 0.3)
            if busy: T.add(t0 + swing(b + 0.25) - 0.0, hat(0.2), 0.35); T.add(t0 + swing(b + 0.75), hat(0.2), 0.35)
    # bass: root - fifth walk
    r = ROOT[chord]; walk = [r, r + 7, r + 12, r + 7] if not half else [r, r, r + 7, r + 7]
    for b in range(4): T.add(t0 + swing(b), bass(walk[b], BEAT * 0.95, 0.9 * level), 0.0)
    if keys:
        for b in range(4):
            for m in CH[chord]: T.add(t0 + swing(b + 0.5), marimba(m + 12, 0.4, 0.55 * level), 0.25 - 0.1 * (m % 3))

def lead(T, t0, phrase, level=1.0, transpose=0, slide_last=0.0):
    for k, (bpos, note, L) in enumerate(phrase):
        sl = slide_last if k == len(phrase) - 1 else 0.0
        T.add(t0 + swing(bpos), kazoo(n(note) + transpose, L, 0.55 * level, slide=sl), -0.12)

def reverb(L, R, wet=0.14, secs=1.3):
    N = int(secs * SR); t = np.arange(N) / SR
    irL = rng.standard_normal(N) * np.exp(-t / (secs / 5)); irR = rng.standard_normal(N) * np.exp(-t / (secs / 5))
    irL = lp(irL, 5000); irR = lp(irR, 5000); irL /= np.sqrt(np.sum(irL ** 2)); irR /= np.sqrt(np.sum(irR ** 2))
    wl = fftconvolve(L, irL)[:len(L)]; wr = fftconvolve(R, irR)[:len(R)]
    return L + wet * wl, R + wet * wr

def score_main(dur=42.0):
    T = Track(dur)
    plan = []  # (bar, chord, mode)
    for b in range(16):
        ch = PROG[b % 4]
        if b < 2: mode = 'hook'
        elif b < 6: mode = 'A'
        elif b < 10: mode = 'B'
        elif b < 12: mode = 'break'
        elif b < 14: mode = 'chorus'
        elif b == 14: mode = 'news'
        else: mode = 'logo'
        plan.append((b, ch, mode))
    for b, ch, mode in plan:
        t0 = b * BAR
        if mode == 'hook': groove(T, b, t0, ch, busy=True); lead(T, t0, MOTIF if b == 0 else ANSWER, 1.0)
        elif mode == 'A': groove(T, b, t0, ch); (lead(T, t0, MOTIF if b % 2 == 0 else ANSWER, 0.8))
        elif mode == 'B': groove(T, b, t0, ch, busy=True); lead(T, t0, MOTIF if b % 2 == 0 else ANSWER, 0.9, transpose=0 if b < 9 else 2)
        elif mode == 'break': groove(T, b, t0, ch, half=True, level=0.8); [T.add(t0 + swing(k * 0.5), bell(n('F5') + [0, 4, 7, 12, 7, 4, 0, 4][k], 0.9, 0.55), 0.3) for k in range(8)]
        elif mode == 'chorus': groove(T, b, t0, ch, busy=True); lead(T, t0, MOTIF if b == 12 else ANSWER, 1.0); [T.add(t0 + swing(k), bell(n('C6') + [0, 2, 4, 9][k], 0.8, 0.4), 0.35) for k in range(4)]
        elif mode == 'news':  # Drool News sting: brass stabs da-da-DUM
            groove(T, b, t0, 'Bb', drums=True, keys=False)
            for k, (bp_, chs, L) in enumerate([(0, 'Bb', 0.3), (0.5, 'Bb', 0.3), (1.0, 'C', 0.5), (2.5, 'F', 0.9)]):
                T.add(t0 + swing(bp_), stab([m + 12 for m in CH[chs]], L, 1.0), 0.0)
        else:  # logo: final motif then ring out
            groove(T, b, t0, 'C', drums=True, keys=True, level=0.8)
            lead(T, t0, [(0, 'C5', 0.45), (0.5, 'D5', 0.45), (1.0, 'E5', 0.45), (1.5, 'A5', 2.2)], 1.0)
    # ending: big F chord + bell sparkle at bar 16 (40.0s)
    tend = 16 * BAR
    T.add(tend, kick(0.9)); T.add(tend, pad(CH['F'] + [n('F4'), n('A4')], dur - tend + 0.5, 1.4), 0.0)
    for m in CH['F']: T.add(tend, marimba(m + 12, 1.5, 0.6))
    T.add(tend, bass(n('F1'), 1.8, 1.0)); T.add(tend + 0.05, bell(n('F6'), 1.9, 0.5), 0.3); T.add(tend + 0.2, bell(n('C6'), 1.7, 0.4), -0.3)
    L, R = reverb(T.L, T.R)
    return finish(L, R, dur)

def score_short(dur=15.0):
    T = Track(dur)
    for b in range(6):
        t0 = b * BAR; ch = PROG[b % 4]
        if b == 0: groove(T, b, t0, ch, busy=True); lead(T, t0, MOTIF)
        elif b in (1, 2): groove(T, b, t0, ch, busy=b == 2); lead(T, t0, ANSWER if b == 1 else MOTIF, 0.9)
        elif b == 3: groove(T, b, t0, ch, half=True, level=0.85); [T.add(t0 + swing(k * 0.5), bell(n('F5') + [0, 4, 7, 12, 7, 4, 0, 4][k], 0.9, 0.5), 0.3) for k in range(8)]
        elif b == 4: groove(T, b, t0, 'C', busy=True); lead(T, t0, [(0, 'C5', 0.45), (0.5, 'D5', 0.45), (1.0, 'E5', 0.45), (1.5, 'A5', 2.0)], 1.0)
        else:
            T.add(t0, kick(0.9)); T.add(t0, pad(CH['F'] + [n('F4'), n('A4')], dur - t0 + 0.4, 1.4))
            for m in CH['F']: T.add(t0, marimba(m + 12, 1.5, 0.6))
            T.add(t0, bass(n('F1'), 1.8)); T.add(t0 + 0.05, bell(n('F6'), 1.9, 0.5), 0.3)
    L, R = reverb(T.L, T.R)
    return finish(L, R, dur)

def finish(L, R, dur):
    N = int(dur * SR); L = L[:N]; R = R[:N]
    fade = int(0.9 * SR); w = np.linspace(1, 0, fade) ** 1.5; L[-fade:] *= w; R[-fade:] *= w
    st = np.stack([L, R], 1); st /= np.max(np.abs(st)) + 1e-9
    return st * 0.5

# ---------------- sound effects ----------------
def tone_sweep(f0, f1, L, shape='sine', curve=1.0):
    t = np.arange(int(L * SR)) / SR; k = (t / L) ** curve
    f = f0 * (f1 / f0) ** k; ph = 2 * np.pi * np.cumsum(f) / SR
    if shape == 'square': return np.sign(np.sin(ph)) * 0.6
    if shape == 'tri': return 2 / np.pi * np.arcsin(np.sin(ph))
    return np.sin(ph)
def noise(L): return rng.standard_normal(int(L * SR))
def ex(L, tau): return np.exp(-np.arange(int(L * SR)) / SR / tau)
def mixs(*xs):
    N = max(len(x) for x in xs); o = np.zeros(N)
    for x in xs: o[:len(x)] += x
    return o
def delay(x, d, g):
    o = np.zeros(len(x) + int(d * SR)); o[:len(x)] += x; o[int(d * SR):] += g * x; return o

def make_sfx():
    S = {}
    pop = mixs(bp(noise(0.09), 500, 3500) * ex(0.09, 0.012) * 0.9, tone_sweep(900, 300, 0.06) * ex(0.06, 0.015) * 0.6)
    S['good'] = mixs(pop, delay(np.sin(2 * np.pi * 988 * np.arange(int(0.35 * SR)) / SR) * ex(0.35, 0.09) * 0.35, 0.02, 0.0))
    chime = sum(np.sin(2 * np.pi * f * np.arange(int(0.6 * SR)) / SR) * a for f, a in [(1319, 0.4), (1976, 0.22), (2637, 0.1)]) * ex(0.6, 0.14)
    S['perfect'] = mixs(pop, np.concatenate([np.zeros(int(0.015 * SR)), chime]))
    arp = np.concatenate([np.sin(2 * np.pi * f * np.arange(int(0.09 * SR)) / SR) * ex(0.09, 0.05) * 0.4 for f in (1047, 1319, 1568)] + [np.sin(2 * np.pi * 2093 * np.arange(int(0.5 * SR)) / SR) * ex(0.5, 0.15) * 0.4])
    S['gold'] = mixs(pop, arp)
    S['poppop'] = mixs(pop * 1.1, chime * 0.7, np.concatenate([np.zeros(int(0.03 * SR)), pop * 0.5]))
    honk = tone_sweep(220, 150, 0.32, 'square') * ex(0.32, 0.18)
    honk = lp(honk + 0.6 * tone_sweep(233, 155, 0.32, 'square') * ex(0.32, 0.18), 1800)
    S['normal'] = mixs(honk * 0.7, tone_sweep(160, 70, 0.4, 'tri') * ex(0.4, 0.2) * 0.5)
    S['miss'] = mixs(hp(noise(0.05), 1500) * ex(0.05, 0.008) * 0.6, tone_sweep(420, 380, 0.06, 'tri') * ex(0.06, 0.02) * 0.25)
    S['tap'] = hp(noise(0.035), 2500) * ex(0.035, 0.005) * 0.45
    S['spawn'] = tone_sweep(500, 820, 0.08) * ex(0.08, 0.03) * 0.18
    S['escape'] = tone_sweep(700, 380, 0.18, 'tri') * ex(0.18, 0.07) * 0.18
    t = np.arange(int(0.7 * SR)) / SR
    f = 240 + 520 * (1 - np.exp(-t / 0.08)) + 90 * np.sin(2 * np.pi * 15 * t) * np.exp(-t / 0.3)
    boing = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.28)
    S['eyespop'] = mixs(boing * 0.7, bp(noise(0.25), 800, 6000) * ex(0.25, 0.06) * 0.35, pop * 0.8)
    S['popend'] = tone_sweep(800, 260, 0.2, 'sine', 0.6) * ex(0.2, 0.08) * 0.35
    splat = mixs(lp(noise(0.5), 1200) * ex(0.5, 0.09) * 1.0, tone_sweep(300, 60, 0.3) * ex(0.3, 0.1) * 0.6)
    drops = mixs(*[np.concatenate([np.zeros(int(d * SR)), tone_sweep(1200 + 300 * k, 600, 0.05) * ex(0.05, 0.015) * 0.25]) for k, d in enumerate([0.12, 0.19, 0.27, 0.36])])
    S['splat'] = mixs(splat, drops)
    S['whoosh'] = bp(noise(0.35), 500, 4000) * np.sin(np.linspace(0, np.pi, int(0.35 * SR))) ** 2 * 0.45
    S['tick'] = bp(noise(0.04), 1800, 4500) * ex(0.04, 0.006) * 0.5 + np.sin(2 * np.pi * 1200 * np.arange(int(0.04 * SR)) / SR) * ex(0.04, 0.01) * 0.25
    S['rank'] = mixs(*[np.concatenate([np.zeros(int(i * 0.07 * SR)), np.sin(2 * np.pi * f * np.arange(int(0.4 * SR)) / SR) * ex(0.4, 0.12) * 0.35]) for i, f in enumerate([784, 988, 1175, 1568])])
    S['cap'] = bp(noise(0.12), 2500, 9000) * ex(0.12, 0.03) * 0.28   # chalk scribble
    S['card'] = bp(noise(0.3), 300, 3000) * np.sin(np.linspace(0, np.pi, int(0.3 * SR))) * 0.35
    S['stamp'] = mixs(lp(noise(0.12), 900) * ex(0.12, 0.03) * 0.9, tone_sweep(140, 70, 0.12) * ex(0.12, 0.05) * 0.6)
    S['notify'] = mixs(np.sin(2 * np.pi * 1047 * np.arange(int(0.25 * SR)) / SR) * ex(0.25, 0.08) * 0.3, np.concatenate([np.zeros(int(0.08 * SR)), np.sin(2 * np.pi * 1568 * np.arange(int(0.3 * SR)) / SR) * ex(0.3, 0.1) * 0.3]))
    S['ding'] = sum(np.sin(2 * np.pi * f * np.arange(int(1.2 * SR)) / SR) * a for f, a in [(1397, 0.35), (2794, 0.12), (3856, 0.05)]) * ex(1.2, 0.35)
    S['soft'] = lp(noise(0.6), 600) * np.sin(np.linspace(0, np.pi, int(0.6 * SR))) * 0.15
    return S

GAIN = {'good': 0.9, 'perfect': 0.95, 'gold': 0.95, 'poppop': 0.9, 'normal': 1.0, 'miss': 0.6, 'tap': 0.55, 'spawn': 0.5, 'escape': 0.5, 'eyespop': 1.0, 'popend': 0.6, 'splat': 1.1,
        'whoosh': 0.8, 'tick': 0.7, 'rank': 0.9, 'cap': 0.6, 'card': 0.8, 'stamp': 0.9, 'notify': 0.8, 'ding': 0.8, 'soft': 0.6}
PAN = {'spawn': 0.0}

def mix(music, cues, sfx, dur):
    N = int(dur * SR); out = music[:N].copy() * 1.0
    duck = np.ones(N)
    for c in cues:
        x = sfx[c['s']] * GAIN[c['s']]
        if c['s'] in ('perfect', 'good', 'poppop') and c.get('combo', 0) > 2:  # rising pitch with combo
            pass
        i = int(round(c['t'] * SR)); j = min(N, i + len(x))
        if i >= N: continue
        out[i:j, 0] += x[:j - i] * 0.62; out[i:j, 1] += x[:j - i] * 0.62
        if c['s'] in ('eyespop', 'splat', 'normal'):
            d = int(0.35 * SR); k = min(N, i + d); duck[i:k] = np.minimum(duck[i:k], 0.6)
    duck = lp(duck, 12)
    out[:, 0] = out[:, 0] * 1.0; out[:, 1] *= 1.0
    out = out * 1.0
    # sidechain-style duck only the music part: approximate by re-adding
    mus = music[:N] * (duck[:, None] - 1.0)
    out += mus
    fade = int(0.85 * SR); w = np.linspace(1, 0, fade) ** 1.5; out[-fade:] *= w[:, None]
    out[-1] = 0
    return out

def write(path, x, bits=16):
    x = np.clip(x, -1, 1)
    if bits == 24:
        i = (x * 8388607).astype(np.int32); b = np.zeros((len(i), x.shape[1] if x.ndim > 1 else 1, 3), np.uint8)
        ii = i.reshape(len(i), -1); b[..., 0] = ii & 255; b[..., 1] = (ii >> 8) & 255; b[..., 2] = (ii >> 16) & 255
        import wave
        with wave.open(path, 'wb') as w: w.setnchannels(ii.shape[1]); w.setsampwidth(3); w.setframerate(SR); w.writeframes(b.tobytes())
    else:
        wavfile.write(path, SR, (x * 32767).astype(np.int16))

if __name__ == '__main__':
    os.makedirs(os.path.join(HERE, 'sfx'), exist_ok=True)
    ev = json.load(open(os.path.join(HERE, 'trailer-events.json')))
    sfx = make_sfx()
    for k, v in sfx.items(): write(os.path.join(HERE, 'sfx', k + '.wav'), (v / (np.max(np.abs(v)) + 1e-9) * 0.8))
    mm = score_main(); ms = score_short()
    write(os.path.join(HERE, 'music-main.wav'), mm); write(os.path.join(HERE, 'music-short.wav'), ms)
    a = mix(mm, ev['main']['cues'], sfx, ev['main']['duration']); b = mix(ms, ev['short']['cues'], sfx, ev['short']['duration'])
    for nm, x in (('mix-main-pre.wav', a), ('mix-short-pre.wav', b)):
        x = x / (np.max(np.abs(x)) + 1e-9) * 0.89
        write(os.path.join(HERE, nm), x, 24)
    json.dump({'bpm': BPM, 'cues_main': len(ev['main']['cues']), 'cues_short': len(ev['short']['cues']), 'sfx': sorted(sfx)}, open(os.path.join(HERE, 'composition.json'), 'w'), indent=1)
    print('ok')
