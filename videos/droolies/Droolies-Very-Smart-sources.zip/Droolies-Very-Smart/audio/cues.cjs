// Map real engine events inside each edited gameplay shot to trailer time, plus UI cues for motion graphics.
const E = require('../prototype/engine.js'); const ED = require('../prototype/edit.json'); const fs = require('fs');
const out = {};
for (const mode of ['main', 'short']) {
  const M = ED[mode]; const cues = [];
  for (const sh of M.shots) {
    const dur = sh.t1 - sh.t0;
    if (sh.type === 'game') {
      const T = ED.takes[sh.take]; const S = E.create({ kind: T.kind, seed: T.seed }); const D = E.driver({ seed: T.seed, mistakes: T.mistakes });
      while (S.step * E.DT < sh.src + dur && !S.over) E.update(S, D.next(S));
      for (const ev of S.events) if (ev.t >= sh.src && ev.t < sh.src + dur) {
        const t = +(sh.t0 + ev.t - sh.src).toFixed(4);
        if (ev.type === 'pop') cues.push({ t, s: ev.kind === 'gold' ? 'gold' : ev.inPop ? 'poppop' : ev.q === 'perfect' ? 'perfect' : 'good', combo: ev.combo });
        else if (['normal', 'miss', 'eyespop', 'popend', 'splat', 'tap', 'spawn', 'escape'].includes(ev.type)) cues.push({ t, s: ev.type });
      }
    } else if (sh.type === 'board') {
      cues.push({ t: sh.t0, s: 'whoosh' });
      for (let i = 0; i < 7; i++) cues.push({ t: +(sh.t0 + 0.35 + 1.5 * (1 - Math.pow(1 - i / 7, 1 / 3)) ).toFixed(3), s: 'tick' });
      cues.push({ t: +(sh.t0 + 1.85).toFixed(3), s: 'rank' });
      cues.push({ t: +(sh.t0 + 0.55).toFixed(3), s: 'cap' });
    } else if (sh.type === 'result') { cues.push({ t: sh.t0, s: 'card' }); cues.push({ t: +(sh.t0 + 0.6).toFixed(3), s: 'stamp' }); }
    else if (sh.type === 'xpost') { cues.push({ t: sh.t0, s: 'notify' }); }
    else if (sh.type === 'news') { cues.push({ t: sh.t0, s: 'whoosh' }); cues.push({ t: +(sh.t0 + 0.55).toFixed(3), s: 'stamp' }); }
    else if (sh.type === 'logo') { cues.push({ t: sh.t0, s: 'ding' }); }
    else if (sh.type === 'endshort') { cues.push({ t: sh.t0, s: 'ding' }); }
    else if (sh.type === 'encore') { cues.push({ t: sh.t0, s: 'soft' }); }
    if (sh.caption && sh.type === 'game') cues.push({ t: sh.t0 + 0.02, s: 'cap' });
  }
  cues.sort((a, b) => a.t - b.t);
  out[mode] = { duration: M.duration, cues };
  const c = {}; cues.forEach(q => c[q.s] = (c[q.s] || 0) + 1); console.log(mode, JSON.stringify(c));
}
fs.writeFileSync(__dirname + '/trailer-events.json', JSON.stringify(out, null, 1));
