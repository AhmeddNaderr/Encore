// node capture.cjs <mode> stills <t,t,...> <outdir>   |   node capture.cjs <mode> video <out.mp4> [from] [to]
const { chromium } = require('playwright'); const { spawn } = require('child_process'); const fs = require('fs');
(async () => {
  const [mode, what, a, b, c] = process.argv.slice(2);
  const br = await chromium.launch({ args: ['--disable-gpu-vsync'] });
  const W = mode === 'short' ? 1080 : 1920, H = mode === 'short' ? 1920 : 1080;
  const p = await br.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
  const errs = []; p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto(`http://localhost:8765/trailer.html?mode=${mode}`);
  await p.waitForFunction(() => window.__ready || window.__error, null, { timeout: 60000 });
  const err = await p.evaluate(() => window.__error); if (err) { console.error(err); process.exit(1); }
  const info = await p.evaluate(() => window.__info); console.log(JSON.stringify(info));
  const el = await p.$('#c');
  if (what === 'stills') {
    fs.mkdirSync(b, { recursive: true });
    for (const t of a.split(',').map(Number)) {
      // render preceding frames for state continuity is automatic (sim steps forward)
      const fi = Math.round(t * 60); await p.evaluate(i => VSTrailer.render(i), fi);
      await el.screenshot({ path: `${b}/${mode}-${t.toFixed(2)}.png` });
    }
  } else {
    const from = Number(b || 0), to = Number(c || info.frames);
    const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'image2pipe', '-framerate', '60', '-c:v', 'png', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '14', '-pix_fmt', 'yuv420p', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv', '-r', '60', a], { stdio: ['pipe', 'inherit', 'inherit'] });
    const t0 = Date.now();
    for (let i = from; i < to; i++) {
      await p.evaluate(i => VSTrailer.render(i), i);
      const buf = await el.screenshot({ type: 'png' });
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
      if (i % 120 === 0) console.log('frame', i, ((Date.now() - t0) / 1000).toFixed(0) + 's');
    }
    ff.stdin.end(); await new Promise(r => ff.on('close', r));
  }
  if (errs.length) console.log('ERRORS', errs.slice(0, 5));
  await br.close();
})();
