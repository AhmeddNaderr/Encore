# Droolies: concepts

## 15 one-liners (the first five obvious ones are rejected)
1. ~~Droolie endless runner~~ (generic)
2. ~~Match-3 of Droolie faces~~ (generic)
3. ~~Flappy drool drop~~ (clone)
4. ~~Droolie fighter~~ (off-tone)
5. ~~Trait memory flip~~ (reskin)
6. **VERY SMART**: aim one eye, let the other one wander, and tap where they cross to pop the *wrong* maths (2+3=6) before your drool hits the desk.
7. **DROOL NEWS LIVE**: anchor the news and slap the right headline before the ticker ends.
8. **SEE DOUBLE**: everything appears twice; tap the real one as your eyes un-cross.
9. **DROOL ROPE**: swing on your own drool rope between polaroids like a pendulum.
10. **BRAINS STOPPED BRAINING**: dodge "too many chains / too many mints" falling on your head.
11. **EYES POP OUT**: catch your own eyeballs bouncing on springs before they roll away.
12. **2+3=6 EXAM**: answer a speed quiz where only the Droolie answer counts.
13. **DROOL SCANNER**: squint at a wallet with both eyes separately and spot the scam links.
14. **SLURP**: hold to suck your drool back up before it splats; release to drip onto targets.
15. **DROOL FAMILY ROLL-CALL**: welcome partner communities into the class photo in order.

## Five developed cards

**A. VERY SMART** (cross-eyed sharpshooter)
Rule: you control one eye's chalk sight-line and the other eye wanders on its own. Tap when the ✕ where they cross sits on a WRONG equation.
Loop: the class of Droolie polaroids shouts equations. Pop the very-smart ones (2+3=6, 1+1=11) and leave the "too normal" ones (2+2=4). Your drool rope grows every second; smart pops slurp it back up, and normal maths makes you drool more. A splat on the desk ends the run (about 30–60 s). Six smart pops in a row trigger **EYES POP OUT**: both eyes lock, the crosshair goes huge and points double for 4 seconds.
Lore: cross-eyed ("one eye on @droolies_rh, the other wherever it wants"), drooling, very smart (2+3=6) and Eyes Pop Out, all in the verbs.
Score: Drool Points, combo multiplier and PERFECT crosses. Result: a polaroid of your Droolie with its points and "IQ: 2+3=6".

**B. DROOL NEWS LIVE**: Stamp FREE CLAIM / FAKE on incoming headlines before the ticker ends. Strong brand fit, but it's a sorting game; the drool and cross-eyed identity is only cosmetic.

**C. SEE DOUBLE**: Every object appears twice and drifts. Tap the real one when the images converge. Clear and cross-eyed, but it plays like a whack-a-mole timing game, and drool isn't part of the play.

**D. DROOL ROPE**: Swing on a drool rope across a wall of polaroids. It's fun physics, but it drifts toward a generic swing-runner.

**E. SLURP**: Hold to slurp, release to drip onto moving targets. Uses drool well, but cross-eyed and "very smart" are absent.

## Scores (1–10)

| Concept | Lore | Original | Clarity 5s | Replay | Share | Trailer | Build | Total |
|---|---|---|---|---|---|---|---|---|
| **A. VERY SMART** | 10 | 8 | 8 | 8 | 8 | 9 | 8 | **59** |
| B. Drool News Live | 9 | 6 | 9 | 6 | 7 | 7 | 9 | 53 |
| C. See Double | 8 | 7 | 7 | 7 | 6 | 7 | 9 | 51 |
| D. Drool Rope | 7 | 6 | 8 | 7 | 6 | 8 | 7 | 49 |
| E. Slurp | 7 | 7 | 7 | 6 | 6 | 6 | 9 | 48 |

**Winner: VERY SMART (59/70; lore 10, originality 8, clarity 8).**
- Every verb is a Droolies trait: aiming cross-eyed, keeping your drool in, being "very smart", and Eyes Pop Out.
- Swap in another collection and the rules stop making sense; nobody else "wins" by picking 2+3=6.
- The crossing ✕, the growing drool rope and popping chalk bubbles read instantly in motion and with the sound off.
