# Droolies game concept production (VERY SMART)
Brief: the Encore master prompt (same as Cloverheads), handle @droolies_rh. The user authorised research, downloads and GitHub delivery like previous sessions.

## Status
- Phase 1 research: DONE. research_brief.md covers droolies.lol full text, the X profile, the pinned post and 4 recent posts read via the TinyFish connector. The 100-post audit was not possible logged out.
- Phase 2 art: DONE. 17 official portraits straightened from the X banner and the droolies.lol link card, plus the official PFP hero and Drool News GIFs. The palette is pixel-sampled. art_bible.md and reference_board.png are written. Direct droolies.lol asset downloads were refused by the session permission policy, so art came from official X media.
- Phase 3 concepts: DONE. VERY SMART won with 59/70.
- Phase 4 prototype: DONE. engine.js, view.js, screens.js and app.js, built into a single index.html. Engine checks pass 9/9. Four deterministic takes are used.
- Phase 5 storyboard: DONE.
- Phase 6 AI inserts: none, by design.
- Phase 7 audio: original synthesized score and SFX, event-aligned, mastered to -16 LUFS.
- Phase 7 capture: in progress (Playwright, 60fps PNG to ffmpeg).

## Decisions
- The hero is the official PFP Droolie (highest-resolution single source). The class wall is the official polaroid portraits.
- Pop-eyes are vector effects modelled on the official Eyes Pop Out trait, not replacement art.
- The leaderboard is a labelled sample. Holder_you's score is the take's real score. No WL or allocation claims and no auction references.
- Landscape captions sit at the top so they don't cover the drool.

## Failures
- The first cut-out pass leaked bubble outlines; fixed with ellipse-mask cleanup.
- Popped-bubble and expiry alpha read as grey blobs; replaced with an outline puff and a shake.
- The first landscape layout made crossings too shallow (few pops); the layout and wander amplitude were rebalanced.
- The container restarted mid-session; the scratchpad persisted and the capture was restarted.
