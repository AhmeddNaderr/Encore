/* VERY SMART: playable app shell (title → play → result → sample leaderboard). No network, no posting. */
(function () {
  'use strict';
  const E = VSEngine, V = VSView, SC = VSScreens;
  const cv = document.getElementById('c'), g = cv.getContext('2d');
  const qs = new URLSearchParams(location.search);
  let A = null, L = null, S = null, scene = 'title', sceneT = 0, last = performance.now(), acc = 0, pendingTap = false, toast = null, R = null, sound = true;
  const aimIn = { x: 960, y: 400 };

  function pickLayout() {
    const kind = qs.get('layout') || (innerHeight > innerWidth ? 'portrait' : 'landscape');
    if (!L || L.kind !== kind) { L = E.makeLayout(kind); cv.width = L.W; cv.height = L.H; }
    const s = Math.min(innerWidth / L.W, innerHeight / L.H);
    cv.style.width = L.W * s + 'px'; cv.style.height = L.H * s + 'px';
  }
  function toLayout(e) { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * L.W, y: (e.clientY - r.top) / r.height * L.H }; }

  // tiny WebAudio SFX (optional; M toggles)
  let ac = null;
  function sfx(kind) {
    if (!sound) return;
    try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { return; }
    const t = ac.currentTime, o = ac.createOscillator(), gn = ac.createGain(); o.connect(gn); gn.connect(ac.destination);
    const set = { pop: ['triangle', 660, 990, 0.12], perfect: ['triangle', 880, 1320, 0.16], normal: ['sawtooth', 160, 90, 0.25], miss: ['sine', 300, 220, 0.08], eyes: ['square', 220, 880, 0.35], splat: ['sawtooth', 120, 40, 0.5], ui: ['sine', 520, 700, 0.08] }[kind] || ['sine', 440, 440, 0.1];
    o.type = set[0]; o.frequency.setValueAtTime(set[1], t); o.frequency.exponentialRampToValueAtTime(set[2], t + set[3]);
    gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(0.18, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + set[3]);
    o.start(t); o.stop(t + set[3] + 0.02);
  }

  function start() { S = E.create({ layout: L, seed: (Date.now() & 0xffff) || 1 }); scene = 'play'; sceneT = 0; sfx('ui'); }
  function finish() {
    R = { score: S.score, pops: S.pops, perfects: S.perfects, best: S.best, eyes: S.popCount };
    R.rank = SC.rankOf(R.score); scene = 'result'; sceneT = 0;
  }
  function shareText() { return `my Droolie popped ${R.pops} wrong answers and scored ${R.score.toLocaleString('en-US')} Drool Points in VERY SMART. still thinks 2+3=6. STAY DROOL`; }

  function resultHit(p) {
    // buttons live in the card's local space; approximate rects by layout
    const P = L.kind === 'portrait';
    const cx = L.W / 2, cy = P ? 860 : L.H / 2 + 10, s = P ? 1.15 : 1.0;
    const lx = (p.x - cx) / s, ly = (p.y - cy) / s;
    if (ly > 450 - 140 && ly < 450 - 48) { if (lx < -10) return 'share'; return 'again'; }
    return 'board';
  }

  function onTap(p) {
    if (!A) return;
    if (scene === 'title') { start(); return; }
    if (scene === 'play') { pendingTap = true; return; }
    if (scene === 'result' && sceneT > 0.8) {
      const h = resultHit(p);
      if (h === 'share') { const t = shareText(); (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(() => toast = { t: 0, msg: 'Copied! (nothing was posted)' }).catch(() => toast = { t: 0, msg: 'Share text ready (nothing was posted)' }); sfx('ui'); }
      else if (h === 'again') start();
      else { scene = 'board'; sceneT = 0; sfx('ui'); }
      return;
    }
    if (scene === 'board' && sceneT > 0.6) { scene = 'title'; sceneT = 0; }
  }

  cv.addEventListener('pointermove', e => { const p = toLayout(e); aimIn.x = p.x; aimIn.y = p.y; });
  let downAt = null;
  cv.addEventListener('pointerdown', e => { const p = toLayout(e); downAt = { p, t: performance.now() }; if (e.pointerType === 'mouse') onTap(p); else { aimIn.x = p.x; aimIn.y = p.y; } });
  cv.addEventListener('pointerup', e => { if (e.pointerType !== 'mouse' && downAt) { const p = toLayout(e); if (Math.hypot(p.x - downAt.p.x, p.y - downAt.p.y) < 30 && performance.now() - downAt.t < 350) onTap(p); } downAt = null; });
  addEventListener('keydown', e => { if (e.code === 'Space') { e.preventDefault(); onTap(aimIn); } if (e.key === 'm' || e.key === 'M') sound = !sound; });
  addEventListener('resize', pickLayout);

  let lastEv = 0;
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000); last = now; sceneT += dt;
    if (scene === 'play' && S) {
      acc += dt;
      while (acc >= E.DT) {
        E.update(S, { aim: { x: aimIn.x, y: aimIn.y }, tap: pendingTap }); pendingTap = false; acc -= E.DT;
        for (; lastEv < S.events.length; lastEv++) { const ev = S.events[lastEv]; if (ev.type === 'pop') sfx(ev.q === 'perfect' ? 'perfect' : 'pop'); else if (ev.type === 'normal') sfx('normal'); else if (ev.type === 'miss') sfx('miss'); else if (ev.type === 'eyespop') sfx('eyes'); else if (ev.type === 'splat') sfx('splat'); }
      }
      if (S.over && S.t - S.endT > 1.6) { lastEv = 0; finish(); }
    }
    draw(now / 1000);
    requestAnimationFrame(frame);
  }
  function draw(time) {
    g.setTransform(1, 0, 0, 1, 0, 0);
    if (!A) { g.fillStyle = '#0F120E'; g.fillRect(0, 0, cv.width, cv.height); return; }
    if (scene === 'title') SC.drawTitle(g, L, A, time);
    else if (scene === 'play') V.draw(g, S, A, { time });
    else if (scene === 'result') { SC.paperBg(g, L, time, true); SC.drawResultCard(g, L, A, R, time, Math.min(1, sceneT / 0.9), L.W / 2, L.kind === 'portrait' ? 860 : L.H / 2 + 10, L.kind === 'portrait' ? 1.15 : 1.0); }
    else if (scene === 'board') SC.drawLeaderboard(g, L, A, R.score, time, Math.min(1, sceneT / 1.6), ['Bots can like a post.', "They can't do 2+3=6."]);
    if (toast) { toast.t += 1 / 60; g.globalAlpha = Math.max(0, 1 - toast.t / 2.5); V.markerText(g, toast.msg, L.W / 2, 60, 40, V.CREAM, V.INK, 'center', 0); g.globalAlpha = 1; if (toast.t > 2.5) toast = null; }
  }

  pickLayout();
  VSAssets.load().then(a => { A = a; window.__ready = true; }).catch(err => { window.__error = String(err); console.error(err); });
  requestAnimationFrame(frame);
})();
