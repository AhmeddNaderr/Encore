/* Shared asset + font loader for the game and the trailer. */
(function (root) {
  'use strict';
  const base = (root.VS_BASE || '') + 'assets/';
  const FONTS = [
    ['Permanent Marker', 'permanent-marker-latin-400-normal.woff2', '400'],
    ['Patrick Hand', 'patrick-hand-latin-400-normal.woff2', '400'],
    ['Inter', 'inter-latin-400-normal.woff2', '400'],
    ['Inter', 'inter-latin-600-normal.woff2', '600'],
    ['Inter', 'inter-latin-700-normal.woff2', '700'],
    ['Inter', 'inter-latin-400-normal.woff2', '500'],
    ['Silkscreen', 'silkscreen-latin-400-normal.woff2', '400']
  ];
  const CAST = ['blonde-grin', 'beanie-2plus3', 'popeyes-beanie', 'headphones-1plus1', 'im-smart', 'propeller-wenmoon', 'party-eyepatch', 'crying-headband-b', 'qmark-shades', 'headband-straw', 'crying-headband', 'cap-checker', 'beret-crying', 'pink-hair-sweat', 'hardhat-popeyes', 'red-cap-beard', 'angry-quiff'];
  function img(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('asset ' + src)); i.src = base + src; }); }
  async function load() {
    await Promise.all(FONTS.map(async ([fam, file, w]) => { const f = new FontFace(fam, `url(${base}fonts/${file})`, { weight: w }); await f.load(); document.fonts.add(f); }));
    const A = { polaroids: {}, cuts: {} };
    const jobs = [
      img('hero.png').then(i => A.hero = i), img('hero-full.png').then(i => A.heroFull = i), img('pfp.jpg').then(i => A.heroThumb = i),
      img('wordmark-droolies.png').then(i => A.wordmark = i), img('tagline.png').then(i => A.tagline = i),
      img('encore-logo.png').then(i => A.encore = i), img('anchor.png').then(i => A.anchor = i)
    ];
    CAST.forEach(n => { jobs.push(img(`polaroids/${n}.png`).then(i => A.polaroids[n] = i)); jobs.push(img(`polaroids/cut-${n}.png`).then(i => A.cuts[n] = i)); });
    await Promise.all(jobs);
    await document.fonts.ready;
    return A;
  }
  root.VSAssets = { load, CAST };
})(typeof window !== 'undefined' ? window : globalThis);
