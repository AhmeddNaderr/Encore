// Engine checks for VERY SMART (node prototype/engine-checks.cjs)
const E = require('./engine.js'); let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log('PASS', m); } else { fail++; console.log('FAIL', m); } };
const L = E.makeLayout('landscape');
// 1 crossing geometry: when both rays aim at the same point, the crossing is that point
{ const S = E.create({ layout: L, seed: 1 }); const tgt = { x: 700, y: 300 };
  S.pAng = Math.atan2(tgt.x - L.eyeR.x, -(tgt.y - L.eyeR.y)); S.wAng = Math.atan2(tgt.x - L.eyeL.x, -(tgt.y - L.eyeL.y));
  const c = E.crossing(S); ok(c && Math.hypot(c.x - tgt.x, c.y - tgt.y) < 1, 'crossing lands where both eyes look'); }
// 2 smart pop scores and slurps drool
{ const S = E.create({ layout: L, seed: 2 }); S.drool = 50; S.bubbles.push({ id: 99, text: '2+3=6', kind: 'smart', src: 0, x: 600, y: 300, sx: 600, sy: 300, tx: 600, ty: 300, age: 1, life: 9, wob: 0, vx: 0, vy: 0, rx: 104, ry: 58, popT: -1 });
  S.cross = { x: 600, y: 300 }; const r = E.tap(S); ok(r === 'perfect' && S.score === 200 && S.drool < 50, 'perfect smart pop: +200 and slurp'); }
// 3 correct maths is too normal: combo reset + drool penalty
{ const S = E.create({ layout: L, seed: 3 }); S.combo = 5; S.brain = 4; S.bubbles.push({ id: 98, text: '2+2=4', kind: 'normal', src: 0, x: 600, y: 300, sx: 600, sy: 300, tx: 600, ty: 300, age: 1, life: 9, wob: 0, vx: 0, vy: 0, rx: 104, ry: 58, popT: -1 });
  S.cross = { x: 610, y: 305 }; const d0 = S.drool; const r = E.tap(S); ok(r === 'normal' && S.combo === 0 && S.brain === 0 && S.drool > d0, 'correct maths = TOO NORMAL penalty'); }
// 4 tapping empty board is a miss
{ const S = E.create({ layout: L, seed: 4 }); S.cross = { x: 300, y: 250 }; E.tap(S); ok(S.misses === 1 && S.combo === 0, 'empty tap = miss'); }
// 5 six smart pops trigger Eyes Pop Out
{ const S = E.create({ layout: L, seed: 5 }); for (let i = 0; i < 6; i++) { S.bubbles.push({ id: 200 + i, text: '1+1=11', kind: 'smart', src: 0, x: 600, y: 300, sx: 600, sy: 300, tx: 600, ty: 300, age: 1, life: 9, wob: 0, vx: 0, vy: 0, rx: 104, ry: 58, popT: -1 }); S.cross = { x: 600, y: 300 }; E.tap(S); }
  ok(S.pop > 0 && S.popCount === 1, 'six in a row = EYES POP OUT'); }
// 6 drool reaching the desk ends with SPLAT
{ const S = E.create({ layout: L, seed: 6 }); S.drool = L.maxDrool; E.update(S, { aim: S.aim }); ok(S.over && S.endReason === 'splat', 'drool on desk = SPLAT'); }
// 7 bell after the round timer
{ const S = E.create({ layout: L, seed: 7, round: 1 }); while (!S.over) E.update(S, { aim: S.aim }); ok(S.endReason === 'bell' || S.endReason === 'splat', 'round ends'); }
// 8 determinism: same seed + driver = identical run
{ const a = E.run({ kind: 'landscape', seed: 34, driver: { seed: 34, mistakes: [{ t: 7.5, kind: 'normal' }] } }); const b = E.run({ kind: 'landscape', seed: 34, driver: { seed: 34, mistakes: [{ t: 7.5, kind: 'normal' }] } });
  ok(a.score === b.score && a.events.length === b.events.length && a.score === 67800, 'deterministic replay (take A = 67,800)'); }
// 9 driver scores only through tap(): every pop event is preceded by a tap event at the same time
{ const S = E.run({ kind: 'portrait', seed: 21, driver: { seed: 21, mistakes: [{ t: 6, kind: 'normal' }] } });
  const taps = new Set(S.events.filter(e => e.type === 'tap').map(e => e.t.toFixed(5)));
  ok(S.events.filter(e => e.type === 'pop').every(e => taps.has(e.t.toFixed(5))), 'every pop comes from a real tap'); }
console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
