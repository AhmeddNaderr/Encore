/* VERY SMART: deterministic game engine (no DOM). Unofficial Encore Studio concept for Droolies.
   One eye follows the player's aim; the other one wanders "wherever it wants".
   Tap when the crossing point sits on WRONG maths (2+3=6). Correct maths is "too normal".
   Your drool grows every second; smart pops slurp it back. Drool on the desk = SPLAT. */
(function (root) {
  'use strict';
  const DT = 1 / 120;
  const ROUND = 60;

  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  const SMART = ['2+3=6', '1+1=11', '2+2=22', '3+3=33', '5+5=55', '9+1=91', '7-2=8', '4+4=44', '6+1=61', '2x2=22', '10-1=1', '3x3=33', '8+2=82', '1+2=12'];
  const NORMAL = ['2+2=4', '1+1=2', '3+3=6', '5+5=10', '9+1=10', '4+4=8', '6-1=5', '2x3=6', '8+2=10', '1+2=3'];

  // Layouts in their own pixel space. hero.* are coordinates in the 800x800 hero sprite.
  const HERO = { eyeL: [338.6, 362], eyeR: [460, 362], chin: [428.6, 612], headTop: 170, headBottom: 610, cx: 401, neck: [401, 620] };
  function makeLayout(kind) {
    if (kind === 'portrait') {
      const s = 0.92, top = 1180;
      const ox = 540 - HERO.cx * s, oy = top - HERO.headTop * s;
      return finish({ kind, W: 1080, H: 1920, s, ox, oy, board: { x: 50, y: 470, w: 980, h: 640 }, deskY: 1838, amp: 1.22,
        sources: polaroidSlots(kind) });
    }
    const s = 0.7, top = 540;
    const ox = 960 - HERO.cx * s, oy = top - HERO.headTop * s;
    return finish({ kind: 'landscape', W: 1920, H: 1080, s, ox, oy, board: { x: 230, y: 175, w: 1460, h: 410 }, deskY: 1062, amp: 1.38,
      sources: polaroidSlots('landscape') });
  }
  function finish(L) {
    const P = (p) => ({ x: L.ox + p[0] * L.s, y: L.oy + p[1] * L.s });
    L.eyeL = P(HERO.eyeL); L.eyeR = P(HERO.eyeR); L.chin = P(HERO.chin); L.neck = P(HERO.neck);
    L.headBox = { x: L.ox + 190 * L.s, y: L.oy + 160 * L.s, w: 430 * L.s, h: 470 * L.s };
    L.baseDrool = 75 * L.s;                    // art's own drool length below the chin
    L.maxDrool = L.deskY - L.chin.y - 18 * L.s; // splat distance
    return L;
  }
  function polaroidSlots(kind) {
    const out = [];
    if (kind === 'portrait') {
      for (let r = 0; r < 2; r++) for (let i = 0; i < 4; i++) out.push({ x: 150 + i * 260 + (r ? 18 : -8), y: 120 + r * 225, size: 205, rot: [-4, 3, -2, 5, 3, -5, 2, -3][r * 4 + i] });
      return out;
    }
    for (let i = 0; i < 8; i++) out.push({ x: 150 + i * 231, y: 96, size: 178, rot: [-5, 3, -2, 4, -4, 2, 5, -3][i] });
    return out;
  }

  function create(opts) {
    opts = opts || {};
    const L = opts.layout || makeLayout(opts.kind || 'landscape');
    const S = {
      L, seed: opts.seed || 1, r: rng(opts.seed || 1), t: 0, step: 0, over: false, endReason: null,
      aim: { x: L.W / 2, y: L.board.y + L.board.h * 0.45 },
      wPhase: 0.3, wAng: 0, pAng: 0,
      bubbles: [], nextId: 1, spawnT: 0.6,
      score: 0, combo: 0, best: 0, brain: 0, pops: 0, perfects: 0, normals: 0, misses: 0,
      drool: 0, droolV: 0, pop: 0, popCount: 0, hitstop: 0, shake: 0, react: 0, reactKind: '', flash: 0,
      events: [], fx: [], cross: null, lastTap: -9, srcPulse: new Array(L.sources.length).fill(0),
      round: opts.round || ROUND
    };
    angles(S);
    return S;
  }

  function wanderSpeed(S) { // rad/s, deterministic, escalates
    const t = S.t, k = 1 + Math.min(1, t / 45) * 0.55;
    return k * (1.55 + 0.45 * Math.sin(0.37 * t + S.seed) + 0.25 * Math.sin(1.31 * t + 2 * S.seed));
  }
  function angles(S) {
    const L = S.L;
    // wanderer (left eye): sweeps -1.25..+1.25 rad from vertical
    S.wAng = L.amp * Math.sin(S.wPhase);
    if (S.pop > 0) S.wAng = null;
    const dx = S.aim.x - L.eyeR.x, dy = S.aim.y - L.eyeR.y;
    S.pAng = Math.atan2(dx, -dy);
    S.cross = crossing(S);
  }
  function dirOf(a) { return { x: Math.sin(a), y: -Math.cos(a) }; }
  function crossing(S) {
    const L = S.L;
    if (S.pop > 0) return { x: S.aim.x, y: S.aim.y, locked: true };
    const p = L.eyeR, q = L.eyeL, d1 = dirOf(S.pAng), d2 = dirOf(S.wAng);
    const den = d1.x * d2.y - d1.y * d2.x;
    if (Math.abs(den) < 1e-4) return null;
    const wx = q.x - p.x, wy = q.y - p.y;
    const a = (wx * d2.y - wy * d2.x) / den, b = (wx * d1.y - wy * d1.x) / den;
    if (a <= 20 || b <= 20) return null;
    const x = p.x + d1.x * a, y = p.y + d1.y * a;
    if (y < 0 || x < -50 || x > L.W + 50) return null;
    return { x, y };
  }

  function difficulty(S) { return Math.min(1, S.t / 50); }
  function spawn(S) {
    const L = S.L, r = S.r, d = difficulty(S);
    const si = Math.floor(r() * L.sources.length);
    const src = L.sources[si];
    const golden = S.t > 8 && r() < 0.06;
    const normal = !golden && r() < 0.26 + 0.14 * d;
    const list = golden ? ['wen moon?'] : normal ? NORMAL : SMART;
    const text = list[Math.floor(r() * list.length)];
    const B = L.board;
    let tx = 0, ty = 0, bestD = -1;
    for (let k = 0; k < 10; k++) { // pick the free-est spot so bubbles do not stack
      let cx = B.x + 120 + r() * (B.w - 240);
      let cy = B.y + 70 + r() * (B.h - 140);
      if (Math.abs(cx - L.W / 2) < 260) cy = Math.min(cy, L.headBox.y - 80);
      if (L.kind === 'landscape' && Math.abs(cx - L.W / 2) > 480) cy = Math.min(cy, B.y + B.h * 0.62);
      let dmin = 1e9;
      for (const o of S.bubbles) if (o.popT < 0) dmin = Math.min(dmin, Math.hypot((o.tx - cx) / 1.8, o.ty - cy), Math.hypot((o.x - cx) / 1.8, o.y - cy));
      if (dmin > bestD) { bestD = dmin; tx = cx; ty = cy; }
    }
    // keep clear of hero head column
    const b = {
      id: S.nextId++, text, kind: golden ? 'gold' : normal ? 'normal' : 'smart', src: si,
      x: src.x, y: src.y + src.size * 0.35, sx: src.x, sy: src.y + src.size * 0.35, tx, ty,
      age: 0, life: 6.2 - 1.6 * d + r() * 1.2, born: S.t, wob: r() * 6.28, vx: (r() - 0.5) * (22 + 36 * d), vy: 4 + r() * 10,
      rx: L.kind === 'portrait' ? 108 : 104, ry: L.kind === 'portrait' ? 62 : 58, dead: false, popT: -1, hit: null
    };
    S.bubbles.push(b);
    S.srcPulse[si] = 1;
    S.events.push({ t: S.step * DT, type: 'spawn', id: b.id, kind: b.kind });
  }

  function inBubble(b, x, y, grow) {
    const g = grow || 1;
    const dx = (x - b.x) / (b.rx * g), dy = (y - b.y) / (b.ry * g);
    return Math.sqrt(dx * dx + dy * dy);
  }

  function tap(S) {
    if (S.over) return null;
    S.lastTap = S.t;
    const c = S.cross;
    const L = S.L;
    S.events.push({ t: S.step * DT, type: 'tap' });
    if (S.pop > 0) {
      // EYES POP OUT: both eyes locked, giant focus. Every smart bubble in range pops.
      const R = L.kind === 'portrait' ? 230 : 210;
      let n = 0;
      for (const b of S.bubbles) {
        if (b.dead || b.popT >= 0 || b.age < 0.25) continue;
        const dd = Math.hypot(b.x - c.x, b.y - c.y);
        if (dd < R + b.rx * 0.5 && b.kind !== 'normal') { popBubble(S, b, 'perfect', true); n++; }
      }
      if (!n) S.events.push({ t: S.step * DT, type: 'whiff' });
      return n;
    }
    if (!c) { miss(S); return null; }
    let best = null, bd = 9;
    for (const b of S.bubbles) {
      if (b.dead || b.popT >= 0 || b.age < 0.25) continue;
      const d = inBubble(b, c.x, c.y);
      if (d < 1 && d < bd) { bd = d; best = b; }
    }
    if (!best) { miss(S); return null; }
    if (best.kind === 'normal') { tooNormal(S, best); return 'normal'; }
    popBubble(S, best, bd < 0.38 ? 'perfect' : 'good', false);
    return bd < 0.38 ? 'perfect' : 'good';
  }

  function popBubble(S, b, q, inPop) {
    b.popT = S.t; b.hit = q;
    const mult = Math.min(6, 1 + Math.floor(S.combo / 2));
    let pts = (q === 'perfect' ? 200 : 100) * mult;
    if (b.kind === 'gold') pts = 500 * mult;
    if (inPop) pts *= 2;
    S.score += pts; S.combo++; S.best = Math.max(S.best, S.combo); S.pops++;
    if (q === 'perfect') S.perfects++;
    const slurp = (b.kind === 'gold' ? 70 : q === 'perfect' ? 30 : 20) * S.L.s;
    S.drool = Math.max(0, S.drool - slurp); S.droolV -= 60 * S.L.s;
    if (!inPop) {
      S.brain = Math.min(6, S.brain + 1);
      if (S.brain >= 6) startPop(S);
      S.hitstop = q === 'perfect' ? 5 : 2;
    }
    S.react = 1; S.reactKind = 'smart'; S.shake = Math.max(S.shake, q === 'perfect' ? 7 : 4);
    S.fx.push({ t: S.t, kind: 'pop', x: b.x, y: b.y, text: b.text, q, pts, gold: b.kind === 'gold', inPop });
    S.events.push({ t: S.step * DT, type: 'pop', q, pts, kind: b.kind, id: b.id, combo: S.combo, inPop, x: b.x, y: b.y });
  }
  function startPop(S) {
    S.pop = 4.0; S.popCount++; S.brain = 0; S.shake = 14; S.flash = 1;
    S.fx.push({ t: S.t, kind: 'eyespop' });
    S.events.push({ t: S.step * DT, type: 'eyespop' });
  }
  function tooNormal(S, b) {
    b.popT = S.t; b.hit = 'normal';
    S.combo = 0; S.brain = 0; S.normals++;
    S.drool += 42 * S.L.s; S.droolV += 90 * S.L.s;
    S.react = 1; S.reactKind = 'normal'; S.shake = 16; S.hitstop = 4;
    S.fx.push({ t: S.t, kind: 'normal', x: b.x, y: b.y, text: b.text });
    S.events.push({ t: S.step * DT, type: 'normal', id: b.id, x: b.x, y: b.y });
  }
  function miss(S) {
    S.combo = 0; S.misses++;
    S.drool += 10 * S.L.s;
    S.fx.push({ t: S.t, kind: 'miss', x: S.cross ? S.cross.x : S.aim.x, y: S.cross ? S.cross.y : S.aim.y });
    S.events.push({ t: S.step * DT, type: 'miss' });
  }

  function update(S, input) {
    if (input && input.aim) { S.aim.x = input.aim.x; S.aim.y = input.aim.y; }
    clampAim(S);
    if (S.over) { S.t += DT; S.step++; decay(S); angles(S); return; }
    if (input && input.tap) tap(S);
    if (S.hitstop > 0) { S.hitstop--; angles(S); S.step++; S.t += DT * 0.0; decay(S); return; }
    S.t += DT; S.step++;
    const L = S.L, d = difficulty(S);
    if (S.pop <= 0) S.wPhase += wanderSpeed(S) * DT;
    // spawn
    S.spawnT -= DT;
    const live = S.bubbles.filter(b => !b.dead && b.popT < 0).length;
    if (S.spawnT <= 0 && live < 4 + Math.round(3 * d)) { spawn(S); S.spawnT = 1.15 - 0.55 * d + S.r() * 0.35; }
    // bubbles
    for (const b of S.bubbles) {
      if (b.dead) continue;
      b.age += DT;
      if (b.popT >= 0) { if (S.t - b.popT > 0.5) b.dead = true; continue; }
      const k = Math.min(1, b.age / 0.7), e = 1 - Math.pow(1 - k, 3);
      const drift = Math.max(0, b.age - 0.7);
      b.x = b.sx + (b.tx - b.sx) * e + b.vx * drift + Math.sin(b.age * 1.3 + b.wob) * 14;
      b.y = b.sy + (b.ty - b.sy) * e + b.vy * drift + Math.cos(b.age * 1.1 + b.wob) * 8;
      if (b.age > b.life) {
        b.popT = S.t; b.hit = 'escape';
        if (b.kind === 'smart') { S.drool += 8 * L.s; S.events.push({ t: S.step * DT, type: 'escape', id: b.id }); }
      }
    }
    S.bubbles = S.bubbles.filter(b => !b.dead);
    // drool physics: grows with time; spring for wobble
    const grow = (7.5 + 9 * d) * L.s;
    S.drool += grow * DT;
    S.droolV += -S.droolV * 6 * DT;
    if (S.pop > 0) { S.pop -= DT; S.drool = Math.max(0, S.drool - 8 * L.s * DT); if (S.pop <= 0) { S.events.push({ t: S.step * DT, type: 'popend' }); S.pop = 0; } }
    if (S.drool >= L.maxDrool - L.baseDrool) { end(S, 'splat'); }
    else if (S.t >= S.round) { end(S, 'bell'); }
    decay(S);
    angles(S);
  }
  function decay(S) {
    S.shake *= 0.86; S.react *= 0.92; S.flash *= 0.9;
    for (let i = 0; i < S.srcPulse.length; i++) S.srcPulse[i] *= 0.93;
    S.fx = S.fx.filter(f => S.t - f.t < 1.6);
  }
  function end(S, why) {
    S.over = true; S.endReason = why; S.endT = S.t;
    S.events.push({ t: S.step * DT, type: why, score: S.score });
    if (why === 'splat') { S.shake = 20; S.fx.push({ t: S.t, kind: 'splat' }); }
  }
  function clampAim(S) {
    const L = S.L;
    S.aim.x = Math.max(20, Math.min(L.W - 20, S.aim.x));
    S.aim.y = Math.max(40, Math.min(L.eyeR.y - 90, S.aim.y));
  }

  // ---------- skilled autoplay driver (uses the same tap() as real input) ----------
  function driver(cfg) {
    cfg = cfg || {};
    const r = rng((cfg.seed || 7) * 31 + 5);
    const D = { target: null, ax: null, ay: null, cool: 0, cfg, mistakes: (cfg.mistakes || []).slice(), sloppy: cfg.sloppy || 0.18, tapLog: [] };
    D.next = function (S) {
      const L = S.L;
      if (D.ax == null) { D.ax = S.aim.x; D.ay = S.aim.y; }
      D.cool -= DT;
      let tapNow = false;
      // scripted mistakes {t, kind:'normal'|'miss'}
      const m = D.mistakes.length && S.t >= D.mistakes[0].t ? D.mistakes[0] : null;
      const live = S.bubbles.filter(b => b.popT < 0 && b.age > 0.3);
      if (S.pop > 0) {
        // aim at densest smart cluster
        let best = null, bs = -1;
        for (const b of live) {
          if (b.kind === 'normal') continue;
          let sc = 0; for (const o of live) if (o.kind !== 'normal' && Math.hypot(o.x - b.x, o.y - b.y) < 260) sc++;
          if (sc > bs) { bs = sc; best = b; }
        }
        if (best) { steer(D, best.x, best.y, 2600, 14); if (Math.hypot(S.aim.x - best.x, S.aim.y - best.y) < 70 && D.cool <= 0) { tapNow = true; D.cool = 0.16; } }
        return out(D, tapNow);
      }
      let want = m && m.kind === 'normal' ? 'normal' : 'smart';
      if (!D.target || D.target.popT >= 0 || !S.bubbles.includes(D.target) || (D.target.kind === 'normal') !== (want === 'normal')) {
        let best = null, bs = -1e9;
        for (const b of live) {
          const isN = b.kind === 'normal';
          if ((want === 'normal') !== isN) continue;
          const urgency = b.age / b.life, gold = b.kind === 'gold' ? 0.6 : 0;
          const dist = Math.hypot(b.x - S.aim.x, b.y - S.aim.y) / L.W;
          const sc = urgency + gold - dist * 0.9 + r() * 0.05;
          if (sc > bs) { bs = sc; best = b; }
        }
        D.target = best; D.thr = r() < D.sloppy ? 0.7 : 0.3; D.prevD = null;
      }
      const T = D.target;
      if (T) {
        steer(D, T.x + T.vx * 0.08, T.y, 2200, 11);
        const c = S.cross;
        if (c && D.cool <= 0) {
          const dd = inBubble(T, c.x, c.y);
          const pd = D.prevD == null ? 9 : D.prevD; D.prevD = dd;
          const settled = Math.hypot(S.aim.x - T.x, S.aim.y - T.y) < T.rx * 0.9;
          if (settled && (dd < D.thr || (pd < 0.85 && dd > pd && D.thr < 0.5))) { tapNow = true; D.cool = 0.18; if (m && m.kind === 'normal') D.mistakes.shift(); }
        }
      } else {
        steer(D, L.W / 2 + Math.sin(S.t) * 200, L.board.y + L.board.h * 0.5, 1200, 6);
      }
      if (m && m.kind === 'miss' && D.cool <= 0) { tapNow = true; D.cool = 0.3; D.mistakes.shift(); }
      return out(D, tapNow);
    };
    function steer(D, x, y, vmax, k) {
      const dx = x - D.ax, dy = y - D.ay, dist = Math.hypot(dx, dy);
      let v = Math.min(vmax, dist * k);
      if (dist > 0.01) { D.ax += dx / dist * v * DT; D.ay += dy / dist * v * DT; }
    }
    function out(D, tapNow) { return { aim: { x: D.ax, y: D.ay }, tap: tapNow }; }
    return D;
  }

  function run(opts) { // simulate whole take, return state
    const S = create(opts); const D = driver(opts.driver || { seed: opts.seed });
    const until = opts.until || 999;
    while (!S.over && S.t < until) update(S, D.next(S));
    return S;
  }

  const API = { DT, ROUND, HERO, rng, create, update, tap, makeLayout, driver, run, crossing, inBubble, SMART, NORMAL };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.VSEngine = API;
})(typeof window !== 'undefined' ? window : globalThis);
