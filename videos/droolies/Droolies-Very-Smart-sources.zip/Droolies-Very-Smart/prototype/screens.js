/* VERY SMART: menus, result card, sample leaderboard, Drool News, X mock-up and end cards. */
(function (root) {
  'use strict';
  const V = root.VSView;
  const { INK, CREAM, PAPER, LIME, RED, YEL, BLUE, DROOL, GRN, MARKER, HAND } = V;
  const INTER = "'Inter', sans-serif", PIX = "'Silkscreen', monospace";
  const ease = k => 1 - Math.pow(1 - Math.max(0, Math.min(1, k)), 3);
  const back = k => { k = Math.max(0, Math.min(1, k)); const c = 1.6; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };

  function paperBg(g, L, time, green) {
    g.fillStyle = green ? GRN : '#f0e8d5'; g.fillRect(0, 0, L.W, L.H);
    // paper speckle
    for (let i = 0; i < 1400; i++) { const h = Math.sin(i * 91.7) * 43758.5; const r = h - Math.floor(h); const h2 = Math.sin(i * 17.3) * 9631.1; const r2 = h2 - Math.floor(h2);
      g.fillStyle = green ? 'rgba(30,28,26,0.06)' : 'rgba(30,28,26,0.05)'; g.fillRect(r * L.W, r2 * L.H, 2, 2); }
    // floating drops + doodles like the banner
    const dd = ['2+3=6', '??', 'wen moon?', '1+1=11'];
    for (let i = 0; i < 12; i++) {
      const x = ((i * 0.37 + 0.05) % 1) * L.W, y = ((i * 0.61 + 0.1 + time * 0.012 * (1 + i % 3)) % 1.1) * L.H - 40;
      V.drawDrop(g, x, y, 13, green ? 'rgba(251,246,233,0.5)' : '#cfe7f5', green ? 'rgba(30,28,26,0.4)' : INK, 3);
    }
    g.font = `46px ${HAND}`; g.fillStyle = green ? 'rgba(30,28,26,0.22)' : 'rgba(30,28,26,0.55)';
    const sp = L.kind === 'portrait' ? [[90, 260], [800, 330], [80, 980], [820, 1020]] : [[90, 120], [1640, 150], [130, 560], [1700, 600]];
    sp.forEach((p, i) => { g.save(); g.translate(p[0], p[1]); g.rotate((i % 2 ? 0.08 : -0.1)); g.fillText(dd[i], 0, 0); g.restore(); });
  }

  function polaroid(g, img, x, y, size, rot, shadow) {
    g.save(); g.translate(x, y); g.rotate(rot);
    if (shadow !== false) { g.fillStyle = 'rgba(30,28,26,0.85)'; g.fillRect(-size / 2 + 8, -size / 2 + 10, size, size); }
    g.drawImage(img, -size / 2, -size / 2, size, size);
    g.restore();
  }

  function button(g, x, y, w, h, label, fill, size) {
    g.fillStyle = INK; V.rr(g, x + 6, y + 7, w, h, 16); g.fill();
    g.fillStyle = fill || LIME; g.strokeStyle = INK; g.lineWidth = 4.5; V.rr(g, x, y, w, h, 16); g.fill(); g.stroke();
    g.fillStyle = INK; g.font = `${size || 34}px ${MARKER}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(label, x + w / 2, y + h / 2 + 2);
  }

  function drawTitle(g, L, A, time) {
    paperBg(g, L, time, false);
    const P = L.kind === 'portrait';
    const cast = V.CLASS;
    const n = P ? 6 : 8;
    for (let i = 0; i < n; i++) {
      const sz = P ? 300 : 230;
      const x = P ? 190 + (i % 3) * 350 : 160 + i * 228, y = P ? 1280 + Math.floor(i / 3) * 330 : 760;
      polaroid(g, A.polaroids[cast[i]], x, y + Math.sin(time * 1.4 + i) * 6, sz, ((i * 37) % 9 - 4) * Math.PI / 180);
    }
    const wm = A.wordmark, ww = P ? 900 : 1040, wh = ww * wm.height / wm.width;
    g.drawImage(wm, L.W / 2 - ww / 2, P ? 180 : 70, ww, wh);
    const sc = 1 + Math.sin(time * 3) * 0.02;
    g.save(); g.translate(L.W / 2, P ? 520 : 335); g.scale(sc, sc); g.rotate(-0.04);
    V.markerText(g, 'VERY SMART', 0, 0, P ? 150 : 170, LIME, INK, 'center', 0, 16);
    g.restore();
    g.fillStyle = INK; g.font = `${P ? 44 : 46}px ${HAND}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('one eye aims. the other one goes wherever it wants.', L.W / 2, P ? 680 : 470);
    g.fillText('tap where they cross. pop the wrong maths.', L.W / 2, P ? 740 : 525);
    const pulse = 1 + Math.sin(time * 5) * 0.04;
    g.save(); g.translate(L.W / 2, P ? 900 : 605); g.scale(pulse, pulse); button(g, -200, -44, 400, 88, 'TAP TO DROOL', LIME, 40); g.restore();
    g.fillStyle = 'rgba(30,28,26,0.7)'; g.font = `26px ${INTER}`; g.fillText('Unofficial Encore Studio game concept · Droolies art © Droolies', L.W / 2, L.H - (P ? 60 : 36));
  }

  function grade(score) { return score >= 30000 ? 'GALAXY BRAIN' : score >= 18000 ? 'VERY SMART' : score >= 8000 ? 'KINDA SMART' : 'STILL DROOLING'; }

  // Result card: polaroid of your Droolie + stats. k = 0..1 entrance
  function drawResultCard(g, L, A, R, time, k, cx, cy, scale) {
    const P = L.kind === 'portrait';
    const w = 760, h = 900;
    g.save(); g.translate(cx, cy); g.scale(scale, scale); g.rotate(-0.025 + (1 - ease(k)) * 0.2);
    g.fillStyle = INK; V.rr(g, -w / 2 + 12, -h / 2 + 14, w, h, 26); g.fill();
    g.fillStyle = CREAM; g.strokeStyle = INK; g.lineWidth = 6; V.rr(g, -w / 2, -h / 2, w, h, 26); g.fill(); g.stroke();
    // header
    const wm = A.wordmark, ww = 330, wh = ww * wm.height / wm.width;
    g.drawImage(wm, -w / 2 + 36, -h / 2 + 28, ww, wh);
    g.fillStyle = RED; g.strokeStyle = INK; g.lineWidth = 4; V.rr(g, w / 2 - 250, -h / 2 + 34, 214, 48, 12); g.fill(); g.stroke();
    g.fillStyle = CREAM; g.font = `28px ${MARKER}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('VERY SMART', w / 2 - 143, -h / 2 + 59);
    // hero polaroid on mint
    const px = -w / 2 + 230, py = -h / 2 + 330;
    g.save(); g.translate(px, py); g.rotate(-0.06);
    g.fillStyle = INK; g.fillRect(-176, -176, 360, 360);
    g.fillStyle = '#fffaf0'; g.fillRect(-184, -184, 360, 400); g.strokeStyle = INK; g.lineWidth = 5; g.strokeRect(-184, -184, 360, 400);
    g.fillStyle = '#79AE5F'; g.fillRect(-164, -164, 320, 300);
    g.save(); g.beginPath(); g.rect(-164, -164, 320, 300); g.clip();
    g.drawImage(A.heroFull, -164 - 40, -164 - 50, 400, 400);
    g.restore();
    g.strokeStyle = INK; g.lineWidth = 4; g.strokeRect(-164, -164, 320, 300);
    g.fillStyle = INK; g.font = `34px ${HAND}`; g.textAlign = 'center'; g.fillText('me, very smart', -4, 176);
    g.restore();
    // stats
    const sx = 92;
    g.textAlign = 'left'; g.fillStyle = INK; g.font = `30px ${HAND}`;
    g.fillText('DROOL POINTS', sx - 20, -h / 2 + 170);
    const shown = Math.round(R.score * ease(Math.min(1, k * 1.6)));
    V.markerText(g, shown.toLocaleString('en-US'), sx - 20, -h / 2 + 232, 76, INK, RED, 'left', 0);
    const rows = [['smart pops', R.pops], ['perfect crosses', R.perfects], ['best streak', R.best], ['eyes popped', R.eyes + 'x']];
    rows.forEach((r, i) => {
      g.fillStyle = INK; g.font = `30px ${HAND}`; g.fillText(r[0], sx - 20, -h / 2 + 310 + i * 48);
      g.font = `32px ${MARKER}`; g.textAlign = 'right'; g.fillText(String(r[1]), w / 2 - 44, -h / 2 + 310 + i * 48); g.textAlign = 'left';
    });
    // IQ stamp
    g.save(); g.translate(170, 150); g.rotate(-0.12); const st = back(Math.min(1, Math.max(0, (k - 0.45) / 0.3)));
    g.scale(st, st);
    g.strokeStyle = RED; g.lineWidth = 7; V.rr(g, -190, -60, 380, 120, 18); g.stroke();
    g.fillStyle = RED; g.font = `30px ${MARKER}`; g.textAlign = 'center'; g.fillText('CERTIFIED IQ', 0, -22);
    g.font = `52px ${MARKER}`; g.fillText('2+3=6', 0, 30);
    g.restore();
    // grade + rank
    g.fillStyle = INK; g.font = `34px ${HAND}`; g.textAlign = 'center';
    g.fillText(`grade: ${grade(R.score)}  ·  sample board rank #${R.rank}`, 0, h / 2 - 190);
    // buttons
    button(g, -w / 2 + 44, h / 2 - 140, 330, 92, 'SHARE ON X', LIME, 36);
    button(g, w / 2 - 374, h / 2 - 140, 330, 92, 'PLAY AGAIN', YEL, 36);
    g.fillStyle = 'rgba(30,28,26,0.6)'; g.font = `22px ${INTER}`; g.fillText('concept · sample board · not a real WL or mint', 0, h / 2 - 22);
    g.restore();
  }

  const SAMPLE = [['drooler_a', 48200], ['drooler_b', 44100], ['drooler_c', 41750], ['drooler_d', 39900], ['drooler_e', 37300], ['drooler_f', 35800], ['drooler_g', 33250], ['drooler_h', 31900], ['drooler_i', 30400], ['drooler_j', 28800]];
  let relative = false;
  const MULT = [1.13, 1.06, 0.95, 0.9, 0.84, 0.79, 0.73, 0.68, 0.62, 0.57];
  function useRelative(v) { relative = v; }
  function boardRows(score) {
    const src = relative ? SAMPLE.map((r, i) => [r[0], Math.round(score * MULT[i] / 50) * 50]) : SAMPLE;
    const rows = src.map(r => ({ name: r[0], pts: r[1], you: false }));
    rows.push({ name: 'holder_you', pts: score, you: true });
    rows.sort((a, b) => b.pts - a.pts);
    return rows.slice(0, 10);
  }
  function rankOf(score) { return boardRows(score).findIndex(r => r.you) + 1 || 11; }

  // Leaderboard: k = 0..1 climb progress (holder_you rises from #10 to final rank)
  function drawLeaderboard(g, L, A, score, time, k, caption) {
    paperBg(g, L, time, true);
    const P = L.kind === 'portrait';
    const w = P ? 960 : 1180, h = P ? 1260 : 800;
    const cx = L.W / 2, cy = P ? 820 : L.H / 2 - 80;
    g.save(); g.translate(cx, cy);
    g.fillStyle = INK; V.rr(g, -w / 2 + 12, -h / 2 + 14, w, h, 28); g.fill();
    g.fillStyle = CREAM; g.strokeStyle = INK; g.lineWidth = 6; V.rr(g, -w / 2, -h / 2, w, h, 28); g.fill(); g.stroke();
    V.markerText(g, 'TOP DROOLERS', -w / 2 + 50, -h / 2 + 70, P ? 72 : 76, INK, RED, 'left', 0);
    g.fillStyle = INK; g.font = `${P ? 30 : 30}px ${HAND}`; g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText('VERY SMART · SAMPLE WL LEADERBOARD (CONCEPT)', -w / 2 + 52, -h / 2 + 130);
    const rows = boardRows(score);
    const inTop = rows.some(r => r.you);
    const finalIdx = inTop ? rows.findIndex(r => r.you) : 9;   // outside the top 10: pinned to the last row, rank shown as "--"
    const startIdx = 9;
    const pos = startIdx + (finalIdx - startIdx) * ease(k);
    const rowH = P ? 88 : 56, top = -h / 2 + (P ? 220 : 200);
    const others = rows.filter(r => !r.you);
    const yOf = (idx) => top + idx * rowH;
    others.slice(0, 9).forEach((r, j) => {
      // j-th other row: its slot is j if j < pos, else j+1, smoothly
      const shift = Math.max(0, Math.min(1, j + 1 - pos));
      const y = yOf(j + shift);
      g.fillStyle = 'rgba(30,28,26,0.75)'; g.font = `${P ? 38 : 32}px ${MARKER}`; g.textAlign = 'left';
      g.fillText(String(Math.round(j + shift + 1)).padStart(2, '0'), -w / 2 + 60, y);
      g.font = `${P ? 40 : 36}px ${HAND}`; g.fillStyle = INK; g.fillText(r.name, -w / 2 + 160, y);
      g.textAlign = 'right'; g.font = `${P ? 38 : 32}px ${MARKER}`; g.fillText(r.pts.toLocaleString('en-US'), w / 2 - 60, y);
    });
    const yy = yOf(pos);
    g.fillStyle = LIME; g.strokeStyle = INK; g.lineWidth = 4; V.rr(g, -w / 2 + 30, yy - rowH * 0.46, w - 60, rowH * 0.92, 14); g.fill(); g.stroke();
    g.fillStyle = INK; g.textAlign = 'left'; g.font = `${P ? 38 : 32}px ${MARKER}`; g.fillText(inTop ? String(Math.round(pos + 1)).padStart(2, '0') : '--', -w / 2 + 60, yy);
    g.save(); g.beginPath(); g.arc(-w / 2 + 116 + rowH * 0.42, yy, rowH * 0.4, 0, 7); g.clip(); g.drawImage(A.heroThumb, -w / 2 + 116, yy - rowH * 0.42, rowH * 0.84, rowH * 0.84); g.restore();
    g.font = `${P ? 42 : 38}px ${MARKER}`; g.fillText('holder_you', -w / 2 + 130 + rowH * 0.84, yy);
    g.textAlign = 'right'; g.fillText(score.toLocaleString('en-US'), w / 2 - 60, yy);
    g.fillStyle = 'rgba(30,28,26,0.6)'; g.font = `${P ? 24 : 22}px ${INTER}`; g.textAlign = 'center';
    g.fillText('illustrative holders · concept only · not connected to any real WL or mint', 0, h / 2 - 30);
    g.restore();
    if (caption) {
      const cw = P ? 980 : 1240, ch = P ? 220 : 150, ccy = P ? L.H - 260 : L.H - 92;
      g.save(); g.translate(L.W / 2, ccy); g.rotate(-0.015);
      g.fillStyle = INK; V.rr(g, -cw / 2 + 8, -ch / 2 + 10, cw, ch, 22); g.fill();
      g.fillStyle = INK; g.strokeStyle = LIME; g.lineWidth = 4; V.rr(g, -cw / 2, -ch / 2, cw, ch, 22); g.fill(); g.stroke();
      g.fillStyle = CREAM; g.font = `${P ? 44 : 44}px ${HAND}`; g.textAlign = 'center'; g.textBaseline = 'middle';
      if (P) { g.fillText(caption[0], 0, -42); V.markerText(g, caption[1], 0, 40, 62, LIME, RED, 'center', 0); }
      else { g.fillText(caption[0], 0, -30); V.markerText(g, caption[1], 0, 30, 56, LIME, RED, 'center', 0); }
      g.restore();
    }
  }

  // DROOL NEWS broadcast (homage to the official TV format) with the real anchor art
  function drawNews(g, L, A, R, time, k) {
    g.fillStyle = GRN; g.fillRect(0, 0, L.W, L.H);
    const P = L.kind === 'portrait';
    const W = P ? 1000 : 1640, H = P ? 1240 : 820;
    const cx = L.W / 2, cy = P ? 780 : L.H / 2 - 40;
    g.save(); g.translate(cx, cy);
    g.fillStyle = INK; V.rr(g, -W / 2 + 10, -H / 2 + 14, W, H, 46); g.fill();
    g.fillStyle = '#2b2a28'; V.rr(g, -W / 2, -H / 2, W, H, 46); g.fill();
    const iW = W - 60, iH = H - 60;
    g.fillStyle = '#f3efe2'; V.rr(g, -iW / 2, -iH / 2, iW, iH, 26); g.fill();
    // scanlines
    g.fillStyle = 'rgba(30,28,26,0.035)'; for (let y = -iH / 2; y < iH / 2; y += 6) g.fillRect(-iW / 2, y, iW, 2);
    // breaking tag
    g.fillStyle = RED; g.strokeStyle = INK; g.lineWidth = 4; V.rr(g, -iW / 2 + 30, -iH / 2 + 26, P ? 470 : 470, 60, 12); g.fill(); g.stroke();
    g.fillStyle = CREAM; g.beginPath(); g.arc(-iW / 2 + 60, -iH / 2 + 56, 9, 0, 7); g.fill();
    g.font = `32px ${MARKER}`; g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillText('BREAKING DROOL NEWS', -iW / 2 + 80, -iH / 2 + 58);
    g.fillStyle = INK; g.textAlign = 'right'; g.font = `36px ${MARKER}`; g.fillText('DROOLIES NEWS', iW / 2 - 36, -iH / 2 + 58);
    // anchor (official blonde anchor portrait, original pixels) behind desk
    const ax = P ? 0 : -iW / 2 + 290, ay = P ? -iH / 2 + 380 : 10;
    const asz = P ? 400 : 400;
    g.save(); g.translate(ax, ay);
    g.fillStyle = '#d6e6d6'; g.strokeStyle = INK; g.lineWidth = 5; V.rr(g, -asz / 2, -asz / 2, asz, asz, 18); g.fill(); g.stroke();
    g.save(); V.rr(g, -asz / 2, -asz / 2, asz, asz, 18); g.clip();
    const talk = Math.sin(time * 16) > 0.3 ? 2 : 0;
    g.drawImage(A.anchor, -asz / 2, -asz / 2 + 10 + talk, asz, asz);
    g.restore();
    g.fillStyle = '#7b4f2f'; g.strokeStyle = INK; g.lineWidth = 5; V.rr(g, -asz / 2 - 20, asz / 2 - 110, asz + 40, 140, 14); g.fill(); g.stroke();
    g.fillStyle = CREAM; g.font = `40px ${MARKER}`; g.textAlign = 'center'; g.fillText('DROOL NEWS', 0, asz / 2 - 40);
    V.drawDrop(g, 150, asz / 2 - 44, 12, DROOL, INK, 3);
    g.restore();
    // headline panel
    const hx = P ? -iW / 2 + 40 : -iW / 2 + 580, hy = P ? 130 : -iH / 2 + 120, hw = P ? iW - 80 : iW - 620, hh = P ? 360 : 440;
    g.fillStyle = '#fffdf6'; g.strokeStyle = INK; g.lineWidth = 5; V.rr(g, hx, hy, hw, hh, 18); g.fill(); g.stroke();
    const kk = ease(k * 1.5);
    g.save(); g.globalAlpha = kk;
    g.textAlign = 'left'; g.font = `${P ? 50 : 54}px ${MARKER}`; g.fillStyle = RED; g.fillText('HOLDER_YOU', hx + 34, hy + 64);
    g.fillStyle = INK; g.fillText(' IS VERY SMART!', hx + 34 + g.measureText('HOLDER_YOU').width, hy + 64);
    g.font = `${P ? 38 : 40}px ${HAND}`;
    g.fillText(`${R.score.toLocaleString('en-US')} Drool Points. ${R.pops} wrong answers popped.`, hx + 34, hy + 140);
    g.fillText('Experts confirm: 2+3 is still 6.', hx + 34, hy + 194);
    g.fillText('Eyes popped out ' + R.eyes + ' times. Drool: contained.', hx + 34, hy + 248);
    g.restore();
    // stamp
    const st = back(Math.max(0, Math.min(1, (k - 0.35) / 0.25)));
    g.save(); g.translate(hx + hw - 210, hy + hh - 70); g.rotate(-0.1); g.scale(st, st);
    g.fillStyle = '#e6f5e8'; g.strokeStyle = '#2f8a46'; g.lineWidth = 6; V.rr(g, -170, -42, 340, 84, 14); g.fill(); g.stroke();
    g.fillStyle = '#2f8a46'; g.font = `44px ${MARKER}`; g.textAlign = 'center'; g.fillText('VERY SMART ✓'.replace(' ✓', ''), 0, 4);
    g.restore();
    // lower third
    const lx = P ? -iW / 2 + 40 : -iW / 2 + 580, ly = P ? iH / 2 - 110 : iH / 2 - 120;
    g.fillStyle = YEL; g.strokeStyle = INK; g.lineWidth = 4; V.rr(g, lx, ly, P ? iW - 80 : iW - 620, 72, 14); g.fill(); g.stroke();
    g.fillStyle = INK; g.font = `32px ${MARKER}`; g.textAlign = 'left'; g.fillText('VERY SMART · A DROOLIES GAME CONCEPT · STAY DROOL', lx + 26, ly + 38);
    g.restore();
    // ticker
    const ty = P ? cy + H / 2 + 40 : L.H - 70;
    g.fillStyle = RED; g.fillRect(0, ty, L.W, 66); g.fillStyle = INK; g.fillRect(0, ty, 150, 66);
    g.fillStyle = CREAM; g.font = `34px ${MARKER}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('LIVE', 75, ty + 35);
    g.save(); g.beginPath(); g.rect(150, ty, L.W - 150, 66); g.clip();
    const tick = '2+3=6 CONFIRMED  ✦  EYES POPPED OUT  ✦  DROOL CONTAINED  ✦  TOP DROOLERS UPDATED  ✦  STAY DROOL  ✦  ';
    g.textAlign = 'left'; g.fillStyle = CREAM; g.font = `32px ${MARKER}`;
    const tw = g.measureText(tick).width; const off = (time * 260) % tw;
    g.fillText(tick + tick + tick, 170 - off, ty + 35);
    g.restore();
  }

  // X post mock-up containing the result card
  function drawXPost(g, L, A, R, time, k) {
    g.fillStyle = '#0f120e'; g.fillRect(0, 0, L.W, L.H);
    const P = L.kind === 'portrait';
    const w = P ? 960 : 1000, h = P ? 1500 : 1000;
    const cx = L.W / 2, cy = L.H / 2 + (1 - ease(k)) * 80;
    g.save(); g.translate(cx, cy); g.globalAlpha = ease(k * 2);
    g.fillStyle = '#000'; g.strokeStyle = '#2f3336'; g.lineWidth = 2; V.rr(g, -w / 2, -h / 2, w, h, 24); g.fill(); g.stroke();
    g.save(); g.beginPath(); g.arc(-w / 2 + 76, -h / 2 + 76, 42, 0, 7); g.clip(); g.drawImage(A.heroThumb, -w / 2 + 34, -h / 2 + 34, 84, 84); g.restore();
    g.save(); g.beginPath(); g.arc(-w / 2 + 76, -h / 2 + 76, 44, 0, 7); g.strokeStyle = '#000'; g.lineWidth = 6; g.stroke(); g.restore();
    g.fillStyle = '#e7e9ea'; g.font = `700 32px ${INTER}`; g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText('holder_you', -w / 2 + 138, -h / 2 + 58);
    g.fillStyle = '#71767b'; g.font = `400 28px ${INTER}`; g.fillText('@holder_you · now', -w / 2 + 138, -h / 2 + 96);
    g.fillStyle = '#e7e9ea'; g.font = `400 ${P ? 34 : 32}px ${INTER}`;
    const lines = [`my Droolie popped ${R.pops} wrong answers and scored`, `${R.score.toLocaleString('en-US')} Drool Points. still thinks 2+3=6.`, 'STAY DROOL'];
    lines.forEach((t, i) => g.fillText(t, -w / 2 + 40, -h / 2 + 170 + i * 48));
    g.fillStyle = '#1d9bf0'; const sdw = g.measureText('STAY DROOL ').width; g.fillText('#VERYSMART', -w / 2 + 40 + sdw, -h / 2 + 170 + 2 * 48); V.drawDrop(g, -w / 2 + 52 + sdw + g.measureText('#VERYSMART').width, -h / 2 + 172 + 2 * 48, 9, DROOL, '#e7e9ea', 2);
    g.restore();
    // card inside post
    drawResultCard(g, L, A, R, time, 1, cx, cy + (P ? 150 : 150) + (1 - ease(k)) * 80, P ? 0.92 : 0.71);
    g.save(); g.globalAlpha = ease(k * 2);
    g.fillStyle = '#71767b'; g.font = `400 26px ${INTER}`; g.textAlign = 'center';
    g.fillText('X post mock-up · not posted', cx, cy - h / 2 - 22);
    g.restore();
  }

  function drawLogoCard(g, L, A, time, k) {
    paperBg(g, L, time, false);
    const P = L.kind === 'portrait';
    const cast = ['popeyes-beanie', 'red-cap-beard', 'crying-headband-b', 'headphones-1plus1', 'angry-quiff'];
    cast.forEach((n, i) => {
      const sz = P ? 300 : 300; const x = P ? 190 + (i % 3) * 350 + (i > 2 ? 175 : 0) : L.W / 2 + (i - 2) * 318;
      const y = P ? 1200 + Math.floor(i / 3) * 330 : 820;
      const e = back(Math.max(0, Math.min(1, k * 3 - i * 0.12)));
      g.save(); g.translate(x, y + (1 - e) * 300); polaroid(g, A.polaroids[n], 0, Math.sin(time * 1.5 + i) * 5, sz, ((i * 3) % 7 - 3) * Math.PI / 180); g.restore();
    });
    const wm = A.wordmark, ww = P ? 920 : 1100, wh = ww * wm.height / wm.width;
    g.drawImage(wm, L.W / 2 - ww / 2, P ? 260 : 70, ww, wh);
    const tg = A.tagline, tw = P ? 900 : 900, th = tw * tg.height / tg.width;
    g.drawImage(tg, L.W / 2 - tw / 2, P ? 260 + wh + 20 : 70 + wh + 10, tw, th);
    g.save(); g.translate(L.W / 2, P ? 700 : 450); g.rotate(-0.04);
    V.markerText(g, 'VERY SMART', 0, 0, P ? 150 : 150, LIME, INK, 'center', 0, 16);
    g.restore();
    g.fillStyle = INK; g.font = `${P ? 46 : 44}px ${HAND}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('a game concept by Encore Studio', L.W / 2, P ? 860 : 590);
  }

  function drawEncore(g, L, A, time, title) {
    g.fillStyle = '#000'; g.fillRect(0, 0, L.W, L.H);
    const P = L.kind === 'portrait';
    const lg = A.encore, lw = P ? 300 : 300, lh = lw * lg.height / lg.width;
    const cy = P ? 560 : 160;
    g.drawImage(lg, L.W / 2 - lw / 2, cy, lw, lh);
    g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
    if (P) {
      g.font = `500 44px ${INTER}`; g.fillText('VERY SMART', L.W / 2, cy + lh + 80);
      g.font = `400 36px ${INTER}`; g.fillText('a game concept for Droolies', L.W / 2, cy + lh + 136);
    } else {
      g.font = `500 38px ${INTER}`; g.fillText('VERY SMART — a game concept for Droolies', L.W / 2, cy + lh + 90);
    }
    g.fillStyle = '#9a9a9a'; g.font = `26px ${PIX}`;
    const by = 'BY ENCORE STUDIO'.split('').join(' ');
    g.fillText(by, L.W / 2, cy + lh + (P ? 200 : 150));
    g.fillStyle = '#fff'; g.font = `600 ${P ? 64 : 64}px ${INTER}`;
    g.fillText('One crew for your whole launch.', L.W / 2, cy + lh + (P ? 330 : 270), L.W - 80);
    g.font = `400 ${P ? 34 : 38}px ${INTER}`;
    if (P) { g.fillText('Book a free 30-min call', L.W / 2, cy + lh + 420); g.fillText('encorestudio.xyz · @EncoreStudiohq', L.W / 2, cy + lh + 470); }
    else g.fillText('Book a free 30-min call · encorestudio.xyz · @EncoreStudiohq', L.W / 2, cy + lh + 380);
    g.strokeStyle = '#333'; g.lineWidth = 2; g.beginPath(); const ly = cy + lh + (P ? 560 : 470); g.moveTo(L.W / 2 - (P ? 440 : 520), ly); g.lineTo(L.W / 2 + (P ? 440 : 520), ly); g.stroke();
    g.fillStyle = '#bdbdbd'; g.font = `400 ${P ? 26 : 26}px ${INTER}`;
    g.fillText('Unofficial concept by Encore Studio. Not affiliated with or endorsed by Droolies.', L.W / 2, ly + 52, L.W - 60);
    g.fillText('Droolies characters and art © Droolies.', L.W / 2, ly + 94);
    // badge
    const bw = 520, bh = 52, bx = L.W - bw - 40, byy = L.H - bh - 40;
    g.fillStyle = '#05070a'; g.strokeStyle = '#5a6270'; g.lineWidth = 2; g.fillRect(bx, byy, bw, bh); g.strokeRect(bx, byy, bw, bh);
    g.fillStyle = '#e33'; g.fillRect(bx + 12, byy + 22, 7, 7);
    g.fillStyle = '#fff'; g.font = `34px ${PIX}`; g.textAlign = 'left'; g.fillText('CONCEPT · UNOFFICIAL', bx + 28, byy + bh / 2 + 2);
  }

  root.VSScreens = { useRelative, drawTitle, drawResultCard, drawLeaderboard, drawNews, drawXPost, drawLogoCard, drawEncore, boardRows, rankOf, grade, paperBg, button, ease, back };
})(typeof window !== 'undefined' ? window : globalThis);
