const E=require('./engine.js');
for (const kind of ['landscape','portrait']) for (const seed of [3,11,21,42]) {
  const S=E.run({kind,seed,driver:{seed}});
  const ev=S.events; const c=t=>ev.filter(e=>e.type===t).length;
  console.log(kind,seed,'end',S.endReason,'t',(S.step*E.DT).toFixed(1),'score',S.score,'pops',S.pops,'perf',S.perfects,'normal',S.normals,'miss',S.misses,'escape',c('escape'),'eyespop',c('eyespop'),'best',S.best,'maxDrool',S.L.maxDrool.toFixed(0));
}
