const E=require('./engine.js');
const kind=process.argv[2]||'landscape';
for (const seed of (process.argv[3]||'5,8,13,21,34,42,55,77').split(',').map(Number)) {
  const mistakes=JSON.parse(process.argv[4]||'[]');
  const S=E.run({kind,seed,driver:{seed,mistakes}});
  const ev=S.events.filter(e=>['pop','normal','eyespop','popend','miss','splat','bell','escape'].includes(e.type));
  const pops=ev.filter(e=>e.type==='pop');
  // density of pops per 3s window
  let best=0,bt=0; for(const e of pops){const n=pops.filter(o=>o.t>=e.t&&o.t<e.t+3).length; if(n>best){best=n;bt=e.t;}}
  console.log(`\n${kind} seed ${seed} end ${S.endReason}@${(S.step*E.DT).toFixed(1)} score ${S.score} pops ${S.pops} eyes@ ${ev.filter(e=>e.type==='eyespop').map(e=>e.t.toFixed(1)).join(',')} normals@ ${ev.filter(e=>e.type==='normal').map(e=>e.t.toFixed(1)).join(',')} densest3s ${best}@${bt.toFixed(1)} maxDroolFrac ${(S.maxDroolSeen||0)}`);
}
