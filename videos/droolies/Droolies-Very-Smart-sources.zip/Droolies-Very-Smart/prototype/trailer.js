/* VERY SMART trailer compositor: deterministic per-frame rendering of real gameplay takes + motion graphics. */
(function (root) {
  'use strict';
  const E = root.VSEngine, V = root.VSView, SC = root.VSScreens;
  let ED = null, A = null, cv = null, g = null, M = null, L = null;
  const takes = {}, finals = {};

  function take(id) {
    if (!takes[id]) {
      const T = ED.takes[id];
      const lay = E.makeLayout(T.kind);
      takes[id] = { T, lay, S: E.create({ layout: lay, seed: T.seed }), D: E.driver({ seed: T.seed, mistakes: T.mistakes }) };
    }
    return takes[id];
  }
  function stateAt(id, srcT) {
    let k = take(id);
    if (k.S.step * E.DT > srcT + 1e-6) { delete takes[id]; k = take(id); }
    while (k.S.step * E.DT + 1e-9 < srcT) E.update(k.S, k.D.next(k.S));
    return k.S;
  }
  function finalOf(id) {
    if (!finals[id]) {
      const T = ED.takes[id];
      const S = E.run({ kind: T.kind, seed: T.seed, driver: { seed: T.seed, mistakes: T.mistakes } });
      finals[id] = { score: S.score, pops: S.pops, perfects: S.perfects, best: S.best, eyes: S.popCount, end: S.endReason };
      finals[id].rank = SC.rankOf(S.score);
    }
    return finals[id];
  }

  function caption(text, t, t0, t1, pos) {
    const P = L.kind === 'portrait';
    const k = Math.min(1, (t - t0) / 0.18), out = Math.min(1, (t1 - t) / 0.12);
    const a = Math.max(0, Math.min(k, out));
    const y = pos === 'top' ? (P ? 528 : 262) : (P ? 1862 : 1012);
    g.save(); g.globalAlpha = a;
    g.font = `${P ? 62 : 60}px ${V.MARKER}`;
    const w = g.measureText(text).width + 80, h = P ? 104 : 96;
    g.translate(L.W / 2, y + (1 - SC.back(k)) * 30); g.rotate(-0.012);
    g.fillStyle = V.INK; V.rr(g, -w / 2 + 8, -h / 2 + 10, w, h, 18); g.fill();
    g.fillStyle = V.CREAM; g.strokeStyle = V.INK; g.lineWidth = 5; V.rr(g, -w / 2, -h / 2, w, h, 18); g.fill(); g.stroke();
    g.fillStyle = 'rgba(204,255,0,0.85)'; g.fillRect(-w / 2 - 14, -h / 2 - 10, 70, 26);
    V.markerText(g, text, 0, 3, P ? 62 : 60, V.INK, V.RED, 'center', 0);
    g.restore();
  }
  function hookTag(t, t0, t1) { // small brand tag so the hook reads as Droolies from frame 0
    const P = L.kind === 'portrait'; const a = Math.min(1, (t1 - t) / 0.2);
    const wm = A.wordmark, ww = P ? 300 : 260, wh = ww * wm.height / wm.width;
    const x = L.W / 2, y = P ? 1866 : 1018, w = ww + (P ? 330 : 300), h = wh + 28;
    g.save(); g.globalAlpha = a; g.translate(x, y); g.rotate(-0.01);
    g.fillStyle = V.INK; V.rr(g, -w / 2 + 6, -h / 2 + 7, w, h, 14); g.fill();
    g.fillStyle = V.CREAM; g.strokeStyle = V.INK; g.lineWidth = 4; V.rr(g, -w / 2, -h / 2, w, h, 14); g.fill(); g.stroke();
    g.drawImage(wm, -w / 2 + 16, -wh / 2, ww, wh);
    V.markerText(g, 'VERY SMART', w / 2 - 18, 2, P ? 46 : 40, V.LIME, V.INK, 'right', 0, 7);
    g.restore();
  }
  function wipe(t, t0) {
    const k = (t - t0) / 0.22; if (k < 0 || k > 1) return;
    g.save(); g.fillStyle = V.CREAM; g.strokeStyle = V.INK; g.lineWidth = 8;
    const x = -L.W * 0.4 + k * L.W * 1.8;
    g.beginPath(); g.moveTo(x, -20); g.lineTo(x + L.W * 0.35, -20); g.lineTo(x + L.W * 0.15, L.H + 20); g.lineTo(x - L.W * 0.2, L.H + 20); g.closePath(); g.fill(); g.stroke();
    g.restore();
  }

  function endShort(t, k) {
    SC.paperBg(g, L, t, false);
    const wm = A.wordmark, ww = 900, wh = ww * wm.height / wm.width;
    g.drawImage(wm, L.W / 2 - ww / 2, 330, ww, wh);
    g.save(); g.translate(L.W / 2, 700); g.rotate(-0.04); const s = SC.back(Math.min(1, k * 3)); g.scale(s, s);
    V.markerText(g, 'VERY SMART', 0, 0, 150, V.LIME, V.INK, 'center', 0, 16); g.restore();
    g.fillStyle = V.INK; g.font = `52px ${V.HAND}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText('Concept by Encore Studio', L.W / 2, 860);
    ['popeyes-beanie', 'headphones-1plus1', 'im-smart'].forEach((n, i) => {
      g.save(); g.translate(230 + i * 310, 1180 + Math.sin(t * 1.5 + i) * 6); g.rotate((i - 1) * 0.06);
      g.fillStyle = 'rgba(30,28,26,0.85)'; g.fillRect(-140 + 8, -140 + 10, 280, 280); g.drawImage(A.polaroids[n], -140, -140, 280, 280); g.restore();
    });
    g.fillStyle = '#000'; V.rr(g, 90, 1440, L.W - 180, 330, 30); g.fill();
    const lg = A.encore, lw = 170, lh = lw * lg.height / lg.width;
    g.drawImage(lg, 140, 1605 - lh / 2, lw, lh);
    g.fillStyle = '#fff'; g.textAlign = 'left'; g.font = `600 44px 'Inter', sans-serif`; g.fillText('One crew for your', 350, 1545); g.fillText('whole launch.', 350, 1600);
    g.font = `400 30px 'Inter', sans-serif`; g.fillStyle = '#cfcfcf'; g.fillText('encorestudio.xyz · @EncoreStudiohq', 350, 1665);
    g.font = `400 22px 'Inter', sans-serif`; g.fillStyle = '#9a9a9a'; g.fillText('Unofficial concept. Not affiliated with or endorsed by Droolies.', 140, 1735);
  }

  function render(i) {
    const t = i / M.fps;
    const sh = M.shots.find(s => t >= s.t0 && t < s.t1) || M.shots[M.shots.length - 1];
    const k = (t - sh.t0) / (sh.t1 - sh.t0);
    g.setTransform(1, 0, 0, 1, 0, 0);
    const R = finalOf(M.resultTake);
    if (sh.type === 'game') {
      const S = stateAt(sh.take, sh.src + (t - sh.t0));
      g.save();
      if (sh.zoom) { const z = sh.zoom[0] + (sh.zoom[1] - sh.zoom[0]) * SC.ease(k); const cx = L.W / 2, cy = L.kind === 'portrait' ? 900 : 480; g.translate(cx, cy); g.scale(z, z); g.translate(-cx, -cy); }
      V.draw(g, S, A, { time: S.step * E.DT, labels: sh.labels ? Math.min(1, (t - sh.t0) / 0.3) * Math.min(1, (sh.t1 - t) / 0.2) : 0 });
      g.restore();
      if (sh.caption) caption(sh.caption, t, sh.t0, sh.t1, sh.capPos);
      if (sh.tag) hookTag(t, sh.t0, sh.t1);
    } else if (sh.type === 'board') {
      SC.drawLeaderboard(g, L, A, R.score, t, Math.min(1, Math.max(0, (t - sh.t0 - 0.35) / 1.5)), (t - sh.t0) > 0.5 ? sh.caption : null);
      wipe(t, sh.t0);
    } else if (sh.type === 'result') {
      SC.paperBg(g, L, t, true);
      SC.drawResultCard(g, L, A, R, t, Math.min(1, (t - sh.t0) / 0.9), L.W / 2, L.kind === 'portrait' ? 900 : L.H / 2 + 6, L.kind === 'portrait' ? 1.2 : 1.02);
    } else if (sh.type === 'xpost') {
      SC.drawXPost(g, L, A, R, t, Math.min(1, (t - sh.t0) / 0.6));
    } else if (sh.type === 'news') {
      SC.drawNews(g, L, A, R, t, Math.min(1, (t - sh.t0) / 1.2));
      wipe(t, sh.t0);
    } else if (sh.type === 'logo') {
      SC.drawLogoCard(g, L, A, t, Math.min(1, (t - sh.t0) / 1.0));
    } else if (sh.type === 'encore') {
      SC.drawEncore(g, L, A, t);
      const fade = Math.max(0, 1 - (t - sh.t0) / 0.25); if (fade > 0) { g.fillStyle = `rgba(0,0,0,${fade})`; g.fillRect(0, 0, L.W, L.H); }
    } else if (sh.type === 'endshort') {
      endShort(t, Math.min(1, (t - sh.t0) / 1.0));
    }
    return { t, shot: sh.type };
  }

  async function setup(mode) {
    ED = await fetch('edit.json').then(r => r.json());
    M = ED[mode]; L = E.makeLayout(M.kind);
    cv = document.getElementById('c'); cv.width = L.W; cv.height = L.H; g = cv.getContext('2d');
    A = await VSAssets.load(); SC.useRelative(true);
    return { frames: Math.round(M.duration * M.fps), W: L.W, H: L.H, result: finalOf(M.resultTake) };
  }
  root.VSTrailer = { setup, render, finalOf: id => finalOf(id) };
})(typeof window !== 'undefined' ? window : globalThis);
