/* VERY SMART: canvas renderer. Official Droolies art pixels are drawn unchanged (cut-out transforms only). */
(function (root) {
  'use strict';
  const INK = '#1E1C1A', CREAM = '#FBF6E9', PAPER = '#FFF1D2', LIME = '#CCFF00', RED = '#D6483C', YEL = '#FFD84D', BLUE = '#9BD0F5', DROOL = '#98C6E2', GRN = '#79AE5F';
  const CHALK = 'rgba(238,247,218,';
  const MARKER = "'Permanent Marker', cursive", HAND = "'Patrick Hand', cursive";
  const CLASS = ['blonde-grin', 'beanie-2plus3', 'popeyes-beanie', 'headphones-1plus1', 'im-smart', 'propeller-wenmoon', 'party-eyepatch', 'crying-headband-b'];
  const bgCache = {};

  function hash(n) { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }

  function chalkboard(L, A) {
    const key = L.kind;
    if (bgCache[key]) return bgCache[key];
    const c = document.createElement('canvas'); c.width = L.W; c.height = L.H;
    const g = c.getContext('2d');
    const grd = g.createLinearGradient(0, 0, 0, L.H);
    grd.addColorStop(0, '#2b4632'); grd.addColorStop(1, '#22392a');
    g.fillStyle = grd; g.fillRect(0, 0, L.W, L.H);
    // eraser smudges
    for (let i = 0; i < 26; i++) {
      const x = hash(i) * L.W, y = hash(i + 50) * L.H, r = 120 + hash(i + 90) * 340;
      const rg = g.createRadialGradient(x, y, 0, x, y, r);
      rg.addColorStop(0, 'rgba(238,247,218,0.045)'); rg.addColorStop(1, 'rgba(238,247,218,0)');
      g.fillStyle = rg; g.fillRect(x - r, y - r, r * 2, r * 2);
    }
    for (let i = 0; i < 9; i++) { // eraser swipes
      g.strokeStyle = 'rgba(238,247,218,0.035)'; g.lineWidth = 60 + hash(i + 7) * 50; g.lineCap = 'round';
      g.beginPath(); const x = hash(i + 3) * L.W, y = hash(i + 13) * L.H;
      g.moveTo(x, y); g.quadraticCurveTo(x + 200, y - 60 + hash(i) * 120, x + 380 + hash(i + 1) * 200, y + hash(i + 2) * 80 - 40); g.stroke();
    }
    // speckle grain
    for (let i = 0; i < L.W * L.H / 260; i++) {
      g.fillStyle = hash(i * 1.7) > 0.5 ? 'rgba(238,247,218,0.05)' : 'rgba(0,0,0,0.08)';
      g.fillRect(hash(i * 3.1) * L.W, hash(i * 5.3) * L.H, 1.5, 1.5);
    }
    // faint chalk doodles from the Droolies banner vocabulary
    const doodles = ['2+3=6', '1+1=11', '??', 'wen moon?', '2+2=fish', '??', '7-2=8', 'IQ 2+3'];
    g.font = `52px ${HAND}`; g.fillStyle = 'rgba(238,247,218,0.10)';
    const spots = L.kind === 'portrait'
      ? [[120, 600], [820, 640], [180, 1020], [860, 980], [520, 560], [130, 1500], [930, 1450], [560, 1120]]
      : [[300, 300], [1560, 280], [420, 520], [1460, 520], [1700, 410], [250, 690], [1660, 700], [980, 230]];
    spots.forEach((p, i) => { g.save(); g.translate(p[0], p[1]); g.rotate((hash(i + 4) - 0.5) * 0.4); g.fillText(doodles[i], 0, 0); g.restore(); });
    for (let i = 0; i < 10; i++) drawDrop(g, hash(i + 21) * L.W, L.board.y + hash(i + 31) * (L.H - L.board.y - 200), 12, 'rgba(238,247,218,0.10)', null);
    // wooden frame + chalk tray (desk)
    const fw = 16;
    g.fillStyle = '#7b4f2f'; g.strokeStyle = INK; g.lineWidth = 5;
    g.fillRect(0, 0, fw, L.H); g.fillRect(L.W - fw, 0, fw, L.H);
    g.beginPath(); g.moveTo(fw, 0); g.lineTo(fw, L.deskY); g.moveTo(L.W - fw, 0); g.lineTo(L.W - fw, L.deskY); g.stroke();
    const ty = L.deskY;
    g.fillStyle = '#8a5a35'; g.fillRect(0, ty, L.W, L.H - ty);
    g.fillStyle = '#6d4427'; g.fillRect(0, ty + (L.H - ty) * 0.55, L.W, L.H - ty);
    g.beginPath(); g.moveTo(0, ty); g.lineTo(L.W, ty); g.stroke();
    // wood grain
    g.strokeStyle = 'rgba(30,28,26,0.25)'; g.lineWidth = 2;
    for (let i = 0; i < 6; i++) { g.beginPath(); const yy = ty + 8 + i * 6; g.moveTo(0, yy); for (let x = 0; x <= L.W; x += 80) g.lineTo(x, yy + Math.sin(x * 0.01 + i) * 2); g.stroke(); }
    // chalk sticks + eraser on the tray
    const cs = [[L.W * 0.12, '#f4f1e6'], [L.W * 0.16, '#f5c9c4'], [L.W * 0.86, '#cfe8f7']];
    cs.forEach(([x, col]) => { g.fillStyle = col; g.strokeStyle = INK; g.lineWidth = 3; rr(g, x, ty - 14, 70, 16, 7); g.fill(); g.stroke(); });
    g.fillStyle = '#c9a073'; g.strokeStyle = INK; g.lineWidth = 3; rr(g, L.W * 0.78, ty - 30, 120, 30, 6); g.fill(); g.stroke();
    g.fillStyle = '#3a3a3a'; rr(g, L.W * 0.78, ty - 12, 120, 12, 4); g.fill(); g.stroke();
    bgCache[key] = c;
    return c;
  }

  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function drawDrop(g, x, y, r, fill, stroke, lw) {
    g.beginPath(); g.moveTo(x, y - r * 1.9);
    g.bezierCurveTo(x + r * 0.35, y - r * 1.2, x + r, y - r * 0.5, x + r, y);
    g.arc(x, y, r, 0, Math.PI, false);
    g.bezierCurveTo(x - r, y - r * 0.5, x - r * 0.35, y - r * 1.2, x, y - r * 1.9);
    g.closePath();
    if (fill) { g.fillStyle = fill; g.fill(); }
    if (stroke) { g.strokeStyle = stroke; g.lineWidth = lw || 3; g.stroke(); }
  }
  function markerText(g, txt, x, y, size, fill, shadow, align, rot, lw) {
    g.save(); g.translate(x, y); if (rot) g.rotate(rot);
    g.font = `${size}px ${MARKER}`; g.textAlign = align || 'center'; g.textBaseline = 'middle';
    if (lw) { g.lineJoin = 'round'; g.strokeStyle = INK; g.lineWidth = lw; g.strokeText(txt, size * 0.06, size * 0.07); }
    g.fillStyle = shadow || RED; g.fillText(txt, size * 0.06, size * 0.07);
    g.fillStyle = fill || INK; g.fillText(txt, 0, 0);
    g.restore();
  }
  function wobblyEllipse(g, x, y, rx, ry, wob) {
    g.beginPath();
    for (let i = 0; i <= 48; i++) {
      const a = i / 48 * Math.PI * 2;
      const k = 1 + 0.03 * Math.sin(3 * a + wob) + 0.018 * Math.sin(5 * a + wob * 2.3);
      const px = x + Math.cos(a) * rx * k, py = y + Math.sin(a) * ry * k;
      i ? g.lineTo(px, py) : g.moveTo(px, py);
    }
    g.closePath();
  }

  // head transform shared by hero, eyes and drool
  function headXf(S, time) {
    const L = S.L;
    const bob = Math.sin(time * 2.1) * 4 * L.s;
    const sq = S.react * (S.reactKind === 'normal' ? 0.05 : 0.07);
    const shakeX = S.reactKind === 'normal' ? Math.sin(time * 70) * 9 * S.react : 0;
    let tilt = ((S.aim.x - L.W / 2) / L.W) * 0.09;
    if (S.pop > 0) tilt = Math.sin(time * 9) * 0.03;
    return { bob, sx: 1 + sq * 0.6, sy: 1 - sq, tilt, shakeX, px: L.neck.x, py: L.neck.y };
  }
  function xfPoint(X, x, y) {
    const dx = (x - X.px) * X.sx, dy = (y - X.py) * X.sy;
    const c = Math.cos(X.tilt), s = Math.sin(X.tilt);
    return { x: X.px + dx * c - dy * s + X.shakeX, y: X.py + dx * s + dy * c + X.bob };
  }

  function drawPolaroids(g, S, A, time) {
    const L = S.L;
    L.sources.forEach((p, i) => {
      const img = A.polaroids[CLASS[i % CLASS.length]];
      const pulse = S.srcPulse[i] || 0;
      const wig = Math.sin(time * 1.3 + i * 1.7) * 0.6 + pulse * Math.sin(time * 30) * 5 + (S.pop > 0 ? Math.sin(time * 12 + i) * 3 : 0);
      g.save(); g.translate(p.x, p.y + Math.sin(time * 1.1 + i) * 1.5 - pulse * 8); g.rotate((p.rot + wig) * Math.PI / 180);
      const sz = p.size * (1 + pulse * 0.06);
      g.fillStyle = 'rgba(0,0,0,0.38)'; g.fillRect(-sz / 2 + 6, -sz / 2 + 8, sz, sz);
      g.drawImage(img, -sz / 2, -sz / 2, sz, sz);
      // tape
      g.fillStyle = 'rgba(251,246,233,0.78)'; g.strokeStyle = 'rgba(30,28,26,0.25)'; g.lineWidth = 1.5;
      g.save(); g.translate(0, -sz / 2 + 2); g.rotate(-0.08 + (i % 2) * 0.14); g.fillRect(-34, -12, 68, 24); g.strokeRect(-34, -12, 68, 24); g.restore();
      g.restore();
    });
  }

  function drawBubble(g, S, b, time, hot) {
    const L = S.L;
    let sc = 1, alpha = 1, dy = 0, rot = 0;
    if (b.age < 0.4) { const k = b.age / 0.4; sc = k < 0.7 ? (k / 0.7) * 1.12 : 1.12 - (k - 0.7) / 0.3 * 0.12; }
    const left = b.life - b.age;
    if (b.popT < 0 && left < 1.0) { rot = Math.sin(time * 38) * 0.06 * (1 - left); sc *= 1 - 0.12 * (1 - left); }
    if (b.popT >= 0) {
      const k = (S.t - b.popT) / 0.5;
      if (b.hit === 'escape') { dy = -40 * k; sc = Math.max(0.001, 0.88 * (1 - k)); }
      else if (b.hit === 'normal') { rot = Math.sin(k * 40) * 0.12 * (1 - k); dy = k * k * 160; sc = 1 - 0.5 * k * k; }
      else { alpha = 1; }
      if (alpha <= 0) return;
    }
    const src = L.sources[b.src];
    g.save(); g.globalAlpha = alpha;
    const popped = b.popT >= 0 && (b.hit === 'perfect' || b.hit === 'good');
    if (popped) { const age = S.t - b.popT;
      if (age < 0.16) { // hold the solved sum on screen: lime glow + check
        g.translate(b.x, b.y); const q = 1 + 0.08 * Math.sin(age / 0.16 * Math.PI);
        g.scale(q, q); wobblyEllipse(g, 0, 0, b.rx + 10, b.ry + 10, b.wob); g.fillStyle = LIME; g.fill(); g.lineWidth = 5; g.strokeStyle = INK; g.stroke();
        wobblyEllipse(g, 0, 0, b.rx, b.ry, b.wob); g.fillStyle = b.kind === 'gold' ? YEL : '#FFFDF6'; g.fill(); g.stroke();
        g.fillStyle = INK; g.font = `${b.text.length > 7 ? 42 : 50}px ${HAND}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(b.text, 0, 3);
        g.strokeStyle = '#2f8a46'; g.lineWidth = 9; g.lineCap = 'round'; g.beginPath(); g.moveTo(b.rx - 40, -b.ry + 6); g.lineTo(b.rx - 24, -b.ry + 24); g.lineTo(b.rx + 6, -b.ry - 16); g.stroke();
        g.restore(); return; }
      const k = (age - 0.16) / 0.2; if (k > 1) { g.restore(); return; }
      g.translate(b.x, b.y); g.scale(1 + 0.6 * k, 1 + 0.6 * k); wobblyEllipse(g, 0, 0, b.rx, b.ry, b.wob);
      g.strokeStyle = `rgba(251,246,233,${1 - k})`; g.lineWidth = 10 * (1 - k) + 2; g.stroke(); g.restore(); return; }
    // thought-bubble tail toward its Droolie (same style as the art)
    if (b.popT < 0 && b.age > 0.2) {
      const sx = src.x, sy = src.y + src.size * 0.5;
      let ux = sx - b.x, uy = sy - b.y; const n = Math.hypot(ux, uy) || 1; ux /= n; uy /= n;
      const ex = b.x + ux * b.rx * 0.92, ey = b.y + uy * b.ry * 0.92;
      [[16, 10], [42, 6.5]].forEach(([d, rad]) => { g.beginPath(); g.arc(ex + ux * d, ey + uy * d, rad, 0, 7); g.fillStyle = '#FFFDF6'; g.fill(); g.lineWidth = 3.5; g.strokeStyle = INK; g.stroke(); });
    }
    g.translate(b.x, b.y + dy); g.rotate(rot + Math.sin(b.age * 1.7 + b.wob) * 0.03); g.scale(sc, sc);
    if (hot && b.popT < 0) {
      g.save(); wobblyEllipse(g, 0, 0, b.rx + 14, b.ry + 14, b.wob); g.strokeStyle = 'rgba(204,255,0,0.85)'; g.lineWidth = 7; g.setLineDash([16, 10]); g.lineDashOffset = -time * 80; g.stroke(); g.restore();
    }
    if (!popped && b.popT < 0) { wobblyEllipse(g, 5, 7, b.rx, b.ry, b.wob); g.fillStyle = 'rgba(0,0,0,0.30)'; g.fill(); }
    wobblyEllipse(g, 0, 0, b.rx, b.ry, b.wob); g.fillStyle = b.kind === 'gold' ? YEL : '#FFFDF6'; g.fill();
    g.lineWidth = 5; g.strokeStyle = INK; g.lineJoin = 'round'; g.stroke();
    g.fillStyle = INK; g.font = `${b.text.length > 7 ? 42 : 50}px ${HAND}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(b.text, 0, 3);
    if (b.popT >= 0 && b.hit === 'normal') { // red cross stamp
      g.strokeStyle = RED; g.lineWidth = 12; g.lineCap = 'round';
      g.beginPath(); g.moveTo(-50, -38); g.lineTo(50, 38); g.moveTo(50, -38); g.lineTo(-50, 38); g.stroke();
    }
    g.restore();
  }

  function chalkLine(g, x1, y1, x2, y2, color, w, dashed, time, seed) {
    g.save(); g.lineCap = 'round';
    for (let k = 0; k < 3; k++) {
      g.strokeStyle = color.replace('A', (k === 0 ? 0.95 : 0.35).toString());
      g.lineWidth = k === 0 ? w : w * 0.5;
      if (dashed) { g.setLineDash([26, 16]); g.lineDashOffset = -time * 120; }
      const o = (k - 1) * w * 0.35;
      g.beginPath(); g.moveTo(x1 + o, y1); g.lineTo(x2 + o, y2); g.stroke();
    }
    g.restore();
  }
  function extend(x, y, tx, ty, L) { // ray to board edge
    const dx = tx - x, dy = ty - y; const n = Math.hypot(dx, dy) || 1;
    const ux = dx / n, uy = dy / n; let t = 4000;
    if (uy < 0) t = Math.min(t, (40 - y) / uy);
    if (ux > 0) t = Math.min(t, (L.W - 20 - x) / ux); if (ux < 0) t = Math.min(t, (20 - x) / ux);
    return { x: x + ux * t, y: y + uy * t };
  }

  function drawHero(g, S, A, X, time) {
    const L = S.L, img = A.hero;
    g.save();
    g.translate(X.px + X.shakeX, X.py + X.bob); g.rotate(X.tilt); g.scale(X.sx, X.sy); g.translate(-X.px, -X.py);
    g.drawImage(img, L.ox, L.oy, 800 * L.s, 800 * L.s);
    if (S.reactKind === 'normal' && S.react > 0.2) { // flushed "too normal" blush
      g.globalAlpha = S.react * 0.35; g.fillStyle = RED; g.fillRect(L.ox + 220 * L.s, L.oy + 240 * L.s, 370 * L.s, 360 * L.s); g.globalAlpha = 1;
    }
    g.restore();
  }

  function drawDrool(g, S, X, time) {
    const L = S.L;
    const base = L.baseDrool, len = base + S.drool + Math.sin(time * 5) * 2 * L.s;
    const a = xfPoint(X, L.chin.x, L.chin.y - 6 * L.s);
    const sway = Math.sin(time * 2.3) * (4 + len * 0.05) + S.droolV * 0.05 + (S.aim.x - L.W / 2) * -0.004 * len * 0.1;
    const ex = a.x + sway, ey = a.y + len;
    const w = 15 * L.s * 1.5, fw = 8 * L.s * 1.5;
    const path = () => { g.beginPath(); g.moveTo(a.x, a.y); g.quadraticCurveTo(a.x + sway * 0.2, a.y + len * 0.6, ex, ey); };
    g.save(); g.lineCap = 'round';
    path(); g.strokeStyle = INK; g.lineWidth = w; g.stroke();
    path(); g.strokeStyle = DROOL; g.lineWidth = fw; g.stroke();
    // highlight
    g.globalAlpha = 0.45; path(); g.strokeStyle = '#d6ecf8'; g.lineWidth = fw * 0.3; g.stroke(); g.globalAlpha = 1;
    // droplet
    const r = 10 * L.s * 1.5 + Math.min(6, S.drool * 0.02);
    g.beginPath(); g.arc(ex, ey + r * 0.6, r, 0, 7); g.fillStyle = DROOL; g.fill(); g.lineWidth = 3.6 * L.s * 1.5; g.strokeStyle = INK; g.stroke();
    g.beginPath(); g.arc(ex - r * 0.35, ey + r * 0.3, r * 0.25, 0, 7); g.fillStyle = '#e4f3fb'; g.fill();
    g.restore();
    // puddle shadow on desk grows as danger rises
    const danger = Math.min(1, (len) / (L.maxDrool));
    g.save(); g.globalAlpha = 0.25 + danger * 0.5; g.fillStyle = danger > 0.8 ? RED : 'rgba(0,0,0,0.6)';
    g.beginPath(); g.ellipse(ex, L.deskY + 6, 18 + danger * 50, 5 + danger * 8, 0, 0, 7); g.fill(); g.restore();
    if (danger > 0.72 && !S.over) { const bl = Math.sin(time * 18) > -0.2; if (bl) markerText(g, 'DROOL ALERT!', ex + 40 * L.s / 0.7, ey - 10, 40, CREAM, RED, 'left', -0.06, 6); }
    return { ex, ey, danger };
  }

  function popAmount(S) { return S.pop > 0 ? Math.min(1, (4 - S.pop) / 0.18, S.pop / 0.25) : 0; }
  function popEyePos(S, X, i, time) { // where each popped eyeball sits (above the head, like the official trait)
    const L = S.L, out = popAmount(S), e = i ? L.eyeR : L.eyeL;
    const age = 4 - S.pop, spring = 1 + Math.sin(Math.min(1, age) * Math.PI * 5) * 0.22 * (1 - Math.min(1, age));
    const base = xfPoint(X, e.x, e.y), top = xfPoint(X, e.x + (i ? 55 : -55) * L.s, L.oy + (HERO_TOP - 10) * L.s);
    return { base, x: base.x + (top.x - base.x) * out * spring, y: base.y + (top.y - base.y) * out * spring, r: 70 * L.s * (0.55 + 0.45 * out), out };
  }
  const HERO_TOP = 170;
  function drawPopEyes(g, S, X, time) {
    const L = S.L; if (popAmount(S) <= 0) return;
    const c = S.cross || S.aim;
    [0, 1].forEach(i => {
      const P = popEyePos(S, X, i, time); if (P.out <= 0) return;
      // empty socket
      g.save(); g.translate(P.base.x, P.base.y); g.rotate(X.tilt);
      g.beginPath(); g.ellipse(0, 0, 54 * L.s * P.out, 30 * L.s * P.out, 0, 0, 7); g.fillStyle = '#3b2a24'; g.fill(); g.lineWidth = 4; g.strokeStyle = INK; g.stroke();
      g.restore();
      // spring
      const n = 7, dx = P.x - P.base.x, dy = P.y - P.base.y, len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len;
      g.beginPath(); g.moveTo(P.base.x, P.base.y);
      for (let k = 1; k < n; k++) { const t = k / n, side = (k % 2 ? 1 : -1) * 14 * L.s / 0.7; g.lineTo(P.base.x + dx * t - uy * side, P.base.y + dy * t + ux * side); }
      g.lineTo(P.x, P.y); g.strokeStyle = INK; g.lineWidth = 6; g.lineJoin = 'round'; g.stroke();
      // eyeball
      g.beginPath(); g.arc(P.x, P.y, P.r, 0, 7); g.fillStyle = '#FFFDF6'; g.fill(); g.lineWidth = 7 * L.s * 1.4; g.strokeStyle = INK; g.stroke();
      g.strokeStyle = RED; g.lineWidth = 2.5;
      for (let v = 0; v < 3; v++) { const a = (i ? 0.4 : 2.7) + v * 0.45; g.beginPath(); g.moveTo(P.x + Math.cos(a) * P.r * 0.95, P.y + Math.sin(a) * P.r * 0.95); g.lineTo(P.x + Math.cos(a + 0.15) * P.r * 0.6, P.y + Math.sin(a + 0.15) * P.r * 0.6); g.stroke(); }
      const ang = Math.atan2(c.y - P.y, c.x - P.x);
      g.beginPath(); g.arc(P.x + Math.cos(ang) * P.r * 0.42, P.y + Math.sin(ang) * P.r * 0.42, P.r * 0.36, 0, 7); g.fillStyle = INK; g.fill();
      g.beginPath(); g.arc(P.x + Math.cos(ang) * P.r * 0.42 - P.r * 0.1, P.y + Math.sin(ang) * P.r * 0.42 - P.r * 0.12, P.r * 0.09, 0, 7); g.fillStyle = '#fff'; g.fill();
    });
  }

  function drawCross(g, S, time) {
    const c = S.cross; if (!c || S.over) return null;
    const L = S.L;
    let hot = null, best = 9;
    for (const b of S.bubbles) { if (b.popT >= 0 || b.age < 0.25) continue; const d = VSEngine.inBubble(b, c.x, c.y); if (d < 1 && d < best) { best = d; hot = b; } }
    const hb = L.headBox, inHead = c.x > hb.x && c.x < hb.x + hb.w && c.y > hb.y - 20 && c.y < hb.y + hb.h;
    g.save(); g.translate(c.x, c.y); if (inHead && S.pop <= 0) g.globalAlpha = 0.35;
    if (S.pop > 0) {
      const R = L.kind === 'portrait' ? 230 : 210;
      g.strokeStyle = 'rgba(204,255,0,0.9)'; g.lineWidth = 8; g.setLineDash([22, 14]); g.lineDashOffset = -time * 200;
      g.beginPath(); g.arc(0, 0, R * (1 + Math.sin(time * 10) * 0.03), 0, 7); g.stroke();
      g.fillStyle = 'rgba(204,255,0,0.10)'; g.fill();
    }
    const s = 30 + Math.sin(time * 8) * 3 + (time - S.lastTap < 0.15 ? 10 : 0);
    g.lineCap = 'round';
    g.strokeStyle = INK; g.lineWidth = 15; g.beginPath(); g.moveTo(-s, -s); g.lineTo(s, s); g.moveTo(s, -s); g.lineTo(-s, s); g.stroke();
    g.strokeStyle = hot ? LIME : '#f4f6ec'; g.lineWidth = 8; g.beginPath(); g.moveTo(-s, -s); g.lineTo(s, s); g.moveTo(s, -s); g.lineTo(-s, s); g.stroke();
    g.restore();
    return hot;
  }

  function drawFx(g, S, time) {
    for (const f of S.fx) {
      const k = (S.t - f.t);
      if (f.kind === 'pop') {
        // chalk burst + drool droplets
        for (let i = 0; i < 10; i++) {
          const a = i / 10 * Math.PI * 2 + f.x, r1 = 40 + k * 260, r2 = r1 + 26 * (1 - k);
          if (k > 0.45) break;
          g.strokeStyle = f.q === 'perfect' ? LIME : CREAM; g.lineWidth = 6 * (1 - k * 2); g.lineCap = 'round';
          g.beginPath(); g.moveTo(f.x + Math.cos(a) * r1, f.y + Math.sin(a) * r1 * 0.7); g.lineTo(f.x + Math.cos(a) * r2, f.y + Math.sin(a) * r2 * 0.7); g.stroke();
        }
        if (k < 0.8) for (let i = 0; i < 5; i++) {
          const a = -Math.PI / 2 + (i - 2) * 0.5, sp = 300 + (i % 2) * 90;
          const x = f.x + Math.cos(a) * sp * k, y = f.y + Math.sin(a) * sp * k + 900 * k * k;
          drawDrop(g, x, y, 11, DROOL, INK, 3);
        }
        if (k < 1.1) {
          const lift = -150 - k * 80, al = Math.min(1, (1.1 - k) * 3, k * 8);
          g.save(); g.globalAlpha = al;
          const lab = f.gold ? 'WEN MOON? NOW!' : f.inPop ? 'EYES POP!' : 'VERY SMART!';
          markerText(g, lab, f.x, f.y + lift, 44, LIME, INK, 'center', -0.04, 8);
          markerText(g, '+' + f.pts.toLocaleString('en-US') + (f.q === 'perfect' && !f.inPop ? ' PERFECT' : ''), f.x, f.y + lift + 46, 34, CREAM, RED, 'center', 0.03, 6);
          g.restore();
        }
      } else if (f.kind === 'normal' && k < 1.2) {
        g.save(); g.globalAlpha = Math.min(1, (1.2 - k) * 3);
        markerText(g, 'TOO NORMAL!', f.x, f.y - 160 - k * 40, 58, CREAM, RED, 'center', -0.08, 8);
        markerText(g, '+DROOL', f.x, f.y - 108 - k * 40, 34, BLUE, INK, 'center', 0.05, 6);
        g.restore();
      } else if (f.kind === 'miss' && k < 0.7) {
        g.save(); g.globalAlpha = (0.7 - k) / 0.7; markerText(g, '??', f.x, f.y - 50 - k * 60, 52, CREAM, INK, 'center', 0.1); g.restore();
      }
    }
  }

  function drawHud(g, S, A, time, opts) {
    const L = S.L, P = L.kind === 'portrait';
    // left sticky note: Drool Points
    const nx = P ? 36 : 60, ny = P ? 1590 : 790, nw = P ? 310 : 360, nh = P ? 210 : 200;
    g.save(); g.translate(nx + nw / 2, ny + nh / 2); g.rotate(-0.035);
    g.fillStyle = 'rgba(0,0,0,0.38)'; rr(g, -nw / 2 + 7, -nh / 2 + 9, nw, nh, 14); g.fill();
    g.fillStyle = CREAM; g.strokeStyle = INK; g.lineWidth = 4.5; rr(g, -nw / 2, -nh / 2, nw, nh, 14); g.fill(); g.stroke();
    g.fillStyle = INK; g.font = `30px ${HAND}`; g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText('DROOL POINTS', -nw / 2 + 22, -nh / 2 + 34); drawDrop(g, -nw / 2 + 228, -nh / 2 + 36, 10, DROOL, INK, 3);
    markerText(g, S.score.toLocaleString('en-US'), -nw / 2 + 22, -nh / 2 + 92, P ? 58 : 64, INK, RED, 'left', 0);
    const mult = Math.min(6, 1 + Math.floor(S.combo / 2));
    g.fillStyle = S.combo >= 2 ? LIME : '#e9e2cc'; g.strokeStyle = INK; g.lineWidth = 3.5; rr(g, -nw / 2 + 20, nh / 2 - 58, P ? 120 : 132, 42, 10); g.fill(); g.stroke();
    g.fillStyle = INK; g.font = `28px ${MARKER}`; g.textAlign = 'center'; g.fillText('x' + mult, -nw / 2 + 20 + (P ? 60 : 66), nh / 2 - 36);
    g.font = `26px ${HAND}`; g.textAlign = 'left'; g.fillText(S.combo + ' in a row', -nw / 2 + (P ? 152 : 166), nh / 2 - 36);
    g.restore();
    // right sticky note: brain meter + bell timer
    const rx = P ? L.W - 346 : L.W - 420, ry = ny;
    g.save(); g.translate(rx + nw / 2, ry + nh / 2); g.rotate(0.03);
    g.fillStyle = 'rgba(0,0,0,0.38)'; rr(g, -nw / 2 + 7, -nh / 2 + 9, nw, nh, 14); g.fill();
    g.fillStyle = PAPER; g.strokeStyle = INK; g.lineWidth = 4.5; rr(g, -nw / 2, -nh / 2, nw, nh, 14); g.fill(); g.stroke();
    g.fillStyle = INK; g.font = `30px ${HAND}`; g.textAlign = 'left'; g.textBaseline = 'middle';
    g.fillText(S.pop > 0 ? 'EYES POPPED OUT!' : '6 IN A ROW = EYES POP', -nw / 2 + 22, -nh / 2 + 34);
    const pips = S.pop > 0 ? 6 : S.brain;
    for (let i = 0; i < 6; i++) {
      const px = -nw / 2 + 40 + i * (P ? 42 : 50), py = -nh / 2 + 96;
      drawDrop(g, px, py + 10, 15, i < pips ? (S.pop > 0 ? LIME : DROOL) : '#e9e2cc', INK, 3.5);
    }
    const left = Math.max(0, Math.ceil(S.round - S.t));
    g.fillStyle = INK; g.font = `28px ${HAND}`; g.fillText('time', -nw / 2 + 22, nh / 2 - 36);
    markerText(g, `0:${String(left).padStart(2, '0')}`, -nw / 2 + (P ? 90 : 96), nh / 2 - 38, 40, INK, RED, 'left', 0);
    g.restore();
  }

  function draw(g, S, A, opts) {
    opts = opts || {};
    const L = S.L, time = opts.time != null ? opts.time : S.t;
    g.save();
    const sh = S.shake;
    if (sh > 0.3) g.translate(Math.sin(time * 91) * sh, Math.cos(time * 77) * sh * 0.7);
    g.drawImage(chalkboard(L, A), 0, 0);
    // drifting chalk dust
    for (let i = 0; i < 26; i++) {
      const ph = (time * 0.05 + hash(i)) % 1;
      g.fillStyle = `rgba(238,247,218,${0.25 * Math.sin(ph * Math.PI)})`;
      g.beginPath(); g.arc(hash(i + 7) * L.W + Math.sin(time * 0.3 + i) * 30, L.deskY - ph * (L.deskY - 100), 2.2, 0, 7); g.fill();
    }
    drawPolaroids(g, S, A, time);
    const X = headXf(S, time);
    const hot = S.cross && !S.over ? (() => { let h = null, bd = 9; for (const b of S.bubbles) { if (b.popT >= 0 || b.age < 0.25) continue; const d = VSEngine.inBubble(b, S.cross.x, S.cross.y); if (d < 1 && d < bd) { bd = d; h = b; } } return h; })() : null;
    for (const b of S.bubbles) drawBubble(g, S, b, time, b === hot);
    drawHero(g, S, A, X, time);
    drawPopEyes(g, S, X, time);
    // sight lines from the (transformed) pupils
    if (!S.over) {
      let eR = xfPoint(X, L.eyeR.x, L.eyeR.y), eL = xfPoint(X, L.eyeL.x, L.eyeL.y);
      if (S.pop > 0) { const a0 = popEyePos(S, X, 0, time), a1 = popEyePos(S, X, 1, time); eL = { x: a0.x, y: a0.y }; eR = { x: a1.x, y: a1.y }; }
      const c = S.cross;
      const off = (e, t, d) => { const dx = t.x - e.x, dy = t.y - e.y, n = Math.hypot(dx, dy) || 1; return { x: e.x + dx / n * d, y: e.y + dy / n * d }; };
      const pT = c ? extend(eR.x, eR.y, c.x, c.y, L) : extend(eR.x, eR.y, S.aim.x, S.aim.y, L);
      let wT;
      if (S.pop > 0) wT = extend(eL.x, eL.y, S.aim.x, S.aim.y, L);
      else if (c) wT = extend(eL.x, eL.y, c.x, c.y, L);
      else { const a = S.wAng; wT = extend(eL.x, eL.y, eL.x + Math.sin(a) * 100, eL.y - Math.cos(a) * 100, L); }
      const gap = S.pop > 0 ? 70 * L.s : 46 * L.s / 0.7 * 0.7 + 18;
      const sL = off(eL, wT, gap), sR = off(eR, pT, gap);
      chalkLine(g, sL.x, sL.y, wT.x, wT.y, S.pop > 0 ? 'rgba(204,255,0,A)' : 'rgba(238,247,218,A)', S.pop > 0 ? 12 : 7, S.pop <= 0, time);
      chalkLine(g, sR.x, sR.y, pT.x, pT.y, 'rgba(204,255,0,A)', S.pop > 0 ? 12 : 8, false, time);
    }
    const dr = drawDrool(g, S, X, time);
    drawCross(g, S, time);
    drawFx(g, S, time);
    if (opts.labels) { // in-world labels for teaching shots
      const eR = xfPoint(X, L.eyeR.x, L.eyeR.y), eL = xfPoint(X, L.eyeL.x, L.eyeL.y);
      g.save(); g.globalAlpha = opts.labels;
      const lab = (txt, x, y, col, al) => { g.font = `${L.kind === 'portrait' ? 40 : 46}px ${HAND}`; g.textAlign = al; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.strokeStyle = INK; g.lineWidth = 9; g.strokeText(txt, x, y); g.fillStyle = col; g.fillText(txt, x, y); };
      const P = L.kind === 'portrait';
      lab('your eye (you aim)', eR.x + (P ? 70 : 260), eR.y + (P ? -150 : 40), LIME, P ? 'left' : 'left');
      lab('the other one', eL.x - (P ? 70 : 260), eL.y + (P ? -150 : 40), CREAM, 'right');
      lab('(goes wherever it wants)', eL.x - (P ? 70 : 260), eL.y + (P ? -102 : 88), CREAM, 'right');
      g.restore();
    }
    if (opts.hud !== false) drawHud(g, S, A, time, opts);
    // EYES POP OUT banner
    for (const f of S.fx) if (f.kind === 'eyespop') {
      const k = S.t - f.t; if (k > 1.4) continue;
      const sc = k < 0.15 ? k / 0.15 * 1.25 : k < 0.3 ? 1.25 - (k - 0.15) / 0.15 * 0.25 : 1;
      g.save(); g.globalAlpha = k > 1.1 ? (1.4 - k) / 0.3 : 1;
      g.translate(L.W / 2, L.board.y + L.board.h * (L.kind === 'portrait' ? 0.42 : 0.38)); g.scale(sc, sc); g.rotate(-0.05);
      markerText(g, 'EYES POP OUT!', 0, 0, L.kind === 'portrait' ? 92 : 112, LIME, INK, 'center', 0, 14);
      g.fillStyle = RED; g.strokeStyle = INK; g.lineWidth = 4; rr(g, -200, 58, 400, 54, 12); g.fill(); g.stroke();
      g.fillStyle = CREAM; g.font = `34px ${MARKER}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('RAREST TRAIT · x2', 0, 86);
      g.restore();
    }
    if (S.flash > 0.08) { const cx = L.W / 2, cy = L.headBox.y; const rg = g.createRadialGradient(cx, cy, 0, cx, cy, L.W * 0.45);
      rg.addColorStop(0, `rgba(204,255,0,${S.flash * 0.28})`); rg.addColorStop(1, 'rgba(204,255,0,0)'); g.fillStyle = rg; g.fillRect(0, 0, L.W, L.H); }
    if (S.over && S.endReason === 'splat') {
      const k = S.t - S.endT, P = L.kind === 'portrait';
      const e = Math.min(1, k * 6);
      g.save();
      // splash puddle on the desk + flying drops
      g.fillStyle = DROOL; g.strokeStyle = INK; g.lineWidth = 6;
      g.beginPath();
      for (let i = 0; i <= 28; i++) { const a = i / 28 * Math.PI * 2, r = (1 + 0.28 * Math.sin(i * 2.7) + 0.18 * Math.sin(i * 5.1)) * e; const x = dr.ex + Math.cos(a) * 190 * r, y = L.deskY - 4 + Math.sin(a) * 34 * r; i ? g.lineTo(x, y) : g.moveTo(x, y); }
      g.closePath(); g.fill(); g.stroke();
      if (k < 0.9) for (let i = 0; i < 9; i++) { const a = -Math.PI + (i + 0.5) / 9 * Math.PI, sp = 420 + (i % 3) * 140; drawDrop(g, dr.ex + Math.cos(a) * sp * k, L.deskY - 20 + Math.sin(a) * sp * k + 1400 * k * k, 14, DROOL, INK, 3.5); }
      const sc = k < 0.12 ? k / 0.12 * 1.3 : k < 0.24 ? 1.3 - (k - 0.12) / 0.12 * 0.3 : 1;
      g.translate(P ? L.W / 2 : dr.ex + 330, P ? L.deskY - 330 : L.deskY - 360); g.scale(sc, sc);
      markerText(g, 'SPLAT!', 0, 0, P ? 150 : 140, CREAM, RED, 'center', -0.08, 14);
      if (k > 0.25) { g.globalAlpha = Math.min(1, (k - 0.25) * 6); g.fillStyle = INK; rr(g, -190, 70, 380, 70, 14); g.fill(); markerText(g, 'RUN OVER', 0, 106, 46, CREAM, RED, 'center', 0); }
      g.restore();
    }
    g.restore();
  }

  root.VSView = { draw, chalkboard, markerText, drawDrop, rr, wobblyEllipse, CLASS, INK, CREAM, PAPER, LIME, RED, YEL, BLUE, DROOL, GRN, MARKER, HAND };
})(typeof window !== 'undefined' ? window : globalThis);
