

// auction numbers: shown in the menu bar and the auction section. Real data plugs in here.
window.setAuction = ({ total = 0, top = 0, bidders = 0, topWho = '' } = {}) => {
  const f = n => (+n).toLocaleString('en-US', { maximumFractionDigits: 4 });
  document.querySelectorAll('[data-total]').forEach(e => e.textContent = f(total));
  document.querySelectorAll('[data-top]').forEach(e => e.textContent = (+top).toLocaleString('en-US', { maximumFractionDigits: top >= 10 ? 1 : 3 }));
  document.querySelectorAll('[data-bidders]').forEach(e => e.textContent = (+bidders).toLocaleString('en-US'));
  const filled = Math.min(+bidders, 500);
  document.querySelectorAll('[data-filled]').forEach(e => e.textContent = filled);
  document.querySelectorAll('[data-fill]').forEach(e => e.style.width = (filled / 5) + '%');
  document.querySelectorAll('[data-topwho]').forEach(e => e.textContent = topWho ? 'by ' + topWho : 'no bids yet');
};
setAuction();

// TV ticker: latest bids (real feed plugs in here)
window.setTicker = items => {
  const t = (items && items.length ? items : ['THE DROOL AUCTION IS COMING', 'BID ANY AMOUNT OF ETH', 'TOP 500 WIN A DROOLIE', 'EVERYONE ELSE GETS REFUNDED', 'STAY DROOL 💧']).join(' ✦ ') + ' ✦ ';
  document.getElementById('tvRun').textContent = t + t + t;
};
setTicker();

// FREE MINT title: letters hop one after another
(() => { const h = document.getElementById('fmWave'); if (!h) return; const t = h.textContent; h.textContent = '';
  [...t].forEach((c, i) => { const sp = document.createElement('span'); sp.textContent = c === ' ' ? ' ' : c; sp.style.animationDelay = (i * 0.07) + 's'; h.appendChild(sp); }); })();



// every Droolies name/logo on the page goes to the home (top)
document.querySelectorAll('.tvBrand, .hero .pill, .end p, .brand').forEach(el => { el.style.cursor = 'pointer'; el.title = 'Home'; el.addEventListener('click', e => { e.preventDefault(); scrollTo({ top: 0, behavior: 'smooth' }); }); });

// chalk dust floating up on the board
(() => { if (!document.body.classList.contains('bgK')) return; const n = innerWidth < 700 ? 14 : 30;
  for (let i = 0; i < n; i++) { const d = document.createElement('div'); d.className = 'dust';
    d.style.left = Math.random() * 100 + 'vw'; d.style.top = (20 + Math.random() * 85) + 'vh';
    d.style.setProperty('--dx', (Math.random() * 80 - 40) + 'px'); const sz = 2 + Math.random() * 4; d.style.width = d.style.height = sz + 'px';
    d.style.animationDuration = (8 + Math.random() * 10) + 's'; d.style.animationDelay = (-Math.random() * 18) + 's'; document.body.appendChild(d); } })();



// real drool: drops form at the drip tips under the menu and fall
(() => { const nav = document.querySelector('nav'); const tips = [24, 87, 164, 230, 284]; // x of the drips in each 300px tile
  setInterval(() => { if (document.hidden) return; const n = document.createElement('div'); n.className = 'ndrop';
    const tile = Math.floor(Math.random() * Math.ceil(innerWidth / 300)), x = tile * 300 + tips[Math.floor(Math.random() * tips.length)];
    n.style.left = (x - 4) + 'px'; n.style.top = (nav.getBoundingClientRect().bottom + 22) + 'px'; document.body.appendChild(n); setTimeout(() => n.remove(), 1700); }, 700); })();



// Home / logo: go to the very top of the page
document.querySelectorAll('a[href="#top"]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); scrollTo({ top: 0, behavior: 'smooth' }); history.replaceState(null, '', location.pathname + location.search); }));

// Home button appears after scrolling down
(() => { const b = document.getElementById('toTop'); addEventListener('scroll', () => b.classList.toggle('show', scrollY > 600), { passive: true }); })();

// preview helper: ?bg=bgK / bgE / bgW picks a background
(() => { const m = location.search.match(/bg=(bg[A-Z])/); if (m) document.body.classList.add(m[1]); })();

// big background eyes look at the mouse, each eye a bit differently (cross-eyed)
(() => { const ps = document.querySelectorAll('#bigEyes i');
  addEventListener('mousemove', e => { const dx = (e.clientX / innerWidth - .5), dy = (e.clientY / innerHeight - .5);
    ps[0].style.transform = `translate(${dx * 70 + 18}%,${dy * 70}%)`; ps[1].style.transform = `translate(${dx * 70 - 18}%,${dy * 50 + 10}%)`; }); })();

// ===== Drool Missions: live points server (/api/state, /api/join, /api/quest). Same account key as the old site. =====
(() => {
  const KEY = 'droolies_key', X = 'droolies_rh', $ = id => document.getElementById(id);
  const fmt = n => (+n).toLocaleString('en-US');
  const esc = v => String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let key = ''; try { key = localStorage.getItem(KEY) || ''; } catch (e) {}
  let S = null; const opened = new Set();
  const toast = t => { let el = document.querySelector('.toast'); if (!el) { el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = t; el.classList.add('show'); clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('show'), 2600); };
  async function api(path, body) {
    const r = await fetch('/api/' + path, { method: body ? 'POST' : 'GET', cache: 'no-store',
      headers: Object.assign({ 'content-type': 'application/json' }, key ? { 'x-key': key } : {}), body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => ({ error: 'Network error. Try again.' }));
    if (!r.ok) throw new Error(d.error || 'Something went wrong.');
    return d;
  }
  const PQ = [
    { k: 'like', name: '❤️ Like', pts: 50, url: id => 'https://x.com/intent/like?tweet_id=' + id },
    { k: 'rt', name: '🔁 RT', pts: 75, url: id => 'https://x.com/intent/retweet?tweet_id=' + id },
    { k: 'comment', name: '💬 Comment', pts: 75, url: id => 'https://x.com/intent/tweet?in_reply_to=' + id + '&text=' + encodeURIComponent('🤤🤤🤤') },
  ];
  function paint() {
    const me = S && S.me, done = (me && me.done) || {};
    $('myPts').textContent = fmt(me ? me.points : 0);
    if (me) {
      $('mWho').hidden = false;
      $('mWho').textContent = '@' + me.handle + ' · ' + me.wallet.slice(0, 6) + '…' + me.wallet.slice(-4);
      $('jBtn').textContent = 'Joined ✅'; $('jBtn').disabled = true; $('jH').hidden = $('jW').hidden = true;
    }
    document.querySelectorAll('.mis[data-m]').forEach(m => {
      const id = m.dataset.m, kind = m.dataset.kind, btn = m.querySelector('button');
      m.classList.remove('done', 'need');
      if (done[id]) { m.classList.add('done'); btn.textContent = kind === 'daily' ? 'Tomorrow' : 'Done ✅'; return; }
      if (kind === 'go' && opened.has(id)) { m.classList.add('need'); btn.textContent = 'Claim'; return; }
      btn.textContent = kind === 'go' ? 'Go' : 'Claim';
    });
    // post missions: like / RT / comment on the 3 latest posts
    const posts = ((S && S.posts) || []).slice(0, 3);
    if (posts.length) $('postMis').innerHTML = posts.map((p, n) => {
      const id = esc(p.id);
      return `<div class="mis"><i>📣</i><div><b>${n === 0 ? 'Latest post' : 'Older post'}</b><a class="open" href="https://x.com/${X}/status/${id}" target="_blank" rel="noopener">open on X ↗</a>
        <div class="pqs">${PQ.map(q => { const qid = q.k + ':' + p.id;
          if (done[qid]) return `<button class="btn sm" disabled style="background:var(--mint)">${q.name} ✅</button>`;
          if (opened.has(qid)) return `<button class="btn sm" data-claim="${esc(qid)}" style="background:var(--lime)">Claim +${q.pts}</button>`;
          return `<button class="btn sm" data-go="${esc(qid)}" data-url="${esc(q.url(p.id))}">${q.name} +${q.pts}</button>`; }).join('')}</div></div></div>`;
    }).join('');
    // live board
    if (S) {
      const rows = S.board.slice(0, 5);
      $('mBoard').innerHTML = rows.length ? rows.map((r, k) => {
        const mine = me && r.handle.toLowerCase() === me.handle.toLowerCase();
        return `<li class="${mine ? 'me' : ''}">${['🥇', '🥈', '🥉'][k] || (k + 1) + ' &nbsp;'} @${esc(r.handle)}${mine ? ' (you)' : ''}<b>${fmt(r.points)}</b></li>`;
      }).join('') : '<li>Nobody yet. Be the first drooler!</li>';
      $('mCount').textContent = fmt(S.droolers);
      $('mRank').textContent = !me ? '' : !me.rank ? 'Do a mission to get on the board 👇'
        : me.rank <= 1000 ? `You're #${fmt(me.rank)} 🎟️ Top 1,000 = WL. Stay there!` : `You're #${fmt(me.rank)}. Climb into the top 1,000 for a WL.`;
    }
  }
  async function load() {
    try { S = await api('state'); if (key && !S.me) { key = ''; try { localStorage.removeItem(KEY); } catch (e) {} } } catch (e) { return; }
    paint();
  }
  function needJoin() { $('jHandle').focus(); $('jMsg').textContent = '👆 Join the drool first, then do missions.'; toast('Join the drool first 👆'); }
  async function claim(id, btn) {
    if (btn) { btn.disabled = true; btn.textContent = '…'; }
    try { const d = await api('quest', { quest: id }); toast('+' + d.pts + ' Drool Points 🤤');
      const b = $('myPts'); b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop');
    } catch (e) { toast(e.message); }
    await load();
  }
  $('jBtn').onclick = async () => {
    if (S && S.me) return;
    const h = $('jHandle').value.trim().replace(/^@/, ''), w = $('jWallet').value.trim();
    $('jH').classList.remove('bad'); $('jW').classList.remove('bad');
    if (w.split(/\s+/).length >= 12) { $('jWallet').value = ''; $('jW').classList.add('bad'); $('jMsg').textContent = '🚨 That looks like a seed phrase! Never paste it anywhere.'; return; }
    if (!/^[A-Za-z0-9_]{1,15}$/.test(h)) { $('jH').classList.add('bad'); $('jMsg').textContent = 'Type your X handle.'; return; }
    if (!/^0x[0-9a-fA-F]{40}$/.test(w)) { $('jW').classList.add('bad'); $('jMsg').textContent = 'Paste your public 0x wallet.'; return; }
    $('jBtn').disabled = true; $('jBtn').textContent = '…';
    try { const d = await api('join', { handle: h, wallet: w }); key = d.key; try { localStorage.setItem(KEY, key); } catch (e) {}
      $('jMsg').textContent = ''; toast('Welcome to the drool, @' + h + ' 🤤'); await load();
    } catch (e) { $('jMsg').textContent = e.message; $('jBtn').disabled = false; $('jBtn').textContent = 'Join the drool 🤤'; }
  };
  document.querySelectorAll('.mis[data-m]').forEach(m => m.querySelector('button').onclick = () => {
    const id = m.dataset.m, kind = m.dataset.kind, btn = m.querySelector('button');
    if (!S || !S.me) return needJoin();
    if (S.me.done[id]) return toast(kind === 'daily' ? 'Come back tomorrow 📅' : 'Already done ✅');
    if (kind === 'go' && !opened.has(id)) { window.open(m.dataset.url, '_blank', 'noopener'); setTimeout(() => { opened.add(id); paint(); }, 1500); return; }
    claim(id, btn);
  });
  $('postMis').addEventListener('click', e => {
    const go = e.target.closest('[data-go]'), cl = e.target.closest('[data-claim]');
    if (!go && !cl) return;
    if (!S || !S.me) return needJoin();
    if (go) { window.open(go.dataset.url, '_blank', 'noopener'); const id = go.dataset.go; setTimeout(() => { opened.add(id); paint(); }, 1500); }
    else claim(cl.dataset.claim, cl);
  });
  paint(); load();
  setInterval(() => { if (!document.hidden) load(); }, 20000);
})();




// auction title: letters hop one after another, then the gavel hits
(() => { const h = document.getElementById('aWave'), t = h.textContent; h.textContent = '';
  [...t].forEach((c, i) => { const sp = document.createElement('span'); sp.textContent = c === ' ' ? ' ' : c; sp.style.animationDelay = (i * 0.06) + 's'; sp.className = i < 3 ? 'c0' : i < 9 ? 'c1' : 'c2'; h.appendChild(sp); }); })();

// placeholder shows example amounts so people see they can type anything
(() => { const el = document.getElementById('bidAmt'), ex = ['0.001', '0.05', '0.3', '1', '2.5', '10']; let i = 0;
  setInterval(() => { if (!el.value && document.activeElement !== el) { i = (i + 1) % ex.length; el.placeholder = ex[i]; } }, 1400); })();

// ===== THE DROOL AUCTION: live numbers + real bids (ETH on Robinhood Chain or Ethereum, sent to the auction wallet) =====
// Bid window: 1 wallet -> 2 chain -> 3 confirm. The server checks every tx on-chain (/api/dbid) before it counts.
(() => {
  const CHAINS = {
    rh:  { id: '0x1237', num: 4663, name: 'Robinhood Chain', exp: 'https://robinhoodchain.blockscout.com/tx/',
           add: { chainId: '0x1237', chainName: 'Robinhood Chain', nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: ['https://rpc.mainnet.chain.robinhood.com'], blockExplorerUrls: ['https://robinhoodchain.blockscout.com'] } },
    eth: { id: '0x1', num: 1, name: 'Ethereum', exp: 'https://etherscan.io/tx/' },
  };
  const BYNUM = { 4663: 'rh', 1: 'eth' };
  const PK = 'droolies_auction_pending', WK = 'droolies_auction_wallet';
  const $ = id => document.getElementById(id);
  const bm = $('bm'), wList = $('wList');
  const providers = new Map();          // EIP-6963: every wallet installed in the browser announces itself
  let prov = null, addr = '', chain = '', bal = null, A = null, skew = 0;
  try { addr = localStorage.getItem(WK) || ''; } catch (e) {}

  window.addEventListener('eip6963:announceProvider', e => { providers.set(e.detail.info.uuid, e.detail); });
  window.dispatchEvent(new Event('eip6963:requestProvider'));

  const short = a => a.slice(0, 6) + '…' + a.slice(-4);
  const eth = g => (g / 1e9).toLocaleString('en-US', { maximumFractionDigits: 6 });
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const toWei = v => { const m = /^(\d*)(?:\.(\d*))?$/.exec(String(v).trim()); if (!m || (!m[1] && !m[2])) return null;
    return BigInt(m[1] || '0') * 10n ** 18n + BigInt((m[2] || '').slice(0, 18).padEnd(18, '0')); };
  const step = n => {
    document.querySelectorAll('.bmPane').forEach(p => p.hidden = +p.dataset.p !== n);
    document.querySelectorAll('.bmSteps li').forEach(l => { const k = +l.dataset.s; l.className = k === n ? 'on' : k < n ? 'done' : ''; });
  };
  const msg = (t, c) => { const m = $('bmMsg'); m.textContent = t; m.style.color = c || 'var(--ink)'; };
  const stat = (el, t, cls) => { el.textContent = t; el.className = 'bstat' + (cls ? ' ' + cls : ''); };

  // ---------- live numbers, ticker, countdown ----------
  function phase() {
    if (!A || !A.cfg.start || !A.cfg.wallet) return 'soon';
    const n = Date.now() + skew;
    return n < A.cfg.start ? 'upcoming' : n < A.cfg.end ? 'live' : 'closed';
  }
  async function load() {
    try { const r = await fetch('/api/dbid' + (addr ? '?w=' + addr : ''), { cache: 'no-store' }); A = await r.json(); skew = A.now - Date.now(); } catch (e) { return; }
    setAuction({ bidders: A.count, top: A.top1 ? A.top1.g / 1e9 : 0, topWho: A.top1 ? short(A.top1.w) : '' });
    const items = A.recent.map(x => short(x.w) + ' BID ' + eth(x.g) + ' ETH ON ' + (x.c === 1 ? 'ETHEREUM' : 'ROBINHOOD'));
    if (items.length) items.push(A.cutoff != null ? '#' + A.cfg.top + ' CUTOFF: ' + eth(A.cutoff) + ' ETH' : (A.cfg.top - A.count) + ' SPOTS LEFT IN THE TOP ' + A.cfg.top);
    setTicker(items);
    $('aWallet').textContent = A.cfg.wallet || 'not set yet';
    status(); tick();
  }
  function status() {
    if (!A) return;
    const p = phase(), el = $('bidStat'), top = A.cfg.top;
    if (p === 'closed') return stat(el, A.me ? (A.me.r <= top ? `SOLD! You finished #${A.me.r}: a Droolie is coming to your wallet 🤤` : `SOLD! You finished #${A.me.r}. Your ETH comes back to your wallet 💸`) : 'SOLD! The Drool Auction is over 🔨', A.me && A.me.r <= top ? 'ok' : '');
    if (A.me) return stat(el, A.me.r <= top ? `You're #${A.me.r} with ${eth(A.me.g)} ETH 🤤 In the top ${top}!` : `You're #${A.me.r} with ${eth(A.me.g)} ETH. Top up to get into the top ${top}.`, A.me.r <= top ? 'ok' : 'bad');
    if (A.cutoff != null) return stat(el, `Right now you need more than ${eth(A.cutoff)} ETH to be in the top ${top}.`);
    if (p === 'live') return stat(el, `${A.count} wallet${A.count === 1 ? '' : 's'} so far. Any bid gets you in the top ${top} right now 👀`);
    stat(el, '');
  }
  function tick() {
    const p = phase(), lbl = $('cdLbl'), now = Date.now() + skew;
    let ms = -1;
    if (p === 'upcoming') { lbl.textContent = 'STARTS IN'; ms = A.cfg.start - now; }
    else if (p === 'live') { lbl.textContent = 'ENDS IN'; ms = A.cfg.end - now; }
    else lbl.textContent = p === 'closed' ? 'SOLD! 🔨' : 'OPENING SOON';
    const hb = document.querySelector('.hb2Live'); if (hb) hb.lastChild.textContent = p === 'live' ? 'LIVE NOW' : p === 'closed' ? 'SOLD' : 'LIVE SOON';
    const s = Math.max(0, Math.floor(ms / 1000));
    const t = ms < 0 ? '' : [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60].map(x => String(x).padStart(2, '0')).join(':');
    document.querySelectorAll('[data-cd]').forEach(e => e.textContent = t);
  }

  // ---------- tell the server about a tx (it checks it on-chain) ----------
  const pend = () => { try { return JSON.parse(localStorage.getItem(PK) || '[]'); } catch (e) { return []; } };
  const setPend = l => { try { localStorage.setItem(PK, JSON.stringify(l)); } catch (e) {} };
  async function submit(tx, num) {
    for (let i = 0; i < 40; i++) {
      try {
        const r = await fetch('/api/dbid', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ tx, chain: num }) });
        const d = await r.json().catch(() => ({}));
        if (r.ok && d.ok) { setPend(pend().filter(x => x.tx !== tx)); return { ok: true, d }; }
        if (![202, 404, 500].includes(r.status)) { setPend(pend().filter(x => x.tx !== tx)); return { ok: false, err: d.error || 'Something went wrong.' }; }
      } catch (e) {}
      await sleep(3000);
    }
    return { ok: false, wait: true };
  }

  // ---------- bid window ----------
  function listWallets() {
    wList.innerHTML = '';
    const HIDE = /magic\s*eden/i;            // wallets we don't show
    const list = [...providers.values()].filter(w => !HIDE.test(w.info.name + ' ' + (w.info.rdns || '')));
    if (!list.length && window.ethereum) list.push({ info: { name: 'Browser wallet', icon: '' }, provider: window.ethereum });
    $('wNone').hidden = list.length > 0;
    list.forEach(w => {
      const b = document.createElement('button'); b.className = 'wBtn';
      b.innerHTML = (w.info.icon ? `<img src="${w.info.icon}" alt="">` : '<span style="font-size:28px">🦊</span>') + `<span></span>`;
      b.lastChild.textContent = w.info.name;
      b.onclick = () => connect(w.provider);
      wList.appendChild(b);
    });
  }
  async function connect(p) {
    try {
      const acc = await p.request({ method: 'eth_requestAccounts' });
      prov = p; addr = acc[0].toLowerCase(); try { localStorage.setItem(WK, addr); } catch (e) {}
      $('bmAddr').textContent = short(addr); step(2); load();
      if (p.on) p.on('accountsChanged', a => { addr = (a[0] || '').toLowerCase(); bm.hidden = true; load(); });
    } catch (e) { $('wNone').hidden = false; $('wNone').textContent = 'Connection cancelled.'; }
  }
  async function pickChain(k) {
    const c = CHAINS[k];
    try { await prov.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: c.id }] }); }
    catch (e) {
      if (e && e.code === 4902 && c.add) { try { await prov.request({ method: 'wallet_addEthereumChain', params: [c.add] }); } catch (e2) { return; } }
      else return;
    }
    chain = k;
    $('sAmt').textContent = $('bidAmt').value; $('sChain').textContent = 'ETH on ' + c.name; $('sAddr').textContent = short(addr);
    step(3); msg(''); bal = null; $('bmConfirm').disabled = false;
    try {
      bal = BigInt(await prov.request({ method: 'eth_getBalance', params: [addr, 'latest'] }));
      $('sBal').textContent = (Number(bal / 10n ** 12n) / 1e6).toLocaleString('en-US', { maximumFractionDigits: 6 }) + ' ETH';
    } catch (e) { $('sBal').textContent = '–'; }
  }

  $('bidGo').onclick = () => {
    const v = $('bidAmt').value;
    if (!v || !(+v > 0)) { $('bidAmt').focus(); $('bidHint').textContent = 'Type how much ETH you want to bid first 👆'; $('bidHint').style.color = 'var(--red)'; return; }
    $('bidHint').style.color = '';
    bm.hidden = false; step(prov ? 2 : 1); window.dispatchEvent(new Event('eip6963:requestProvider')); wList.innerHTML = '<p class="bmSmall">Looking for your wallets…</p>'; setTimeout(listWallets, 350);
  };
  $('bmX').onclick = () => bm.hidden = true;
  bm.addEventListener('click', e => { if (e.target === bm) bm.hidden = true; });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') bm.hidden = true; });
  document.querySelectorAll('.chain').forEach(b => b.onclick = () => pickChain(b.dataset.chain));

  $('bmConfirm').onclick = async () => {
    const p = phase(), btn = $('bmConfirm');
    if (p !== 'live') return msg(p === 'closed' ? 'The auction is over 🔨' : 'The auction is not open yet. Turn on notifications on @droolies_rh 🔔', 'var(--red)');
    const wei = toWei($('bidAmt').value), c = CHAINS[chain];
    if (!wei || wei < 10n ** 9n) return msg('That amount is too small.', 'var(--red)');
    if (bal != null && wei > bal) return msg('Not enough ETH on ' + c.name + ' (keep a little for gas).', 'var(--red)');
    btn.disabled = true;
    try {
      const cur = String(await prov.request({ method: 'eth_chainId' })).toLowerCase();
      if (cur !== c.id) { msg('Your wallet switched chains. Pick the chain again.', 'var(--red)'); step(2); btn.disabled = false; return; }
      msg('Confirm the bid in your wallet… 🤤');
      const tx = await prov.request({ method: 'eth_sendTransaction', params: [{ from: addr, to: A.cfg.wallet, value: '0x' + wei.toString(16) }] });
      setPend(pend().concat([{ tx, c: c.num }]));
      msg('Sent! Waiting for ' + c.name + ' to confirm… ⏳');
      const r = await submit(tx, c.num);
      if (r.ok) { msg('Bid counted! 🔨 ' + $('bidAmt').value + ' ETH on ' + c.name, 'var(--grn2)'); $('bidAmt').value = ''; $('bidHint').textContent = ''; load(); }
      else if (r.wait) msg('Still confirming. Your bid will show up soon (keep this page open). tx: ' + short(tx));
      else msg(r.err, 'var(--red)');
    } catch (e) {
      msg(e && e.code === 4001 ? 'Cancelled in your wallet.' : 'Wallet error: ' + ((e && e.message) || 'try again'), 'var(--red)');
    }
    btn.disabled = false;
  };

  // ---------- sent from another app: paste the tx hash ----------
  $('aCopy').onclick = async () => { if (!A || !A.cfg.wallet) return; try { await navigator.clipboard.writeText(A.cfg.wallet); $('aCopy').textContent = 'Copied ✅'; setTimeout(() => $('aCopy').textContent = 'Copy', 1500); } catch (e) {} };
  $('txBtn').onclick = async () => {
    const tx = $('txIn').value.trim().toLowerCase(), num = +$('txChain').value, el = $('txMsg');
    if (!/^0x[0-9a-f]{64}$/.test(tx)) return stat(el, 'Paste the transaction hash (0x + 64 characters).', 'bad');
    $('txBtn').disabled = true; stat(el, 'Checking on ' + CHAINS[BYNUM[num]].name + '… ⏳');
    const r = await submit(tx, num);
    if (r.ok) { stat(el, 'Counted! ' + eth(r.d.gwei) + ' ETH from ' + short(r.d.wallet) + ' 🔨', 'ok'); addr = r.d.wallet; try { localStorage.setItem(WK, addr); } catch (e) {} load(); }
    else stat(el, r.wait ? 'Not confirmed yet. Try again in a minute.' : r.err, 'bad');
    $('txBtn').disabled = false;
  };

  // retry bids that were sent but not counted yet (page closed too early)
  load().then(() => pend().forEach(x => submit(x.tx, x.c).then(r => r.ok && load())));
  setInterval(tick, 1000);
  setInterval(() => { if (!document.hidden) load(); }, 10000);
})();


// TV anchor: a new Droolie every 3 seconds, with a channel-switch effect
(() => {
  const box = document.querySelector('.ancBox'), img = document.getElementById('ancImg'), no = document.getElementById('ancNo');
  const ids = [...Array(24)].map((_, i) => i + 1); let last = 7;
  ids.forEach(i => { const im = new Image(); im.src = 'assets/gif/' + i + '.webp'; });
  setInterval(() => {
    let n; do { n = ids[Math.floor(Math.random() * ids.length)]; } while (n === last); last = n;
    box.classList.remove('zap'); void box.offsetWidth; box.classList.add('zap');
    setTimeout(() => { img.src = 'assets/gif/' + n + '.webp'; no.textContent = '#' + n; }, 120);
  }, 3000);
})();

// bid box: only numbers, one dot
const bidIn=document.getElementById('bidAmt'),bidHint=document.getElementById('bidHint');
bidIn.addEventListener('input',()=>{let v=bidIn.value.replace(',','.').replace(/[^0-9.]/g,'');const i=v.indexOf('.');if(i>-1)v=v.slice(0,i+1)+v.slice(i+1).replace(/\./g,'');bidIn.value=v;
 bidHint.textContent=v&&+v>0?'You will bid '+v+' ETH.':''});
// drool scanner (reads whitelist.js, same list as the live site)
const WL = (window.WHITELIST || []).map(a => a.toLowerCase());
const scImg = document.getElementById('scFace'), tag = document.getElementById('scTag'), out = document.getElementById('wOut'), fld = document.getElementById('field'), scanEl = document.querySelector('.scan');
document.getElementById('wBtn').onclick = () => {
  let v = document.getElementById('wIn').value.trim().toLowerCase();
  if (v && !v.startsWith('0x')) v = '0x' + v;
  out.className = 'ticket'; fld.classList.remove('bad'); document.getElementById('scStamp').className = 'scStamp';
  if (!/^0x[0-9a-f]{40}$/.test(v)) { fld.classList.add('bad'); tag.textContent = "THAT'S NOT A WALLET 🤔"; return; }
  scanEl.classList.add('scanning'); tag.textContent = 'SCANNING… 👀👀';
  setTimeout(() => {
    scanEl.classList.remove('scanning');
    let st, t1, t2, img;
    if (!WL.length) { st = 'wait'; img = 2; t1 = 'LIST NOT OUT YET'; t2 = 'Keep doing missions. Stay drool 💧'; }
    else if (WL.includes(v)) { st = 'yes'; img = 5; t1 = "YOU'RE IN! 🤤"; t2 = 'Certified drooler. See you at the mint.'; }
    else { st = 'no'; img = 1; t1 = 'NOT ON THE LIST 😭'; t2 = 'Climb the Drool Missions board and try again.'; }
    const sp = document.getElementById('scStamp'); sp.className = 'scStamp show ' + st; sp.textContent = st === 'yes' ? 'IN ✅' : st === 'no' ? 'NOT YET' : 'SOON'; tag.textContent = t1;
    out.innerHTML = `<b>${t1}</b><span>${t2}</span><small>${v.slice(0, 6)}…${v.slice(-4)}</small>`;
    out.className = 'ticket show ' + st;
  }, 1600);
};
document.getElementById('wIn').addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('wBtn').click(); });
const ids=[...Array(24)].map((_,i)=>i+1);
const face=i=>`<img src="assets/gif/${i}.webp" alt="Droolie #${i}" loading="lazy">`;
document.getElementById('faces').innerHTML=[...ids,...ids].map(face).join('');
document.getElementById('coll').innerHTML=ids.slice(0,12).map(face).join('');
const NET=[['p_BoredApeYC.jpg','Bored Ape Yacht Club','BoredApeYC'],['p_TheSuitedApes.png','Suited Apes','TheSuitedApes'],['p_quirkiesnft.jpg','Quirkies','quirkiesnft'],['p_ClutchMarkets.jpg','StonkBrokers','ClutchMarkets'],['p_badbunnz_.jpg','Bad Bunnz','badbunnz_'],['p_artasmonkey.png','Monkey Yacht Club','artasmonkey']];
const chipH=([img,n,h])=>`<a class="nchip" href="https://x.com/${h}" target="_blank" rel="noopener">${img==='RH'?'<span class="rh">⛓️</span>':`<img src="assets/img/${img}" alt=""${img.includes('SuitedApes')?' style="background:#000"':''}>`}<span>${n}</span></a>`;
const one=NET.map(chipH).join('');
const tr=document.getElementById('netTrack');tr.innerHTML=one+one+one+one;
document.getElementById('netBtn').onclick=e=>{const p=tr.classList.toggle('paused');e.target.textContent=p?'PLAY':'PAUSE'};
// background: falling drool drops + cross-eyed peepers
const fx=document.createElement('div');fx.className='fx';document.body.prepend(fx);
let h='';
for(let i=0;i<9;i++){const s=.6+Math.random()*.9;h+=`<div class="drop" style="left:${Math.random()*100}%;animation-duration:${7+Math.random()*9}s;animation-delay:-${Math.random()*16}s;transform:scale(${s})"></div>`}
for(let i=0;i<5;i++){h+=`<div class="blob" style="left:${Math.random()*90}%;top:${Math.random()*90}%;animation-delay:-${Math.random()*30}s;animation-duration:${24+Math.random()*16}s"></div>`}
fx.innerHTML=h;
