# Droolies (@droolies_rh): research brief

**Identity.** DROOLIES: "10,000 hand-drawn, cross-eyed faces on Robinhood Chain." Every Droolie is "cross-eyed, drooling and very smart (2+3=6)". The X bio reads: "too many chains. too many mints. our brains stopped braining. 🧠 10,000 Droolies coming to our mother @RobinhoodApp."

**World and tone.** Lovably dumb, self-aware and meme-literate, with a joke on every line. From the site: "No roadmap to the moon. No 47-page whitepaper. Just this." "Built with one eye on the code." "Our Droolie will squint at it with both eyes (separately)." "Keep one eye on @droolies_rh. The other one… wherever it wants 👀". The sign-off is always "STAY DROOL 🤤💧". Posts are heavy on caps, 🤤 👀 💧 🔨, and "WE SEE YOU". The visual world is cream paper, taped polaroids, chalkboard doodles ("2+3=6", "??", "wen moon?") and blue drool drops. The project also runs a "DROOL NEWS" TV with a Droolie anchor.

**Five core motifs.** (1) Cross-eyed, where each eye goes its own way. (2) Drool: a blue rope with a droplet, the 💧, "STAY DROOL". (3) "Very smart" wrong math: 2+3=6, 1+1=11, "I'm smart", "???", "where am i?", "wen moon?". (4) Eyes Pop Out, the rarest trait (100 of 10,000, 1%). (5) The Drool Family of partner communities, plus Drool Missions and Drool Points with a "Top droolers" board.

**Traits (site).** 3 expressions (Derpy, Happy, Crying), 20 drooly mouths, and 100 with Eyes Pop Out. Everything is hand-drawn.

**Mint status (Nov 14 2026, from official sources).** FREE MINT on OpenSea on Robinhood Chain, date TBA. There are 4 phases: The Inner Circle, First to Drool, The Drooling Families, and The Drool Apocalypse. **The Drool Auction is live** (500 Droolies, any ETH bid, top 500 win, others refunded, ends Nov 17 07:00 UTC), and the #500 bid sets the Phase 03 price. Drool Missions: the top 1,000 on the points board get WL, snapshots come without warning, and "Points are not a token". Free claims go to holders of BAYC, Suited Apes, Quirkies, StonkBrokers, Bad Bunnz and Monkey Yacht Club. **The game must not reference auction prices or promise WL or allocation.** Its leaderboard is a labelled sample.

**Team.** CM: @jayjaynft4 (named in the official Nov 10 post). Founders: unknown. Joined X November 2026; 73 posts; 2.4K followers per a community screenshot.

**Things the community loves.** The wrong-math jokes, free claims for their communities, "STAY DROOL", the Drool News format, and leaderboard climbing (the auction and missions are both leaderboard-driven).

**Avoid.** Financial or auction claims, a ranking that implies WL, mocking real partner projects, generic runners and fighters, off-model faces, glossy 3D, and pixel art. The hand-drawn line is the brand.

**Existing games.** None found. The site has interactive Missions, an auction "TV" and a "Drool Scanner" wallet checker, but no game. The absence of a game in search results is not proof that none exists.

**Coverage limits.** The logged-out profile showed 5 recent posts plus the pinned post. The media and replies tabs require login, so the requested 100-post audit was not possible. Direct image downloads from droolies.lol were refused by this session's permission policy, so the art comes from official X media (profile picture, banner, post images and GIFs) and the official droolies.lol link-preview card served by X.

**Sources opened:**
- https://droolies.lol/ (full page text saved in research/droolies-lol.txt)
- https://x.com/droolies_rh
- https://x.com/droolies_rh/status/2121607011603210479 (Drool Auction live, Nov 14)
- https://x.com/droolies_rh/status/2121256279377125486 (auctions coming, Bad Bunnz and MYC claims, Nov 13)
- https://x.com/droolies_rh/status/2120655788611878917 (StonkBrokers in, Nov 11)
- https://x.com/droolies_rh/status/2120251474429038854 (Stonkbrokers poll, Nov 10)
- https://x.com/droolies_rh/status/2119951386087444661 (Quirkies claim; CM @jayjaynft4, Nov 10)
- Community posts used only for re-shared official images: https://x.com/StormFrens/status/2120815391668645895, https://x.com/wale_gmi/status/2121329051822612584, https://x.com/0xDamah/status/2118856184786489841, https://x.com/KingsEcheeh/status/2120119850672767080, https://x.com/jayjaynft4/status/2118597072203260128
