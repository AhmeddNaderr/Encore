# Review notes

## Loop 1: independent cold review (fresh agent, v1 cut)
Scores: art 7, originality 7, hook 6, clarity 5, motion 7, polish 6, text 5, lore 7, pitch 7, founder 6. The reviewer's top problems:
1. Popups hid the teaching beats.
2. Captions covered gameplay.
3. A "WL LEADERBOARD" label contradicted the "no WL" disclaimer; rank and name offsets didn't line up.
4. Sight-line dots replaced the hero's inward pupils; Eyes Pop Out didn't follow the official trait; "1% RARE" appeared on a mode that repeats.
5. The hook had a heavy lime wash and clutter.

It also flagged: SPLAT read too briefly with no "run over" beat, cryptic HUD labels, square avatar corners, a clipped "not posted" line, badge padding, text collisions on the result card and the end cards, and a soft upscaled news anchor.

## Loop 2: fixes (v2, the delivered cut)
- **Pupils:** sight-lines now start at the edge of the eye, and the official black inward pupils stay visible.
- **Eyes Pop Out:** rebuilt to match the official trait: eyeballs rise on springs above the head, with dark sockets left in the face, and the beams leave from the eyeballs. Label changed to "RAREST TRAIT · x2".
- **Flash:** the full-frame lime wash became a short radial burst at the hero.
- **Readable sums:** a solved bubble holds for 0.16 s with a lime outline and a ✓ before it puffs. Popups float well above bubbles. Every smart pop reads "VERY SMART!".
- **Captions:** moved to the desk band, except on the drool shots, where the caption sits at the top so it never covers the drool.
- **SPLAT:** the shot now holds about 1 s and adds a "RUN OVER" plate.
- **Wording:** HUD reads "6 IN A ROW = EYES POP" and "time". The board is titled "SAMPLE WL LEADERBOARD (CONCEPT)" with the disclaimer "not connected to any real WL or mint". Handles are now drooler_a…j, so no rank/name mismatch. Avatars are round.
- **Layout:** fixed the X-post footer, badge padding, result-card spacing, doodle positions and the anchor size.
- **Branding:** a "DROOLIES · VERY SMART" tag shows from frame 0 of the hook.

The fixes were checked on rendered stills and on decoded frames from the final MP4s.

## Not fixed (kept as known limits)
- **Aim easing:** the autoplay aim has no ease-in. Changing the driver would change every take's outcome and timings.
- **HUD jumps:** score and timer jump across montage cuts between moments of different takes.
- **Socket edges:** a sliver of the original eye-white remains visible around the Eyes Pop Out sockets.
