# VERY SMART: storyboard and edit

Every gameplay shot is a deterministic capture of the playable slice (`prototype/engine.js` + `view.js`). The skilled autoplay driver calls the same `tap()` that pointer and Space input call. It does not inject points. Four takes are used, defined in `prototype/edit.json`:

- **A**: landscape seed 34. Final score 67,800, 46 pops, 4 Eyes Pop Out, one scripted "too normal" mistake.
- **F**: landscape seed 13. A genuine drool SPLAT failure at 16.6 s.
- **P**: portrait seed 21. Final score 44,400.
- **PF**: portrait seed 34. Genuine SPLAT at 13.0 s.

Text overlays are motion graphics added in the edit. No AI video, no AI images.

## Main cut: 42 s, 1920×1080, 60 fps

| Time | Source | On screen / motion | Text | Sound |
|---|---|---|---|---|
| 0.0–3.0 | Take A 44.55–47.55 | Mid-game, x6 combo. **EYES POP OUT** at 0.42: eyeballs spring out, both sight-lines lock, 4 smart bubbles pop in 0.9 s. Slow push-in from 1.00 to 1.07. No logo. | In-game banner "EYES POP OUT! 1% RARE · x2" | Boing, pops and chimes on the beat, full groove |
| 3.0–5.6 | A 2.90–5.50 | Fresh round. Lime "your eye" line aims; dashed "the other one" wanders; the ✕ slides along and the tap pops a wrong-maths bubble. | **"Tap where your eyes cross."** plus in-world labels | Chalk scribble, tap, perfect chime |
| 5.6–8.3 | A 6.20–8.90 | A smart pop, then a real **TOO NORMAL** hit on a correct sum: red ✕ stamp, face flush, drool drips longer. | **"Only wrong maths is smart."** | Pop, honk |
| 8.3–10.4 | A 12.30–14.40 | Golden "wen moon?" bubble popped (bonus), then another smart pop; the drool slurps up. | — | Coin arpeggio, pop |
| 10.4–12.6 | Take F 15.40–17.60 | Drool rope hangs to the desk; DROOL ALERT blinks; **SPLAT** at 11.57 (held 1 s). | **"Keep your drool off the desk."** | Splat and drips |
| 12.6–14.5 | A 14.00–15.90 | Recovery rhythm, combo building. | — | Pops |
| 14.5–17.4 | A 17.30–20.20 | Six in a row, then **EYES POP OUT** at 14.83: a burst of pops plus a gold bubble. Push-in. | In-game banner | Boing, pops |
| 17.4–19.4 | A 23.60–25.60 | Faster wander, denser board. | — | Pops |
| 19.4–22.0 | A 28.90–31.50 | Third Eyes Pop Out at 19.87. | In-game banner | Boing, pops |
| 22.0–25.0 | A 53.00–56.00 | Late-game difficulty, fourth Eyes Pop Out at 23.89, gold bubble. Push-in. | — | Groove peak |
| 25.0–29.0 | Motion graphics | Chalk wipe to **TOP DROOLERS**. holder_you climbs from #10 to #3 with Take A's real score (67,800); the other rows are labelled sample. | "Bots can like a post. **They can't do 2+3=6.**" | Rank ticks, breakdown |
| 29.0–32.0 | Motion graphics | Result card: polaroid of the official profile-picture Droolie, 67,800 Drool Points, 46 pops, 40 perfects, a 38-long streak, 4 eye pops, the "CERTIFIED IQ 2+3=6" stamp and a Share on X button. | — | Card slide, stamp |
| 32.0–35.0 | Motion graphics | The result card inside an **X post mock-up** ("not posted"). | Post copy ends "STAY DROOL #VERYSMART" | Notification |
| 35.0–37.2 | Motion graphics | **BREAKING DROOL NEWS**, an homage to their TV format, with the official blonde anchor portrait. "HOLDER_YOU IS VERY SMART!" | Ticker: "2+3=6 CONFIRMED" | News stabs |
| 37.2–39.4 | Motion graphics | Official DROOLIES wordmark and tagline (from the banner), "VERY SMART", five banner polaroids bounce in. | "a game concept by Encore Studio" | Logo motif |
| 39.4–42.0 | Motion graphics | Encore end card matching the supplied reference: logo, concept line, tagline, CTA, disclaimer, CONCEPT · UNOFFICIAL badge. | Encore copy | Final F chord, fade |

## 15 s X cut: 1080×1920, 60 fps, readable with sound off

| Time | Source | Content |
|---|---|---|
| 0.0–2.0 | Take P 51.45–53.45 | Eyes Pop Out burst, mid-game (hook). |
| 2.0–4.6 | P 1.00–3.60 | Aim, cross, pop. "Tap where your eyes cross." plus labels. |
| 4.6–6.6 | P 5.00–7.00 | Smart pop, then a real TOO NORMAL hit. "Only wrong maths is smart." |
| 6.6–8.1 | Take PF 12.30–13.80 | Drool hits the desk: SPLAT. "Keep your drool off the desk." |
| 8.1–9.2 | P 18.00–19.10 | Eyes Pop Out again (escalation). |
| 9.2–12.0 | Motion graphics | TOP DROOLERS sample board, climbing to #3 with the real score 44,400. "Bots can like a post. They can't do 2+3=6." |
| 12.0–13.4 | Motion graphics | Result card. |
| 13.4–15.0 | Motion graphics | DROOLIES / VERY SMART / Concept by Encore Studio, polaroids, compact Encore card and disclaimer. |

## Phase 6: AI inserts
None. There is no image-to-video tool in this environment, and the brief ranks art fidelity first. All character pixels come from official Droolies media.
