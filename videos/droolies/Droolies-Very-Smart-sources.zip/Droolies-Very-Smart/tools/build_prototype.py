"""Inline the prototype's JS modules into one playable prototype/index.html (assets stay in prototype/assets/)."""
import os, re
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'prototype')
src = open(os.path.join(P, 'src.html')).read()
mods = ['engine.js', 'view.js', 'screens.js', 'assets.js', 'app.js']
inline = '\n'.join(f'<script>/* {m} */\n' + open(os.path.join(P, m)).read() + '\n</script>' for m in mods)
out = re.sub(r'<!--SCRIPTS-->.*<!--/SCRIPTS-->', lambda _: inline, src, flags=re.S)
open(os.path.join(P, 'index.html'), 'w').write(out)
print('index.html', len(out), 'bytes')
