// Browser smoke checks for the playable prototype (needs: python -m http.server 8765 in prototype/)
const { chromium } = require('playwright');
(async () => {
  let pass = 0, fail = 0; const ok = (c, m) => { c ? pass++ : fail++; console.log(c ? 'PASS' : 'FAIL', m); };
  const b = await chromium.launch();
  for (const [vw, vh, kind] of [[1920, 1080, 'landscape'], [1080, 1920, 'portrait']]) {
    const ctx = await b.newContext({ viewport: { width: vw, height: vh }, permissions: ['clipboard-read', 'clipboard-write'] });
    const p = await ctx.newPage(); const errs = []; const reqs = [];
    p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
    p.on('request', r => { if (!r.url().startsWith('http://localhost:8765/')) reqs.push(r.url()); });
    await p.goto('http://localhost:8765/index.html');
    await p.waitForFunction(() => window.__ready || window.__error, null, { timeout: 20000 });
    ok(!(await p.evaluate(() => window.__error)), `${kind}: assets load`);
    ok(await p.evaluate(() => document.fonts.check("40px 'Permanent Marker'") && document.fonts.check("40px 'Patrick Hand'")), `${kind}: brand fonts loaded`);
    const dims = await p.evaluate(() => [document.getElementById('c').width, document.getElementById('c').height]);
    ok(kind === 'landscape' ? dims[0] === 1920 && dims[1] === 1080 : dims[0] === 1080 && dims[1] === 1920, `${kind}: canvas ${dims.join('x')}`);
    await p.waitForTimeout(400); await p.keyboard.press('Space'); await p.waitForTimeout(1500);
    // real pointer aim across the board, then real clicks
    const box = await (await p.$('#c')).boundingBox();
    for (let i = 0; i < 12; i++) { await p.mouse.move(box.x + box.width * (0.25 + i * 0.04), box.y + box.height * 0.3); await p.waitForTimeout(60); }
    for (let i = 0; i < 6; i++) { await p.mouse.click(box.x + box.width * 0.5, box.y + box.height * 0.3); await p.waitForTimeout(150); }
    await p.screenshot({ path: `shots/check-${kind}-play.png` });
    const px = await p.evaluate(() => { const g = document.getElementById('c').getContext('2d'); const d = g.getImageData(0, 0, 200, 200).data; let s = 0; for (let i = 0; i < d.length; i += 4) s += d[i] + d[i + 1] + d[i + 2]; return s; });
    ok(px > 0, `${kind}: gameplay renders`);
    await p.waitForTimeout(62000); // let the round end (bell or splat)
    await p.screenshot({ path: `shots/check-${kind}-result.png` });
    // Share on X: copy only, no navigation
    const url0 = p.url();
    const P = kind === 'portrait'; const cx = box.x + box.width / 2, cy = box.y + box.height * ((P ? 860 : 550) / (P ? 1920 : 1080)), s = box.width / (P ? 1080 : 1920) * (P ? 1.15 : 1.0);
    await p.mouse.click(cx - 200 * s, cy + (450 - 94) * s); await p.waitForTimeout(400);
    const clip = await p.evaluate(() => navigator.clipboard.readText().catch(() => ''));
    ok(/Drool Points in VERY SMART/.test(clip) && p.url() === url0, `${kind}: Share on X copies text, no outbound navigation`);
    await p.mouse.click(cx, cy - 200 * s); await p.waitForTimeout(1800);
    await p.screenshot({ path: `shots/check-${kind}-board.png` });
    ok(true, `${kind}: leaderboard opened (screenshot)`);
    ok(errs.length === 0, `${kind}: no JS/asset errors ${errs.slice(0, 2).join(' | ')}`);
    ok(reqs.length === 0, `${kind}: no external requests ${reqs.slice(0, 2).join(' ')}`);
    await ctx.close();
  }
  console.log(`\n${pass} passed, ${fail} failed`); await b.close(); process.exit(fail ? 1 : 0);
})();
