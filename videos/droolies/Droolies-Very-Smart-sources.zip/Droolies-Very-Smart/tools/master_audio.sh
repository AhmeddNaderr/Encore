#!/bin/bash
# Master mix-*-pre.wav to -16 LUFS / -1.5 dBTP (two-pass linear loudnorm after a limiter)
cd "$(dirname "$0")/../audio"
for m in main short; do
  J=$(ffmpeg -hide_banner -i mix-$m-pre.wav -af "alimiter=level_in=2.2:limit=0.89:attack=3:release=60:level=false,loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json" -f null - 2>&1 | sed -n '/^{/,/^}/p')
  set -- $(echo "$J" | python3 -c "import json,sys;d=json.load(sys.stdin);print(d['input_i'],d['input_tp'],d['input_lra'],d['input_thresh'],d['target_offset'])")
  ffmpeg -hide_banner -y -v error -i mix-$m-pre.wav -af "alimiter=level_in=2.2:limit=0.89:attack=3:release=60:level=false,loudnorm=I=-16:TP=-1.5:LRA=11:measured_I=$1:measured_TP=$2:measured_LRA=$3:measured_thresh=$4:offset=$5:linear=true,aresample=48000" -c:a pcm_s24le droolies-$m-mix.wav
done
