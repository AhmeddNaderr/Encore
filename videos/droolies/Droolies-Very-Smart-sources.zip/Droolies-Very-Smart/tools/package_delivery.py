"""Build the sources ZIP (everything except the two final MP4s, raw captures and scratch renders) + manifest."""
import os, zipfile, hashlib, json
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
OUT = os.path.join(ROOT, 'delivery', 'Droolies-Very-Smart-sources.zip')
INCLUDE = ['README.md', 'research_brief.md', 'art_bible.md', 'concepts.md', 'storyboard.md', 'quality_report.md', 'review_notes.md', 'progress.md',
           'DM-description.txt', 'AUDIO-SOURCES.md', 'art', 'prototype', 'audio', 'research', 'tools', 'video/final-validation.json', 'video/frames-jpg', 'video/review-main-sheet.jpg', 'video/review-short-sheet.jpg', 'capture.cjs']
SKIP_DIRS = {'debug', 'node_modules', '__pycache__'}
SKIP_FILES = {'mix-main-pre.wav', 'mix-short-pre.wav', 'probe.html'}
def files():
    for inc in INCLUDE:
        p = os.path.join(ROOT, inc)
        if os.path.isfile(p): yield p
        elif os.path.isdir(p):
            for d, ds, fs in os.walk(p):
                ds[:] = [x for x in ds if x not in SKIP_DIRS]
                for f in sorted(fs):
                    if f in SKIP_FILES or f.endswith('.mp4') and 'raw' not in d: continue
                    yield os.path.join(d, f)
os.makedirs(os.path.dirname(OUT), exist_ok=True)
man = []
with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in files():
        rel = os.path.relpath(f, ROOT); data = open(f, 'rb').read()
        man.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        z.writestr('Droolies-Very-Smart/' + rel, data)
    z.writestr('Droolies-Very-Smart/DELIVERY-MANIFEST.json', json.dumps({'files': man, 'excluded': ['video/droolies_concept_main.mp4 (separate download)', 'video/droolies_concept_15s.mp4 (separate download)', 'audio/mix-*-pre.wav (pre-master)', 'art/debug (scratch)']}, indent=1))
print(OUT, os.path.getsize(OUT), len(man), 'files')
