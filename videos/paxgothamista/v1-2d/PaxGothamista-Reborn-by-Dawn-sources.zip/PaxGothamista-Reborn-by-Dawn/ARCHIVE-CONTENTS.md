# Source package contents
- `build/` — game engine (`engine.js`), renderer (`render.js`), screens, edit lists (`film.js`, `compose.js`), frame renderer (`render_cli.js`, `render_all.sh`), final encode (`finalize.sh`), tombstone mask tool (`make_masks.py`), prepared assets and fonts (OFL). Install with `npm install @napi-rs/canvas`, then `./render_all.sh main 2700`.
- `audio/` — score generator (`compose_score.py`), SFX + mix (`mix_audio.py`), MIDI, event timeline, AAC masters. The GeneralUser GS SoundFont is not included (32 MB); get it from https://www.schristiancollins.com/generaluser to re-render the score.
- `art/raw/` — official Pax Gothamista art as downloaded (site + X), `side_by_side.jpg` fidelity check, `poster.jpg`.
- `research/` — saved X post JSON and site scripts; docs: research brief, concepts, art bible, storyboard, quality report, DM copy.
