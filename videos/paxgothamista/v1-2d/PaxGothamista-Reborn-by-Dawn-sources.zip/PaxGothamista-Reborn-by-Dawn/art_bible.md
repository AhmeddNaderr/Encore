# Art bible — Pax Gothamista / Reborn by Dawn

**Rule:** every character, logo and environment pixel is official Pax Gothamista art. New pixels are limited to effects (soul glow, particles, bats, fog), UI and type.

## Canonical references (art/raw/site, art/raw/x)
- Cast (full-body PNGs from paxgothamista.xyz): Morticia Belladonna `girl_1`, Falon St Clair `girl_2`, Vera Locks `girl_3`, Odette Noir `girl_4`, Rowena Inkgrave `girl_5`, Mort the Intern `girl_6`.
- Portrait cameos: `nft_01` Morticia, `nft_02` Rowena, `nft_03` Odette, `nft_05` Falon, `nft_06` Vera, `nft_04` (unnamed Gothamista, used as the sample holder avatar).
- World: `deathly-offerings-cemetery-v2.png` (cemetery with five blank tombstones and the stone reaper statue) — the game board.
- Logos: Pax Gothamista wordmark (`embedded_image_1`), Mortuary, Orbituary frame, Mort / Morticia name logos, Rest in Pax.
- 1/1: Bella Saw (X post 2124062816185569766).

## Palette (sampled from pixels)
| Role | Hex |
|---|---|
| Night sky / site navy | #1C2663 |
| Stone light / stone shade | #C4C2D6 / #433B77 |
| Moon | #B9DBF7 |
| Chapel window warm | #EFD7B1 |
| Brand pink (PFP logo) | #F04A9E |
| Registry gold (site buttons) | #F6D860 |
| Morticia / Falon / Vera / Odette / Rowena (site colours) | #F37079 / #8ED4E8 / #FFD2F3 / #8899E7 / #B79CFF |
| Mort | #302343 |

## Style notes
Clean cel-shaded 2D, dark purple/indigo outlines, soft gradients, glossy highlights; elongated elf ears, heart-shaped catchlights, freckles, black lips, goth fashion (plaid, chains, chokers, platforms). Mort is a chibi reaper with coffee mug and ledger. Type: ornate white blackletter with four-point sparkles and dangling dot ornaments (matched in-game with UnifrakturMaguntia); UI in Montserrat (the site's font).

## Invariants
Faces, outfits, horns/ears, colours and proportions untouched (cut-out transforms only: translate, gentle scale/sway, additive light). Logos used as supplied, never redrawn.

## Forbidden
3D/photoreal restyles, generic anime faces, invented characters, AI-generated variants of the cast, male Gothamistas (no published art), real holder handles.
