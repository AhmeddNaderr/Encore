"""REBORN BY DAWN — original score. 120 BPM, D minor, resolves to D major at dawn.
Generates MIDI per cut (main 45 s, short 15 s) with section styles on a global beat grid and
event-locked hits, then renders with FluidSynth + GeneralUser GS."""
import json, subprocess, sys, os, mido

BPM = 120; PPQ = 960; SPB = 60 / BPM  # seconds per beat
HERE = os.path.dirname(os.path.abspath(__file__))
SF2 = os.path.join(HERE, 'source', 'GeneralUser-GS.sf2')

N = {n: i for i, n in enumerate(['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'])}
def m(name):  # 'D4' -> midi
    p, o = (name[:-1], int(name[-1])); p = p.replace('Bb', 'A#').replace('Eb', 'D#'); return 12 * (o + 1) + N[p]

CH = {  # channel: (program, volume, pan, reverb)
    'harp': (0, 6, 84, 54, 50), 'pizz': (1, 45, 80, 74, 40), 'bass': (2, 38, 92, 64, 10), 'choir': (3, 52, 88, 64, 90), 'strings': (4, 48, 78, 50, 80),
    'cel': (5, 8, 92, 76, 70), 'mbox': (6, 10, 100, 64, 90), 'organ': (7, 19, 84, 64, 100), 'bells': (8, 14, 90, 70, 100), 'timp': (10, 47, 100, 64, 60),
    'revcym': (11, 119, 80, 64, 40), 'drums': (9, None, 104, 64, 30),
}
CHORDS = {'Dm': ['D', 'F', 'A'], 'Bb': ['Bb', 'D', 'F'], 'Gm': ['G', 'Bb', 'D'], 'A': ['A', 'C#', 'E'], 'D': ['D', 'F#', 'A']}
PROG = ['Dm', 'Bb', 'Gm', 'A']
def chord_at(t, major_after=None):
    if major_after is not None and t >= major_after: return 'D'
    return PROG[int(t // (4 * SPB)) % 4]

MOTIF = [  # (beat offset in 4-bar phrase, note, beats)
    (0, 'A4', 1), (1, 'D5', 1), (2, 'F5', 1), (3, 'E5', .5), (3.5, 'D5', .5),
    (4, 'F5', 1), (5, 'D5', 1), (6, 'Bb4', 2),
    (8, 'G4', 1), (9, 'Bb4', 1), (10, 'D5', 1), (11, 'C5', .5), (11.5, 'Bb4', .5),
    (12, 'A4', 1), (13, 'C#5', 1), (14, 'E5', 1), (15, 'A5', 1)]
SPIRAL = [(0, 'D6', .5), (.5, 'C#6', .5), (1, 'D6', .5), (1.5, 'A5', .5), (2, 'Bb5', .5), (2.5, 'A5', .5), (3, 'G#5', 1)]

class Score:
    def __init__(self): self.ev = []  # (time, kind, ch, note, vel, dur)
    def note(self, ch, t, note, vel, dur):
        if isinstance(note, str): note = m(note)
        self.ev.append((t, CH[ch][0], note, max(1, min(127, int(vel))), dur))
    def drum(self, t, note, vel, dur=.1): self.ev.append((t, 9, note, max(1, min(127, int(vel))), dur))
    def chord(self, ch, t, names, octave, vel, dur):
        for i, n in enumerate(names): self.note(ch, t, f'{n}{octave + (1 if i and N[n.replace("Bb","A#")] < N[names[0].replace("Bb","A#")] else 0)}', vel, dur)

def build(mode):
    S = Score(); E = json.load(open(os.path.join(HERE, 'trailer-events.json')))[mode]; dur = E['duration']
    if mode == 'main':
        secs = [(0, 3, 'full'), (3, 5, 'title'), (5, 12, 'loop'), (12, 15, 'loop2'), (15, 19, 'build'), (19, 22.5, 'spiral'), (22.5, 25.5, 'full'), (25.5, 26.8, 'dawn'),
                (26.8, 32, 'half'), (32, 35.1, 'lift'), (35.1, 38, 'loop'), (38, 41, 'theme'), (41, 45, 'end')]
        major_after = 25.45
    else:
        secs = [(0, 2.4, 'full'), (2.4, 7.0, 'loop'), (7.0, 9.0, 'loop2'), (9.0, 9.5, 'build'), (9.5, 10.4, 'dawn'), (10.4, 12.3, 'half'), (12.3, 13.2, 'lift'), (13.2, 15, 'end')]
        major_after = 9.45
    cues = E['cues']; err = [c['t'] for c in cues if c['type'] == 'error']; special = [c['t'] for c in cues if c['type'] == 'special']
    def style(t):
        for a, b, s in secs:
            if a <= t < b: return s
        return None
    def stopped(t): return any(e + .05 <= t < e + .7 for e in err)  # comedic stop-time after a mistake
    eighth = SPB / 2; n8 = int(dur / eighth)
    for i in range(n8):
        t = i * eighth; st = style(t); b = i % 8; beat = i // 2
        if st is None or stopped(t): continue
        ch = chord_at(t, major_after); notes = CHORDS[ch]; r = notes[0]
        sp = [s for s in special if s <= t < s + 2.6]
        if st == 'spiral' and sp:
            continue
        drums = st in ('full', 'loop', 'loop2', 'build', 'half', 'lift', 'theme')
        if drums:
            hard = st in ('full', 'build', 'theme')
            if st == 'half':
                if b == 0: S.drum(t, 36, 112)
                if b == 4: S.drum(t, 38, 96); S.drum(t, 39, 70)
                S.drum(t, 42, 52 if b % 2 else 66)
            else:
                if b in (0, 4) or (hard and b == 3) or (st == 'build' and b == 7): S.drum(t, 36, 118 if hard else 100)
                if b in (2, 6): S.drum(t, 38 if hard else 39, 104 if hard else 84); (S.drum(t, 39, 64) if hard else None)
                S.drum(t, 42, (70 if b % 2 == 0 else 50) if not hard else (84 if b % 2 == 0 else 62))
                if st == 'build': S.drum(t + eighth / 2, 42, 46)
                if hard and b == 7: S.drum(t, 46, 60)
        # bass
        if st in ('full', 'loop', 'loop2', 'build', 'half', 'lift', 'theme'):
            if st == 'half':
                if b in (0, 3, 4): S.note('bass', t, f'{r}2', 96, eighth * (2 if b == 0 else 1))
            else:
                S.note('bass', t, f'{r}2' if b % 2 == 0 else f'{r}3', 100 if b % 2 == 0 else 78, eighth * .9)
        # harpsichord ostinato
        if st in ('full', 'loop', 'loop2', 'build', 'lift', 'theme'):
            pat = [f'{r}4', f'{notes[2]}4', f'{notes[1]}4', f'{notes[2]}4', f'{r}5', f'{notes[2]}4', f'{notes[1]}4', f'{notes[2]}4']
            p = pat[b]
            if m(p) < m('D4'): p = p[:-1] + '5'
            S.note('harp', t, p, 82 if b % 2 == 0 else 64, eighth * 1.6)
        # pizzicato on beats
        if st in ('loop', 'loop2', 'lift') and b % 2 == 0: S.note('pizz', t, f'{r}3' if b in (0, 4) else f'{notes[2]}3', 86, .3)
        # pads
        if b == 0 and st in ('full', 'build', 'theme', 'lift', 'half', 'loop2'):
            if st in ('full', 'build', 'theme'): S.chord('choir', t, notes, 4, 88, 4 * SPB); S.chord('strings', t, notes, 3, 80, 4 * SPB)
            elif st == 'half': S.chord('strings', t, notes, 3, 60, 4 * SPB)
            else: S.chord('strings', t, notes, 3, 70, 4 * SPB)
        # celesta arpeggio in half-time board section
        if st == 'half':
            S.note('cel', t, [f'{r}5', f'{notes[1]}5', f'{notes[2]}5', f'{notes[1]}5'][b % 4] if True else None, 70, eighth * 1.5)
    # melody (motif) on a 16-beat phrase grid
    for a, b_, st in secs:
        if st not in ('full', 'loop', 'build', 'theme', 'lift'): continue
        ins = {'full': ['cel', 'strings'], 'loop': ['cel'], 'build': ['harp', 'strings'], 'theme': ['cel', 'harp', 'choir'], 'lift': ['strings']}[st]
        ph0 = (a // (16 * SPB)) * 16 * SPB
        if st == 'loop' and mode == 'main' and a == 5: ph0 = 6.0
        t = ph0
        while t < b_:
            for off, nn, ln in MOTIF:
                tt = t + off * SPB
                if a <= tt < b_ and not stopped(tt) and not (major_after and tt >= major_after and st != 'theme' and st != 'lift'):
                    for k, insn in enumerate(ins):
                        S.note(insn, tt, nn if insn != 'strings' else nn[:-1] + str(int(nn[-1]) - 1 if insn == 'strings' and st == 'full' else int(nn[-1])), 92 - k * 10, ln * SPB * .95)
            t += 16 * SPB
    # ---- event-locked hits ----
    def hit_big(t, bell='D5'):
        S.drum(t, 49, 120); S.drum(t, 57, 100); S.note('timp', t, 'D2', 120, 1.2); S.note('timp', t + .12, 'D2', 90, 1.0)
        S.chord('choir', t, ['D', 'F', 'A'] if t < major_after else ['D', 'F#', 'A'], 4, 118, 1.8); S.note('bells', t, bell, 110, 3)
    for c in cues:
        t = c['t']; ty = c['type']
        if ty == 'fullhouse': hit_big(t, 'D5'); S.note('bells', t + .25, 'A5', 96, 2); S.note('bells', t + .5, 'D6', 90, 2)
        if ty == 'title':
            S.note('timp', t, 'D2', 120, 2); S.note('bells', t, 'D4', 115, 4); S.chord('organ', t, ['D', 'F', 'A'], 3, 96, 2.0); S.note('organ', t, 'E4', 70, 2.0); S.note('organ', t, 'D2', 100, 2.0)
            for k, nn in enumerate(['A5', 'D6', 'F6', 'A6', 'D7']): S.note('cel', t + .2 + k * .12, nn, 72, .5)
            S.note('revcym', t + 1.0, 'C4', 96, 1.0)
        if ty == 'mass':
            S.drum(t, 49, 118); S.chord('organ', t, ['D', 'F', 'A'], 4, 110, .45); S.chord('organ', t + .5, ['Bb', 'D', 'F'], 4, 110, .45); S.note('timp', t, 'A2', 110, .6)
        if ty == 'special':
            S.note('organ', t, 'D1', 110, 2.6); S.note('organ', t, 'D2', 90, 2.6); S.note('timp', t, 'D2', 127, 1.5)
            for k in range(3):
                for off, nn, ln in SPIRAL: S.note('mbox', t + .15 + k * 1.0 * 0 + off * SPB * .5 + k * 2 * SPB * .5 * 0, nn, 96, ln * SPB * .5) if k == 0 else None
            for off, nn, ln in SPIRAL: S.note('mbox', t + .15 + off * SPB * .6, nn, 100, ln * SPB * .6); S.note('cel', t + 1.35 + off * SPB * .6, nn[:-1] + str(int(nn[-1]) - 1), 80, ln * SPB * .6)
            for k in range(6): S.drum(t + k * SPB * .5, 36, 70 + k * 6)  # heartbeat
            rs = t + 2.6
            for k in range(8): S.drum(rs - 1.0 + k * .125, 38, 50 + k * 9)
            S.note('revcym', rs - 1.0, 'C4', 90, 1.0)
        if ty == 'dawn':
            for k, nn in enumerate(['D4', 'A4', 'D5', 'F#5']): S.note('bells', t + k * .32, nn, 118 - k * 8, 3.5)
            S.chord('choir', t, ['D', 'F#', 'A'], 4, 110, 2.6 if mode == 'main' else 1.8); S.chord('strings', t, ['D', 'F#', 'A'], 3, 96, 2.6 if mode == 'main' else 1.8); S.note('organ', t, 'D2', 100, 2.4); S.drum(t, 49, 110); S.note('timp', t, 'D2', 120, 1.6)
        if ty == 'stamp': S.note('timp', t, 'D2', 125, 1.0); S.chord('choir', t, ['D', 'F#', 'A'], 4, 112, 1.6); S.drum(t, 49, 100); S.note('bells', t, 'A5', 100, 2)
        if ty == 'gamecard': S.drum(t, 49, 120); S.note('timp', t, 'D2', 120, 1.2); S.chord('organ', t, ['D', 'F#', 'A'], 3, 90, 3.0)
        if ty == 'board': S.drum(t, 49, 96)
        if ty == 'encore':
            S.chord('organ', t, ['D', 'F#', 'A'], 3, 88, dur - t); S.note('organ', t, 'D2', 92, dur - t); S.note('bells', t, 'D5', 100, 4); S.chord('strings', t, ['D', 'F#', 'A'], 3, 74, dur - t)
            for k, nn in enumerate(['F#5', 'A5', 'D6', 'F#6']): S.note('cel', t + .3 + k * .22, nn, 64, .8)
    return S, dur

def write_midi(S, dur, path):
    mid = mido.MidiFile(ticks_per_beat=PPQ); tr = mido.MidiTrack(); mid.tracks.append(tr)
    tr.append(mido.MetaMessage('set_tempo', tempo=mido.bpm2tempo(BPM), time=0))
    for name, (ch, prog, vol, pan, rev) in CH.items():
        if prog is not None: tr.append(mido.Message('program_change', channel=ch, program=prog, time=0))
        else: tr.append(mido.Message('program_change', channel=9, program=0, time=0))
        tr.append(mido.Message('control_change', channel=ch, control=7, value=vol, time=0)); tr.append(mido.Message('control_change', channel=ch, control=10, value=pan, time=0)); tr.append(mido.Message('control_change', channel=ch, control=91, value=rev, time=0))
    msgs = []
    tick = lambda s: int(round(s / SPB * PPQ))
    for (t, ch, note, vel, d) in S.ev:
        if t >= dur: continue
        off = min(t + d, dur + 1.5)
        msgs.append((tick(t), 1, mido.Message('note_on', channel=ch, note=note, velocity=vel)))
        msgs.append((tick(off), 0, mido.Message('note_off', channel=ch, note=note, velocity=0)))
    msgs.sort(key=lambda x: (x[0], x[1])); last = 0
    for tk, _, msg in msgs: msg.time = tk - last; last = tk; tr.append(msg)
    mid.save(path)

if __name__ == '__main__':
    for mode in sys.argv[1:] or ['main', 'short']:
        S, dur = build(mode); mp = os.path.join(HERE, f'score-{mode}.mid'); write_midi(S, dur, mp)
        wav = os.path.join(HERE, f'music-{mode}-raw.wav')
        subprocess.run(['fluidsynth', '-ni', '-q', '-g', '0.55', '-r', '48000', '-F', wav, SF2, mp], check=True)
        print(mode, len(S.ev), 'notes ->', wav)
