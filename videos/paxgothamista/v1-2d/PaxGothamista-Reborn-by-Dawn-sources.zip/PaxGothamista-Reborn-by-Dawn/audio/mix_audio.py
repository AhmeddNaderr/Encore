"""Original SFX (oscillators + seeded noise only) mixed onto the engine event timeline, plus the score.
Usage: python mix_audio.py  -> mix-main.wav, mix-short.wav (48 kHz stereo, pre-master)"""
import json, os, numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt, fftconvolve

SR = 48000; HERE = os.path.dirname(os.path.abspath(__file__)); RNG = np.random.default_rng(666)
def t_(d): return np.arange(int(d * SR)) / SR
def env(n, a=.005, d=.2, curve=6):
    t = np.arange(n) / SR; e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-np.maximum(0, t - a) * curve / max(d, 1e-4)); return e
def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)
def lp(x, f, order=2): return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)
def hp(x, f, order=2): return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)
def noise(d): return RNG.standard_normal(int(d * SR))
def hz(midi): return 440 * 2 ** ((midi - 69) / 12)
def bell(f, d=1.2, amp=1.0):
    t = t_(d); y = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * k) for r, a, k in [(1, 1, 3.5), (2.76, .45, 6), (5.4, .25, 9), (8.93, .12, 14), (.5, .2, 2.5)])
    return amp * y * np.minimum(1, t / .002)
def sweep(f0, f1, d, shape='sine'):
    t = t_(d); f = f0 * (f1 / f0) ** (t / d); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) if shape == 'sine' else np.sign(np.sin(ph)) * .6 + .4 * (2 * ((ph / (2 * np.pi)) % 1) - 1)
IR = (lambda n: (RNG.standard_normal(n) * np.exp(-np.arange(n) / SR * 4.5)))(int(1.6 * SR)); IR /= np.sqrt((IR ** 2).sum())
def verb(x, wet=.25): w = fftconvolve(x, IR)[:len(x) + len(IR) - 1]; y = np.zeros(len(w)); y[:len(x)] += x * (1 - wet * .4); return y + w * wet

PENT = [74, 77, 81, 84, 86]  # D5 F5 A5 C6 D6 — one per grave
GRAVE_X = [398, 782, 985, 1262, 1545]

def sfx(kind, g=None, i=0):
    if kind == 'catch':
        f = hz(PENT[g] + 12 if g is not None else 88); y = (np.sin(2 * np.pi * f * t_(.35)) + .4 * np.sin(2 * np.pi * f * 1.5 * t_(.35))) * env(int(.35 * SR), .003, .12, 5); return verb(y * .16, .3)
    if kind == 'tap':
        n = noise(.26); y = np.zeros_like(n)
        for k, (lo, hi) in enumerate([(500, 1500), (900, 2600), (1600, 4200)]): seg = bp(n, lo, hi); y += seg * np.interp(np.arange(len(n)), [0, len(n) * (.3 + k * .15), len(n)], [0, 1, 0])
        return y * .1
    if kind == 'drop':
        y = sweep(1100, 260, .22) * env(int(.22 * SR), .005, .15, 3) * .14 + lp(noise(.22), 1800) * env(int(.22 * SR), .01, .1, 4) * .06; return y
    if kind in ('rise', 'pop'):
        out = []
        if kind == 'rise':
            th = np.sin(2 * np.pi * np.cumsum(np.linspace(95, 42, int(.4 * SR))) / SR) * env(int(.4 * SR), .003, .25, 5) * .55
            th += lp(noise(.4), 400) * env(int(.4 * SR), .002, .08, 6) * .35 + bp(noise(.4), 1500, 6000) * env(int(.4 * SR), .002, .05, 7) * .05; out.append((0, th))
            for k in range(4): out.append((.06 + k * .055, bell(hz(PENT[g] + [0, 3, 7, 12][k] + (0 if k < 3 else 0)), .9, .2 - k * .02)))
        else:
            out.append((0, bell(hz(PENT[g] + 12), .8, .22))); out.append((.05, bell(hz(PENT[g] + 19), .6, .1)))
        sp = bp(noise(.7), 5000, 12000) * env(int(.7 * SR), .02, .35, 4) * (.07 if kind == 'rise' else .04); out.append((.04, sp))
        n = int(max(o + len(x) / SR for o, x in out) * SR) + 10; y = np.zeros(n)
        for o, x in out: s = int(o * SR); y[s:s + len(x)] += x
        return verb(y, .32)
    if kind == 'error':
        y = np.zeros(int(1.2 * SR))
        for k, (f0, f1) in enumerate([(233, 220), (220, 196), (196, 147)]):  # sad "wah-wah"
            s = int(k * .2 * SR); d = .2 if k < 2 else .5; x = sweep(f0, f1, d, 'square') * env(int(d * SR), .01, d, 2.5); x = lp(x, 1400) * (1 + .3 * np.sin(2 * np.pi * 6 * t_(d))); y[s:s + len(x)] += x * .22
        st = lp(noise(.18), 700) * env(int(.18 * SR), .001, .06, 6) * .5 + np.sin(2 * np.pi * 70 * t_(.18)) * env(int(.18 * SR), .001, .1, 5) * .5; y[:len(st)] += st
        spl = np.zeros(int(.6 * SR))
        for k in range(18): s = int(RNG.uniform(.05, .45) * SR); gr = bp(noise(.04), 500, 2500) * env(int(.04 * SR), .001, .02, 5); spl[s:s + len(gr)] += gr * .2
        y[int(.25 * SR):int(.25 * SR) + len(spl)] += spl; return y
    if kind == 'lost':
        d = .9; t = t_(d); f = 700 * np.exp(-t * 1.2) * (1 + .03 * np.sin(2 * np.pi * 7 * t)); y = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), .05, .6, 2) * .15; return verb(y, .4)
    if kind == 'fullhouse':
        y = np.zeros(int(2.2 * SR))
        for k in range(26): s = int(RNG.uniform(0, 1.2) * SR); b = bell(hz(RNG.choice(PENT) + 12 * RNG.integers(0, 2)), .8, .05); y[s:s + len(b)] += b[:len(y) - s]
        up = bp(noise(1.0), 800, 6000) * np.interp(np.arange(int(SR)), [0, SR * .15, SR], [0, 1, 0]) * .15; y[:len(up)] += up
        for k in range(10):  # bat flutter
            s = int((.15 + k * .07) * SR); fl = bp(noise(.06), 1500, 5000) * (np.sin(2 * np.pi * 28 * t_(.06)) > 0) * .07; y[s:s + len(fl)] += fl
        return verb(y, .3)
    if kind == 'special':
        d = 2.4; t = t_(d); sw = np.sin(2 * np.pi * np.cumsum(500 + 260 * np.sin(2 * np.pi * 1.6 * t) * np.exp(-t * .4)) / SR) * env(len(t), .1, 1.6, 2) * .07
        rev = bp(noise(.5), 300, 5000) * np.linspace(0, 1, int(.5 * SR)) ** 2 * .18; y = np.zeros(len(t) + int(.5 * SR)); y[:len(rev)] += rev; y[int(.5 * SR) - 2000:int(.5 * SR) - 2000 + len(sw)] += sw
        g = sum(np.sin(2 * np.pi * 55 * r * t_(2.0)) * a for r, a in [(1, 1), (1.47, .5), (2.09, .35), (2.76, .2)]) * np.exp(-t_(2.0) * 1.8) * .25; y[int(.45 * SR):int(.45 * SR) + len(g)] += g
        return verb(y, .35)
    if kind == 'mass':
        y = np.zeros(int(1.6 * SR))
        for k in range(6): s = int(k * .13 * SR); w = sfx('tap') * (1.3 - k * .1); y[s:s + len(w)] += w
        return y
    if kind == 'dawn':
        x = bp(noise(2.0), 2000, 9000) * np.interp(np.arange(int(2 * SR)), [0, SR * .6, 2 * SR], [0, 1, 0]) * .05; return verb(x, .5)
    if kind == 'caption': return np.sin(2 * np.pi * 1320 * t_(.06)) * env(int(.06 * SR), .002, .03, 5) * .08
    if kind in ('title', 'board', 'card', 'post', 'gamecard', 'encore', 'whoosh'):
        d = {'title': .7, 'encore': .9}.get(kind, .5); n = noise(d); y = bp(n, 300, 5000) * np.interp(np.arange(len(n)), [0, len(n) * .6, len(n)], [0, 1, 0]) * (.10 if kind != 'encore' else .05)
        if kind in ('title', 'gamecard', 'encore'): y = y + np.pad(sum(bell(hz(f), 1.4, .05) for f in ([86, 93, 98] if kind != 'encore' else [86, 90, 93, 98])), (int(len(y) * .55), 0))[:len(y) + int(1.4 * SR)][:len(y)] if False else y
        return verb(y, .2)
    if kind == 'row': return np.sin(2 * np.pi * (900 + i * 40) * t_(.03)) * env(int(.03 * SR), .001, .015, 5) * .05
    if kind == 'tick': return np.sin(2 * np.pi * (1200 + i * 60) * t_(.04)) * env(int(.04 * SR), .001, .02, 5) * .06
    if kind == 'rankup':
        y = np.zeros(int(1.2 * SR)); b1 = bell(hz(81), .9, .18); b2 = bell(hz(86), 1.0, .2); y[:len(b1)] += b1; y[int(.12 * SR):int(.12 * SR) + len(b2)] += b2[:len(y) - int(.12 * SR)]; return verb(y, .3)
    if kind == 'bots': d = .9; return (np.sin(2 * np.pi * np.cumsum(np.linspace(70, 38, int(d * SR))) / SR) * env(int(d * SR), .005, .7, 3) * .35)
    if kind == 'stamp':
        y = lp(noise(.3), 900) * env(int(.3 * SR), .001, .08, 6) * .5 + np.sin(2 * np.pi * 62 * t_(.3)) * env(int(.3 * SR), .001, .2, 5) * .6; return y
    if kind == 'click': return (bp(noise(.03), 2000, 8000) * env(int(.03 * SR), .0005, .01, 6) * .25)
    if kind == 'like': return bell(hz(98 + (i % 3) * 2), .25, .05)
    if kind == 'cut': return bp(noise(.18), 1000, 7000) * np.interp(np.arange(int(.18 * SR)), [0, .14 * SR, .18 * SR], [0, 1, 0]) * .035
    return None

def pan_of(c):
    if c.get('g') is not None and c['type'] in ('rise', 'pop', 'tap', 'drop', 'error'): return (GRAVE_X[c['g']] - 960) / 960 * .7
    return 0.0

def mix(mode):
    E = json.load(open(os.path.join(HERE, 'trailer-events.json')))[mode]; dur = E['duration']; n = int(dur * SR)
    music, sr = sf.read(os.path.join(HERE, f'music-{mode}-raw.wav')); assert sr == SR
    music = music[:n] if len(music) >= n else np.pad(music, ((0, n - len(music)), (0, 0)))
    music = np.stack([hp(lp(music[:, c], 15000), 32) for c in range(2)], 1)
    fx = np.zeros((n + 3 * SR, 2)); last = {}
    for c in E['cues']:
        ty = c['type']
        if ty in ('catch',) and c.get('quiet'): continue
        if ty in last and c['t'] - last[ty] < (.05 if ty in ('row', 'tick', 'like') else .03): continue
        last[ty] = c['t']
        y = sfx(ty, c.get('g'), c.get('i') or 0)
        if y is None: continue
        g = .55 if c.get('quiet') else 1.0; p = pan_of(c); L = np.sqrt((1 - p) / 2) * 1.414; R = np.sqrt((1 + p) / 2) * 1.414
        s = int(c['t'] * SR); e = min(len(fx), s + len(y)); fx[s:e, 0] += y[:e - s] * L * g; fx[s:e, 1] += y[:e - s] * R * g
    fx = fx[:n]
    # duck music slightly under big SFX moments
    out = music * 0.92 + fx * 1.0
    fade = int(.6 * SR); out[-fade:] *= np.linspace(1, 0, fade)[:, None] ** 1.5
    out[:int(.004 * SR)] *= np.linspace(0, 1, int(.004 * SR))[:, None]
    sf.write(os.path.join(HERE, f'mix-{mode}.wav'), out.astype(np.float32), SR, subtype='FLOAT'); print(mode, 'peak', np.abs(out).max())

if __name__ == '__main__':
    for mode in ('main', 'short'): mix(mode)
