# Concepts (shortlist) and winner

Rule test: "You [verb from their lore] to [goal from their world] while [constraint from their identity]." Rejected obvious: runner, fighter, match-3, flappy, generic dress-up.

| # | Name | One-sentence rule | Lore fit | Orig | Clarity | Replay | Share | Trailer | Build | Total |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | **Reborn by Dawn** | You file each falling soul into the grave with her personality so she rises reborn before dawn, while Mort's five coffees are your only lives. | 10 | 8 | 9 | 8 | 8 | 10 | 8 | **61** |
| 2 | Death Registry Desk | Stamp applicants Alive/Dead at the Mortuary; living impostors sneak in. | 9 | 8 | 7 | 7 | 7 | 6 | 8 | 52 |
| 3 | The Crematorium | Three matching souls enter, one rarer emerges. | 8 | 6 | 8 | 8 | 7 | 7 | 8 | 52 (needs unreleased male art) |
| 4 | Spider Drop | Lower the Mortuary spider on its thread to deliver offerings to graves. | 7 | 8 | 7 | 6 | 6 | 7 | 8 | 49 |
| 5 | Lantern Walk | Morticia's lantern reveals graves in the dark; guide lost souls home. | 7 | 6 | 7 | 6 | 6 | 8 | 8 | 48 |

**Winner — REBORN BY DAWN.** Played on their own cemetery art: its five blank tombstones become the five Gothly Departed's graves (winged skull = Falon "dressed like an angel", thorn-wrapped = Odette "a lot of thorns", flower arch = Vera, skull crown = Morticia, broken slab = Rowena the bad influence). The bio line "Buried in one world. Reborn in another." is literally the core action. Mort the Intern is the avatar, his "fifth coffee" is the life bar, the dawn is the clock, all five risen at once triggers "THE GOTHLY DEPARTED", and a long streak raises their 1/1 (Bella Saw). Swap in another collection's art and it stops making sense.

**30-second loop:** shift starts → souls fall into Mort's hands → tap the right grave → she rises, streak climbs → wrong grave spills a coffee → dawn arrives → Orbituary result card (souls reborn, best streak, coffees left, WL rank) → share.
