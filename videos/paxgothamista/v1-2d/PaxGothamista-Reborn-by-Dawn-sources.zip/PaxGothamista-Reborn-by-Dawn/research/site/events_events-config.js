/*
 * Pax Gothamista — Deathly Offerings: event configuration
 * --------------------------------------------------------
 * Single source of truth for the cemetery section on index.html AND the three
 * event pages in /events/. To activate an event later, edit ONE event below:
 *
 *   NOTE (Round 5): once the Event Manager is in use, the database is the source of truth. This file is the built-in fallback
 *   (used when the database is unreachable or has no published events) and supplies the default form labels.
 *   status: 'coming-soon' | 'open' | 'closed'
 *
 *  - 'coming-soon' : tombstone shows its description, nothing navigates, page form is disabled.
 *  - 'open'        : clicking the tombstone navigates to `url`. The event page enables its
 *                    submission form ONLY when `submissionEndpoint` is also set (see below).
 *  - 'closed'      : tombstone shows the CLOSED badge; the event page form stays disabled.
 *
 * Fill in rules / eligibility (arrays of strings), prizes, deadline (ISO date string or free text)
 * whenever they are decided; empty values render as "To be announced".
 *
 * submissionEndpoint: leave null until the Pax Gothamista backend exists. When set, the event page
 * POSTs JSON to it:  { eventId, xHandle, wallet, entryTitle, entryDescription, xPostUrl, rulesAccepted }
 * The backend is expected to store each entry as event-specific record with review status
 * 'pending' (admin review -> 'approved' | 'rejected'), support CSV export / Google Sheets mirroring,
 * and handle OGoth whitelist allocations for selected winners SEPARATELY. A submission must never
 * grant whitelist access automatically.
 *
 * `url` is relative to the site root (index.html).
 */
window.PAX_EVENTS = {
  defaultMessage: 'Creative offerings from the living. Select a tombstone to discover what awaits.',
  statusLabels: { 'coming-soon': 'COMING SOON', 'open': 'NOW OPEN', 'closed': 'CLOSED', 'results-published': 'RESULTS PUBLISHED' },
  events: {
    'dead-on-arrival': {
      id: 'dead-on-arrival',
      title: 'Dead on Arrival',
      stoneLines: ['DEAD ON', 'ARRIVAL'],
      type: 'UGC / Creative Content Contest',
      description: 'UGC contest. Make videos, memes or creative content from the world of Pax Gothamista.',
      status: 'coming-soon',
      url: 'events/dead-on-arrival/',
      rules: [],
      eligibility: [],
      deadline: null,
      prizes: null,
      submissionEndpoint: null,
      labels: {
        entryTitle: 'Content title',
        entryDescription: 'Content description',
        xPostUrl: 'Public X post link (your content)'
      }
    },
    'art-of-dying': {
      id: 'art-of-dying',
      title: 'The Art of Dying',
      stoneLines: ['THE ART', 'OF DYING'],
      type: 'Art Contest',
      description: 'Art contest. Visitors create artwork inspired by Pax Gothamista.',
      status: 'coming-soon',
      url: 'events/art-of-dying/',
      rules: [],
      eligibility: [],
      deadline: null,
      prizes: null,
      submissionEndpoint: null,
      labels: {
        entryTitle: 'Artwork title',
        entryDescription: 'Artwork description',
        xPostUrl: 'Public X post link (your artwork)'
      }
    },
    'inked-for-eternity': {
      id: 'inked-for-eternity',
      title: 'Inked for Eternity',
      stoneLines: ['INKED FOR', 'ETERNITY'],
      type: 'Tattoo Design Contest',
      description: 'Tattoo design contest. Leave your mark on Pax Gothamista.',
      status: 'coming-soon',
      url: 'events/inked-for-eternity/',
      rules: [],
      eligibility: [],
      deadline: null,
      prizes: null,
      submissionEndpoint: null,
      labels: {
        entryTitle: 'Design name',
        entryDescription: 'Design concept',
        xPostUrl: 'Public X post link (your design)'
      }
    }
  }
};
