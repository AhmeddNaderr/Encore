/* Preserve the approved timeline; serialize seeks and recover a stuck decoder once. */
(() => {
  const stage = document.getElementById('stage'), video = document.getElementById('film');
  const welcome = document.getElementById('welcome'), lore = document.getElementById('lore');
  const shade = document.getElementById('shade'), hint = document.getElementById('hint');
  const progress = document.getElementById('progress'), toggle = document.getElementById('heroMotion');
  const clamp = (v, a=0, b=1) => Math.max(a, Math.min(b,v));
  const range = (v,a,b) => clamp((v-a)/(b-a)), smooth = v => v*v*(3-2*v);
  let current=0, target=.01, pending=false, started=0, lastSeek=0, retries=0, frame=0;
  let paused=matchMedia('(prefers-reduced-motion: reduce)').matches, failed=false, videoLoadRequested=false;
  let duration=7.041667, loadStarted=performance.now();
  // Keep the poster underneath the decoder; reveal video only after decoded data arrives.
  video.style.opacity='0';
  function label() { toggle.textContent=paused||failed?'Play animation':'Pause animation'; toggle.setAttribute('aria-pressed',String(paused||failed)); }
  function requestVideoLoad() {
    if(videoLoadRequested)return;
    videoLoadRequested=true;loadStarted=performance.now();video.load();
  }
  function fallback() { failed=true; pending=false; video.style.opacity='0'; video.pause(); label(); }
  function recover() {
    pending=false; video.style.opacity='0';
    if(retries++ < 1) { videoLoadRequested=true;loadStarted=performance.now();video.load(); }
    else fallback();
  }
  function decoded() {
    if (!paused && !failed && video.readyState>=2) video.style.opacity='1';
  }
  video.addEventListener('loadedmetadata',()=>{
    if(Number.isFinite(video.duration)&&video.duration>0) duration=video.duration;
    pending=false; video.pause();
  });
  video.addEventListener('loadeddata',decoded);
  video.addEventListener('seeked',()=>{pending=false;decoded();});
  video.addEventListener('error',recover);
  toggle.addEventListener('click',()=>{
    if(paused||failed) {
      paused=false;failed=false;retries=0;pending=false;requestVideoLoad();
    } else {paused=true;video.pause();}
    label(); schedule();
  });
  function tick(now) {
    frame=0;
    if(document.hidden)return;
    const rect=stage.getBoundingClientRect(),total=Math.max(1,stage.offsetHeight-innerHeight);
    const desired=clamp(-rect.top/total);
    current+=(desired-current)*.2;
    if(Math.abs(desired-current)<.00015)current=desired;
    const p=current;
    target=p<.26?(p/.26)*1.35:p<.40?1.35:1.35+range(p,.40,1)*(duration-1.35);
    target=clamp(target,.01,Math.max(.01,duration-.05));
    if(!paused&&!failed&&rect.bottom>0&&rect.top<innerHeight) {
      if(desired>.001&&!videoLoadRequested)requestVideoLoad();
      if(pending && now-started>2500)recover();
      else if(videoLoadRequested&&video.readyState<2&&now-loadStarted>10000)recover();
      else if(!pending&&!video.seeking&&video.readyState>=2&&now-lastSeek>=50&&Math.abs(video.currentTime-target)>.045) {
        pending=true;started=lastSeek=now;
        try {video.currentTime=target;}catch {recover();}
      }
    }
    const inV=smooth(range(p,.055,.23)),outV=1-smooth(range(p,.39,.53));
    welcome.style.opacity=(inV*outV).toFixed(3);
    welcome.style.transform=`translate3d(0,calc(${innerWidth<761?'0px':'-50%'} + ${(1-inV)*140-(1-outV)*150}px),0)`;
    const loreV=smooth(range(p,.77,.9));
    lore.style.opacity=loreV.toFixed(3);lore.style.transform=`translateY(${(1-loreV)*35}px)`;
    shade.classList.toggle('lore',p>.73);hint.style.opacity=String(1-smooth(range(p,0,.12)));
    progress.style.width=`${(p*100).toFixed(2)}%`;
    if(rect.bottom>0&&rect.top<innerHeight)schedule();
  }
  function schedule(){if(!frame&&!document.hidden)frame=requestAnimationFrame(tick);}
  addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else{pending=false;loadStarted=performance.now();schedule();}});
  label();schedule();
})();
