/* Generated at build time from Netlify environment variables (public values only). */
window.PAX_CONFIG = {
  "supabaseUrl": "https://yrclcmkqiovhlbihbtyu.supabase.co",
  "supabaseKey": "sb_publishable_9Fg3wtLhBcUP6Gj3cXnTow_hQBYbPTk"
};
