/*
 * Pax Gothamista — public content loader (no SDK, no secrets).
 * Reads PUBLISHED rows through Supabase's REST API using the publishable key; Row Level Security
 * guarantees visitors can only ever receive published rows.
 *
 *   PaxContent.characters  -> Promise<Array|null>   (null = not configured / failed: keep static content)
 *   PaxContent.ribbon      -> Promise<Array|null>
 *
 * Any failure resolves to null so the page keeps its built-in static content and never breaks.
 *
 * Admin preview: when the page is opened inside the admin dashboard as  index.html?paxPreview=1  it
 * does NOT fetch; it waits for a same-origin postMessage from the admin containing draft data.
 */
(() => {
  const cfg = window.PAX_CONFIG || {};
  const base = String(cfg.supabaseUrl || '').replace(/\/+$/, '');
  const key = String(cfg.supabaseKey || '');
  const configured = /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(base) && key.length > 20;
  const enc = p => String(p).split('/').map(encodeURIComponent).join('/');
  const publicUrl = (bucket, path) => (path ? base + '/storage/v1/object/public/' + bucket + '/' + enc(path) : '');

  const toCharacter = r => ({
    id: r.id, name: r.name, slug: r.slug,
    fact: r.description || '',
    bg: /^#[0-9a-fA-F]{6}$/.test(r.background_color || '') ? r.background_color : '#302343',
    image: publicUrl('gothly-departed', r.portrait_path),
    logo: publicUrl('gothly-departed', r.logo_path)
  });
  const toRibbon = r => ({
    id: r.id, title: r.title || '',
    alt: r.alt_text || r.title || 'Pax Gothamista NFT',
    src: publicUrl('ribbon-marquee', r.image_path)
  });

  async function get(table, query) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 7000);
    try {
      const r = await fetch(base + '/rest/v1/' + table + '?' + query, {
        headers: { apikey: key, Authorization: 'Bearer ' + key, Accept: 'application/json' },
        signal: ctrl.signal
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const rows = await r.json();
      return Array.isArray(rows) ? rows : null;
    } finally { clearTimeout(timer); }
  }

  const safe = fn => fn().catch(() => null);
  let serverOffset = 0;                                   // ms; trusted server clock minus this device's clock
  const serverNow = () => new Date(Date.now() + serverOffset);
  async function syncClock() {
    const t0 = Date.now();
    const r = await fetch(base + '/rest/v1/rpc/server_time', { method: 'POST', headers: { apikey: key, Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, body: '{}' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const t = new Date(await r.json()).getTime(); const t1 = Date.now();
    if (!isNaN(t)) serverOffset = t - (t0 + t1) / 2;
    return serverOffset;
  }
  const EVENT_COLS = 'id,slug,title,type_label,tombstone_label,short_description,rules,eligibility,prizes,tombstone_slot,status,is_published,opens_at,closes_at,require_x_post_url,require_wallet,allow_image,require_image,max_submissions_per_user,display_order';
  let characters, ribbon, events = Promise.resolve(null), clockP = Promise.resolve(null);
  const isPreview = /[?&]paxPreview=1(&|$)/.test(location.search) && window.parent !== window;

  if (isPreview) {
    // Data comes from the admin dashboard (same origin only). URLs are restricted to https / blob / data:image.
    const okUrl = u => typeof u === 'string' && (u === '' || /^(https:\/\/|blob:|data:image\/)/.test(u));
    const pass = new Promise(resolve => {
      window.addEventListener('message', e => {
        if (e.origin !== location.origin || !e.data || e.data.type !== 'pax-preview') return;
        const d = e.data;
        const chars = (d.characters || []).filter(c => okUrl(c.image) && okUrl(c.logo)).map(c => ({ name: String(c.name || ''), fact: String(c.fact || ''), bg: /^#[0-9a-fA-F]{6}$/.test(c.bg) ? c.bg : '#302343', image: c.image || '', logo: c.logo || '' }));
        const rib = (d.ribbon || []).filter(r => okUrl(r.src) && r.src).map(r => ({ title: String(r.title || ''), alt: String(r.alt || r.title || ''), src: r.src }));
        resolve({ characters: chars, ribbon: rib });
      });
    });
    characters = pass.then(d => d.characters);
    ribbon = pass.then(d => d.ribbon);
    try { window.parent.postMessage({ type: 'pax-preview-ready' }, location.origin); } catch (e) {}
  } else if (!configured) {
    characters = Promise.resolve(null);
    ribbon = Promise.resolve(null);
  } else {
    events = safe(async () => { const rows = await get('events', 'select=' + EVENT_COLS + '&order=display_order.asc,created_at.asc'); return rows && rows.length ? rows : null; });
    clockP = safe(syncClock);
    characters = safe(async () => {
      const rows = await get('gothly_characters', 'select=id,name,slug,description,background_color,portrait_path,logo_path&is_published=eq.true&portrait_path=not.is.null&order=display_order.asc,created_at.asc');
      return rows && rows.length ? rows.map(toCharacter) : null;   // empty table => keep static content
    });
    ribbon = safe(async () => {
      const rows = await get('ribbon_images', 'select=id,title,image_path,alt_text&is_published=eq.true&order=display_order.asc,created_at.asc');
      return rows && rows.length ? rows.map(toRibbon) : null;
    });
  }

  window.PaxContent = { characters, ribbon, events, serverNow, syncClock: clockP, preview: isPreview, publicUrl, base, key, configured };
})();
