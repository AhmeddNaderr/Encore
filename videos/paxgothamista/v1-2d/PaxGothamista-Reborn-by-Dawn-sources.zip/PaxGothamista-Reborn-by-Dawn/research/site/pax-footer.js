/* Shared public footer. Social destinations are supplied by pax-links.js. */
(() => {
 const script=document.currentScript,base=new URL('.',script.src),home=new URL('index.html',base);
 if(document.querySelector('.pax-footer'))return;
 const isHome=location.pathname===base.pathname||location.pathname===home.pathname;
 const footer=document.createElement('footer');footer.className='pax-footer';footer.setAttribute('aria-label','Pax Gothamista footer');
 const link=(text,url)=>{const a=document.createElement('a');a.textContent=text;a.href=url;return a;};
 const grid=document.createElement('div');grid.className='pax-footer-grid';
 const brand=document.createElement('div');brand.className='pax-footer-brand';const logoLink=link('',(isHome?'':home.href)+'#top');logoLink.setAttribute('aria-label','Pax Gothamista home');
 const logo=document.createElement('img');logo.src=new URL('embedded_image_1.png',base).href;logo.alt='Pax Gothamista';logo.width=220;logo.loading='lazy';logoLink.append(logo);brand.append(logoLink);grid.append(brand);
 function column(title){const nav=document.createElement('nav');nav.setAttribute('aria-label',title);const h=document.createElement('h2');h.textContent=title;nav.append(h);grid.append(nav);return nav;}
 const explore=column('Explore the Cemetery'),list=document.createElement('ul');explore.append(list);
 for(const [title,id] of [['Home','top'],['The Gothly Departed','gothly-departed'],['Mortuary','mortuary'],['Orbituary','orbituary'],['Deathly Offerings','deathly-offerings'],['Unfinished Business','unfinished-business']]){const li=document.createElement('li');li.append(link(title,(isHome?'':home.href)+'#'+id));list.append(li);}
 const social=column('Stay Among the Dead'),icons=document.createElement('div');icons.className='pax-footer-socials';social.append(icons);
 const paths={X:'M18.9 2H22l-6.8 7.8L23.2 22h-6.3l-4.9-7.4L5.5 22H2.4l7.3-8.5L1.9 2h6.5l4.4 6.7L18.9 2Zm-1.1 18h1.7L7.5 3.9H5.7Z',Discord:'M19.7 5.2a18 18 0 0 0-4.4-1.4l-.5 1a16 16 0 0 0-5.6 0l-.5-1a18 18 0 0 0-4.4 1.4C1.5 9.2.7 13 1.1 16.7a18 18 0 0 0 5.5 2.8l1.2-1.9-1.9-.9.5-.4c3.7 1.8 7.5 1.8 11.2 0l.5.4-1.9.9 1.2 1.9a18 18 0 0 0 5.5-2.8c.5-4.3-.8-8-3.2-11.5ZM8.8 14.7c-1 0-1.7-.9-1.7-2s.8-2 1.7-2 1.7.9 1.7 2-.8 2-1.7 2Zm6.4 0c-1 0-1.7-.9-1.7-2s.8-2 1.7-2 1.7.9 1.7 2-.7 2-1.7 2Z',OpenSea:'M12.1 1.5 7 9.2h3.2V3.5l1.9-2Zm1 2.1v9.3H5.7l-1.5 2.6 5.4 1.1 4.1-3.5 6.1 2.6-2.2 4.5H5.5l-2.3-2.6 2-3.7H2.6L.9 17l4.1 5.1h12.8l5.3-8.3-10-4.4V3.6Z'};
 for(const [name,path] of Object.entries(paths)){const a=document.createElement('a');a.dataset.social=name;a.setAttribute('aria-label',name+' — link not configured');a.setAttribute('aria-disabled','true');a.title=name+' — link not configured';const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');const p=document.createElementNS(svg.namespaceURI,'path');p.setAttribute('d',path);svg.append(p);a.append(svg);icons.append(a);}
 const fine=column('The Fine Print'),legal=document.createElement('ul');fine.append(legal);
 for(const [title,path] of [['Privacy Policy','privacy-policy/'],['Terms & Conditions','terms-and-conditions/'],['Disclaimer','disclaimer/'],['Contact Us','contact/']]){const li=document.createElement('li');li.append(link(title,new URL(path,base).href));legal.append(li);}
 const bottom=document.createElement('div');bottom.className='pax-footer-bottom';const copyright=document.createElement('p');copyright.textContent='© 2026 Pax Gothamista. All rights reserved.';bottom.append(copyright);footer.append(grid,bottom);script.before(footer);
})();
