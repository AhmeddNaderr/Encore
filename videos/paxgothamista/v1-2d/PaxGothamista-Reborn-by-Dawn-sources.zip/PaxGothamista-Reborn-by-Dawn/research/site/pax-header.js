/* Loaded synchronously where the header belongs, before existing navigation/auth scripts. */
(() => {
 const script=document.currentScript,base=new URL('.',script.src),header=script.previousElementSibling;
 const home=new URL('index.html',base),isHome=location.pathname===base.pathname||location.pathname===home.pathname;
 const active=location.pathname.includes('/events/')?'offerings':/\/(mortuary-application|mass-death-registry)\//.test(location.pathname)?'mortuary':null;
 const brand=document.createElement('a');brand.className='brand';brand.href=isHome?'#top':home.href+'#top';brand.setAttribute('aria-label','Pax Gothamista home');
 const logo=document.createElement('img');logo.src=new URL('embedded_image_1.png',base).href;logo.alt='Pax Gothamista';brand.append(logo);
 const nav=document.createElement('nav');nav.className='nav';nav.setAttribute('aria-label','Main navigation');
 for(const [key,anchor,label] of [['home','top','HOME'],['departed','gothly-departed','THE GOTHLY DEPARTED'],['mortuary','mortuary','MORTUARY'],['orbituary','orbituary','ORBITUARY'],['offerings','deathly-offerings','DEATHLY OFFERINGS'],['unfinished','unfinished-business','UNFINISHED BUSINESS']]){
  const a=document.createElement('a');a.href=(isHome?'':home.href)+'#'+anchor;a.dataset.nav=key;a.textContent=label;
  if(key==='home')a.classList.add('nav-home');if(key==='departed')a.classList.add('departed-nav');
  if(key===active){a.classList.add('active');a.setAttribute('aria-current','page');}nav.append(a);
 }
 const connect=document.createElement('a');connect.href='#connect';connect.className='connect';connect.id='connectX';connect.dataset.paxConnect='';connect.textContent='CONNECT X';nav.append(connect);
 header.append(brand,nav);
 // Application headers previously occupied normal flow. Reserve the same new header height so forms stay below it.
 if(active==='mortuary'){
  const spacer=document.createElement('div');spacer.setAttribute('aria-hidden','true');script.after(spacer);
  const measure=()=>{spacer.style.height=header.getBoundingClientRect().height+'px';};
  new ResizeObserver(measure).observe(header);measure();
 }
})();
