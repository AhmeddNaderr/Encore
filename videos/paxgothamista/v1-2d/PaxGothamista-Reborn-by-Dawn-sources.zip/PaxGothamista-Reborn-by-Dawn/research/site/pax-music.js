(() => {
  if(window.PaxMusic)return;
  const base=new URL('.',document.currentScript.src),cfg=window.PAX_CONFIG||{};
  const assignment=/\/(mortuary-application|mass-death-registry)(\/|$)/.test(location.pathname)?'applications':'main';
  const key='pax-music-preferences-v1',positionKey='pax-music-position-'+assignment;
  const read=(k,f)=>{try{return JSON.parse(localStorage.getItem(k))??f;}catch{return f;}};
  const write=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch{}};
  let preferences=read(key,{playing:null,muted:false}),settings=null,objectUrl=null,fadeId=0,loading=null,wanted=false;
  const owner=crypto.randomUUID();
  const audio=new Audio();audio.preload='none';audio.muted=!!preferences.muted;
  const panel=document.createElement('div');panel.className='pax-music';panel.setAttribute('role','group');panel.setAttribute('aria-label','Background music');
  const play=document.createElement('button'),mute=document.createElement('button'),label=document.createElement('span');
  play.type=mute.type='button';label.className='music-state';label.setAttribute('aria-live','polite');panel.append(play,mute,label);document.body.append(panel);
  function paint(message){play.textContent=audio.paused?'▶':'Ⅱ';play.setAttribute('aria-label',audio.paused?'Play background music':'Pause background music');mute.textContent=audio.muted?'♩':'♪';mute.setAttribute('aria-label',audio.muted?'Unmute background music':'Mute background music');mute.setAttribute('aria-pressed',String(audio.muted));label.textContent=message||(!settings?.enabled?'Music off':audio.paused?'Music paused':audio.muted?'Music muted':'Music playing');play.disabled=!settings?.enabled;}
  function save(){write(key,preferences);}
  function remember(){if(audio.src)write(positionKey,{src:settings?.storage_path||settings?.local,time:audio.currentTime});}
  function fade(target,done){cancelAnimationFrame(fadeId);const from=audio.volume,start=performance.now();function tick(t){const p=Math.min(1,(t-start)/280);audio.volume=from+(target-from)*p;if(p<1)fadeId=requestAnimationFrame(tick);else done?.();}fadeId=requestAnimationFrame(tick);}
  async function source(){
    if(audio.getAttribute('src'))return;
    if(!loading)loading=(async()=>{
      if(settings.local)audio.src=new URL(settings.local,base).href;
      else{
        const r=await fetch(cfg.supabaseUrl+'/storage/v1/object/authenticated/pax-music/'+settings.storage_path,{headers:{apikey:cfg.supabaseKey,Authorization:'Bearer '+cfg.supabaseKey}});
        if(!r.ok)throw Error('Audio unavailable');objectUrl=URL.createObjectURL(await r.blob());audio.src=objectUrl;
      }
      audio.loop=settings.loop;const saved=read(positionKey,null);
      audio.addEventListener('loadedmetadata',()=>{if(saved?.src===(settings.storage_path||settings.local)&&Number.isFinite(saved.time)&&saved.time<audio.duration)audio.currentTime=saved.time;},{once:true});
    })().catch(e=>{loading=null;throw e;});
    await loading;
  }
  let resumeGesture=null;
  function clearResume(){if(!resumeGesture)return;document.removeEventListener('pointerdown',resumeGesture);document.removeEventListener('keydown',resumeGesture);resumeGesture=null;}
  function afterGesture(){
    clearResume();resumeGesture=e=>{if(e.target.closest?.('.pax-music'))return;clearResume();if(preferences.playing!==false)start();};
    document.addEventListener('pointerdown',resumeGesture);document.addEventListener('keydown',resumeGesture);
  }
  async function start(automatic=false){
    clearResume();
    wanted=true;
    try{await source();if(!wanted)return;audio.volume=automatic?Number(settings.volume):0;await audio.play();write('pax-music-owner',owner);if(!wanted){audio.pause();return;}preferences.playing=true;save();fade(Number(settings.volume));paint();}
    catch(e){wanted=false;paint(e.name==='NotAllowedError'?'Tap to play':'Unavailable');if(automatic&&e.name==='NotAllowedError'&&preferences.playing!==false)afterGesture();}
  }
  function stop(persist=true){clearResume();wanted=false;remember();if(persist){preferences.playing=false;save();}fade(0,()=>{audio.pause();paint();});}
  play.onclick=()=>{if(wanted||!audio.paused)stop();else start();};
  mute.onclick=()=>{audio.muted=!audio.muted;preferences.muted=audio.muted;save();paint();};
  audio.addEventListener('ended',()=>{preferences.playing=false;save();paint();});audio.addEventListener('error',()=>{wanted=false;paint('Unavailable');});
  ['play','pause'].forEach(type=>audio.addEventListener(type,()=>paint()));
  addEventListener('pagehide',()=>{remember();cancelAnimationFrame(fadeId);audio.pause();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){remember();wanted=false;cancelAnimationFrame(fadeId);audio.pause();}});
  addEventListener('storage',e=>{if(e.key==='pax-music-owner'&&e.newValue!==JSON.stringify(owner)){wanted=false;cancelAnimationFrame(fadeId);audio.pause();paint();}if(e.key===key){preferences=read(key,{playing:false,muted:false});audio.muted=!!preferences.muted;if(!preferences.playing)stop(false);paint();}});
  // Homepage attempts audible autoplay normally; a blocked attempt waits for a visitor gesture.
  const headers={apikey:cfg.supabaseKey,Authorization:'Bearer '+cfg.supabaseKey};
  async function init(){
    if(cfg.supabaseKey){
      try{const r=await fetch(cfg.supabaseUrl+'/rest/v1/pax_music_settings?select=*&assignment=eq.'+assignment,{headers});if(!r.ok)throw Error();settings=(await r.json())[0]||null;}catch{paint('Unavailable');return;}
    }else settings={enabled:true,volume:.3,loop:true,local:assignment==='main'?'audio/welcome-to-pax.mp3':'audio/mort-music-box.mp3'};
    paint();
    if(settings?.enabled){if(assignment==='main'&&preferences.playing!==false)start(true);else if(preferences.playing)afterGesture();}
  }
  window.PaxMusic={assignment};paint('Loading music');init();
})();
