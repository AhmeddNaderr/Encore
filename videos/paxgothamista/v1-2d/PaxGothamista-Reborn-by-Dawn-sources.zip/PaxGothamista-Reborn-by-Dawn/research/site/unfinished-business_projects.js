window.PAX_PROJECTS = [
  {
    "slot": 1,
    "slug": "gothamista-reborn",
    "name": "Gothamista Reborn",
    "description": "The genesis of a new afterlife. A collection of 6,666 female Gothamista NFTs, each carrying a piece of the Pax Gothamista universe. The first souls are preparing to rise from their digital graves.",
    "status": "IN DEVELOPMENT",
    "image": "unfinished-business/cards/gothamista-reborn.png"
  },
  {
    "slot": 2,
    "slug": "rest-in-pax",
    "name": "Rest in Pax",
    "description": "A cemetery is nothing without its residents. We are building a home for the beautifully departed through our Discord community, creative activities, deathly conversations, and gatherings with Mort the Intern. Come for the afterlife. Stay for the company.",
    "status": "IN DEVELOPMENT",
    "image": "unfinished-business/cards/rest-in-pax.png"
  },
  {
    "slot": 3,
    "slug": "black-market",
    "name": "Black Market",
    "description": "Even the dead have a living to make. A planned underground marketplace where Gothamista NFT holders may stake their NFTs to unlock merchant stalls and sell digital creations, from illustrations and stickers to templates and collectibles.",
    "status": "PLANNED",
    "image": "unfinished-business/cards/black-market.png"
  },
  {
    "slot": 4,
    "slug": "the-crematorium",
    "name": "The Crematorium",
    "description": "Three souls enter. One emerges. A future voluntary ritual where holders can burn three eligible female Gothamista NFTs to mint one rarer male Gothamista from the same collection. No more than 666 males can ever emerge.",
    "status": "PLANNED",
    "image": "unfinished-business/cards/the-crematorium.png"
  },
  {
    "slot": 5,
    "slug": "the-deathly-departed",
    "name": "The Deathly Departed",
    "description": "Death was only the beginning of their story. Follow five unlikely friends navigating their second lives in Pax Gothamista, a peculiar cemetery town filled with dark humor, unexpected friendships, and mysteries buried deeper than the graves themselves.",
    "status": "IN DEVELOPMENT",
    "image": "unfinished-business/cards/the-deathly-departed.png"
  }
];
