# Pax Gothamista — research brief

**Handle note:** the requested `@Pax_Gothamistan` returns "This account doesn't exist" on X. The project matching the name, theme and artist is **@Pax_Gothamista** (X bio: "Buried in one world. Reborn in another. 🖤 Welcome to Pax Gothamista.", website paxgothamista.xyz, joined Apr 2022, ~1.85k followers). Artist/builder: **@MynddNFT** ("I do art 🖤🎧🐈‍⬛ … Building @Pax_Gothamista"). Community CM listed in a post: @jikannians.

**One line:** A peculiar little cemetery town where the dead have a little more living to do: goth girls reborn into a second life.

**Lore (site, opened 2026-11-26):** "DEATH IS ONLY THE BEGINNING." "Every soul has a story, every grave has a personality, and fitting in was never part of the plan." "Welcome to your second life. Try not to waste this one." WL = "Declare yourself dearly departed at the Pax Gothamista Mortuary" (Death Registry = personal WL; Mass Death Registry = collabs). "The paperwork is dreadful. The afterlife is worth it." Orbituary = WL status check (Alive / Dead). Events (Deathly Offerings): Dead on Arrival (UGC), The Art of Dying (art), Inked for Eternity (tattoo). Roadmap (Unfinished Business): Gothamista Reborn (6,666 female Gothamistas, in development), Rest in Pax (Discord, gatherings with Mort the Intern), Black Market (planned), The Crematorium (burn 3 → 1 rarer male, max 666, planned), The Deathly Departed (story of five friends). 1/1 theme: pop-culture horror villains (latest: "Bella Saw", prize "OGoth WL or your soul").

**The Gothly Departed (site roster, verbatim facts):**
| Name | Site colour | Fact |
|---|---|---|
| Morticia Belladonna | #F37079 | Just because you're dead doesn't mean you can't be beautiful. |
| Falon St Clair | #8ED4E8 | Dressed like an angel. Filed under suspicious. |
| Vera Locks | #FFD2F3 | Hearts are her specialty. Handle yours carefully. |
| Odette Noir | #8899E7 | A little romance. A lot of thorns. |
| Rowena Inkgrave | #B79CFF | A bad influence? She prefers trendsetter. |
| Mort the Intern | #302343 | Death intern. Overworked, underpaid, and on his fifth coffee. |

**5 core motifs:** graves with personality · rising/rebirth ("buried… reborn") · Mort the overworked intern + coffee · death paperwork / registries as WL · dark-cute fashion (Behind the Gravestone: Outfits).

**Tone:** dark humour, cute-gothic, playful puns (Orbituary, Rest in Pax, OGoth), 💀🖤🪦⚰️ emojis, "GM, Gothamista!".

**Mint status:** not minted. Collection "Gothamista Reborn" 6,666 in development; chain, price and date **unknown** (not found on site or posts). OGoth WL used as contest prizes.

**Competitive check:** no game found on site, roadmap or recent posts.

**Things to avoid:** inventing chain/mint facts; showing male Gothamistas (no art published); real holder handles; implying WL is granted by the game (site states submissions never grant WL automatically).

## Sources
- https://x.com/Pax_Gothamista (profile, posts 2125523876180594842, 2124806802042917371, 2124062816185569766, 2123276602255786149, 2122912179481633089 via api.fxtwitter.com)
- https://x.com/MynddNFT
- https://x.com/Pax_Gothamistan (does not exist)
- https://paxgothamista.xyz/ (+ events/events-config.js, unfinished-business/projects.js, pax-content.js)
