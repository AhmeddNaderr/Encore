# Storyboard — Reborn by Dawn (main 45 s, 1920×1080, 60 fps)

| Time | On screen | Source | Text | Audio |
|---|---|---|---|---|
| 0–3 | Mid-shift: three girls risen, Mort files a halo soul (Falon rises) then a crown soul (Rowena) → ALL FIVE RISEN, "The Gothly Departed" +5,000 | Engine take (hook) | in-game only | full groove; choir/timpani/bell hit on the bonus |
| 3–5 | Official wordmark + **Reborn by Dawn** over the live board | Engine + title | "Buried in one world. Reborn in another." | bell, organ chord, celesta sparkle |
| 5–12 | Shift starts: heart → Vera, horns → Morticia, rose → Odette, names flash as each is REBORN | Engine take (main 0.4–7.4) | "Match each soul to her grave." / "Every grave has a personality." | light groove, pentatonic grave chimes |
| 12–15 | Halo soul filed into the thorn grave → PAPERWORK ERROR, a coffee spills | Engine (main 8.3–11.3) | "Wrong grave? Mort spills a coffee." | stop-time "wah-wah", stamp, splash |
| 15–19 | MASS DEATH REGISTRY collab wave, rapid filing, sky starts warming | Engine (main 25.6–29.6) | "Raise them all before dawn." | build, organ stabs |
| 19–22.5 | Streak 15 → spiral → **1/1 HORROR RISEN: Bella Saw** +6,666 | Engine (main 32.3–35.8) | in-game | music-box spiral, heartbeat, riser |
| 22.5–26.8 | Five different souls in a row → The Gothly Departed at dawn → **Shift Complete** | Engine (main 42.0–46.3) | in-game | climax, resolves to D major with dawn bells |
| 26.8–32 | Death Registry WL leaderboard (sample), holder_you climbs to #2 | Motion graphics | "Bots can like a post. They can't raise the dead." | half-time groove, rank-up chime |
| 32–35.1 | Their Orbituary frame: status **Dead** stamped, 42 souls reborn, stats, Share on X tapped | Motion graphics (official frame) | — | stamp + choir |
| 35.1–38 | Result inside an X post mock-up | Motion graphics | POST PREVIEW · MOCK-UP | playful loop |
| 38–41 | Wordmark + game title over all five risen at dawn | Engine tableau | "A game concept for Pax Gothamista" | theme statement |
| 41–45 | Encore end card: silver mark, slogan, CTA, disclaimer | Encore house style | One crew for your whole launch. | organ + bells resolve |

15 s vertical cut: hook (0–2.4) → rule + rises (2.4–6.6) → coffee spill (6.6–8.6) → dawn (8.6–9.8) → leaderboard + bots line (9.8–11.8) → Orbituary result (11.8–13) → Encore card (13–15).
