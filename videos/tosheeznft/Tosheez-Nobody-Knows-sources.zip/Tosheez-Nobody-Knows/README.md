# Tosheez · Nobody Knows: source package

Unofficial Encore Studio concept. Tosheez characters and art © Tosheez. This package excludes the finished MP4, which is a separate download.

## Contents

| Path | What it is |
|---|---|
| `game/` | Trailer engine (HTML5 canvas): `engine.js` (layer compositing, looks), `gameplay.js` (trend waves, hunter lens, match rules, HUD), `scenes.js` (44 s timeline). `assets/layers/` holds the 34 extracted trait layers plus the base face at 1024 px canvas. |
| `art/layers/` | Full-resolution (1769 px canvas) trait layers with `layers.json` offsets; `art/base.png` is the reconstructed clean base face. |
| `art/*.jpg` | Alignment check, every trait on the base face, and random recombinations. |
| `tools/` | Art pipeline: `align.py` and `align_fix.py` (register portraits to the shared canvas), `make_base.py` (clean base face), `extract.py` (trait separation by differencing), `compose.py` (preview compositor), `capture.cjs` (Playwright frame capture → FFmpeg). |
| `audio/` | `compose.py` synthesizes the original score and all SFX from `events.json` (the engine's cue list). |
| `research/` | Public posts and media metadata from @TosheezNFT, source URLs (`sources.csv`) and the original images used. |

## Reproduce

Requires Python 3 with NumPy, SciPy and OpenCV, plus Node with Playwright/Chromium and FFmpeg.

1. Preview the film in a browser: serve `game/` (`python -m http.server` inside `game/`) and open `index.html`.
2. Rebuild the art: `python tools/align.py && python tools/align_fix.py && python tools/make_base.py && python tools/extract.py`. The tools read `research/raw/` and write to `art/`.
3. Export cues: `node tools/capture.cjs events` (writes `audio/events.json`).
4. Score: `python audio/compose.py audio/events.json audio/mix_raw.wav`, then `ffmpeg -i audio/mix_raw.wav -af loudnorm=I=-16:TP=-1.5:LRA=11 audio/mix.wav`.
5. Picture: `node tools/capture.cjs video video/picture.mp4 60 0 44`, then mux with the mix.

No AI image or video generation is used. Fonts are Inter Tight and JetBrains Mono under the SIL OFL (licences in `game/fonts/`).
