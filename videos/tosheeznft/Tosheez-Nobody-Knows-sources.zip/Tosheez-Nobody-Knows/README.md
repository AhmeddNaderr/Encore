# Tosheez · Nobody Knows: source package

Unofficial Encore Studio concept. Tosheez characters and art © Tosheez. This package excludes the finished MP4, which is a separate download.

## Contents

| Path | What it is |
|---|---|
| `game/` | Trailer engine (HTML5 canvas): `engine.js` (layer compositing, looks), `gameplay.js` (trend waves, hunter lens, match rules, HUD), `scenes.js` (44 s timeline). `assets/layers/` holds the 34 extracted trait layers plus the base face at 1024 px canvas. |
| `art/layers/` | Full-resolution (1769 px canvas) trait layers with `layers.json` offsets; `art/base.png` is the reconstructed clean base face. |
| `art/*.jpg` | Alignment check, every trait on the base face, and random recombinations. |
| `tools/` | Art pipeline: `align.py` and `align_fix.py` (register portraits to the shared canvas), `make_base.py` (clean base face), `extract.py` (trait separation by differencing), `compose.py` (preview compositor), `capture.cjs` (Playwright frame capture → FFmpeg). |
| `audio/` | `score.py` writes the original score as MIDI stems (`stems/*.mid`) plus the SFX cues from `events.json` (the engine's cue list). `mix.py` renders them with FluidSynth and the GeneralUser GS instrument bank (see `soundfont/README.md`), then applies room reverb, EQ, bus compression and mastering. `tosheez-mix-v2.wav` is the final mix. |
| `research/` | Public posts and media metadata from @TosheezNFT, source URLs (`sources.csv`) and the original images used. |

## Reproduce

Requires Python 3 with NumPy, SciPy and OpenCV, plus Node with Playwright/Chromium and FFmpeg.

1. Preview the film in a browser: serve `game/` (`python -m http.server` inside `game/`) and open `index.html`.
2. Rebuild the art: `python tools/align.py && python tools/align_fix.py && python tools/make_base.py && python tools/extract.py`. The tools read `research/raw/` and write to `art/`.
3. Export cues: `node tools/capture.cjs events` (writes `audio/events.json`).
4. Score: `python audio/score.py audio/stems audio/events.json`, then `python audio/mix.py audio/stems audio/soundfont/GeneralUser-GS.sf2 audio/mix_raw.wav`, then `ffmpeg -i audio/mix_raw.wav -af loudnorm=I=-16:TP=-1.5:LRA=11 audio/mix.wav`. This needs `fluidsynth` and `pip install mido`.
5. Picture: `node tools/capture.cjs video video/picture.mp4 60 0 44`, then mux with the mix.

No AI image, video or music generation is used. The game UI uses Inter Tight and JetBrains Mono; the Encore end card uses Geist, Geist Mono and Doto from the Encore Brand Kit. All fonts are under the SIL OFL, with licences in `game/fonts/`. The Encore lockup and crew art in `game/assets/logo/` come from the Encore Brand Kit.
