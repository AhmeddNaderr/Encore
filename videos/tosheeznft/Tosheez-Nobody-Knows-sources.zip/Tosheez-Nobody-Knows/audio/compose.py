# Original score + SFX for "Tosheez: Nobody Knows" (concept film). All sounds synthesized here.
# 120 BPM, D minor "sneaky spy" groove. Usage: python compose.py events.json out.wav
import sys, json, numpy as np
SR = 48000
DUR = 44.0
N = int(SR * DUR)
BEAT = 0.5
rs = np.random.RandomState(7)

def t_(d): return np.arange(int(SR * d)) / SR
def mtof(m): return 440.0 * 2 ** ((m - 69) / 12)
def env_ad(n, a, d, curve=4.0):
    t = np.arange(n) / SR
    e = np.where(t < a, t / max(a, 1e-6), np.exp(-(t - a) * curve / max(d, 1e-6)))
    return e
def lp1(x, fc):
    a = np.exp(-2 * np.pi * fc / SR); y = np.zeros_like(x); s = 0.0
    # vectorised one-pole via lfilter-like recursion (scipy-free)
    from scipy.signal import lfilter
    return lfilter([1 - a], [1, -a], x)
from scipy.signal import butter, sosfilt, lfilter
def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)
def hp(x, fc, order=2): return sosfilt(butter(order, fc, btype='high', fs=SR, output='sos'), x)
def lp(x, fc, order=2): return sosfilt(butter(order, fc, btype='low', fs=SR, output='sos'), x)

L = np.zeros(N); R = np.zeros(N)
def add(sig, t0, gain=1.0, pan=0.0, bus=None):
    i0 = int(round(t0 * SR));
    if i0 >= N: return
    if i0 < 0: sig = sig[-i0:]; i0 = 0
    n = min(len(sig), N - i0)
    gl = gain * np.cos((pan + 1) * np.pi / 4); gr = gain * np.sin((pan + 1) * np.pi / 4)
    (bus or (L, R))[0][i0:i0 + n] += sig[:n] * gl * 1.4142
    (bus or (L, R))[1][i0:i0 + n] += sig[:n] * gr * 1.4142

# ---------------------------------------------------------------- instruments
def kick(g=1.0):
    t = t_(0.35); f = 45 + 95 * np.exp(-t * 28); ph = 2 * np.pi * np.cumsum(f) / SR
    return g * np.sin(ph) * np.exp(-t * 9) + 0.15 * g * rs.randn(len(t)) * np.exp(-t * 200)
def snap():
    t = t_(0.18); n = rs.randn(len(t)); s = bp(n, 1800, 5200) * np.exp(-t * 38)
    return s * 0.9 + 0.3 * bp(rs.randn(len(t)), 900, 1600) * np.exp(-t * 60)
def hat(open_=False):
    t = t_(0.25 if open_ else 0.06); n = hp(rs.randn(len(t)), 7000); return n * np.exp(-t * (14 if open_ else 70)) * 0.5
def shaker():
    t = t_(0.07); n = bp(rs.randn(len(t)), 5000, 11000); return n * np.sin(np.pi * np.clip(t / 0.07, 0, 1)) ** 2 * 0.35
def pluck_bass(m, d=0.5):
    f = mtof(m); n = int(SR * (d + 0.25)); t = np.arange(n) / SR
    # upright pizz: few harmonics, quick attack, body resonance
    s = (np.sin(2 * np.pi * f * t) + 0.45 * np.sin(4 * np.pi * f * t) * np.exp(-t * 6) + 0.18 * np.sin(6 * np.pi * f * t) * np.exp(-t * 12))
    e = np.minimum(t / 0.004, 1) * np.exp(-t * 3.2)
    thump = lp(rs.randn(n), 600) * np.exp(-t * 60) * 0.3
    return (s * e + thump) * 0.55
def vibe(m, d=0.6, g=1.0):
    f = mtof(m); n = int(SR * (d + 0.6)); t = np.arange(n) / SR
    s = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * f * 4.0 * t) * np.exp(-t * 18) + 0.08 * np.sin(2 * np.pi * f * 10.0 * t) * np.exp(-t * 40)
    trem = 1 + 0.18 * np.sin(2 * np.pi * 5.2 * t)
    e = np.minimum(t / 0.002, 1) * np.exp(-t * 2.6)
    return s * e * trem * 0.32 * g
def brass(m, d=0.25, g=1.0):
    f = mtof(m); n = int(SR * (d + 0.15)); t = np.arange(n) / SR
    vib = 1 + 0.004 * np.sin(2 * np.pi * 5.5 * t)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    saw = sum((1 / k) * np.sin(k * ph) * (1 if k < 9 else 0.5) for k in range(1, 14))
    e = np.minimum(t / 0.012, 1) * np.where(t < d, 1.0, np.exp(-(t - d) * 30))
    w = np.exp(-t * 10); x = saw * e
    s = lp(x, 3200) * w + lp(x, 1400) * (1 - w)
    return s * 0.16 * g
def pad(ms, d, g=1.0):
    n = int(SR * d); t = np.arange(n) / SR; out = np.zeros(n)
    for m in ms:
        for det in (-0.08, 0.0, 0.08):
            f = mtof(m) * 2 ** (det / 12); ph = 2 * np.pi * f * t + rs.rand() * 6
            out += sum((1 / k) * np.sin(k * ph) for k in range(1, 8))
    e = np.minimum(t / 0.6, 1) * np.minimum((d - t) / 0.6, 1)
    return lp(out * e, 1500) * 0.03 * g
def noise_sweep(d, f0, f1, g=1.0, rev=False):
    n = int(SR * d); t = np.arange(n) / SR; x = rs.randn(n); out = np.zeros(n)
    blocks = 40; bl = n // blocks
    for b in range(blocks):
        u = b / blocks; fc = f0 * (f1 / f0) ** u
        seg = bp(x[b * bl:(b + 1) * bl + 2000] if b < blocks - 1 else x[b * bl:], max(fc * 0.7, 40), min(fc * 1.4, 20000))
        L_ = min(len(seg), n - b * bl); out[b * bl:b * bl + L_] += seg[:L_] * np.hanning(L_ * 2)[:L_] if False else seg[:L_]
    e = np.sin(np.pi * np.clip(t / d, 0, 1)) ** (1.5)
    if rev: e = np.clip(t / d, 0, 1) ** 2.2
    return out * e * 0.35 * g
def sine_sweep(f0, f1, d, g=1.0, curve=1.0):
    t = t_(d); f = f0 * (f1 / f0) ** ((t / d) ** curve); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) * np.exp(-t * 3 / d) * g
def chime(ms, step=0.06, g=1.0):
    out = np.zeros(int(SR * (step * len(ms) + 1.4)))
    for i, m in enumerate(ms):
        v = vibe(m, 0.8, 1.0); i0 = int(SR * i * step); out[i0:i0 + len(v)] += v[:len(out) - i0]
    return out * g

# ---------------------------------------------------------------- arrangement
PROG = [(38, [65, 69, 72, 76], [38, 41, 45, 48]),   # Dm7
        (34, [65, 69, 74, 77], [34, 38, 41, 45]),   # Bbmaj7
        (31, [65, 70, 74, 77], [31, 34, 38, 41]),   # Gm7
        (33, [64, 67, 73, 76], [33, 37, 40, 43])]   # A7
SW = 0.31  # swung offbeat delay (s)
def bar_time(b): return b * 2.0
def section(t): # intensity map
    if t < 3.5: return 'groove'
    if t < 8.0: return 'intro'
    if t < 21.9: return 'groove'
    if t < 24.0: return 'tension'
    if t < 32.0: return 'cool'
    if t < 36.0: return 'groove'
    return 'end'
MEL = [(0, 74), (0.5, None), (1.0, 77), (1.25, 76), (1.5, 74), (2.0, 73), (2.5, 74), (3.0, None),
       (4.0, 74), (4.5, 69), (5.0, 70), (5.25, 69), (5.5, 67), (6.0, 69), (7.0, None)]
for b in range(22):
    t0 = bar_time(b)
    root, chord, walk = PROG[b % 4]
    for beat in range(4):
        tb = t0 + beat * BEAT
        sec = section(tb)
        if sec in ('groove', 'cool', 'tension'):
            # bass walk (approach note on beat 4 every other bar)
            m = walk[beat]
            if beat == 3 and b % 2 == 1: m = PROG[(b + 1) % 4][2][0] + 1
            add(pluck_bass(m, 0.45), tb, 0.95 if sec != 'cool' else 0.8, -0.05)
            if sec == 'tension':
                add(pluck_bass(m + 12, 0.2), tb + 0.25, 0.4, 0.1)
        if sec == 'groove' or sec == 'tension':
            if beat in (0, 2): add(kick(0.75), tb, 0.8)
            if beat in (1, 3): add(snap(), tb, 0.55, 0.25)
            add(hat(), tb, 0.3, -0.3); add(hat(), tb + SW, 0.22, -0.3)
            if tb >= 13.9 and tb < 21.9:
                for k in range(4): add(shaker(), tb + k * 0.125, 0.25, 0.35)
        if sec == 'cool':
            if beat in (1, 3): add(snap(), tb, 0.5, 0.25)
            add(hat(), tb + SW, 0.18, -0.3)
        # vibes comp stabs on swung "and" of 2 and 4
        if sec in ('groove', 'cool') and beat in (1, 3):
            for i, m in enumerate(chord): add(vibe(m, 0.25, 0.55), tb + SW + i * 0.004, 0.55, -0.2 + i * 0.13)
    # melody: brass on groove bars from 10-22 & 32-36, vibes in cool section
    sec = section(t0 + 0.01)
    if (10.0 <= t0 < 21.9 or 32.0 <= t0 < 36.0 or t0 < 3.5) and b % 4 in (0, 2):
        for (bt, m) in MEL:
            if m is None: continue
            tt = t0 + bt * BEAT + (SW - 0.25 if (bt * 2) % 2 == 1 else 0)
            if section(tt) != 'groove': continue
            add(brass(m, 0.18, 1.0), tt, 0.9, 0.15)
    if 24.0 <= t0 < 32.0 and b % 4 in (0, 2):
        for (bt, m) in MEL:
            if m is None: continue
            tt = t0 + bt * BEAT + (SW - 0.25 if (bt * 2) % 2 == 1 else 0)
            add(vibe(m + 12, 0.4, 0.8), tt, 0.7, 0.2)

# intro (3.5–8): drone + clock ticks + reveal chime + riser
add(pad([50, 57, 62], 4.6, 1.2), 3.45, 1.0)
def clocktick():
    h = hat() * 0.8; c = bp(rs.randn(len(h)), 2500, 4000) * np.exp(-np.arange(len(h)) / 120) * 0.2; return h + c
for k in range(9): add(clocktick(), 3.5 + k * 0.5, 0.35, 0.4 * (-1) ** k)
add(pluck_bass(26, 1.5), 3.5, 1.1)
add(chime([62, 65, 69, 74, 77, 81], 0.05, 1.0), 4.5, 0.9, 0.1)
add(pluck_bass(38, 1.0), 5.5, 1.0); add(pluck_bass(34, 1.0), 6.5, 0.9); add(pluck_bass(31, 0.6), 7.0, 0.9); add(pluck_bass(33, 0.5), 7.5, 0.9)
riser = noise_sweep(2.45, 300, 9000, 1.3, rev=True); add(riser, 5.55, 0.65)
add(sine_sweep(110, 440, 2.4, 0.15, 2.0), 5.6, 0.6)
# title slams
for tt, g in ((8.0, 1.0), (8.5, 0.9)):
    add(kick(1.2), tt, 1.0); add(snap() * 1.4, tt, 0.6)
    for m in (50, 57, 62, 65): add(brass(m, 0.32, 1.4), tt, 0.9)
    add(hp(rs.randn(int(SR * 1.2)), 5000) * np.exp(-t_(1.2) * 3.5) * 0.25, tt, 0.7)
# fail: stop groove after found handled by ducking below; add low boom later
# end card (36–44): final chord + arpeggio
add(pad([38, 50, 57, 64, 65, 72], 7.6, 1.6), 36.0, 1.0)
add(pluck_bass(26, 3.0), 36.0, 1.0)
for i, m in enumerate([62, 65, 69, 72, 76, 77, 81, 84]): add(vibe(m, 1.5, 0.7), 36.15 + i * 0.12, 0.55, -0.4 + i * 0.1)
for i, m in enumerate([74, 77, 81]): add(vibe(m, 2.0, 0.5), 39.0 + i * 0.2, 0.45, 0.2)

music = np.vstack([L, R]).copy()
# duck music for the found moment (23.14 → 24.0) and gently under the end card tail
env = np.ones(N); tt = np.arange(N) / SR
fd = 23.14
env *= np.where((tt > fd) & (tt < 24.0), np.clip(1 - (tt - fd) / 0.08, 0.0, 1), 1)
env *= np.where(tt > 42.4, np.clip(1 - (tt - 42.4) / 1.55, 0, 1), 1)
music *= env
L[:] = 0; R[:] = 0

# ---------------------------------------------------------------- SFX from events
ev = json.load(open(sys.argv[1]))
def sfx(e):
    ty, t0 = e['type'], e['t']
    if ty == 'tap':
        s = np.sin(2 * np.pi * 1250 * t_(0.05)) * np.exp(-t_(0.05) * 90) + 0.4 * hp(rs.randn(int(SR * 0.01)), 3000).tolist().__len__() * 0
        add(s, t0, 0.5, 0.1)
        b = sine_sweep(420, 1150, 0.12, 0.6, 0.7); add(b, t0 + 0.02, 0.45, 0.0)
        add(chime([86], 0.0, 0.6), t0 + 0.06, 0.25, 0.3)
    elif ty == 'tapSecret':
        add(np.sin(2 * np.pi * 1250 * t_(0.05)) * np.exp(-t_(0.05) * 90), t0, 0.5)
    elif ty == 'wave':
        for k in range(14):
            m = [74, 76, 79, 81, 83, 86, 88][k % 7] + (12 if k > 9 else 0)
            add(vibe(m, 0.12, 0.5), t0 + k * 0.045 + rs.rand() * 0.01, 0.16, -0.7 + k * 0.1)
        add(noise_sweep(0.7, 800, 6000, 0.6), t0, 0.35, 0.0)
    elif ty in ('banner', 'banner2'):
        add(noise_sweep(0.3, 400, 4000, 0.8), t0 - 0.02, 0.35, 0)
        add(chime([81, 88], 0.07, 0.7), t0 + 0.12, 0.35, 0)
    elif ty == 'lock':
        for k, f in enumerate((1320, 990)):
            s = np.sign(np.sin(2 * np.pi * f * t_(0.08))) * 0.25 * np.exp(-t_(0.08) * 25); add(lp(s, 5000), t0 + k * 0.1, 0.32, 0.25)
    elif ty == 'hidden':
        add(chime([74, 77, 81, 86, 89], 0.045, 1.0), t0, 0.55, 0.2)
        add(hp(rs.randn(int(SR * 0.5)), 6000) * np.exp(-t_(0.5) * 7) * 0.4, t0, 0.3, 0.3)
    elif ty == 'huh':
        t = t_(0.32); f = 520 * (1 + 0.55 * np.clip(t / 0.25, 0, 1) ** 1.5) * (1 + 0.02 * np.sin(2 * np.pi * 9 * t))
        s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.minimum(t / 0.02, 1) * np.exp(-t * 4)
        add(s, t0, 0.22, -0.2)
    elif ty == 'found':
        # camera shutter + flash boom + sub drop
        add(hp(rs.randn(int(SR * 0.04)), 2000) * np.exp(-t_(0.04) * 120), t0 - 0.02, 0.7)
        add(hp(rs.randn(int(SR * 0.06)), 1500) * np.exp(-t_(0.06) * 90), t0 + 0.05, 0.6)
        add(sine_sweep(140, 32, 0.9, 1.0, 0.6), t0, 1.0)
        add(lp(rs.randn(int(SR * 1.2)), 900) * np.exp(-t_(1.2) * 3.5), t0, 0.6)
        for m in (38, 41, 44): add(brass(m, 0.5, 1.3), t0 + 0.02, 0.8)
    elif ty == 'shimmer':
        for k in range(8): add(vibe(93 + (k % 3) * 3, 0.15, 0.4), t0 + k * 0.09, 0.14, 0.5 * (-1) ** k)
    elif ty == 'split':
        add(chime([74, 78, 81, 86, 90, 93, 98], 0.035, 1.0), t0 + 0.05, 0.5, 0)
        add(noise_sweep(0.5, 1000, 9000, 1.0), t0, 0.35)
    elif ty in ('whoosh', 'cut', 'zoomout'):
        add(noise_sweep(0.45 if ty != 'cut' else 0.25, 300, 5000, 1.0), t0 - (0.2 if ty != 'cut' else 0.1), 0.4 if ty != 'cut' else 0.22)
    elif ty == 'reveal':
        add(hp(rs.randn(int(SR * 0.8)), 4000) * np.exp(-t_(0.8) * 6) * 0.4, t0, 0.18)
    elif ty == 'card':
        add(sine_sweep(180, 90, 0.12, 0.8), t0, 0.35); add(chime([84], 0.0, 0.5), t0 + 0.02, 0.18, 0.2)
    elif ty == 'pop':
        add(sine_sweep(380 + 60 * (int(t0 * 10) % 6), 1200, 0.1, 0.7, 0.6), t0, 0.35, rs.rand() - 0.5)
    elif ty == 'tick':
        add(np.sin(2 * np.pi * 2200 * t_(0.02)) * np.exp(-t_(0.02) * 200), t0, 0.22, 0.3)
    elif ty == 'post':
        add(noise_sweep(0.35, 500, 6000, 0.9), t0 - 0.1, 0.35); add(chime([81, 86], 0.06, 0.8), t0 + 0.2, 0.35)
    elif ty == 'lensswoop':
        add(noise_sweep(0.7, 200, 3000, 1.2), t0, 0.5)
    elif ty == 'iris':
        add(sine_sweep(90, 40, 0.9, 1.0, 0.7), t0 + 0.55, 0.8); add(noise_sweep(0.8, 3000, 150, 1.0), t0, 0.35)
    elif ty == 'logo':
        add(chime([74, 81, 86, 93], 0.09, 0.8), t0, 0.45)
        add(hp(rs.randn(int(SR * 1.6)), 6000) * np.exp(-t_(1.6) * 2.6) * 0.18, t0, 0.15)
    elif ty == 'slogan':
        add(kick(0.6), t0, 0.35)
    elif ty in ('slam', 'slam2'):
        pass
for e in ev: sfx(e)
fx = np.vstack([L, R])
mix = music * 0.9 + fx * 1.0
# simple room: short stereo early reflections on music only (gives a bit of space)
for d, g in ((0.017, 0.18), (0.029, 0.12), (0.043, 0.08)):
    k = int(SR * d); mix[0, k:] += music[1, :-k] * g; mix[1, k:] += music[0, :-k] * g
# fade in/out edges
mix[:, :240] *= np.linspace(0, 1, 240)
mix[:, -int(SR * 0.4):] *= np.linspace(1, 0, int(SR * 0.4))
# soft clip + normalise peak (loudness is finalised with ffmpeg loudnorm)
mix = np.tanh(mix * 1.1) / np.tanh(1.1)
mix /= max(1e-9, np.abs(mix).max()) / 0.89
import wave
pcm = (np.clip(mix.T, -1, 1) * 32767).astype('<i2')
with wave.open(sys.argv[2], 'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
print('wrote', sys.argv[2], mix.shape[1] / SR, 's')
