# Render stems with FluidSynth + GeneralUser GS, then mix and master.
# usage: python mix.py <stems_dir> <soundfont.sf2> <out.wav>
import sys, os, json, subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, fftconvolve

D, SF2, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
SR = 48000; DUR = 44.0; N = int(SR * DUR)
rs = np.random.RandomState(11)

def render(name, gain=0.9):
    mid = os.path.join(D, name + '.mid'); wav = os.path.join(D, name + '.wav')
    if not (os.path.exists(wav) and os.path.getmtime(wav) > os.path.getmtime(mid)): subprocess.run(['fluidsynth', '-ni', '-q', '-R', '0', '-C', '0', '-g', str(gain), '-r', str(SR),
                    '-O', 'float', '-T', 'wav', '-F', wav, SF2, mid], check=True)
    import warnings; warnings.filterwarnings('ignore')
    sr, x = wavfile.read(wav); assert sr == SR
    x = x.astype(np.float32).T if x.ndim == 2 else np.vstack([x, x]).astype(np.float32)
    out = np.zeros((2, N), np.float32); n = min(N, x.shape[1]); out[:, :n] = x[:, :n]
    return out

def sos(kind, f, order=2): return butter(order, f, btype=kind, fs=SR, output='sos')
def filt(x, s): return np.vstack([sosfilt(s, x[0]), sosfilt(s, x[1])]).astype(np.float32)
def pan(x, p):  # constant-power re-pan of a stereo stem toward p in [-1, 1]
    mono = x.mean(0); l = np.cos((p + 1) * np.pi / 4) * np.sqrt(2); r = np.sin((p + 1) * np.pi / 4) * np.sqrt(2)
    return np.vstack([0.5 * x[0] + 0.5 * mono * l, 0.5 * x[1] + 0.5 * mono * r]).astype(np.float32)
def db(v): return 10 ** (v / 20)

# ---------------------------------------------------------------- room reverb (stereo IR)
def make_ir(rt_low=2.1, rt_high=1.1, length=2.6, pre=0.012):
    n = int(SR * length); t = np.arange(n) / SR
    ir = np.zeros((2, n), np.float32)
    for ch in range(2):
        noise = rs.randn(n)
        lo = sosfilt(sos('low', 2500), noise) * np.exp(-6.9 * t / rt_low)
        hi = sosfilt(sos('high', 2500), noise) * np.exp(-6.9 * t / rt_high)
        tail = (lo + 0.6 * hi) * np.clip((t - pre) / 0.03, 0, 1)
        er = np.zeros(n)
        for k in range(14):  # early reflections
            d = pre + rs.uniform(0.004, 0.065); g = rs.uniform(0.25, 0.7) * np.exp(-d * 18)
            er[int(d * SR)] += g * (1 if rs.rand() > 0.5 else -1)
        ir[ch] = (tail * 0.35 + er).astype(np.float32)
    ir /= np.sqrt((ir ** 2).sum() / 2)
    return ir
IR = make_ir()
def reverb(x):
    y = np.vstack([fftconvolve(x[0], IR[0])[:N], fftconvolve(x[1], IR[1])[:N]]).astype(np.float32)
    return filt(y, sos('high', 180))

# ---------------------------------------------------------------- compressor (feed-forward, soft knee)
def compress(x, thr_db=-18, ratio=2.2, att=0.012, rel=0.18, makeup_db=2.0):
    lvl = np.abs(x).max(0) + 1e-9
    a_a = np.exp(-1 / (att * SR)); a_r = np.exp(-1 / (rel * SR))
    env = np.zeros_like(lvl); e = 0.0
    # vectorised-ish envelope via chunks (python loop on decimated signal)
    dec = 48; L = lvl[: (len(lvl) // dec) * dec].reshape(-1, dec).max(1)
    envd = np.zeros_like(L); aa = a_a ** dec; ar = a_r ** dec
    for i, v in enumerate(L):
        e = aa * e + (1 - aa) * v if v > e else ar * e + (1 - ar) * v; envd[i] = e
    env = np.repeat(envd, dec); env = np.pad(env, (0, len(lvl) - len(env)), mode='edge')
    edb = 20 * np.log10(env + 1e-9)
    over = np.maximum(0, edb - thr_db)
    gain_db = -over * (1 - 1 / ratio) + makeup_db
    return (x * db(gain_db)).astype(np.float32)

# ---------------------------------------------------------------- synthesized foley (non-musical cues only)
def air(d=0.55):
    n = int(SR * d); t = np.arange(n) / SR
    noise = rs.randn(2, n)
    # pink-ish noise, band moving upward then down, smooth envelope
    out = np.zeros((2, n))
    for ch in range(2):
        x = sosfilt(sos('low', 6000), noise[ch]); x = sosfilt(sos('high', 350), x)
        seg = 8; L = n // seg
        for k in range(seg):
            u = k / (seg - 1); fc = 700 + 2600 * np.sin(np.pi * u)
            blk = sosfilt(sos('band', [fc * 0.6, fc * 1.6], 1), x[k * L:(k + 1) * L + 1200])[: min(L + 1200, n - k * L)]
            w = np.hanning(len(blk)); out[ch, k * L:k * L + len(blk)] += blk * w
    env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 1.6
    return (out * env * 0.22).astype(np.float32)
def shutter():
    n = int(SR * 0.22); out = np.zeros((2, n))
    def click(at, f, g):
        i = int(at * SR); L = int(SR * 0.012); imp = rs.randn(L) * np.exp(-np.arange(L) / (SR * 0.0016))
        c = sosfilt(sos('band', [f * 0.7, f * 1.4], 2), imp) * g
        out[0, i:i + L] += c; out[1, i:i + L] += c * 0.9
    click(0.0, 3200, 1.0); click(0.004, 7000, 0.5)
    i = int(0.012 * SR); L = int(SR * 0.04); mech = sosfilt(sos('band', [1500, 5000], 2), rs.randn(L)) * np.exp(-np.arange(L) / (SR * 0.008)) * 0.25
    out[0, i:i + L] += mech; out[1, i:i + L] += mech
    click(0.058, 2600, 0.8); click(0.061, 6000, 0.35)
    return (out * 0.9).astype(np.float32)

# ---------------------------------------------------------------- render + mix
stems = {k: render(k) for k in ('drums', 'bass', 'keys', 'lead', 'color', 'sfx_sf')}
for k, x in stems.items():
    r = np.sqrt((x ** 2).mean()) + 1e-9; print(f'{k:7s} rms {20*np.log10(r):6.1f} dBFS  peak {20*np.log10(np.abs(x).max()+1e-9):6.1f}')
# per-stem processing: level, EQ, pan, reverb send
P = {
    'drums': dict(gain=6.0, hp=35, pan=0.0, send=0.10),
    'bass':  dict(gain=-5.0, hp=30, pan=0.0, send=0.04),
    'keys':  dict(gain=-2.5, hp=140, pan=-0.15, send=0.22),
    'lead':  dict(gain=0.0, hp=180, pan=0.12, send=0.26),
    'color': dict(gain=-1.0, hp=120, pan=-0.1, send=0.30),
    'sfx_sf': dict(gain=-2.0, hp=200, pan=0.05, send=0.14),
}
dry = np.zeros((2, N), np.float32); wet_in = np.zeros((2, N), np.float32); sfx_bus = np.zeros((2, N), np.float32)
for k, x in stems.items():
    p = P[k]; y = filt(x, sos('high', p['hp'])) * db(p['gain'])
    if p['pan']: y = pan(y, p['pan'])
    if k == 'lead': y = filt(y, sos('low', 9000))
    (sfx_bus if k == 'sfx_sf' else dry)[:] += y
    wet_in += y * p['send']
cues = json.load(open(os.path.join(D, 'synth_cues.json')))
for t, kind, g in cues:
    s = air() if kind == 'air' else shutter()
    i = int(t * SR); n = min(s.shape[1], N - i)
    if n > 0: sfx_bus[:, i:i + n] += s[:, :n] * g
    if n > 0 and kind == 'air': wet_in[:, i:i + n] += s[:, :n] * g * 0.15
music = dry
# gentle ducking of the music under the FOUND hit's shutter and during the end-card hold tail
mix = compress(music, thr_db=-20, ratio=2.0, makeup_db=1.5) + reverb(wet_in) * 0.9 + sfx_bus
# master EQ (RBJ biquads): -2 dB bell at 350 Hz (de-box the comping register), +2 dB shelf above 7 kHz (ride air)
from scipy.signal import lfilter
def peq(x, f0, gdb, q):
    A = 10 ** (gdb / 40); w = 2 * np.pi * f0 / SR; al = np.sin(w) / (2 * q)
    b = [1 + al * A, -2 * np.cos(w), 1 - al * A]; a = [1 + al / A, -2 * np.cos(w), 1 - al / A]
    return np.vstack([lfilter(b, a, x[0]), lfilter(b, a, x[1])]).astype(np.float32)
def hshelf(x, f0, gdb):
    A = 10 ** (gdb / 40); w = 2 * np.pi * f0 / SR; al = np.sin(w) / 2 * np.sqrt(2); c = np.cos(w)
    b = [A * ((A + 1) + (A - 1) * c + 2 * np.sqrt(A) * al), -2 * A * ((A - 1) + (A + 1) * c), A * ((A + 1) + (A - 1) * c - 2 * np.sqrt(A) * al)]
    a = [(A + 1) - (A - 1) * c + 2 * np.sqrt(A) * al, 2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - 2 * np.sqrt(A) * al]
    return np.vstack([lfilter(b, a, x[0]), lfilter(b, a, x[1])]).astype(np.float32)
mix = hshelf(peq(mix, 350, -2.0, 0.9), 7000, 2.0)
# end fade and tiny fade-in
tt = np.arange(N) / SR
mix *= np.clip((DUR - 0.05 - tt) / 1.6, 0, 1)[None, :]
mix[:, :200] *= np.linspace(0, 1, 200)[None, :]
# soft peak limiter
pk = np.abs(mix).max(); mix = mix / max(pk, 1e-9) * 0.95
mix = np.tanh(mix * 1.15) / np.tanh(1.15)
wavfile.write(OUT, SR, (np.clip(mix.T, -1, 1) * 32767).astype(np.int16))
print('wrote', OUT)
