# "Tosheez: Nobody Knows" — original score v2 (sampled instruments, humanized)
# Writes one MIDI file per stem; render.sh renders them with FluidSynth + GeneralUser GS,
# mix.py does reverb / EQ / compression / mastering.
# 120 BPM swing, D minor spy-caper. 1 bar = 2.0 s, 1 beat = 0.5 s.
import json, random, sys, os
import mido

OUT = sys.argv[1] if len(sys.argv) > 1 else 'stems'
EVENTS = sys.argv[2] if len(sys.argv) > 2 else 'events.json'
os.makedirs(OUT, exist_ok=True)
random.seed(2026)
BPM, PPQ = 120, 480
SPB = 60 / BPM            # seconds per beat
SW = 0.64                 # swing: offbeat 8th lands at 64% of the beat

def sw(beat):
    """beat position with swung offbeats (x.5 -> x.64)"""
    whole = int(beat); frac = beat - whole
    if abs(frac - 0.5) < 1e-6: frac = SW
    return whole + frac

class Stem:
    def __init__(self, name):
        self.name = name; self.notes = []; self.progs = []; self.cc = []
    def prog(self, ch, program, t=0.0): self.progs.append((t, ch, program))
    def note(self, ch, t, dur, pitch, vel, human=0.007, vhuman=7):
        if human: t = max(0.0, t + random.gauss(0, human))
        vel = int(max(1, min(127, vel + random.randint(-vhuman, vhuman))))
        self.notes.append((t, ch, pitch, vel, max(0.03, dur)))
    def control(self, ch, t, num, val): self.cc.append((t, ch, num, val))
    def save(self):
        mid = mido.MidiFile(ticks_per_beat=PPQ); tr = mido.MidiTrack(); mid.tracks.append(tr)
        tr.append(mido.MetaMessage('set_tempo', tempo=int(SPB * 1e6), time=0))
        ev = []
        for t, ch, p in self.progs: ev.append((t, 0, mido.Message('program_change', channel=ch, program=p)))
        for t, ch, n, v in self.cc: ev.append((t, 1, mido.Message('control_change', channel=ch, control=n, value=v)))
        for t, ch, p, v, d in self.notes:
            ev.append((t, 3, mido.Message('note_on', channel=ch, note=p, velocity=v)))
            ev.append((t + d, 2, mido.Message('note_off', channel=ch, note=p, velocity=0)))
        ev.append((46.5, 9, mido.MetaMessage('marker', text='end')))
        ev.sort(key=lambda e: (e[0], e[1]))
        last = 0
        for t, _, m in ev:
            tick = int(round(t / SPB * PPQ)); m.time = max(0, tick - last); last = tick; tr.append(m)
        mid.save(os.path.join(OUT, self.name + '.mid'))

def T(bar, beat=0.0): return bar * 4 * SPB + sw(beat) * SPB

# MIDI note helpers
N = {'C':0,'C#':1,'Db':1,'D':2,'D#':3,'Eb':3,'E':4,'F':5,'F#':6,'Gb':6,'G':7,'G#':8,'Ab':8,'A':9,'A#':10,'Bb':10,'B':11}
def m(s):  # 'D5' -> 74
    name, octv = s[:-1], int(s[-1]); return 12 * (octv + 1) + N[name]

# ---------------------------------------------------------------- harmony
# 8-bar form: the minor line cliché, then ii-V
FORM = [
    ('Dm',     ['D2','A2','D3','C#3'], ['F3','A3','C4','E4']),
    ('DmMaj7', ['D2','F2','A2','C#3'], ['F3','A3','C#4','E4']),
    ('Dm7',    ['D2','C3','A2','F2'],  ['F3','A3','C4','E4']),
    ('Dm6',    ['D2','B2','A2','G#2'], ['F3','A3','B3','E4']),
    ('Gm7',    ['G2','Bb2','D3','F3'], ['F3','Bb3','D4','A4']),
    ('A7',     ['A2','C#3','E3','G3'], ['G3','C#4','F4','Bb4']),
    ('Dm9',    ['D2','F2','A2','B2'],  ['F3','A3','C4','E4']),
    ('A7',     ['A2','E2','G2','C#3'], ['G3','C#4','F4','Bb4']),
]

drums = Stem('drums'); bass = Stem('bass'); keys = Stem('keys'); lead = Stem('lead'); color = Stem('color')
# channels / programs (GeneralUser GS)
DR = 9
drums.prog(DR, 32)                    # Jazz kit
bass.prog(0, 32)                      # Acoustic (upright) bass
keys.prog(1, 4); keys.prog(2, 11)     # Tine EP, Vibraphone
lead.prog(3, 59); lead.prog(4, 71)    # Muted trumpet, Clarinet
color.prog(5, 45); color.prog(6, 8); color.prog(7, 119); color.prog(8, 47)  # Pizzicato, Celeste, Reverse cymbal, Timpani
# GM drum notes
KICK, SIDE, SNARE, BRUSH_TAP, BRUSH_SLAP, BRUSH_SWIRL, HH_PED, HH_CL, RIDE, RIDE_BELL, CRASH, TOM_L, TOM_M, TOM_H = 36, 37, 38, 38, 39, 40, 44, 42, 51, 53, 49, 45, 47, 50

def kit(prog, t): drums.prog(DR, prog, t)

def ride_bar(bar, vel=58, ride=RIDE):
    for b in (0, 1, 1.5, 2, 3, 3.5):
        acc = 10 if b in (1, 3) else 0
        drums.note(DR, T(bar, b), 0.4, ride, vel + acc - (12 if b % 1 else 0), human=0.004)
    for b in (1, 3): drums.note(DR, T(bar, b), 0.1, HH_PED, 52, human=0.004)
    for b in range(4): drums.note(DR, T(bar, b), 0.2, KICK, 30, human=0.004, vhuman=5)   # feathered kick

def comp_snare(bar, density=0.45, vel=40):
    for b in (0.5, 1.5, 2.5, 3.5, 1, 3):
        if random.random() < density: drums.note(DR, T(bar, b), 0.1, SNARE, vel + random.randint(-12, 10), human=0.006)

def brush_bar(bar, vel=50):
    for b in range(4):
        drums.note(DR, T(bar, b), 0.45, BRUSH_SWIRL, vel - 14, human=0.006)
    for b in (1, 3): drums.note(DR, T(bar, b), 0.15, BRUSH_SLAP, vel + 6, human=0.005)
    for b in (1.5, 3.5):
        if random.random() < 0.7: drums.note(DR, T(bar, b), 0.1, BRUSH_TAP, vel - 10, human=0.006)
    for b in (1, 3): drums.note(DR, T(bar, b), 0.1, HH_PED, 44, human=0.004)
    drums.note(DR, T(bar, 0), 0.2, KICK, 30, human=0.004)

def fill(bar, start=2.0, vel=62):
    seq = [(start, SNARE), (start + 0.5, SNARE), (start + 1.0, TOM_M), (start + 1.33, TOM_M), (start + 1.66, TOM_L)]
    for b, n in seq:
        if b < 4: drums.note(DR, T(bar, 0) + b * SPB, 0.12, n, vel + random.randint(-6, 6), human=0.004)

def walk(bar, chord_idx, vel=78, two_feel=False):
    _, line, _ = FORM[chord_idx % 8]
    if two_feel:
        bass.note(0, T(bar, 0), 0.9, m(line[0]), vel); bass.note(0, T(bar, 2), 0.9, m(line[2]), vel - 6)
        return
    for b in range(4):
        bass.note(0, T(bar, b), 0.42, m(line[b]), vel - (8 if b % 2 else 0), human=0.006)
    if random.random() < 0.35:   # a ghosted skip note before beat 4
        bass.note(0, T(bar, 2.5), 0.12, m(line[2]) , vel - 30, human=0.004)

def rhodes(bar, chord_idx, vel=56, pattern=((0, 0.35), (1.5, 0.3), (3.5, 0.25))):
    _, _, voicing = FORM[chord_idx % 8]
    for b, d in pattern:
        for i, n in enumerate(voicing):
            keys.note(1, T(bar, b) + i * 0.006, d, m(n), vel - i * 2, human=0.005, vhuman=5)

def vibes(t, notes, dur=0.9, vel=60):
    for i, n in enumerate(notes): keys.note(2, t + i * 0.012, dur, m(n), vel, human=0.004)

def melody(bar0, phrase, ch=3, vel=88, octave=0):
    for (b, n, d) in phrase:
        bar = bar0 + int(b // 4); beat = b - 4 * int(b // 4)
        lead.note(ch, T(bar, beat), d * SPB, m(n) + 12 * octave, vel + (6 if d >= 1 else 0), human=0.009, vhuman=6)

# phrases (beat, note, duration-in-beats) over 2 bars
A1 = [(0, 'A4', .3), (0.5, 'D5', .3), (1.5, 'F5', .8), (2.5, 'E5', .3), (3, 'D5', .3), (3.5, 'C#5', 1.2),
      (5, 'D5', 1.4), (6.5, 'A4', .3), (7, 'Bb4', .3), (7.5, 'A4', .4)]
A2 = [(0.5, 'G4', .3), (1, 'A4', .3), (1.5, 'C5', .5), (2.5, 'D5', 1.2), (4, 'B4', 1.3), (6, 'A4', .3), (6.5, 'G#4', .3), (7, 'A4', .9)]
B1 = [(0, 'A4', 1.0), (1.5, 'Bb4', .3), (2, 'D5', .3), (2.5, 'G5', 1.1), (4, 'F5', .3), (4.5, 'E5', .3), (5, 'C#5', .3), (5.5, 'A4', .5), (6.5, 'Bb4', .3), (7, 'C#5', .8)]
B2 = [(0, 'D5', 1.6), (2.5, 'F5', .3), (3, 'E5', .3), (3.5, 'D5', .3), (4, 'C#5', .6), (5, 'E5', .3), (5.5, 'A4', 1.5)]
TAG = [(0, 'A4', .3), (0.5, 'D5', .3), (1.5, 'F5', .4), (2.5, 'E5', .4), (3.5, 'D5', 3.0)]

# ---------------------------------------------------------------- arrangement
# Bars 0–1 (0–3.5 s): hook groove
for bar in (0, 1):
    ride_bar(bar, 60); comp_snare(bar, 0.4)
    walk(bar, bar); rhodes(bar, bar)
melody(0, A1[:7])
# stop-time hit on 3.5 s (bar 1 beat 3) then silence for the cut
t_hit = T(1, 3)
drums.note(DR, t_hit, 0.6, CRASH, 70, human=0); drums.note(DR, t_hit, 0.2, KICK, 70, human=0)
bass.note(0, t_hit, 0.6, m('D2'), 90, human=0)
for i, n in enumerate(['F3', 'A3', 'C#4', 'E4']): keys.note(1, t_hit + i * 0.004, 0.5, m(n), 70, human=0)

# 3.5–5.5 s: "Last seen in 2011." — tiptoe pizzicato line cliché + clock ticks
line_cliche = ['D4', 'C#4', 'C4', 'B3']
for k in range(4):
    color.note(5, 3.5 + k * 0.5, 0.3, m(line_cliche[k]), 62, human=0.004)
    color.note(5, 3.5 + k * 0.5 + 0.25 * 1.28, 0.2, m('A4') if k % 2 == 0 else m('F4'), 44, human=0.004)
for k in range(4): drums.note(DR, 3.5 + k * 0.5, 0.05, SIDE, 22 + (5 if k % 2 else 0), human=0.002)
bass.note(0, 3.5, 1.8, m('D2'), 70, human=0)
# 4.5 s reveal: vibraphone + celeste bloom (Dm9)
vibes(4.5, ['D4', 'F4', 'A4', 'C5', 'E5'], 1.8, 58)
for i, n in enumerate(['A5', 'D6', 'E6', 'A6']): color.note(6, 4.52 + i * 0.07, 0.6, m(n), 40, human=0.003)
for k in range(2):
    color.note(5, 4.5 + k * 0.5, 0.3, m(['A3', 'G#3'][k]), 56, human=0.004)
# 5.5–8.0 s: pull-back build — brush swirl, bass 8ths on D, rising line cliché in the Rhodes, reverse cymbal
kit(40, 5.45)
for k in range(10):
    t = 5.5 + k * 0.25
    bass.note(0, t, 0.18, m('D2') if k % 4 != 3 else m('A1'), 64 + k * 2, human=0.004)
for k in range(5): drums.note(DR, 5.5 + k * 0.5, 0.48, BRUSH_SWIRL, 34 + k * 7, human=0.004)
for k in range(5): drums.note(DR, 5.5 + k * 0.5 + 0.32, 0.1, BRUSH_TAP, 30 + k * 6, human=0.004)
for k, (t, v) in enumerate([(5.5, ['F3', 'A3', 'D4']), (6.0, ['F3', 'A3', 'C#4']), (6.5, ['F3', 'A3', 'C4']), (7.0, ['F3', 'A3', 'B3']), (7.5, ['G3', 'Bb3', 'D4'])]):
    for i, n in enumerate(v): keys.note(1, t + i * 0.005, 0.42, m(n), 50 + k * 4, human=0.004)
color.note(7, 8.0 - 1.62, 1.62, m('C4'), 96, human=0)  # reverse cymbal lands on the title
color.note(8, 7.0, 1.0, m('D2'), 40, human=0)            # timpani swell
for k in range(8): color.note(8, 7.0 + k * 0.125, 0.12, m('D2'), 36 + k * 6, human=0.002)

# 8.0–10.0 s: title — two hits ("Nobody" / "knows."), then the band settles into the groove
kit(32, 7.98)
for th, v in ((8.0, 100), (8.5, 92)):
    drums.note(DR, th, 1.2, CRASH, v - 10, human=0); drums.note(DR, th, 0.2, KICK, v - 15, human=0)
    bass.note(0, th, 0.45, m('D2'), v, human=0)
    for i, n in enumerate(['F3', 'A3', 'C4', 'E4']): keys.note(1, th + i * 0.004, 0.42, m(n), v - 20, human=0)
    lead.note(3, th, 0.4, m('D5') if th == 8.0 else m('A5'), v - 8, human=0)
ride_bar(4, 54)
for b in range(2, 4): bass.note(0, T(4, b), 0.42, m(['A2', 'C#3'][b - 2]), 72)
rhodes(4, 7, 50, pattern=((1.5, 0.3), (3.5, 0.25)))
for b in (2.5, 3.0, 3.5): lead.note(3, T(4, b), 0.2, m({2.5: 'E5', 3.0: 'F5', 3.5: 'E5'}[b]), 72)
fill(4, 2.0, 58)

# 10.0–21.9 s: main groove, 8-bar form with the trumpet theme (bars 5–10)
for i, bar in enumerate(range(5, 11)):
    ci = i  # chord index in the form
    if bar < 9 or bar == 9:
        ride_bar(bar, 58 + (4 if bar >= 7 else 0)); comp_snare(bar, 0.42 + (0.15 if bar >= 7 else 0))
    walk(bar, ci); rhodes(bar, ci)
melody(5, A1); melody(7, B1)
# bar 7–8 add clarinet counter-line (lower, legato)
for (b, n, d) in [(0, 'D4', 1.8), (2, 'F4', 1.8), (4, 'E4', 1.8), (6, 'G4', 1.8)]:
    bar = 7 + int(b // 4); lead.note(4, T(bar, b - 4 * int(b // 4)), d * SPB, m(n), 54, human=0.008)
fill(8, 2.5, 60)
# 18.9–21.9 s: "Some traits hold a secret." — drop to brushes, bass two-feel, vibes; celeste on the split
kit(40, T(9, 0) - 0.02)
for bar in (9, 10):
    brush_bar(bar, 48)
    walk(bar, 6 + (bar - 9), 70, two_feel=True)
    rhodes(bar, 6 + (bar - 9), 46, pattern=((0, 0.6), (2.5, 0.4)))
vibes(T(9, 1.5), ['A4', 'C5', 'E5'], 0.6, 50); vibes(T(9, 3.5), ['G4', 'B4', 'E5'], 0.6, 46)
vibes(T(10, 1.5), ['G4', 'C#5', 'F5'], 0.6, 50)
# (split sparkle is in the sfx stem, timed to the tap)

# 21.9–24.0 s: the fail — tension ostinato, then the hit on FOUND and silence
kit(32, 21.88)
t0 = 21.9
for k in range(10):
    t = t0 + k * 0.125 * 1.0
for k in range(int((23.14 - t0) / 0.25)):
    t = t0 + k * 0.25
    bass.note(0, t, 0.2, m(['D2', 'D2', 'C#2', 'C2'][k % 4]), 74 + k, human=0.003)
    drums.note(DR, t, 0.1, SNARE if k % 2 else SIDE, 36 + k * 2, human=0.003)
    if k % 2 == 0: drums.note(DR, t, 0.3, RIDE, 50, human=0.003)
for i, (t, v) in enumerate([(21.9, ['F3', 'A3', 'C#4']), (22.4, ['F3', 'A3', 'C4']), (22.9, ['F3', 'Ab3', 'B3'])]):
    for j, n in enumerate(v): keys.note(1, t + j * 0.005, 0.4, m(n), 52 + i * 6, human=0.004)
tf = 23.14
drums.note(DR, tf, 1.4, CRASH, 108, human=0); drums.note(DR, tf, 0.3, KICK, 110, human=0); drums.note(DR, tf, 0.2, SNARE, 100, human=0)
bass.note(0, tf, 0.9, m('D1') if False else m('D2'), 110, human=0)
for i, n in enumerate(['D3', 'Ab3', 'C#4', 'G4']): keys.note(1, tf + i * 0.003, 0.7, m(n), 92, human=0)
lead.note(3, tf, 0.8, m('Ab5'), 104, human=0); lead.note(4, tf, 0.8, m('D4'), 90, human=0)
color.note(8, tf, 1.2, m('D2'), 110, human=0)

# 24.0–32.0 s: leaderboard / result — laid-back brushes, two-feel bass, vibes answer melody
kit(40, 23.98)
for i, bar in enumerate(range(12, 16)):
    brush_bar(bar, 46)
    walk(bar, i, 70, two_feel=(i % 2 == 0))
    rhodes(bar, i, 48, pattern=((0, 0.5), (1.5, 0.3), (3.5, 0.25)))
for (b, n, d) in [(0.5, 'A4', .3), (1, 'D5', .3), (1.5, 'F5', 1.0), (4.5, 'E5', .3), (5, 'D5', .3), (5.5, 'C#5', 1.4),
                  (8.5, 'C5', .3), (9, 'D5', .3), (9.5, 'E5', 1.0), (12, 'D5', .4), (12.5, 'B4', .4), (13, 'A4', 2.2)]:
    bar = 12 + int(b // 4); keys.note(2, T(bar, b - 4 * int(b // 4)), d * SPB + 0.3, m(n), 58, human=0.006)
fill(15, 2.5, 52)

# 32.0–35.2 s: outro — theme returns with the full band
kit(32, 31.98)
drums.note(DR, 32.0, 1.0, CRASH, 84, human=0)
for i, bar in enumerate(range(16, 18)):
    ride_bar(bar, 62); comp_snare(bar, 0.5, 46)
    walk(bar, i, 82); rhodes(bar, i, 58)
melody(16, A1[:8], vel=92)
# 35.0 s: band stops, low D under the iris; 36.0 s: final chord for the end card
for i, n in enumerate(['F3', 'A3', 'C4', 'E4']): keys.note(1, 35.0 + i * 0.004, 0.25, m(n), 66, human=0)
drums.note(DR, 35.0, 0.3, KICK, 60, human=0); bass.note(0, 35.0, 0.9, m('D2'), 84, human=0)
color.note(7, 36.0 - 1.62, 1.62, m('C4'), 80, human=0)  # reverse cymbal into the end card
# end card: Dm(maj9) bloom, ride shimmer, trumpet tag resolving to D
t_end = 36.0
bass.note(0, t_end, 6.5, m('D2'), 80, human=0)
for i, n in enumerate(['F3', 'A3', 'C#4', 'E4', 'A4']): keys.note(1, t_end + i * 0.03, 6.8, m(n), 58, human=0)
vibes(t_end + 0.05, ['D5', 'E5', 'A5'], 4.0, 48)
for k in range(16): drums.note(DR, t_end + k * 0.18, 0.4, RIDE, 30 - k, human=0.004)
drums.note(DR, t_end, 3.5, CRASH, 50, human=0)
for (b, n, d) in TAG: lead.note(3, t_end + 0.9 + b * SPB, d * SPB, m(n), 72, human=0.008)
for i, n in enumerate(['D6', 'A6']): color.note(6, t_end + 3.6 + i * 0.12, 1.0, m(n), 34, human=0)

for s in (drums, bass, keys, lead, color): s.save()

# ---------------------------------------------------------------- SFX (sampled where possible)
ev = json.load(open(EVENTS))
sfx = Stem('sfx_sf')
sfx.prog(0, 115); sfx.prog(1, 11); sfx.prog(2, 8); sfx.prog(3, 45)   # wood block, vibraphone, celeste, pizzicato
synth_cues = []  # whoosh / shutter rendered in mix.py
for e in ev:
    t, ty = e['t'], e['type']
    if ty == 'tap':
        sfx.note(0, t, 0.08, m('A5'), 46, human=0, vhuman=4)
    elif ty == 'tapSecret':
        sfx.note(0, t, 0.08, m('C6'), 46, human=0)
    elif ty in ('banner', 'banner2'):
        sfx.note(3, t + 0.05, 0.2, m('A5'), 40, human=0); sfx.note(3, t + 0.05 + 0.12, 0.2, m('D6'), 34, human=0)
    elif ty == 'wave':
        synth_cues.append((t, 'air', 0.55))
    elif ty == 'lock':
        sfx.note(0, t, 0.06, m('E5'), 34, human=0); sfx.note(0, t + 0.11, 0.06, m('E5'), 28, human=0)
    elif ty == 'hidden':
        sfx.note(1, t, 0.9, m('A5'), 62, human=0); sfx.note(1, t + 0.09, 1.1, m('D6'), 58, human=0)
    elif ty == 'shimmer':
        for i, n in enumerate(['A6', 'D7', 'A6']): sfx.note(2, t + i * 0.14, 0.4, m(n), 30, human=0)
    elif ty == 'split':
        for i, n in enumerate(['D6', 'F6', 'A6', 'C7', 'D7', 'F7']): sfx.note(2, t + 0.04 + i * 0.045, 0.6, m(n), 48 - i * 2, human=0)
        synth_cues.append((t, 'air', 0.45))
    elif ty == 'found':
        synth_cues.append((t - 0.01, 'shutter', 1.0))
    elif ty == 'pop':
        k = int(round((t - 8.9) / 0.15))
        sfx.note(3, t, 0.2, m(['D5', 'F5', 'A5', 'D6', 'F6', 'A6'][max(0, min(5, k))]), 52, human=0)
    elif ty == 'tick':
        sfx.note(0, t, 0.04, m('E6'), 22, human=0, vhuman=2)
    elif ty == 'post':
        synth_cues.append((t - 0.12, 'air', 0.5)); sfx.note(1, t + 0.15, 0.8, m('A5'), 50, human=0)
    elif ty in ('whoosh', 'zoomout', 'lensswoop'):
        synth_cues.append((t - 0.18, 'air', 0.6 if ty != 'lensswoop' else 0.7))
sfx.save()
json.dump(synth_cues, open(os.path.join(OUT, 'synth_cues.json'), 'w'))
print('stems written to', OUT)
