# Instrument bank

The score is rendered with **GeneralUser GS v2.0.3** by S. Christian Collins (FluidSynth 2.3.4). The 32 MB bank is not bundled. Download the pinned copy to `audio/soundfont/GeneralUser-GS.sf2`:

https://raw.githubusercontent.com/mrbumpy409/GeneralUser-GS/684543d5e5efaef08d02be50dcda8d552478fa60/GeneralUser-GS.sf2

- Expected bytes: 32319396
- Expected SHA-256: `9575028c7a1f589f5770fccc8cff2734566af40cd26ed836944e9a5152688cfe`

The licence is in `GeneralUser-GS-LICENSE.txt` ("You may use GeneralUser GS without restriction for your own music creation, private or commercial.").

Instruments used: Acoustic Bass, Jazz Kit, Brush Kit, Tine Electric Piano, Vibraphone, Muted Trumpet, Clarinet, Pizzicato Strings, Celeste, Reverse Cymbal, Timpani and Wood Block.
