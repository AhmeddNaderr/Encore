// Tosheez: Nobody Knows — core engine (deterministic, pure function of time)
'use strict';
const W = 1920, H = 1080;
const COL = {
  cream: '#F2EEE6', ink: '#111111', blue: '#5DABD8', blueDeep: '#3E8FC0', white: '#FFFFFF',
  grey: '#8A8782', soft: '#E6E1D6', coral: '#F0574B', gold: '#E9B949'
};
const PASTELS = ['#B5E7FE', '#FED5D3', '#D4CCFD', '#C9FBC0', '#F6F3C2', '#FFEEDA', '#FFE0F4', '#DCDCDC'];
const ORDER = ['back', 'base', 'hair', 'fit', 'mouth', 'eyes', 'hat'];
const CAROUSEL = {
  hat: ['hat_cone', 'hat_crown', 'hat_hardhat', 'hat_viking', 'hat_halo'],
  eyes: ['eyes_pixel', 'eyes_3d', 'eyes_heart', 'eyes_gradient', 'eyes_shades'],
  fit: ['fit_trench', 'fit_hoodie', 'fit_leather', 'fit_prison', 'fit_suit']
};
const TRAIT_NAME = {
  hat_crown: 'Crown', hat_hardhat: 'Hard Hat', hat_cone: 'Traffic Cone', hat_viking: 'Viking Helmet', hat_halo: 'Halo',
  hat_foil: 'Foil Hat', hat_laurel: 'Laurel', hat_bikehelmet: 'Bike Helmet',
  eyes_pixel: 'Pixel Shades', eyes_3d: '3D Glasses', eyes_heart: 'Heart Glasses', eyes_gradient: 'Gradient Shades',
  eyes_shades: 'Black Shades', eyes_clear: 'Clear Glasses', eyes_blindfold: 'Blindfold',
  fit_trench: 'Trench Coat', fit_hoodie: 'Hoodie', fit_leather: 'Leather Jacket', fit_prison: 'Prison Stripes',
  fit_suit: 'Suit', fit_raincoat: 'Raincoat', fit_fleece: 'Fleece', fit_robe: 'Bathrobe', fit_vest: 'Puffer Vest',
  fit_overalls: 'Overalls', fit_tattoo: 'Tattoos', fit_anatomy: 'Anatomy'
};
const TREND_WORD = {
  hat_crown: 'Crowns', hat_hardhat: 'Hard hats', hat_cone: 'Cones', hat_viking: 'Vikings', hat_halo: 'Halos',
  eyes_3d: '3D glasses', eyes_pixel: 'Pixel shades', eyes_heart: 'Heart glasses', eyes_gradient: 'Gradients', eyes_shades: 'Shades',
  fit_hoodie: 'Hoodies', fit_leather: 'Leather', fit_prison: 'Stripes', fit_suit: 'Suits', fit_trench: 'Trench coats'
};

// ---------- utils
const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a, b, t) => a + (b - a) * t;
const ease = {
  inOut: t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
  out: t => 1 - Math.pow(1 - t, 3),
  in: t => t * t * t,
  outBack: t => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  outElastic: t => t === 0 ? 0 : t === 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - .75) * (2 * Math.PI / 3)) + 1,
  outQuint: t => 1 - Math.pow(1 - t, 5),
  inOutSine: t => -(Math.cos(Math.PI * t) - 1) / 2
};
const seg = (t, a, b) => clamp((t - a) / (b - a));
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const hash = (i, s = 0) => { let x = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return x - Math.floor(x); };

// ---------- assets
const A = { layers: {}, meta: null, mips: {}, img: {} };
function loadImage(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('load ' + src)); i.src = src; }); }
async function loadAssets() {
  A.meta = await (await fetch('assets/layers.json')).json();
  const keys = Object.keys(A.meta.layers);
  await Promise.all(keys.map(async k => { A.layers[k] = await loadImage('assets/layers/' + k + '.png'); }));
  A.img.wordmark = await loadImage('assets/logo/tosheez_mask.png');
  A.img.encore = await loadImage('assets/logo/encore_mark.png');
  // mip levels for each layer: 1024 (orig), 512, 256
  for (const k of keys) {
    const im = A.layers[k], m = A.meta.layers[k];
    A.mips[k] = { 1024: im };
    let src = im;
    for (const lvl of [512, 256]) {
      const s = lvl / 1024, c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(m.w * s)); c.height = Math.max(1, Math.round(m.h * s));
      const g = c.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(src, 0, 0, c.width, c.height);
      A.mips[k][lvl] = c; src = c;
    }
  }
  A.tinted = {};
  A.tinted.wmBlue = tint(A.img.wordmark, COL.blue);
  A.tinted.wmWhite = A.img.wordmark;
  A.tinted.wmInk = tint(A.img.wordmark, COL.ink);
  // silhouette of the base for the intro
  A.silhouette = tint(A.layers.base, '#13232F');
}
function tint(img, color) {
  const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
  const g = c.getContext('2d'); g.drawImage(img, 0, 0); g.globalCompositeOperation = 'source-in'; g.fillStyle = color; g.fillRect(0, 0, c.width, c.height);
  return c;
}

// ---------- looks
// a look: {bg, hat, eyes, fit, hair, mouth, back}
function lookKey(L) { return [L.bg, L.hat, L.eyes, L.fit, L.hair, L.mouth, L.back].join('|'); }
function lookLayers(L) {
  const out = [];
  for (const slot of ORDER) {
    if (slot === 'base') { out.push('base'); continue; }
    const k = L[slot]; if (k) out.push(k);
  }
  return out;
}
// draw a look's figure (no background) into ctx in 1024-canvas space mapped to (x,y,size)
function drawFigure(g, L, x, y, size, anim) {
  const lvl = size > 420 ? 1024 : size > 210 ? 512 : 256;
  const s = size / 1024;
  for (const slot of ORDER) {
    const k = slot === 'base' ? 'base' : L[slot];
    if (!k) continue;
    const m = A.meta.layers[k], im = A.mips[k][lvl];
    let dx = 0, dy = 0, sc = 1, rot = 0, al = 1;
    if (anim && anim[slot]) ({ dx = 0, dy = 0, sc = 1, rot = 0, al = 1 } = anim[slot]);
    if (al <= 0) continue;
    g.save();
    g.globalAlpha *= al;
    if (sc !== 1 || rot !== 0) {
      const cx = x + (m.x + m.w / 2) * s, cy = y + (m.y + m.h / 2) * s;
      g.translate(cx + dx * s, cy + dy * s); g.rotate(rot); g.scale(sc, sc);
      g.drawImage(im, -m.w * s / 2, -m.h * s / 2, m.w * s, m.h * s);
    } else {
      g.drawImage(im, x + m.x * s + dx * s, y + m.y * s + dy * s, m.w * s, m.h * s);
    }
    g.restore();
  }
}
// circle portrait: figure clipped in a pastel circle. (cx,cy) centre, r radius
const FIG = { cx: 512, cy: 545, r: 505 }; // figure-canvas circle
function drawPortrait(g, L, cx, cy, r, anim, opts = {}) {
  const size = 1024 * r / FIG.r; // figure canvas size on screen
  const x = cx - FIG.cx * size / 1024, y = cy - FIG.cy * size / 1024;
  g.save();
  g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.closePath();
  g.fillStyle = opts.bgOverride || L.bg; g.fill();
  g.clip();
  drawFigure(g, L, x, y, size, anim);
  g.restore();
}
const portraitCache = new Map();
function cachedPortrait(L, px) {
  const bucket = px <= 100 ? 100 : px <= 190 ? 190 : px <= 380 ? 380 : 760;
  const key = lookKey(L) + '@' + bucket;
  let c = portraitCache.get(key);
  if (!c) {
    c = document.createElement('canvas'); c.width = c.height = bucket;
    const g = c.getContext('2d'); g.imageSmoothingQuality = 'high';
    drawPortrait(g, L, bucket / 2, bucket / 2, bucket / 2);
    portraitCache.set(key, c);
  }
  return c;
}
function blitPortrait(g, L, cx, cy, r) {
  const c = cachedPortrait(L, r * 2 * (g.__zoom || 1));
  g.drawImage(c, cx - r, cy - r, r * 2, r * 2);
}

// random crowd look
const ALL = {
  hat: ['hat_crown', 'hat_hardhat', 'hat_cone', 'hat_viking', 'hat_halo', 'hat_foil', 'hat_laurel', 'hat_bikehelmet'],
  eyes: ['eyes_pixel', 'eyes_3d', 'eyes_heart', 'eyes_gradient', 'eyes_shades', 'eyes_clear', 'eyes_blindfold'],
  fit: ['fit_trench', 'fit_hoodie', 'fit_leather', 'fit_prison', 'fit_suit', 'fit_raincoat', 'fit_fleece', 'fit_robe', 'fit_vest', 'fit_overalls', 'fit_tattoo', 'fit_anatomy'],
  hair: ['hair_green', 'hair_blonde', 'hair_blue'],
  mouth: ['mouth_bubblegum', 'mouth_kazoo']
};
function randomLook(r, exclude = {}) {
  const pick = a => a[Math.floor(r() * a.length)];
  const L = { bg: pick(PASTELS), hat: null, eyes: null, fit: pick(ALL.fit), hair: null, mouth: null, back: null };
  if (r() < 0.72) L.hat = pick(ALL.hat);
  if (r() < 0.62) L.eyes = pick(ALL.eyes);
  if (r() < 0.30) L.hair = pick(ALL.hair);
  if (r() < 0.10) L.mouth = pick(ALL.mouth);
  if (r() < 0.07) L.back = 'back_wings';
  if (L.fit === 'fit_raincoat' || L.fit === 'fit_anatomy') { L.hat = null; }
  if (L.fit === 'fit_anatomy') L.hair = null;
  if (L.fit === 'fit_anatomy' && L.eyes === 'eyes_blindfold') L.eyes = null;
  for (const s in exclude) if (L[s] === exclude[s]) L[s] = null;
  return L;
}
