// Tosheez: Nobody Knows — gameplay (rule evaluation + rendering)
'use strict';
const GRID = (() => {
  const tiles = [], rows = 4, cols = 10, colStep = 176, rowStep = 158, r = 74;
  const x0 = (W - (9 * colStep + colStep / 2)) / 2, y0 = 268;
  for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++)
    tiles.push({ x: x0 + i * colStep + (j % 2 ? colStep / 2 : 0), y: y0 + j * rowStep, r, row: j, col: i });
  return { tiles, rows, cols, r };
})();
const SAT_TILE = 15; // row 1, col 5

// shadow sprite
let SHADOW = null;
function shadowSprite() {
  if (SHADOW) return SHADOW;
  const c = document.createElement('canvas'); c.width = c.height = 220; const g = c.getContext('2d');
  g.filter = 'blur(10px)'; g.fillStyle = 'rgba(60,50,30,0.22)'; g.beginPath(); g.arc(110, 118, 78, 0, Math.PI * 2); g.fill();
  SHADOW = c; return c;
}

// ------------------------------------------------------------ session model
function makeSession(def) {
  const r = rng(def.seed);
  const S = Object.assign({}, def);
  S.crowd = GRID.tiles.map((_, i) => randomLook(r));
  S.sat0 = Object.assign({ bg: '#B5E7FE', hat: null, eyes: null, fit: 'fit_trench', hair: null, mouth: null, back: null }, def.sat0 || {});
  S.crowd[SAT_TILE] = S.sat0;
  // waves
  S.waves = [];
  for (const R of S.rounds) {
    R.waveStart = R.t0 + (R.waveDelay ?? 0.32);
    S.waves.push({ t: R.waveStart, origin: R.origin, trend: R.trend, speed: R.waveSpeed || 2600 });
    if (R.flip) { R.flip.waveStart = R.flip.t + 0.18; S.waves.push({ t: R.flip.waveStart, origin: R.flip.origin, trend: R.flip.trend, speed: R.flip.speed || 3200 }); }
    R.finalTrend = R.flip ? R.flip.trend : R.trend;
    R.tArrive = R.lensStart + R.lensDur;
  }
  // pre-sort taps
  S.taps = []; for (const R of S.rounds) for (const tp of (R.taps || [])) S.taps.push(Object.assign({ round: R }, tp));
  S.taps.sort((a, b) => a.t - b.t);
  // pre-compute satoshi look after each tap (carousel cycling = the real input rule)
  let cur = Object.assign({}, S.sat0);
  for (const tp of S.taps) {
    if (tp.slot === 'secret') { tp.prev = Object.assign({}, cur); tp.next = Object.assign({}, cur); continue; }
    const car = CAROUSEL[tp.slot]; const idx = car.indexOf(cur[tp.slot]);
    tp.prev = Object.assign({}, cur);
    cur[tp.slot] = car[(idx + 1) % car.length];
    tp.next = Object.assign({}, cur);
  }
  // outcomes
  let score = 0, streak = def.streak0 || 0, hidden = def.hidden0 || 0; score = def.score0 || 0;
  for (const R of S.rounds) {
    const L = satLookAt(S, R.tArrive);
    const split = R.secret && R.secret.tTap < R.tArrive;
    R.matched = Object.keys(R.finalTrend).every(k => L[k] === R.finalTrend[k]);
    R.success = R.matched || split;
    if (R.lens2) { R.lens2.tArrive = R.lens2.start + R.lens2.dur; }
    if (R.success) { streak++; hidden++; R.points = (split ? 1000 : 250) * Math.min(streak, 9); score += R.points; }
    else { R.points = 0; streak = 0; }
    R.scoreAfter = score; R.streakAfter = streak; R.hiddenAfter = hidden;
  }
  // lens rest positions chain
  let rest = def.lensRest0 || { x: 1780, y: 160 };
  for (const R of S.rounds) {
    R.lensFrom = rest;
    const tgt = GRID.tiles[SAT_TILE];
    if (R.success) { const k = hash(R.t0, 3); rest = { x: k < .5 ? 330 + k * 300 : 1350 + k * 300, y: 300 + hash(R.t0, 5) * 380 }; }
    else rest = { x: tgt.x, y: tgt.y };
    R.lensExit = rest;
  }
  S.events = sessionEvents(S);
  return S;
}
function satLookAt(S, t) {
  let L = S.sat0;
  for (const tp of S.taps) { if (tp.t <= t) L = tp.next; else break; }
  return L;
}
function activeRound(S, t) { let R = null; for (const r of S.rounds) if (r.t0 <= t) R = r; return R; }
function crowdLookAt(S, i, t) {
  if (i === SAT_TILE) return { L: satLookAt(S, t), pop: 1 };
  let L = S.crowd[i], pop = 1, popT = -1;
  const tile = GRID.tiles[i];
  for (const w of S.waves) {
    if (t < w.t) continue;
    const o = GRID.tiles[w.origin];
    const d = Math.hypot(tile.x - o.x, tile.y - o.y);
    const tr = w.t + d / w.speed;
    if (t >= tr) { L = Object.assign({}, L, w.trend); popT = tr; }
    else if (t >= tr - 0.14) { popT = tr; }
  }
  // split decoys copy satoshi
  for (const R of S.rounds) if (R.secret && t >= R.secret.tTap && t < (R.secret.tEnd || 1e9)) {
    const di = R.secret.decoys.indexOf(i);
    if (di >= 0) { const tc = R.secret.tTap + 0.12 + di * 0.06; if (t >= tc) { L = satLookAt(S, R.secret.tTap); popT = tc; } }
  }
  return { L, popT };
}
function popScale(t, popT) {
  if (popT < 0) return 1;
  const u = (t - popT);
  if (u < -0.14) return 1;
  if (u < 0) return 1 - 0.16 * ease.out((u + 0.14) / 0.14);
  if (u < 0.5) return 0.84 + 0.16 * ease.outElastic(u / 0.5);
  return 1;
}

// ------------------------------------------------------------ events for audio
function sessionEvents(S) {
  const ev = [];
  for (const R of S.rounds) {
    ev.push({ t: R.t0, type: 'banner' });
    ev.push({ t: R.waveStart, type: 'wave', n: 38 });
    if (R.flip) { ev.push({ t: R.flip.t, type: 'banner2' }); ev.push({ t: R.flip.waveStart, type: 'wave', n: 38 }); }
    ev.push({ t: R.lensStart, type: 'lock' });
    if (R.secret) { ev.push({ t: R.secret.tShow, type: 'shimmer' }); ev.push({ t: R.secret.tTap, type: 'split' }); }
    if (R.success) { ev.push({ t: R.tArrive, type: 'hidden', streak: R.streakAfter }); ev.push({ t: R.tArrive + 0.18, type: 'huh' }); }
    else { ev.push({ t: R.tArrive, type: 'found' }); }
    if (R.lens2) ev.push({ t: R.lens2.start, type: 'lock' });
  }
  for (const tp of S.taps) ev.push({ t: tp.t, type: tp.slot === 'secret' ? 'tapSecret' : 'tap', slot: tp.slot });
  return ev;
}

// ------------------------------------------------------------ rendering
function satAnim(S, t) {
  const anim = {};
  for (const tp of S.taps) {
    if (tp.slot === 'secret') continue;
    const u = t - tp.t;
    if (u < 0 || u > 0.42) continue;
    const slot = tp.slot;
    // new trait drops in with bounce
    const k = ease.outBack(clamp(u / 0.32));
    anim[slot] = { dy: -260 * (1 - k), sc: 0.7 + 0.3 * k, rot: (1 - k) * -0.25, al: clamp(u / 0.06) };
  }
  return anim;
}
function drawTile(g, S, i, t, opts = {}) {
  const tile = GRID.tiles[i];
  const bob = Math.sin(t * 2.1 + i * 1.7) * 2.2;
  const { L, popT } = crowdLookAt(S, i, t);
  const sc = popScale(t, popT);
  const x = tile.x, y = tile.y + bob, r = tile.r * sc;
  if (!opts.noShadow) g.drawImage(shadowSprite(), x - 110 * r / 74, y - 110 * r / 74 + 6, 220 * r / 74, 220 * r / 74);
  g.save();
  // white rim
  g.beginPath(); g.arc(x, y, r + 4, 0, Math.PI * 2); g.fillStyle = '#FFFFFF'; g.fill();
  if (i === SAT_TILE) drawPortrait(g, L, x, y, r, satAnim(S, t));
  else blitPortrait(g, L, x, y, r);
  // pop flash ring
  if (popT >= 0) {
    const u = t - popT;
    if (u >= 0 && u < 0.35) {
      g.globalAlpha = (1 - u / 0.35) * 0.9; g.strokeStyle = '#FFFFFF'; g.lineWidth = 6 * (1 - u / 0.35) + 1;
      g.beginPath(); g.arc(x, y, r + 6 + u * 60, 0, Math.PI * 2); g.stroke();
      // sparkles
      for (let k = 0; k < 6; k++) {
        const a = k / 6 * Math.PI * 2 + i, d = r + 10 + ease.out(u / 0.35) * 34;
        g.fillStyle = k % 2 ? COL.blue : '#FFFFFF';
        g.beginPath(); g.arc(x + Math.cos(a) * d, y + Math.sin(a) * d, 4 * (1 - u / 0.35) + 1, 0, Math.PI * 2); g.fill();
      }
    }
  }
  g.restore();
  return { x, y, r, L };
}
function drawCrowd(g, S, t, opts = {}) {
  const order = GRID.tiles.map((_, i) => i);
  const info = [];
  for (const i of order) info[i] = drawTile(g, S, i, t, opts);
  return info;
}
function satStatus(S, t) {
  const R = activeRound(S, t); if (!R) return null;
  const L = satLookAt(S, t);
  let trend = R.trend; if (R.flip && t >= R.flip.t) trend = R.flip.trend;
  const keys = Object.keys(trend);
  const ok = keys.map(k => L[k] === trend[k]);
  return { R, trend, keys, ok, all: ok.every(Boolean) };
}
function drawSatMarker(g, S, t) {
  const tile = GRID.tiles[SAT_TILE];
  const bob = Math.sin(t * 2.1 + SAT_TILE * 1.7) * 2.2;
  const st = satStatus(S, t);
  const R = st && st.R;
  const hunting = R && t >= R.lensStart - 0.05 && t < R.tArrive + 0.05;
  const off = st && !st.all;
  let color = COL.blue;
  if (hunting && off) color = COL.coral;
  if (R && !R.success && t >= R.tArrive) color = COL.coral;
  const x = tile.x, y = tile.y + bob, r = tile.r + 13;
  g.save();
  g.lineWidth = 5; g.strokeStyle = color; g.setLineDash([14, 10]); g.lineDashOffset = -t * 40;
  const pulse = hunting && off && !(R && R.secret && t >= R.secret.tTap) ? 1 + 0.05 * Math.sin(t * 22) : 1;
  g.beginPath(); g.arc(x, y, r * pulse, 0, Math.PI * 2); g.stroke(); g.setLineDash([]);
  // pill
  const splitOn = R && R.secret && t >= R.secret.tTap && t < R.tArrive + 1.2;
  if (splitOn) color = COL.blue;
  const label = splitOn ? 'WHICH ONE?' : (hunting && off) ? 'OFF-TREND' : (st && st.all && R && t > R.waveStart) ? 'BLENDED' : 'YOU';
  g.font = '800 19px "Inter Tight"'; const tw = g.measureText(label).width + 26;
  const py = y + r + 6;
  g.fillStyle = color; roundRect(g, x - tw / 2, py, tw, 32, 16); g.fill();
  g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(label, x, py + 17);
  g.restore();
}
function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

// lens position + state
function lensState(S, t, which = 1) {
  let st = { vis: 0, x: 1780, y: 160, mode: 'idle', ang: 0 };
  const first = S.rounds[0];
  for (const R of S.rounds) {
    const L2 = which === 2 ? R.lens2 : null;
    if (which === 2 && !L2) continue;
    const start = which === 2 ? L2.start : R.lensStart, arrive = which === 2 ? L2.tArrive : R.tArrive;
    const from = which === 2 ? L2.from : R.lensFrom;
    if (t < start) { if (R === first || which === 2) { st.x = from.x; st.y = from.y; st.vis = clamp((t - (start - 0.35)) / 0.35); } else { st.vis = 1; } continue; }
    const tgt0 = GRID.tiles[SAT_TILE]; const tgt = which === 2 ? { x: tgt0.x + 96, y: tgt0.y + 70 } : tgt0;
    st.vis = 1;
    if (t <= arrive) {
      const u = ease.inOut(seg(t, start, arrive));
      const mx = (from.x + tgt.x) / 2 + (which === 2 ? 120 : -140), my = Math.min(from.y, tgt.y) - 120;
      // quadratic bezier for an arcing swoop
      st.x = (1 - u) * (1 - u) * from.x + 2 * (1 - u) * u * mx + u * u * tgt.x;
      st.y = (1 - u) * (1 - u) * from.y + 2 * (1 - u) * u * my + u * u * tgt.y;
      st.mode = 'seek'; st.u = u;
    } else if (R.success) {
      const u = t - arrive;
      if (u < 0.75) { st.x = tgt.x + Math.sin(u * 26) * 26 * (1 - u / 0.75); st.y = tgt.y + Math.cos(u * 19) * 12 * (1 - u / 0.75); st.mode = 'confused'; st.u = u; }
      else {
        const v = ease.inOut(clamp((u - 0.75) / 0.8));
        const ex = which === 2 ? { x: 1700, y: 200 } : R.lensExit;
        st.x = lerp(tgt.x, ex.x, v); st.y = lerp(tgt.y, ex.y, v); st.mode = v < 1 ? 'leave' : 'idle';
        if (u < 1.2) { st.mode = 'confused'; st.u = u; }
      }
    } else { st.x = tgt.x; st.y = tgt.y; st.mode = 'found'; st.u = t - arrive; }
  }
  return st;
}
function drawLens(g, S, t, which = 1) {
  const st = lensState(S, t, which);
  if (st.vis <= 0) return st;
  const R0 = 112 * (0.6 + 0.4 * ease.outBack(st.vis));
  const x = st.x, y = st.y;
  g.save();
  g.globalAlpha = st.vis;
  // handle
  const ha = Math.PI * 0.27;
  g.save(); g.translate(x, y); g.rotate(ha);
  g.fillStyle = 'rgba(40,30,20,0.18)'; roundRect(g, R0 + 4, -14 + 10, 150, 34, 17); g.fill();
  g.fillStyle = '#1B1B1B'; roundRect(g, R0 - 6, -16, 156, 32, 16); g.fill();
  g.fillStyle = COL.blue; roundRect(g, R0 + 52, -16, 96, 32, 16); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.35)'; roundRect(g, R0 + 58, -12, 84, 7, 4); g.fill();
  g.restore();
  // glass: magnified crowd
  g.save();
  g.beginPath(); g.arc(x, y, R0, 0, Math.PI * 2); g.clip();
  g.fillStyle = COL.cream; g.fillRect(x - R0, y - R0, R0 * 2, R0 * 2);
  g.translate(x, y); g.scale(1.32, 1.32); g.translate(-x, -y);
  for (let i = 0; i < GRID.tiles.length; i++) {
    const tl = GRID.tiles[i];
    if (Math.abs(tl.x - x) < R0 + 90 && Math.abs(tl.y - y) < R0 + 90) drawTile(g, S, i, t, { noShadow: true });
  }
  g.restore();
  // tint & glare
  g.save(); g.beginPath(); g.arc(x, y, R0, 0, Math.PI * 2); g.clip();
  if (st.mode === 'found') { g.fillStyle = 'rgba(240,87,75,0.22)'; g.fillRect(x - R0, y - R0, R0 * 2, R0 * 2); }
  else { g.fillStyle = 'rgba(93,171,216,0.10)'; g.fillRect(x - R0, y - R0, R0 * 2, R0 * 2); }
  const gr = g.createLinearGradient(x - R0, y - R0, x + R0, y + R0);
  gr.addColorStop(0, 'rgba(255,255,255,0.55)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.0)'); gr.addColorStop(1, 'rgba(255,255,255,0.08)');
  g.fillStyle = gr; g.fillRect(x - R0, y - R0, R0 * 2, R0 * 2);
  g.restore();
  // rim
  g.lineWidth = 15; g.strokeStyle = st.mode === 'found' ? COL.coral : '#1B1B1B';
  g.beginPath(); g.arc(x, y, R0, 0, Math.PI * 2); g.stroke();
  g.lineWidth = 3; g.strokeStyle = 'rgba(255,255,255,0.5)'; g.beginPath(); g.arc(x, y, R0 - 9, Math.PI * 1.05, Math.PI * 1.6); g.stroke();
  // tag
  g.font = '700 15px "JetBrains Mono"'; g.textAlign = 'center'; g.textBaseline = 'middle';
  const tag = which === 2 ? 'HUNTER #2' : 'SATOSHI HUNTER';
  if (st.mode !== 'found') {
  const tw = g.measureText(tag).width + 22;
  g.fillStyle = '#1B1B1B'; roundRect(g, x - tw / 2, y - R0 - 46, tw, 28, 14); g.fill();
  g.fillStyle = '#fff'; g.fillText(tag, x, y - R0 - 31); }
  // confused question marks
  if (st.mode === 'confused') {
    const u = st.u;
    for (let k = 0; k < 3; k++) {
      const uu = u - k * 0.12; if (uu < 0) continue;
      const a = clamp(1 - (uu - 0.7) / 0.5);
      g.globalAlpha = st.vis * a;
      g.font = `900 ${54 - k * 8}px "Inter Tight"`;
      g.fillStyle = k === 1 ? COL.blue : COL.ink;
      const px = x + (k - 1) * 70, py = y - R0 - 80 - ease.out(clamp(uu / 0.4)) * 30 - k * 6;
      g.save(); g.translate(px, py); g.rotate((k - 1) * 0.25 + Math.sin(uu * 9) * 0.1); g.scale(ease.outBack(clamp(uu / 0.25)), ease.outBack(clamp(uu / 0.25)));
      g.fillText('?', 0, 0); g.restore();
    }
  }
  g.restore();
  return st;
}
function drawTargetLine(g, S, t, st) {
  if (st.mode !== 'seek') return;
  const tgt = GRID.tiles[SAT_TILE];
  const ss = satStatus(S, t);
  if (!ss || ss.all) return;
  g.save(); g.strokeStyle = 'rgba(240,87,75,0.75)'; g.lineWidth = 4; g.setLineDash([4, 12]); g.lineDashOffset = -t * 60; g.lineCap = 'round';
  g.beginPath(); g.moveTo(st.x, st.y); g.lineTo(tgt.x, tgt.y); g.stroke(); g.restore();
}

// ---------------------------------------------------------------- HUD
function chip(g, k, x, y, size) {
  // draw trait thumbnail fit into a box centred at x,y
  const m = A.meta.layers[k]; const im = A.mips[k][size > 120 ? 512 : 256];
  const s = Math.min(size / m.w, size * 0.82 / m.h);
  g.drawImage(im, x - m.w * s / 2, y - m.h * s / 2, m.w * s, m.h * s);
}
function trendText(trend) {
  const ks = Object.keys(trend).map(k => TREND_WORD[trend[k]] || TRAIT_NAME[trend[k]]);
  const lc = (w, i) => i === 0 || /^\d/.test(w) ? w : w.charAt(0).toLowerCase() + w.slice(1);
  const ws = ks.map(lc);
  return ws.length === 1 ? ws[0] : ws.slice(0, -1).join(', ') + ' + ' + ws[ws.length - 1];
}
function drawHUD(g, S, t) {
  // left: brand
  g.save();
  const wm = A.tinted.wmBlue; const ww = 190, wh = ww * wm.height / wm.width;
  g.drawImage(wm, 54, 38, ww, wh);
  g.font = '700 15px "JetBrains Mono"'; g.fillStyle = COL.ink; g.textBaseline = 'top'; g.letterSpacing = '3px';
  g.fillText('NOBODY KNOWS', 56, 38 + wh + 10);
  g.letterSpacing = '0px';
  // right: score
  const R = activeRound(S, t);
  let hidden = S.hidden0 || 0, score = S.score0 || 0, streak = S.streak0 || 0, lastPts = null;
  for (const r of S.rounds) if (t >= r.tArrive) { hidden = r.hiddenAfter; score = r.scoreAfter; streak = r.streakAfter; lastPts = r; }
  g.textAlign = 'right';
  g.font = '700 15px "JetBrains Mono"'; g.letterSpacing = '3px'; g.fillStyle = COL.grey; g.fillText('TRENDS SURVIVED', W - 56, 40); g.letterSpacing = '0px';
  let bump = 1; if (lastPts && t - lastPts.tArrive < 0.4) bump = 1 + 0.25 * (1 - ease.out((t - lastPts.tArrive) / 0.4));
  g.font = '900 64px "Inter Tight"'; const nw = g.measureText(String(hidden)).width;
  g.save(); g.translate(W - 56, 66); g.scale(bump, bump); g.fillStyle = COL.ink; g.fillText(String(hidden), 0, 0); g.restore();
  g.font = '800 26px "Inter Tight"'; g.fillStyle = COL.blue;
  g.fillText(score.toLocaleString('en-US') + ' pts' + (streak > 1 ? '  ·  x' + streak : ''), W - 56 - nw - 26, 86);
  g.restore();
  // centre: trend banner
  if (R) {
    let trend = R.trend, tb = R.t0; let prefix = '';
    if (R.flip && t >= R.flip.t) { trend = R.flip.trend; tb = R.flip.t; prefix = 'JK. '; }
    const u = t - tb;
    const k = ease.outBack(clamp(u / 0.38));
    const txt = prefix + trendText(trend) + (Object.keys(trend).length > 1 ? ' are ' : (trendText(trend).endsWith('s') || trend.fit === 'fit_leather' ? ' is ' : ' is '));
    const verb = Object.keys(trend).length > 1 || /s$/.test(trendText(trend)) ? ' are ' : ' is ';
    const main = prefix + trendText(trend) + verb;
    g.save();
    g.font = '900 46px "Inter Tight"'; g.letterSpacing = '-1px';
    const w1 = g.measureText(main).width, w2 = g.measureText('in.').width;
    const chips = Object.values(trend);
    const cw = chips.length * 78;
    const bw = w1 + w2 + cw + 90, bh = 92, bx = W / 2 - bw / 2, by = 30 - (1 - k) * 140;
    g.globalAlpha = clamp(u / 0.12);
    g.shadowColor = 'rgba(70,60,40,0.16)'; g.shadowBlur = 30; g.shadowOffsetY = 10;
    g.fillStyle = '#fff'; roundRect(g, bx, by, bw, bh, 26); g.fill(); g.shadowColor = 'transparent';
    // chips
    let cx = bx + 30 + 34;
    for (const c of chips) { g.fillStyle = '#F2EEE6'; g.beginPath(); g.arc(cx, by + bh / 2, 34, 0, Math.PI * 2); g.fill(); chip(g, c, cx, by + bh / 2, 58); cx += 78; }
    g.textBaseline = 'middle'; g.textAlign = 'left';
    g.fillStyle = COL.ink; g.fillText(main, bx + 30 + cw + 14, by + bh / 2 + 2);
    g.fillStyle = COL.blue; g.fillText('in.', bx + 30 + cw + 14 + w1, by + bh / 2 + 2);
    g.restore();
  }
}
function drawDock(g, S, t) {
  const ss = satStatus(S, t);
  const L = satLookAt(S, t);
  const bw = 1010, bh = 168, bx = W / 2 - bw / 2, by = H - bh - 26;
  g.save();
  g.shadowColor = 'rgba(70,60,40,0.16)'; g.shadowBlur = 34; g.shadowOffsetY = 12;
  g.fillStyle = '#fff'; roundRect(g, bx, by, bw, bh, 34); g.fill(); g.shadowColor = 'transparent';
  // portrait
  const pcx = bx + 100, pcy = by + bh / 2;
  g.beginPath(); g.arc(pcx, pcy, 66, 0, Math.PI * 2); g.fillStyle = COL.blue; g.fill();
  drawPortrait(g, L, pcx, pcy, 61, satAnim(S, t));
  g.font = '700 14px "JetBrains Mono"'; g.letterSpacing = '2px'; g.fillStyle = COL.grey; g.textAlign = 'left'; g.textBaseline = 'top';
  g.fillText('SATOSHI', bx + 186, by + 28); g.letterSpacing = '0px';
  g.font = '900 30px "Inter Tight"'; g.fillStyle = COL.ink; g.fillText('Your look', bx + 186, by + 50);
  g.font = '600 18px "Inter Tight"'; g.fillStyle = COL.grey; g.fillText('Tap a slot to swap', bx + 186, by + 90);
  // slots
  const slots = ['hat', 'eyes', 'fit'];
  for (let s = 0; s < 3; s++) {
    const slot = slots[s];
    const sx = bx + 420 + s * 192, sy = by + 18, sw = 176, sh = bh - 36;
    // press animation
    let press = 0, lastTap = null;
    for (const tp of S.taps) if (tp.slot === slot && tp.t <= t) lastTap = tp;
    if (lastTap) { const u = t - lastTap.t; if (u < 0.3) press = Math.sin(clamp(u / 0.3) * Math.PI); }
    const need = ss && ss.trend[slot];
    const ok = need ? L[slot] === need : true;
    g.save(); g.translate(sx + sw / 2, sy + sh / 2); g.scale(1 - press * 0.07, 1 - press * 0.07); g.translate(-(sx + sw / 2), -(sy + sh / 2));
    g.fillStyle = need ? (ok ? '#E8F4FB' : '#FDECEA') : '#F4F1EA'; roundRect(g, sx, sy, sw, sh, 24); g.fill();
    if (need) { g.lineWidth = 3; g.strokeStyle = ok ? COL.blue : COL.coral; roundRect(g, sx, sy, sw, sh, 24); g.stroke(); }
    if (L[slot]) {
      // slide-in for new trait
      let off = 0; if (lastTap) { const u = t - lastTap.t; if (u < 0.25) off = (1 - ease.outBack(u / 0.25)) * -40; }
      chip(g, L[slot], sx + sw / 2, sy + sh / 2 + 8 + off, 96);
    }
    g.font = '800 15px "JetBrains Mono"'; g.letterSpacing = '2px'; g.textAlign = 'left'; g.textBaseline = 'top'; g.fillStyle = COL.grey;
    g.fillText(slot.toUpperCase(), sx + 16, sy + 12); g.letterSpacing = '0px';
    if (need) {
      g.fillStyle = ok ? COL.blue : COL.coral; g.beginPath(); g.arc(sx + sw - 22, sy + 22, 13, 0, Math.PI * 2); g.fill();
      g.strokeStyle = '#fff'; g.lineWidth = 3.5; g.lineCap = 'round'; g.beginPath();
      if (ok) { g.moveTo(sx + sw - 28, sy + 22); g.lineTo(sx + sw - 23, sy + 27); g.lineTo(sx + sw - 15, sy + 17); }
      else { g.moveTo(sx + sw - 27, sy + 17); g.lineTo(sx + sw - 17, sy + 27); g.moveTo(sx + sw - 17, sy + 17); g.lineTo(sx + sw - 27, sy + 27); }
      g.stroke();
    }
    g.restore();
    // tap ripple (finger)
    if (lastTap) { const u = t - lastTap.t; if (u < 0.45) tapRipple(g, sx + sw / 2 + 30, sy + sh / 2 + 20, u); }
  }
  g.restore();
}
function tapRipple(g, x, y, u) {
  g.save();
  const k = clamp(u / 0.45);
  g.globalAlpha = 1 - k; g.strokeStyle = COL.ink; g.lineWidth = 4;
  g.beginPath(); g.arc(x, y, 18 + k * 46, 0, Math.PI * 2); g.stroke();
  g.globalAlpha = 0.55 * (1 - k); g.fillStyle = COL.ink; g.beginPath(); g.arc(x, y, 20 * (1 - k * 0.4), 0, Math.PI * 2); g.fill();
  g.restore();
}
function drawPopups(g, S, t) {
  const tile = GRID.tiles[SAT_TILE];
  for (const R of S.rounds) {
    const u = t - R.tArrive;
    if (u < 0 || u > 1.35 || !R.success) continue;
    g.save();
    const a = clamp(1 - (u - 0.95) / 0.4);
    const k = ease.outBack(clamp(u / 0.3));
    const split = R.secret && R.secret.tTap < R.tArrive;
    const x = tile.x + 330, y = tile.y - 40 - ease.out(clamp(u / 1.3)) * 26;
    g.globalAlpha = a; g.translate(x, y); g.scale(k, k);
    const w = 330, h = 150;
    g.shadowColor = 'rgba(70,60,40,0.18)'; g.shadowBlur = 30; g.shadowOffsetY = 10;
    g.fillStyle = '#fff'; roundRect(g, -w / 2, -h / 2, w, h, 30); g.fill(); g.shadowColor = 'transparent';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    const label = split ? 'SPLIT!' : 'HIDDEN';
    g.font = '900 34px "Inter Tight"'; const tw = g.measureText(label).width + 40;
    g.fillStyle = split ? COL.gold : COL.blue; roundRect(g, -tw / 2, -h / 2 + 18, tw, 50, 25); g.fill();
    g.fillStyle = '#fff'; g.fillText(label, 0, -h / 2 + 44);
    g.font = '900 44px "Inter Tight"'; g.fillStyle = COL.ink; g.fillText('+' + R.points.toLocaleString('en-US'), 0, 22);
    g.font = '700 14px "JetBrains Mono"'; g.letterSpacing = '2px'; g.fillStyle = COL.grey; g.fillText('STREAK x' + R.streakAfter, 0, 56); g.letterSpacing = '0px';
    g.restore();
  }
}
function drawSecret(g, S, t) {
  for (const R of S.rounds) {
    const sc = R.secret; if (!sc) continue;
    if (t < sc.tShow || t > sc.tTap + 1.5) continue;
    const tile = GRID.tiles[sc.tile];
    g.save();
    if (t < sc.tTap) {
      const u = t - sc.tShow;
      const k = ease.outBack(clamp(u / 0.35));
      // golden shimmer ring + coin
      g.globalAlpha = 0.9; g.strokeStyle = COL.gold; g.lineWidth = 6;
      g.beginPath(); g.arc(tile.x, tile.y, tile.r + 12 + Math.sin(u * 12) * 4, 0, Math.PI * 2); g.stroke();
      const cx = tile.x + tile.r * 0.7, cy = tile.y - tile.r * 0.7;
      g.translate(cx, cy); g.scale(k * (1 + 0.06 * Math.sin(u * 14)), k);
      g.fillStyle = COL.gold; g.beginPath(); g.arc(0, 0, 30, 0, Math.PI * 2); g.fill();
      g.fillStyle = '#FFF6D8'; g.font = '900 34px "Inter Tight"'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('₿', 0, 2);
      // sparkle
      for (let s = 0; s < 4; s++) { const a = u * 3 + s * Math.PI / 2; g.fillStyle = '#fff'; g.beginPath(); g.arc(Math.cos(a) * 44, Math.sin(a) * 44, 4, 0, Math.PI * 2); g.fill(); }
    } else {
      const u = t - sc.tTap;
      tapRipple(g, tile.x + tile.r * 0.7, tile.y - tile.r * 0.7, u);
      // streaks from satoshi to decoys
      const st = GRID.tiles[SAT_TILE];
      for (let d = 0; d < sc.decoys.length; d++) {
        const dt = GRID.tiles[sc.decoys[d]];
        const k = clamp((u - d * 0.06) / 0.25);
        if (k <= 0) continue;
        const fade = clamp(1 - (u - 0.5) / 0.6);
        g.globalAlpha = fade; g.strokeStyle = COL.gold; g.lineWidth = 6; g.lineCap = 'round';
        g.beginPath(); g.moveTo(st.x, st.y); g.lineTo(lerp(st.x, dt.x, ease.out(k)), lerp(st.y, dt.y, ease.out(k))); g.stroke();
        g.strokeStyle = COL.blue; g.lineWidth = 5; g.setLineDash([14, 10]);
        if (k >= 1) { g.beginPath(); g.arc(dt.x, dt.y, dt.r + 13, 0, Math.PI * 2); g.stroke(); }
        g.setLineDash([]);
      }
    }
    g.restore();
  }
}
// Full game view
function renderGame(g, S, t, cam) {
  g.save();
  g.fillStyle = COL.cream; g.fillRect(0, 0, W, H);
  // soft vignette glow
  const rg = g.createRadialGradient(W / 2, H * 0.45, 100, W / 2, H * 0.45, 1100);
  rg.addColorStop(0, 'rgba(255,255,255,0.55)'); rg.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = rg; g.fillRect(0, 0, W, H);
  cam = cam || { z: 1, fx: W / 2, fy: H / 2, sx: 0, sy: 0 };
  g.translate(W / 2 + (cam.sx || 0), H / 2 + (cam.sy || 0)); g.scale(cam.z, cam.z); g.translate(-cam.fx, -cam.fy);
  g.__zoom = cam.z;
  drawCrowd(g, S, t);
  drawSecret(g, S, t);
  drawSatMarker(g, S, t);
  const l1 = lensState(S, t, 1);
  drawTargetLine(g, S, t, l1);
  drawLens(g, S, t, 1);
  drawLens(g, S, t, 2);
  drawPopups(g, S, t);
  g.__zoom = 1;
  g.restore();
  // HUD is screen-space but scaled gently with camera for depth
  drawHUD(g, S, t);
  drawDock(g, S, t);
  // found flash
  for (const R of S.rounds) if (!R.success) {
    const u = t - R.tArrive;
    if (u >= 0 && u < 0.5) { g.fillStyle = `rgba(255,255,255,${1 - u / 0.5})`; g.fillRect(0, 0, W, H); }
  }
}
