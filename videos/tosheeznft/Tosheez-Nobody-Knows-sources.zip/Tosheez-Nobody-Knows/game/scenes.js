// Tosheez: Nobody Knows — trailer timeline (120 BPM; 1 beat = 0.5 s)
'use strict';
const DURATION = 44.0;
const SAT_HERO = { bg: '#B5E7FE', hat: 'hat_hardhat', eyes: null, fit: 'fit_hoodie', hair: null, mouth: null, back: null };

// ---------------------------------------------------------------- sessions
let SESS = {};
function buildSessions() {
  SESS.hook = makeSession({
    seed: 11, hidden0: 11, streak0: 3, score0: 4750,
    sat0: { bg: '#FED5D3', hat: 'hat_cone', eyes: 'eyes_gradient', fit: 'fit_leather' },
    lensRest0: { x: 330, y: 330 },
    rounds: [
      { t0: -0.95, trend: { hat: 'hat_crown' }, origin: 2, waveSpeed: 2300, lensStart: 0.15, lensDur: 1.55, taps: [{ t: 1.22, slot: 'hat' }] },
      { t0: 2.62, trend: { eyes: 'eyes_3d' }, origin: 37, waveSpeed: 3000, lensStart: 3.3, lensDur: 1.3, taps: [] }
    ]
  });
  SESS.rule = makeSession({
    seed: 21, hidden0: 0, streak0: 0, score0: 0,
    sat0: { bg: '#B5E7FE', hat: 'hat_crown', eyes: null, fit: 'fit_trench' },
    lensRest0: { x: 1760, y: 240 },
    rounds: [
      { t0: 10.12, trend: { hat: 'hat_hardhat' }, origin: 0, waveSpeed: 1700, lensStart: 11.0, lensDur: 1.45, taps: [{ t: 11.86, slot: 'hat' }] }
    ]
  });
  SESS.esc1 = makeSession({
    seed: 31, hidden0: 4, streak0: 4, score0: 2500,
    sat0: { bg: '#D4CCFD', hat: 'hat_cone', eyes: 'eyes_pixel', fit: 'fit_suit' },
    lensRest0: { x: 300, y: 650 },
    rounds: [
      { t0: 13.92, trend: { hat: 'hat_crown', eyes: 'eyes_3d' }, origin: 39, waveSpeed: 3100, lensStart: 14.45, lensDur: 1.32, taps: [{ t: 14.98, slot: 'hat' }, { t: 15.36, slot: 'eyes' }] }
    ]
  });
  SESS.esc2 = makeSession({
    seed: 41, hidden0: 5, streak0: 5, score0: 3750,
    sat0: { bg: '#C9FBC0', hat: 'hat_viking', eyes: 'eyes_shades', fit: 'fit_trench' },
    lensRest0: { x: 1650, y: 700 },
    rounds: [
      { t0: 16.42, trend: { fit: 'fit_hoodie' }, origin: 9, waveSpeed: 3200, lensStart: 16.85, lensDur: 1.6, taps: [{ t: 17.02, slot: 'fit' }, { t: 17.86, slot: 'fit' }],
        flip: { t: 17.4, trend: { fit: 'fit_leather' }, origin: 30, speed: 3600 } }
    ]
  });
  SESS.secret = makeSession({
    seed: 51, hidden0: 6, streak0: 6, score0: 5250,
    sat0: { bg: '#FFEEDA', hat: 'hat_crown', eyes: 'eyes_3d', fit: 'fit_prison' },
    lensRest0: { x: 260, y: 300 },
    rounds: [
      { t0: 18.92, trend: { hat: 'hat_viking', eyes: 'eyes_heart', fit: 'fit_suit' }, origin: 4, waveSpeed: 3300, lensStart: 19.5, lensDur: 1.7,
        taps: [{ t: 20.18, slot: 'secret' }],
        secret: { tShow: 19.45, tile: 22, tTap: 20.18, decoys: [3, 8, 24, 27, 33, 36], tEnd: 22.5 } }
    ]
  });
  SESS.fail = makeSession({
    seed: 61, hidden0: 31, streak0: 8, score0: 61750,
    sat0: { bg: '#F6F3C2', hat: 'hat_viking', eyes: 'eyes_heart', fit: 'fit_prison' },
    lensRest0: { x: 240, y: 260 },
    rounds: [
      { t0: 21.9, trend: { hat: 'hat_halo', fit: 'fit_suit' }, origin: 20, waveSpeed: 4400, lensStart: 22.12, lensDur: 1.02, taps: [{ t: 22.5, slot: 'hat' }, { t: 23.34, slot: 'fit' }],
        lens2: { start: 22.2, dur: 0.92, from: { x: 1800, y: 820 } } }
    ]
  });
}

// ---------------------------------------------------------------- shots
const SHOTS = [
  { a: 0.0, b: 3.5, fn: shotHook },
  { a: 3.5, b: 5.5, fn: shotLastSeen },
  { a: 5.5, b: 8.0, fn: shotReveal },
  { a: 8.0, b: 10.0, fn: shotTitle },
  { a: 10.0, b: 13.9, fn: (g, t) => shotGame(g, t, SESS.rule, { caption: ['Match the crowd.', 'Stay hidden.'], big: [10.0, 11.0], camKick: 10.0 }) },
  { a: 13.9, b: 16.4, fn: (g, t) => shotGame(g, t, SESS.esc1, { camKick: 13.9, zoomTo: { z: 1.06, at: [14.8, 15.9] } }) },
  { a: 16.4, b: 18.9, fn: (g, t) => shotGame(g, t, SESS.esc2, { caption: ['Trends move', 'fast.'], camKick: 16.4 }) },
  { a: 18.9, b: 21.9, fn: (g, t) => shotGame(g, t, SESS.secret, { caption: ['Some traits', 'hold a secret.'], camKick: 18.9 }) },
  { a: 21.9, b: 24.0, fn: shotFail },
  { a: 24.0, b: 28.0, fn: shotLeaderboard },
  { a: 28.0, b: 32.0, fn: shotResult },
  { a: 32.0, b: 36.0, fn: shotOutro },
  { a: 36.0, b: 44.0, fn: shotEnd }
];

function renderAt(g, t) {
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.filter = 'none';
  const sh = SHOTS.find(s => t >= s.a && t < s.b) || SHOTS[SHOTS.length - 1];
  sh.fn(g, t, sh);
}

// ---------------------------------------------------------------- helpers
function card(g, x, y, w, h, r = 28, shadow = true) {
  g.save();
  if (shadow) { g.shadowColor = 'rgba(70,60,40,0.16)'; g.shadowBlur = 36; g.shadowOffsetY = 12; }
  g.fillStyle = '#fff'; roundRect(g, x, y, w, h, r); g.fill(); g.restore();
}
function twoTone(g, l1, l2, x, y, size, align = 'center', gap = 1.02) {
  g.save(); g.font = `900 ${size}px "Inter Tight"`; g.letterSpacing = `${-size * 0.03}px`; g.textAlign = align; g.textBaseline = 'alphabetic';
  g.fillStyle = COL.ink; g.fillText(l1, x, y);
  if (l2) { g.fillStyle = COL.blue; g.fillText(l2, x, y + size * gap); }
  g.restore();
}
function inlineTwoTone(g, a, b, x, y, size, align = 'center') {
  // "Same face. " ink + "New look." blue on one line
  g.save(); g.font = `900 ${size}px "Inter Tight"`; g.letterSpacing = `${-size * 0.03}px`; g.textBaseline = 'alphabetic';
  const wa = g.measureText(a).width, wb = g.measureText(b).width;
  let x0 = align === 'center' ? x - (wa + wb) / 2 : align === 'right' ? x - wa - wb : x;
  g.textAlign = 'left'; g.fillStyle = COL.ink; g.fillText(a, x0, y); g.fillStyle = COL.blue; g.fillText(b, x0 + wa, y);
  g.restore();
}
function camKickZoom(t, t0) { const u = t - t0; return u < 0.3 ? 1 + 0.045 * (1 - ease.out(u / 0.3)) : 1; }

// ---------------------------------------------------------------- 0–3.5 hook
function shotHook(g, t) {
  const S = SESS.hook;
  const tgt = GRID.tiles[SAT_TILE];
  // slow push toward satoshi, then settle back as next trend arrives
  const u = ease.inOutSine(seg(t, 0, 2.0)), v = ease.inOut(seg(t, 2.3, 3.0));
  const z = 1 + 0.16 * u - 0.16 * v;
  const fx = lerp(W / 2, lerp(W / 2, tgt.x, 0.55), u * (1 - v)), fy = lerp(H / 2, lerp(H / 2, tgt.y, 0.45), u * (1 - v));
  let sx = 0, sy = 0; const r0 = S.rounds[0];
  const k = t - r0.tArrive; if (k > 0 && k < 0.25) { sx = Math.sin(k * 90) * 6 * (1 - k / 0.25); }
  renderGame(g, S, t, { z, fx, fy, sx, sy });
  drawHunterETA(g, S, t);
  drawStreakCard(g, S, t);
}
// HUNTER ETA card bottom-right; caption card bottom-left
function drawHunterETA(g, S, t) {
  const x = W - 56 - 370, y = H - 26 - 168, w = 370, h = 168;
  card(g, x, y, w, h, 30);
  const R = activeRound(S, t);
  g.save();
  g.font = '700 14px "JetBrains Mono"'; g.letterSpacing = '2px'; g.fillStyle = COL.grey; g.textBaseline = 'top'; g.textAlign = 'left';
  g.fillText('HUNTER ETA', x + 28, y + 26); g.letterSpacing = '0px';
  let eta = null, frac = 0, found = false;
  if (R) {
    if (t >= R.lensStart && t < R.tArrive) { eta = R.tArrive - t; frac = seg(t, R.lensStart, R.tArrive); }
    else if (t >= R.tArrive && !R.success) { eta = 0; frac = 1; found = true; }
  }
  g.font = '900 64px "Inter Tight"'; g.fillStyle = found ? COL.coral : eta !== null && eta < 0.6 ? COL.coral : COL.ink;
  g.fillText(found ? 'FOUND' : eta === null ? '—' : eta.toFixed(1) + 's', x + 26, y + 50);
  // bar
  g.fillStyle = '#EEE9DF'; roundRect(g, x + 28, y + 130, w - 56, 14, 7); g.fill();
  if (frac > 0) { g.fillStyle = found || frac > 0.65 ? COL.coral : COL.blue; roundRect(g, x + 28, y + 130, (w - 56) * frac, 14, 7); g.fill(); }
  g.restore();
}
function drawCaptionCard(g, t, lines, t0, big) {
  if (!lines) return;
  const x = 56, y = H - 26 - 168, w = 370, h = 168;
  // big centre version first
  if (big && t < big[1] + 0.35) {
    const u = t - big[0];
    const k = ease.outBack(clamp(u / 0.35));
    const out = ease.inOut(seg(t, big[1], big[1] + 0.35));
    const bw = 1040, bh = 300;
    const cx = lerp(W / 2, x + w / 2, out), cy = lerp(H * 0.47, y + h / 2, out);
    const s = lerp(1, w / bw, out) * (0.8 + 0.2 * k);
    g.save(); g.globalAlpha = clamp(u / 0.15);
    g.translate(cx, cy); g.scale(s, s);
    card(g, -bw / 2, -bh / 2, bw, bh, 40);
    twoTone(g, lines[0], lines[1], 0, -18, 104, 'center', 1.0);
    g.restore();
    return;
  }
  const u = t - t0; const k = ease.outBack(clamp(u / 0.35));
  g.save(); g.globalAlpha = clamp(u / 0.12);
  g.translate(x + w / 2, y + h / 2); g.scale(0.85 + 0.15 * k, 0.85 + 0.15 * k); g.translate(-(x + w / 2), -(y + h / 2));
  card(g, x, y, w, h, 30);
  twoTone(g, lines[0], lines[1], x + 28, y + 72, 44, 'left', 1.05);
  g.restore();
}
function shotGame(g, t, S, o) {
  let z = camKickZoom(t, o.camKick);
  let fx = W / 2, fy = H / 2;
  if (o.zoomTo) { const u = ease.inOutSine(seg(t, o.zoomTo.at[0], o.zoomTo.at[1])); const tgt = GRID.tiles[SAT_TILE]; z *= lerp(1, o.zoomTo.z, Math.sin(u * Math.PI)); fx = lerp(W / 2, tgt.x, 0.3 * Math.sin(u * Math.PI)); fy = lerp(H / 2, tgt.y, 0.3 * Math.sin(u * Math.PI)); }
  let sx = 0; for (const R of S.rounds) { const k = t - R.tArrive; if (k > 0 && k < 0.25) sx = Math.sin(k * 90) * 6 * (1 - k / 0.25); }
  renderGame(g, S, t, { z, fx, fy, sx, sy: 0 });
  drawHunterETA(g, S, t);
  if (o.caption) drawCaptionCard(g, t, o.caption, o.camKick + 0.1, o.big);
  else drawCaptionCard(g, t, null);
  if (!o.caption) { // keep bottom-left balanced with a streak card
    drawStreakCard(g, S, t);
  }
}
function drawStreakCard(g, S, t) {
  const x = 56, y = H - 26 - 168, w = 370, h = 168;
  card(g, x, y, w, h, 30);
  let streak = S.streak0 || 0; for (const R of S.rounds) if (t >= R.tArrive) streak = R.streakAfter;
  g.save(); g.font = '700 14px "JetBrains Mono"'; g.letterSpacing = '2px'; g.fillStyle = COL.grey; g.textBaseline = 'top'; g.fillText('STREAK', x + 28, y + 26); g.letterSpacing = '0px';
  g.font = '900 64px "Inter Tight"'; g.fillStyle = COL.ink; g.fillText('x' + streak, x + 26, y + 50);
  for (let i = 0; i < 9; i++) { g.fillStyle = i < streak ? COL.blue : '#EEE9DF'; g.beginPath(); g.arc(x + 40 + i * 35, y + 137, 11, 0, Math.PI * 2); g.fill(); }
  g.restore();
}

// ---------------------------------------------------------------- 3.5–5.5 last seen
function shotLastSeen(g, t) {
  g.fillStyle = COL.cream; g.fillRect(0, 0, W, H);
  const u = t - 3.5;
  const reveal = seg(t, 4.5, 4.75);
  const cx = W / 2, cy = 590, r = 300;
  const k = ease.outBack(clamp(u / 0.4));
  g.save(); g.translate(cx, cy); g.scale(0.9 + 0.1 * k + u * 0.012, 0.9 + 0.1 * k + u * 0.012); g.translate(-cx, -cy);
  // ring
  g.strokeStyle = 'rgba(93,171,216,0.35)'; g.lineWidth = 3; g.beginPath(); g.arc(cx, cy, r + 26, 0, Math.PI * 2); g.stroke();
  if (reveal < 1) {
    g.save(); g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fillStyle = COL.blue; g.fill(); g.clip();
    const size = 1024 * r / FIG.r; const x = cx - FIG.cx * size / 1024, y = cy - FIG.cy * size / 1024;
    const m = A.meta.layers.base; const s = size / 1024;
    g.drawImage(A.silhouette, x + m.x * s, y + m.y * s, m.w * s, m.h * s);
    // shoulders silhouette from hoodie fit
    const mf = A.meta.layers.fit_hoodie; if (!A.silFit) A.silFit = tint(A.layers.fit_hoodie, '#13232F');
    g.drawImage(A.silFit, x + mf.x * s, y + mf.y * s, mf.w * s, mf.h * s);
    g.restore();
  }
  if (reveal > 0) {
    g.save(); g.beginPath(); g.arc(cx, cy, r * ease.out(reveal) + 0.01, 0, Math.PI * 2); g.clip();
    drawPortrait(g, SAT_HERO, cx, cy, r);
    g.restore();
    if (reveal < 1) { g.globalAlpha = 1 - reveal; g.fillStyle = '#fff'; g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.fill(); g.globalAlpha = 1; }
  }
  g.restore();
  // copy
  const a1 = clamp(u / 0.25) * (1 - seg(t, 4.42, 4.55));
  if (a1 > 0) { g.globalAlpha = a1; inlineTwoTone(g, 'Last seen in ', '2011.', W / 2, 205, 96); g.globalAlpha = 1; }
  if (t >= 4.5) { const v = ease.outBack(clamp((t - 4.5) / 0.3)); g.save(); g.translate(W / 2, 175); g.scale(v, v); inlineTwoTone(g, 'Satoshi ', 'returns.', 0, 30, 96); g.restore(); }
  if (u < 0.2) { g.fillStyle = `rgba(242,238,230,${1 - u / 0.2})`; g.fillRect(0, 0, W, H); }
}

// ---------------------------------------------------------------- mosaic
const MOSAIC = { step: 104, r: 46, cols: 25, rows: 15, looks: null };
function mosaicLook(i, j) {
  if (i === 0 && j === 0) return SAT_HERO;
  if (!MOSAIC.looks) MOSAIC.looks = new Map();
  const key = i + ',' + j; let L = MOSAIC.looks.get(key);
  if (!L) { L = randomLook(rng(1000 + (i + 50) * 131 + (j + 50) * 7)); MOSAIC.looks.set(key, L); }
  return L;
}
function drawMosaic(g, t, cam, opts = {}) {
  const { z, fx, fy } = cam; // fx,fy in mosaic coords (0,0 = centre tile)
  g.save();
  g.fillStyle = COL.cream; g.fillRect(0, 0, W, H);
  const st = MOSAIC.step, rr = MOSAIC.r;
  const halfW = W / 2 / z + st, halfH = H / 2 / z + st;
  const i0 = Math.floor((fx - halfW) / st), i1 = Math.ceil((fx + halfW) / st);
  const j0 = Math.floor((fy - halfH) / st), j1 = Math.ceil((fy + halfH) / st);
  for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
    const mx = i * st + (j & 1 ? st / 2 : 0), my = j * st * 0.92;
    const sx = W / 2 + (mx - fx) * z, sy = H / 2 + (my - fy) * z;
    const sr = rr * z;
    if (sx < -sr || sx > W + sr || sy < -sr || sy > H + sr) continue;
    const bob = Math.sin(t * 2 + i * 1.3 + j * 2.1) * 1.5 * z;
    let L = mosaicLook(i, j);
    if (opts.shuffle) { const k = Math.floor(t * 3 + hash(i, j) * 10); if (hash(i * 7 + k, j) < opts.shuffle) L = mosaicLook(i + 40 + k % 5, j + 30); }
    g.fillStyle = '#fff'; g.beginPath(); g.arc(sx, sy + bob, sr + 3 * Math.min(z, 3), 0, Math.PI * 2); g.fill();
    g.__zoom = 1;
    blitPortrait(g, L, sx, sy + bob, sr);
    if (opts.highlight && opts.highlight(i, j)) {
      g.save(); g.strokeStyle = COL.blue; g.lineWidth = 5; g.setLineDash([12, 9]); g.lineDashOffset = -t * 40;
      g.beginPath(); g.arc(sx, sy + bob, sr + 10, 0, Math.PI * 2); g.stroke(); g.restore();
    }
  }
  g.restore();
}

// ---------------------------------------------------------------- 5.5–8 reveal pull-back
function shotReveal(g, t) {
  const u = seg(t, 5.5, 7.7);
  const z0 = 300 / MOSAIC.r * 1.0;
  const z = Math.exp(lerp(Math.log(z0), Math.log(0.82), ease.inOut(u)));
  // keep satoshi at screen centre (his tile is at mosaic 0,0); slight upward drift
  const fy = lerp(-((590 - H / 2) / z0), 0, ease.inOut(u));
  drawMosaic(g, t, { z, fx: 0, fy }, { highlight: (i, j) => i === 0 && j === 0 && t > 6.0 && t < 7.0 });
  // copy card
  const a = ease.outBack(clamp((t - 5.85) / 0.35));
  if (t > 5.85) {
    const bw = 1180, bh = 250, bx = W / 2 - bw / 2, by = H / 2 - bh / 2 + 10;
    g.save(); g.globalAlpha = clamp((t - 5.85) / 0.15); g.translate(W / 2, H / 2); g.scale(0.85 + 0.15 * a, 0.85 + 0.15 * a); g.translate(-W / 2, -H / 2);
    card(g, bx, by, bw, bh, 40);
    twoTone(g, 'Nobody knows who he is.', null, W / 2, by + 108, 74);
    if (t > 6.75) { g.globalAlpha = clamp((t - 6.75) / 0.15); twoTone(g, '', null, 0, 0, 10); g.save(); g.font = '900 74px "Inter Tight"'; g.letterSpacing = '-2.2px'; g.textAlign = 'center'; g.fillStyle = COL.blue; g.fillText('Everybody knows how he looks.', W / 2, by + 196); g.restore(); }
    g.restore();
  }
}

// ---------------------------------------------------------------- 8–10 title
function shotTitle(g, t) {
  const u = t - 8.0;
  drawMosaic(g, t, { z: 0.82 * (1 + u * 0.02), fx: 0, fy: 0 }, { shuffle: 0.08 });
  g.fillStyle = 'rgba(242,238,230,0.86)'; g.fillRect(0, 0, W, H);
  // wordmark
  const k0 = ease.outBack(clamp(u / 0.35));
  const wm = A.tinted.wmBlue, ww = 360 * k0, wh = ww * wm.height / wm.width;
  g.drawImage(wm, W / 2 - ww / 2, 250 - wh / 2, ww, wh);
  // title words slam on beats
  const s1 = ease.outBack(clamp((u - 0.0) / 0.25)), s2 = ease.outBack(clamp((u - 0.5) / 0.25));
  g.save(); g.font = '900 230px "Inter Tight"'; g.letterSpacing = '-8px'; g.textBaseline = 'alphabetic'; g.textAlign = 'left';
  const w1 = g.measureText('Nobody ').width, w2 = g.measureText('knows.').width;
  const x0 = W / 2 - (w1 + w2) / 2, y = 590;
  g.save(); g.translate(x0 + w1 / 2, y - 80); g.scale(s1, s1); g.fillStyle = COL.ink; g.fillText('Nobody ', -w1 / 2, 80); g.restore();
  if (u > 0.5) { g.save(); g.translate(x0 + w1 + w2 / 2, y - 80); g.scale(s2, s2); g.fillStyle = COL.blue; g.fillText('knows.', -w2 / 2, 80); g.restore(); }
  g.restore();
  // trait confetti popping around
  const pops = [['hat_crown', 360, 420, 0.9], ['eyes_3d', 1560, 430, 1.05], ['hat_cone', 470, 800, 1.2], ['hat_hardhat', 1450, 800, 1.35], ['eyes_heart', 250, 610, 1.5], ['hat_viking', 1690, 640, 1.6]];
  for (const [k, x, y2, at] of pops) { const v = ease.outBack(clamp((u - at) / 0.3)); if (v <= 0) continue; g.save(); g.translate(x, y2 + Math.sin(t * 3 + x) * 6); g.rotate(Math.sin(x) * 0.25); g.scale(v, v); chip(g, k, 0, 0, 170); g.restore(); }
  // subtitle
  if (u > 1.0) { const a = clamp((u - 1.0) / 0.25); g.save(); g.globalAlpha = a; g.font = '700 22px "JetBrains Mono"'; g.letterSpacing = '5px'; g.textAlign = 'center'; g.fillStyle = COL.grey; g.fillText('A HIDE-IN-PLAIN-SIGHT GAME  ·  BUILT FROM TOSHEEZ ART', W / 2, 700); g.restore(); }
  if (u > 1.7) { const v = seg(t, 9.7, 10.0); g.fillStyle = `rgba(242,238,230,${v})`; g.fillRect(0, 0, W, H); }
}

// ---------------------------------------------------------------- 21.9–24 fail
function shotFail(g, t) {
  const S = SESS.fail; const R = S.rounds[0];
  const tgt = GRID.tiles[SAT_TILE];
  let z = camKickZoom(t, 21.9), fx = W / 2, fy = H / 2, sx = 0, sy = 0;
  if (t > R.tArrive) {
    const u = ease.outQuint(seg(t, R.tArrive, R.tArrive + 0.5));
    z = lerp(1, 1.75, u); fx = lerp(W / 2, tgt.x, u); fy = lerp(H / 2, tgt.y + 30, u);
    const k = t - R.tArrive; if (k < 0.4) { sx = Math.sin(k * 80) * 14 * (1 - k / 0.4); sy = Math.cos(k * 67) * 9 * (1 - k / 0.4); }
  }
  renderGame(g, S, t, { z, fx, fy, sx, sy });
  drawHunterETA(g, S, t);
  drawStreakCard(g, S, t);
  if (t > R.tArrive + 0.12) {
    const u = t - R.tArrive - 0.12; const k = ease.outBack(clamp(u / 0.22));
    g.save(); g.translate(W / 2, 470); g.rotate(-0.08); g.scale(1.6 - 0.6 * k, 1.6 - 0.6 * k); g.globalAlpha = clamp(u / 0.08);
    g.font = '900 220px "Inter Tight"'; g.letterSpacing = '-6px'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.lineWidth = 16; g.strokeStyle = '#fff'; g.strokeText('FOUND.', 0, 0); g.fillStyle = COL.coral; g.fillText('FOUND.', 0, 0);
    g.restore();
  }
}

// ---------------------------------------------------------------- 24–28 leaderboard
const BOARD = [
  ['holder_07', 58], ['holder_02', 44], ['holder_11', 29], ['holder_05', 26], ['holder_09', 22], ['holder_03', 17], ['holder_12', 12], ['holder_04', 8]
];
function shotLeaderboard(g, t) {
  const u = t - 24.0;
  g.fillStyle = COL.cream; g.fillRect(0, 0, W, H);
  // left copy
  const a = ease.outBack(clamp(u / 0.35));
  g.save(); g.globalAlpha = clamp(u / 0.15); g.translate(-60 * (1 - a), 0);
  g.font = '700 18px "JetBrains Mono"'; g.letterSpacing = '4px'; g.fillStyle = COL.grey; g.fillText('WL LEADERBOARD', 120, 330); g.letterSpacing = '0px';
  twoTone(g, 'Bots can like', null, 120, 430, 92, 'left');
  twoTone(g, 'a post.', null, 120, 525, 92, 'left');
  g.restore();
  if (u > 0.55) { const b = ease.outBack(clamp((u - 0.55) / 0.35)); g.save(); g.globalAlpha = clamp((u - 0.55) / 0.15); g.translate(-60 * (1 - b), 0);
    g.font = '900 92px "Inter Tight"'; g.letterSpacing = '-2.7px'; g.fillStyle = COL.blue; g.fillText("They can't hide", 120, 660); g.fillText('in plain sight.', 120, 755); g.restore(); }
  // board card
  const bx = 1080, by = 150, bw = 720, bh = 790;
  const c = ease.outQuint(clamp((u - 0.15) / 0.5));
  g.save(); g.translate(0, (1 - c) * 120); g.globalAlpha = c;
  card(g, bx, by, bw, bh, 36);
  g.font = '700 16px "JetBrains Mono"'; g.letterSpacing = '3px'; g.fillStyle = COL.grey; g.fillText('TOP HIDERS  ·  SAMPLE DATA', bx + 40, by + 56); g.letterSpacing = '0px';
  // player's trends tally; ranks slide continuously as the tally passes each holder
  const tf = 31 * ease.inOut(seg(t, 24.8, 26.9));
  const tally = Math.round(tf);
  const rowH = 76, targetY = i => by + 96 + i * rowH;
  let youIdx = 0;
  const sorted = BOARD.slice().sort((p, q) => q[1] - p[1]);
  sorted.forEach(([h, s2], k) => { const pass = ease.inOut(clamp((tf - s2) / 2 + 0.5)); youIdx += 1 - pass; drawBoardRow(g, bx, targetY(k + pass), bw, rowH, Math.round(k + 1 + pass), { h, s: s2, you: false }, t); });
  drawBoardRow(g, bx, targetY(youIdx), bw, rowH, Math.round(youIdx + 1), { h: 'you', s: tally, you: true }, t);
  g.restore();
}
const BOARD_LOOK = {};
function drawBoardRow(g, bx, y, bw, h, rank, r, t) {
  g.save();
  if (r.you) { g.fillStyle = '#E8F4FB'; roundRect(g, bx + 20, y + 4, bw - 40, h - 8, 20); g.fill(); g.lineWidth = 3; g.strokeStyle = COL.blue; roundRect(g, bx + 20, y + 4, bw - 40, h - 8, 20); g.stroke(); }
  g.font = '900 30px "Inter Tight"'; g.fillStyle = r.you ? COL.blue : COL.ink; g.textBaseline = 'middle'; g.textAlign = 'left';
  g.fillText('#' + rank, bx + 44, y + h / 2);
  let L = BOARD_LOOK[r.h]; if (!L) { L = r.you ? SESS.fail.rounds[0] && satLookAt(SESS.fail, 23.3) : randomLook(rng(r.h.length * 97 + r.h.charCodeAt(8))); BOARD_LOOK[r.h] = L; }
  g.fillStyle = '#fff'; g.beginPath(); g.arc(bx + 150, y + h / 2, 30, 0, Math.PI * 2); g.fill();
  blitPortrait(g, L, bx + 150, y + h / 2, 28);
  g.font = '800 28px "Inter Tight"'; g.fillStyle = COL.ink; g.fillText(r.you ? 'you  (satoshi?)' : r.h, bx + 200, y + h / 2);
  g.textAlign = 'right'; g.font = '900 30px "Inter Tight"'; g.fillStyle = r.you ? COL.blue : COL.ink; g.fillText(String(r.s), bx + bw - 120, y + h / 2);
  g.font = '700 14px "JetBrains Mono"'; g.fillStyle = COL.grey; g.fillText('TRENDS', bx + bw - 40, y + h / 2 + 2);
  g.restore();
}

// ---------------------------------------------------------------- 28–32 result + share
function resultCard(g, cx, cy, s, t, showTap) {
  const w = 620, h = 760;
  g.save(); g.translate(cx, cy); g.scale(s, s); g.translate(-w / 2, -h / 2);
  card(g, 0, 0, w, h, 40);
  const L = satLookAt(SESS.fail, 23.3);
  g.fillStyle = '#F2EEE6'; g.beginPath(); g.arc(w / 2, 250, 196, 0, Math.PI * 2); g.fill();
  drawPortrait(g, L, w / 2, 250, 184);
  g.textAlign = 'center';
  g.font = '700 16px "JetBrains Mono"'; g.letterSpacing = '4px'; g.fillStyle = COL.grey; g.fillText('NOBODY KNOWS  ·  RESULT', w / 2, 490); g.letterSpacing = '0px';
  g.font = '900 64px "Inter Tight"'; g.letterSpacing = '-2px'; g.fillStyle = COL.ink; g.fillText('Hidden for', w / 2, 562);
  g.fillStyle = COL.blue; g.fillText('31 trends.', w / 2, 626); g.letterSpacing = '0px';
  g.font = '700 22px "Inter Tight"'; g.fillStyle = COL.grey; g.fillText('Rank #3 on the WL leaderboard (sample)', w / 2, 668);
  // share button
  g.fillStyle = COL.ink; roundRect(g, w / 2 - 150, 690, 300, 56, 28); g.fill();
  g.fillStyle = '#fff'; g.font = '800 24px "Inter Tight"'; g.textBaseline = 'middle'; g.fillText('Share on X', w / 2, 719);
  if (showTap !== null && showTap !== undefined && showTap >= 0 && showTap < 0.45) tapRipple(g, w / 2 + 40, 726, showTap);
  g.restore();
}
function shotResult(g, t) {
  const u = t - 28.0;
  g.fillStyle = COL.cream; g.fillRect(0, 0, W, H);
  if (t < 30.0) {
    const k = ease.outBack(clamp(u / 0.45));
    resultCard(g, W / 2, H / 2 + (1 - k) * 200, 0.85 + 0.1 * k, t, t - 29.45);
    // side copy
    if (u > 0.4) { const a = clamp((u - 0.4) / 0.2); g.globalAlpha = a; twoTone(g, 'Your look.', 'Your score.', 330, 500, 76); twoTone(g, 'Your', 'flex.', 1590, 500, 76); g.globalAlpha = 1; }
    return;
  }
  // X post mock-up
  const v = ease.outQuint(seg(t, 30.0, 30.6));
  const pw = 860, ph = 880, px = W / 2 - pw / 2, py = H / 2 - ph / 2 - 20 + (1 - v) * 80;
  g.save(); g.globalAlpha = v;
  card(g, px, py, pw, ph, 30);
  const L = satLookAt(SESS.fail, 23.3);
  g.fillStyle = '#fff'; g.beginPath(); g.arc(px + 78, py + 82, 36, 0, Math.PI * 2); g.fill(); blitPortrait(g, L, px + 78, py + 82, 34);
  g.textAlign = 'left'; g.textBaseline = 'alphabetic';
  g.font = '800 28px "Inter Tight"'; g.fillStyle = COL.ink; g.fillText('holder_01', px + 132, py + 74);
  g.font = '500 24px "Inter Tight"'; g.fillStyle = '#7A7A7A'; g.fillText('@holder_01 · now', px + 132, py + 106);
  g.font = '500 32px "Inter Tight"'; g.fillStyle = COL.ink;
  g.fillText('Hid in plain sight for 31 trends.', px + 50, py + 180);
  g.fillText('Nobody knows it was me.', px + 50, py + 224);
  g.restore();
  // result card shrinks into the post
  const s = lerp(0.95, 0.78, v), cx = W / 2, cy = lerp(H / 2, py + 252 + 760 * 0.78 / 2, v);
  g.save(); g.globalAlpha = 1;
  resultCard(g, cx, cy, s, t, null);
  g.restore();
  g.save(); g.globalAlpha = v;
  g.font = '700 15px "JetBrains Mono"'; g.letterSpacing = '3px'; g.fillStyle = COL.grey; g.textAlign = 'center'; g.fillText('POST MOCK-UP  ·  NOTHING WAS POSTED', W / 2, py + ph + 44);
  g.restore();
  if (u < 0.15) { g.fillStyle = `rgba(242,238,230,${1 - u / 0.15})`; g.fillRect(0, 0, W, H); }
}

// ---------------------------------------------------------------- 32–36 outro mosaic
function shotOutro(g, t) {
  const u = t - 32.0;
  const z = lerp(0.72, 0.62, ease.inOutSine(seg(t, 32, 36)));
  const fx = lerp(-40, 60, seg(t, 32, 36));
  // hunt highlight hops around
  const hop = Math.floor(u * 2.2);
  const hi = Math.round(hash(hop, 1) * 10 - 5), hj = Math.round(hash(hop, 2) * 6 - 3);
  drawMosaic(g, t, { z, fx, fy: 0 }, { highlight: (i, j) => u < 2.6 && i === hi && j === hj });
  // copy card
  const a = ease.outBack(clamp((u - 0.15) / 0.35));
  const bw = 1320, bh = 330, bx = W / 2 - bw / 2, by = H / 2 - bh / 2;
  const iris = seg(t, 35.2, 36.0);
  g.save(); g.globalAlpha = clamp((u - 0.15) / 0.15) * (1 - seg(t, 35.0, 35.3)); g.translate(W / 2, H / 2); g.scale(0.85 + 0.15 * a, 0.85 + 0.15 * a); g.translate(-W / 2, -H / 2);
  card(g, bx, by, bw, bh, 40);
  twoTone(g, '7,021 looks.', null, W / 2, by + 118, 88);
  if (u > 0.75) { g.globalAlpha *= clamp((u - 0.75) / 0.15); g.font = '900 72px "Inter Tight"'; g.letterSpacing = '-2px'; g.textAlign = 'center'; g.fillStyle = COL.blue; g.fillText('Nobody knows which one is him.', W / 2, by + 214); }
  if (u > 1.3) { g.globalAlpha = clamp((u - 1.3) / 0.2) * (1 - seg(t, 35.0, 35.3)); const wm = A.tinted.wmBlue, ww = 170, wh = ww * wm.height / wm.width; g.drawImage(wm, W / 2 - ww / 2, by + 252, ww, wh); }
  g.restore();
  // lens iris to black
  if (t > 34.6) {
    const v = ease.inOut(seg(t, 34.6, 35.2));
    const lx = lerp(W + 200, W / 2, v), ly = lerp(H + 160, H / 2, v);
    const R0 = lerp(112, 1300, ease.in(iris));
    g.save();
    // black glass growing
    g.fillStyle = `rgba(10,10,10,${0.25 + 0.75 * iris})`; g.beginPath(); g.arc(lx, ly, R0 - 6, 0, Math.PI * 2); g.fill();
    g.lineWidth = 15 + iris * 30; g.strokeStyle = '#1B1B1B'; g.beginPath(); g.arc(lx, ly, R0, 0, Math.PI * 2); g.stroke();
    g.save(); g.translate(lx, ly); g.rotate(Math.PI * 0.27); g.fillStyle = '#1B1B1B'; roundRect(g, R0 - 6, -16 * (1 + iris * 2), 156 * (1 + iris * 2), 32 * (1 + iris * 2), 16); g.fill(); g.fillStyle = COL.blue; roundRect(g, R0 + 52 * (1 + iris * 2), -16 * (1 + iris * 2), 96 * (1 + iris * 2), 32 * (1 + iris * 2), 16); g.fill(); g.restore();
    g.restore();
    if (iris > 0.92) { g.fillStyle = `rgba(0,0,0,${(iris - 0.92) / 0.08})`; g.fillRect(0, 0, W, H); }
  }
}

// ---------------------------------------------------------------- 36–44 Encore end card
function shotEnd(g, t) {
  const u = t - 36.0;
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const fade = (a, d = 0.35) => clamp((u - a) / d);
  const up = (a, d = 0.5) => (1 - ease.out(clamp((u - a) / d))) * 24;
  // header bar (mono, like the studio reference)
  g.save(); g.globalAlpha = fade(0.1) * 0.75; g.font = '500 20px "JetBrains Mono"'; g.letterSpacing = '1px'; g.fillStyle = '#9C9AA6'; g.textBaseline = 'top';
  g.textAlign = 'left'; g.fillText('ENCORE STUDIO  /  GAME CONCEPT FILM', 96, 30); g.textAlign = 'right'; g.fillText('TOSHEEZ', W - 98, 30); g.restore();
  // mark
  const em = A.img.encore; const ew = 276, eh = ew * em.height / em.width;
  g.save(); g.globalAlpha = fade(0.15, 0.6); const ms = 0.92 + 0.08 * ease.out(fade(0.15, 0.8));
  g.translate(W / 2, 252); g.scale(ms, ms); g.drawImage(em, -ew / 2, -eh / 2, ew, eh);
  // chrome sheen sweep
  const sw = ((u - 0.6) / 1.2); if (sw > 0 && sw < 1) { g.globalCompositeOperation = 'lighter'; const gx = -ew / 2 + sw * ew * 1.6 - ew * 0.3; const gr = g.createLinearGradient(gx - 60, 0, gx + 60, 0); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.22)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(-ew / 2, -eh / 2, ew, eh); }
  g.restore();
  g.save(); g.textAlign = 'center'; g.textBaseline = 'alphabetic';
  g.globalAlpha = fade(0.55); g.font = '600 40px "Inter Tight"'; g.fillStyle = '#F4F4F4'; g.fillText('TOSHEEZ: NOBODY KNOWS — a game concept for Tosheez', W / 2, 432 + up(0.55));
  g.globalAlpha = fade(0.8); g.font = '500 24px "JetBrains Mono"'; g.letterSpacing = '9px'; g.fillStyle = '#9C9AA6'; g.fillText('BY ENCORE STUDIO', W / 2, 488 + up(0.8)); g.letterSpacing = '0px';
  g.globalAlpha = fade(1.15); g.font = '800 82px "Inter Tight"'; g.letterSpacing = '-2px'; g.fillStyle = '#FFFFFF'; g.fillText('One crew for your whole launch.', W / 2, 606 + up(1.15)); g.letterSpacing = '0px';
  g.globalAlpha = fade(1.6); g.font = '600 38px "Inter Tight"'; g.fillStyle = '#F0F0F0'; g.fillText('Book a free 30-min call · encorestudio.xyz · @EncoreStudiohq', W / 2, 696 + up(1.6));
  g.globalAlpha = fade(2.0); g.fillStyle = '#2A2A2E'; g.fillRect(W / 2 - 520, 788, 1040, 2);
  g.font = '500 25px "Inter Tight"'; g.fillStyle = '#A9A9B0';
  g.fillText('Unofficial concept by Encore Studio. Not affiliated with or endorsed by Tosheez.', W / 2, 846);
  g.fillText('Tosheez characters and art © Tosheez.', W / 2, 888);
  g.restore();
  // badge
  g.save(); g.globalAlpha = fade(2.3); g.font = '700 20px "JetBrains Mono"'; g.letterSpacing = '2px';
  const bt = 'CONCEPT · UNOFFICIAL'; const bw = g.measureText(bt).width + 48;
  g.fillStyle = '#0B0B12'; g.fillRect(W - 96 - bw, 980, bw, 44); g.fillStyle = COL.blue; g.fillRect(W - 96 - bw, 980, 5, 44);
  g.fillStyle = '#F4F4F4'; g.textBaseline = 'middle'; g.fillText(bt, W - 96 - bw + 26, 1003);
  g.restore();
  // tiny tosheez wordmark bottom-left
  g.save(); g.globalAlpha = fade(2.3) * 0.9; const wm = A.tinted.wmWhite, ww = 120, wh = ww * wm.height / wm.width; g.drawImage(wm, 96, 1002 - wh / 2, ww, wh); g.restore();
  if (u < 0.12) { g.fillStyle = `rgba(0,0,0,${1 - u / 0.12})`; g.fillRect(0, 0, W, H); }
}

// ---------------------------------------------------------------- events for audio
function allEvents() {
  const ev = [];
  const shotOf = t => SHOTS.find(s => t >= s.a && t < s.b);
  for (const [name, S] of Object.entries(SESS)) {
    for (const e of S.events) {
      const sh = shotOf(e.t);
      // keep only events inside the shot that renders this session
      const map = { hook: 0, rule: 4, esc1: 5, esc2: 6, secret: 7, fail: 8 };
      if (sh === SHOTS[map[name]]) ev.push(Object.assign({ session: name }, e));
    }
  }
  // editorial cues
  const ed = [
    [3.5, 'whoosh'], [4.5, 'reveal'], [5.5, 'zoomout'], [5.85, 'card'], [6.75, 'card'], [8.0, 'slam'], [8.5, 'slam2'], [8.9, 'pop'], [9.05, 'pop'], [9.2, 'pop'], [9.35, 'pop'], [9.5, 'pop'], [9.6, 'pop'],
    [10.0, 'card'], [13.9, 'cut'], [16.4, 'cut'], [16.5, 'card'], [18.9, 'cut'], [19.0, 'card'], [21.9, 'cut'],
    [24.0, 'whoosh'], [24.55, 'card'], [28.0, 'card'], [29.45, 'tap'], [30.0, 'post'], [32.0, 'whoosh'], [32.15, 'card'], [32.75, 'card'], [34.6, 'lensswoop'], [35.2, 'iris'],
    [36.15, 'logo'], [37.15, 'slogan']
  ];
  for (const [t, type] of ed) ev.push({ t, type });
  // leaderboard rank ticks
  let last = -1; for (let t = 24.8; t <= 26.95; t += 1 / 60) { const v = Math.round(31 * ease.inOut(seg(t, 24.8, 26.9))); if (v !== last) { if (v % 2 === 0) ev.push({ t: +t.toFixed(3), type: 'tick' }); last = v; } }
  ev.sort((a, b) => a.t - b.t);
  return ev;
}
