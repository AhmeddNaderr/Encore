import cv2, numpy as np, json
R='research/raw/'
N=1769
g=cv2.cvtColor(cv2.imread(R+'x-2124274435012329977-0.jpg'),cv2.COLOR_BGR2GRAY)
tx0,ty0,tx1,ty1=640,880,1060,1010
tpl=g[ty0:ty1,tx0:tx1]
imgs={
 'trench':'x-2124274435012329977-0.jpg','math':'x-2123511513847873644-0.jpg','cone':'x-2123511513847873644-1.jpg','foil':'x-2123511513847873644-2.jpg',
 'crown':'rt-HomerCarbone-2124442130240147871-0.jpg','prison':'rt-HomerCarbone-2124820284179976538-0.jpg','halo':'rt-HomerCarbone-2125184985204166882-0.jpg','raincoat':'rt-HomerCarbone-2125546478059884813-0.jpg',
 'angel':'x-2120830270635167986-0.jpg','robe':'x-2121216087551263212-0.jpg','viking':'x-2121526718695411747-0.jpg','overalls':'x-2121938080034599003-0.jpg',
 'suit':'x-2122786005904445471-0.jpg','ab':'x-2124638882805477383-0.jpg','laurel':'x-2125016628475924797-0.jpg','hardhat':'x-2125369515009573289-0.jpg','collab':'x-2123145900365070376-0.jpg',
 'math2':'rt-NZNFTguy-2124572060894851386-0.jpg',
}
def match(sub,tpl,fs):
    best=(-2,None)
    for f in fs:
        rs=cv2.resize(sub,None,fx=f,fy=f,interpolation=cv2.INTER_AREA if f<1 else cv2.INTER_LINEAR)
        if rs.shape[0]<tpl.shape[0] or rs.shape[1]<tpl.shape[1]: continue
        m=cv2.matchTemplate(rs,tpl,cv2.TM_CCOEFF_NORMED); _,mv,_,ml=cv2.minMaxLoc(m)
        if mv>best[0]: best=(mv,(f,ml))
    return best
res={}
for k,fn in imgs.items():
    im=cv2.imread(R+fn); tg=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    H,W=tg.shape
    regions=[(0,0,W,H)] if k!='ab' else [(0,0,W//2,H),(W//2,0,W,H)]
    for (rx0,ry0,rx1,ry1) in regions:
        sub=tg[ry0:ry1,rx0:rx1]
        # coarse at quarter res
        q=0.25
        tq=cv2.resize(tpl,None,fx=q,fy=q,interpolation=cv2.INTER_AREA)
        sq=cv2.resize(sub,None,fx=q,fy=q,interpolation=cv2.INTER_AREA)
        mv,(f,ml)=match(sq,tq,np.arange(0.4,2.4,0.02))
        mv,(f,ml)=match(sub,tpl,np.arange(f-0.025,f+0.025,0.0025))
        M=np.array([[f,0,-f*rx0+tx0-ml[0]],[0,f,-f*ry0+ty0-ml[1]]],dtype=np.float64)
        warped=cv2.warpAffine(im,M,(N,N),flags=cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=(255,0,255))
        vm=np.zeros(im.shape[:2],np.uint8); vm[ry0:ry1,rx0:rx1]=255
        valid=cv2.warpAffine(vm,M,(N,N),flags=cv2.INTER_LINEAR,borderValue=0)
        name=k if len(regions)==1 else k+('A' if rx0==0 else 'B')
        cv2.imwrite(f'art/aligned/{name}.png',warped); cv2.imwrite(f'art/aligned/{name}_valid.png',valid)
        res[name]={'src':fn,'score':round(float(mv),4),'scale':round(float(f),4),'M':M.tolist()}
        print(name,round(mv,3),round(f,4),flush=True)
json.dump(res,open('art/aligned/align.json','w'),indent=1)
