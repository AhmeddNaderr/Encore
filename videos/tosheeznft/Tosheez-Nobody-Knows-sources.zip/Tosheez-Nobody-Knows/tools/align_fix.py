import cv2, numpy as np, json
R='research/raw/'
N=1769
res=json.load(open('art/aligned/align.json'))
g=cv2.cvtColor(cv2.imread(R+'x-2124274435012329977-0.jpg'),cv2.COLOR_BGR2GRAY)
def save(name,im,M,vm):
    warped=cv2.warpAffine(im,M,(N,N),flags=cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=(255,0,255))
    valid=cv2.warpAffine(vm,M,(N,N),flags=cv2.INTER_LINEAR,borderValue=0)
    cv2.imwrite(f'art/aligned/{name}.png',warped); cv2.imwrite(f'art/aligned/{name}_valid.png',valid)
for name,fn in [('foil','x-2123511513847873644-2.jpg'),('prison','rt-HomerCarbone-2124820284179976538-0.jpg')]:
    im=cv2.imread(R+fn); M=np.array([[1.,0,0],[0,1.,0]]); save(name,im,M,np.full(im.shape[:2],255,np.uint8))
    res[name]={'src':fn,'score':1.0,'scale':1.0,'M':M.tolist(),'note':'same canvas (1769), identity'}
    print(name,'identity')
# viking & abB with left-cheek/nose template above kazoo/pipe; also eyebrow-free
for name,fn,reg,fr,tplr in [('viking','x-2121526718695411747-0.jpg',None,(1.36,1.41),(700,860,980,960)),
                       ('abB','x-2124638882805477383-0.jpg','B',(1.55,1.80),(700,860,980,960))]:
    im=cv2.imread(R+fn); tg=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY); H,W=tg.shape
    rx0,ry0,rx1,ry1=(0,0,W,H) if reg is None else (W//2,0,W,H)
    sub=tg[ry0:ry1,rx0:rx1]
    tx0,ty0,tx1,ty1=tplr; tpl=g[ty0:ty1,tx0:tx1]
    best=(-2,None)
    for f in np.arange(fr[0],fr[1],0.0025):
        rs=cv2.resize(sub,None,fx=f,fy=f,interpolation=cv2.INTER_LINEAR)
        m=cv2.matchTemplate(rs,tpl,cv2.TM_CCOEFF_NORMED); _,mv,_,ml=cv2.minMaxLoc(m)
        if mv>best[0]: best=(mv,(f,ml))
    mv,(f,ml)=best
    M=np.array([[f,0,-f*rx0+tx0-ml[0]],[0,f,-f*ry0+ty0-ml[1]]])
    vm=np.zeros(im.shape[:2],np.uint8); vm[ry0:ry1,rx0:rx1]=255
    save(name,im,M,vm); res[name]={'src':fn,'score':round(float(mv),4),'scale':round(float(f),4),'M':M.tolist()}
    print(name,round(mv,3),round(f,4))
json.dump(res,open('art/aligned/align.json','w'),indent=1)
