// usage: node capture.cjs stills t1,t2,...  |  node capture.cjs video out.mp4 [fps] [start] [end]
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs'), { spawn } = require('child_process');
const http = require('http');
const ROOT = path.resolve(__dirname, '../game');
function serve() {
  const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.json': 'application/json', '.ttf': 'font/ttf', '.svg': 'image/svg+xml', '.jpg': 'image/jpeg' };
  return new Promise(res => { const s = http.createServer((req, rsp) => { const p = path.join(ROOT, decodeURIComponent(req.url.split('?')[0])); fs.readFile(p, (e, d) => { if (e) { rsp.writeHead(404); rsp.end(); return; } rsp.writeHead(200, { 'Content-Type': types[path.extname(p)] || 'application/octet-stream' }); rsp.end(d); }); }); s.listen(0, () => res(s)); });
}
(async () => {
  const mode = process.argv[2];
  const srv = await serve(); const port = srv.address().port;
  const browser = await chromium.launch({ args: ['--disable-gpu-vsync', '--force-color-profile=srgb'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  const errs = []; page.on('pageerror', e => errs.push(String(e))); page.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await page.goto(`http://127.0.0.1:${port}/index.html?capture=1`);
  await page.evaluate(() => window.ready);
  const grab = async t => { const b64 = await page.evaluate(t => { window.renderFrame(t); return document.getElementById('c').toDataURL('image/png').split(',')[1]; }, t); return Buffer.from(b64, 'base64'); };
  if (mode === 'stills') {
    const ts = process.argv[3].split(',').map(Number);
    fs.mkdirSync(path.resolve(__dirname, '../frames'), { recursive: true });
    for (const t of ts) { fs.writeFileSync(path.resolve(__dirname, `../frames/f_${t.toFixed(2)}.png`), await grab(t)); }
  } else if (mode === 'events') {
    const ev = await page.evaluate(() => window.getEvents());
    fs.writeFileSync(path.resolve(__dirname, '../audio/events.json'), JSON.stringify(ev, null, 1));
    console.log('events', ev.length);
  } else if (mode === 'video') {
    const out = process.argv[3], fps = +(process.argv[4] || 60), a = +(process.argv[5] || 0), b = +(process.argv[6] || await page.evaluate(() => DURATION));
    const n = Math.round((b - a) * fps);
    const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'png', '-i', '-', '-c:v', 'libx264', '-preset', 'slow', '-crf', '14', '-pix_fmt', 'yuv420p', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-movflags', '+faststart', out], { stdio: ['pipe', 'inherit', 'inherit'] });
    const t0 = Date.now();
    for (let i = 0; i < n; i++) {
      const buf = await grab(a + i / fps);
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
      if (i % 120 === 0) console.log(`frame ${i}/${n}  ${((Date.now() - t0) / 1000).toFixed(0)}s`);
    }
    ff.stdin.end(); await new Promise(r => ff.on('close', r));
  }
  if (errs.length) console.log('PAGE ERRORS:\n' + errs.join('\n'));
  await browser.close(); srv.close();
})();
