import sys, json; sys.path.insert(0,'tools')
from lib import *
L=json.load(open('art/layers/layers.json'))
bc,ba=load_rgba('art/base.png')
cache={}
def layer(k):
    if k not in cache: cache[k]=load_rgba(f'art/layers/{k}.png')
    return cache[k]
def over(dst,da,k):
    c,a=layer(k); m=L[k]; y0,x0=m['y'],m['x']; h,w=a.shape
    sl=(slice(y0,y0+h),slice(x0,x0+w))
    A=a[...,None]; dst[sl]=c*A+dst[sl]*(1-A); da[sl]=a+da[sl]*(1-a)
ORDER=['back','base','hair','fit','mouth','eyes','hat']
def compose(traits,bg=(230,230,230)):
    img=np.zeros((N,N,3),np.float32); img[:]=bg; al=np.ones((N,N),np.float32)
    for slot in ORDER:
        if slot=='base':
            A=ba[...,None]; img[:]=bc*A+img*(1-A); continue
        for k in traits:
            if L[k]['slot']==slot: over(img,al,k)
    return img
if __name__=='__main__':
    keys=list(L.keys())
    tiles=[]
    for k in keys:
        t=[k]
        if L[k]['slot']!='fit': t.append('fit_trench' if k!='fit_trench' else None)
        t=[x for x in t if x]
        im=compose(t)
        im=cv2.resize(im,(300,300),interpolation=cv2.INTER_AREA).astype(np.uint8)
        cv2.putText(im,k,(5,18),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,0,200),1)
        tiles.append(im)
    while len(tiles)%8: tiles.append(np.zeros_like(tiles[0]))
    cv2.imwrite('art/layers_preview.jpg',np.vstack([np.hstack(tiles[i:i+8]) for i in range(0,len(tiles),8)]))
