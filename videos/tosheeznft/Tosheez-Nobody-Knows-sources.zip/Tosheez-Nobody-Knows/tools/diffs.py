import sys; sys.path.insert(0,'tools')
from lib import *
import json
bc,ba=load_rgba('art/base.png')
names=['trench','cone','foil','crown','prison','halo','raincoat','angel','robe','viking','overalls','suit','abA','abB','laurel','hardhat','collab','math']
tiles=[]
circle_bg={'hardhat':None,'laurel':None,'collab':None}
for n in names:
    im,v=load(n)
    if n in ('hardhat','laurel','collab','math'):
        # bg = colour just inside the valid circle near top-left of head: sample at fixed canvas points
        pts=[(150,885),(300,300),(300,1469)]
        bg=np.median(np.array([im[y,x] for y,x in pts]),axis=0)
    elif n=='abA':
        bg=np.median(np.array([im[y,x] for y,x in [(100,200),(400,250),(150,500)] ]),axis=0)
    elif n=='abB':
        bg=np.median(np.array([im[y,x] for y,x in [(100,1600),(400,1550),(150,1300)] ]),axis=0)
    else:
        bg=bgcolor(im,v)
    im=np.where((v>0.5)[...,None],im,bg)
    a,c=matte(im,bg,v)
    save_rgba(f'art/mattes/{n}.png',c,a)
    d=np.linalg.norm(c-bc,axis=2)
    t=a*np.where(ba>0.5,np.clip((d-22)/23,0,1),1)
    vis=(c*0.5+np.array([128,128,128])*0.5)
    vis[t>0.5]=[0,0,255]
    vis=cv2.resize(vis,(354,354)).astype(np.uint8)
    for y in range(0,354,40): cv2.line(vis,(0,y),(353,y),(255,255,255),1)
    cv2.putText(vis,n,(5,18),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,0,0),2)
    tiles.append(vis); print(n,bg)
while len(tiles)%6: tiles.append(np.zeros_like(tiles[0]))
cv2.imwrite('art/diffs.jpg',np.vstack([np.hstack(tiles[i:i+6]) for i in range(0,len(tiles),6)]))
