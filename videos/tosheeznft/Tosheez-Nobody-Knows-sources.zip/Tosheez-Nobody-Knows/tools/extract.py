import sys, json; sys.path.insert(0,'tools')
from lib import *
bc,ba=load_rgba('art/base.png')
yy,xx=np.mgrid[0:N,0:N]
def get(n,bgpts=None):
    im,v=load(n)
    bg=np.median(np.array([im[y,x] for y,x in bgpts]),axis=0) if bgpts else bgcolor(im,v)
    im=np.where((v>0.5)[...,None],im,bg)
    a,c=matte(im,bg,v)
    d=np.linalg.norm(c-bc,axis=2)
    t=a*np.where(ba>0.5,np.clip((d-22)/23,0,1),1)
    hsv=cv2.cvtColor(np.clip(c,0,255).astype(np.uint8),cv2.COLOR_BGR2HSV).astype(np.float32)
    return dict(a=a,c=c,t=t,h=hsv[...,0],s=hsv[...,2]*0+hsv[...,1]/255,v=hsv[...,2])
def hue(S,lo,hi,smin=0.3):
    return (S['h']>=lo)&(S['h']<=hi)&(S['s']>=smin)
def clean(m,minarea=300,fill=True,close=2):
    m=m.astype(bool)
    if close: m=ndi.binary_closing(m,iterations=close)
    if fill: m=ndi.binary_fill_holes(m)
    lab,nl=ndi.label(m)
    if nl:
        sz=ndi.sum(m,lab,range(1,nl+1)); keep=np.zeros(nl+1,bool); keep[1:]=sz>=minarea; m=keep[lab]
    return m
layers={}
def emit(slot,name,S,mask,soft=None,src=''):
    m=cv2.GaussianBlur(mask.astype(np.float32),(0,0),0.8)
    a=np.minimum(S['t'] if soft is None else soft, m)
    a[a<0.02]=0
    ys,xs=np.where(a>0)
    x0,x1,y0,y1=max(xs.min()-2,0),min(xs.max()+3,N),max(ys.min()-2,0),min(ys.max()+3,N)
    save_rgba(f'art/layers/{slot}_{name}.png',S['c'][y0:y1,x0:x1],a[y0:y1,x0:x1])
    layers[f'{slot}_{name}']=dict(slot=slot,name=name,x=int(x0),y=int(y0),w=int(x1-x0),h=int(y1-y0),src=src)
    print(slot,name,x0,y0,x1-x0,y1-y0,flush=True)
D=lambda S: S['t']>0.5
band=(yy>=590)&(yy<=900)
# ---------------- HATS
S=get('crown'); m=D(S)&(yy<520)&~hue(S,95,135,0.35); m=clean(m,800); emit('hat','crown',S,m,src='crown')
S=get('halo'); m=D(S)&(yy<232); emit('hat','halo',S,clean(m,500),src='halo')
S=get('cone'); m=D(S)&(yy<615)&~((yy>535)&(S['s']<0.15)&(S['v']>150)); emit('hat','cone',S,clean(m,800),src='cone')
blind=get('cone'); 
S=get('foil'); m=D(S)&(yy<480)&~hue(S,12,38,0.35)&~(hue(S,0,12,0.4)|hue(S,168,180,0.4)); emit('hat','foil',S,clean(m,800),src='foil')
S=get('viking'); m=D(S)&(yy<625); emit('hat','viking',S,clean(m,800),src='viking')
ang=get('angel')
strap=((xx>=470)&(xx<=625)|(xx>=1145)&(xx<=1300))&(yy>=560)&(yy<1000)&(ang['v']<110)
chin=(yy>=950)&(yy<1130)&(xx>=560)&(xx<=1210)&(ang['v']<120)&(ang['s']<0.5)
m=D(ang)&((yy<575)|strap|chin); emit('hat','bikehelmet',ang,clean(m,400,fill=False),src='angel')
hh=get('hardhat',[(500,330),(500,1440),(300,600)]); m=D(hh)&(yy<600)&hue(hh,12,40,0.35); emit('hat','hardhat',hh,clean(m,800),src='hardhat')
la=get('laurel',[(500,330),(500,1440),(300,600)]); m=D(la)&(yy<585)&(la['v']>70)&hue(la,8,45,0.25); emit('hat','laurel',la,clean(m,300,fill=False),src='laurel')
# ---------------- EYES
S=get('trench'); m=D(S)&band; emit('eyes','pixel',S,clean(m,300),src='trench')
rc=get('raincoat'); m=D(rc)&band&(xx>=470)&(xx<=1300)&~hue(rc,120,165,0.25)&~hue(rc,12,40,0.35); emit('eyes','shades',rc,clean(m,300),src='raincoat')
pr=get('prison'); m=D(pr)&band&~hue(pr,30,90,0.25)&~((yy>840)&hue(pr,140,180,0.05)); emit('eyes','3d',pr,clean(m,300),src='prison')
rb=get('robe'); m=D(rb)&band; emit('eyes','gradient',rb,clean(m,300),src='robe')
su=get('suit'); m=D(su)&band&(xx>=545)&(xx<=1235)&~hue(su,135,168,0.3)&~(su['v']<70); emit('eyes','heart',su,clean(m,300),src='suit')
m=D(ang)&band&(xx>=520)&(xx<=1255)&~(strap); emit('eyes','clear',ang,clean(m,100,fill=False,close=1),src='angel')
m=D(blind)&(yy>=600)&((yy<1080)|((xx>1100)&(yy<1270)))&(xx>=380)&(xx<=1440)&~(blind['v']<60)&~hue(blind,0,25,0.45)&(yy>=575); emit('eyes','blindfold',blind,clean(m,500),src='cone')
# ---------------- MOUTH / SPECIAL
m=D(pr)&(yy>880)&(yy<1260)&(xx>620)&(xx<1150)&(yy<1185)&hue(pr,140,180,0.05); emit('mouth','bubblegum',pr,clean(m,800),src='prison')
vk=get('viking'); m=D(vk)&(yy>900)&(yy<1230)&(xx>520)&(xx<1010)&(vk['s']>0.35)&(hue(vk,0,25,0.35)|hue(vk,165,180,0.35)); emit('mouth','kazoo',vk,clean(m,400),src='viking')
w=D(ang)&(ang['s']<0.16)&(ang['v']>130)&((xx<560)|(xx>1210))&(yy>560); w=clean(w,3000); emit('back','wings',ang,w,src='angel')
# ---------------- FITS
def fitmask(S,extra_ex=None,top=950):
    m=(D(S)|(yy>=1200))&(S['a']>0.02)&(yy>=top)
    if extra_ex is not None: m&=~extra_ex
    return m
S=get('trench'); emit('fit','trench',S,clean(fitmask(S)&~band,800),soft=np.where(yy>=1200,S['a'],S['t']),src='trench')
cr=get('crown'); emit('fit','leather',cr,clean(fitmask(cr,hue(cr,95,135,0.35)&(yy<1150)),800),soft=np.where(yy>=1200,cr['a'],cr['t']),src='crown')
ha_neck=get('halo')
gum=(yy<1206)&(xx>600)&(xx<1170)&(yy>880)
neckbox=(yy>=1180)&(yy<1262)&(xx>600)&(xx<1170)&~(hue(pr,5,22,0.45))
pr['c']=np.where(neckbox[...,None],ha_neck['c'],pr['c']); pr['a']=np.where(neckbox,np.maximum(pr['a'],ha_neck['a']),pr['a']); pr['t']=np.where(neckbox,pr['a'],pr['t'])
gum=gum&(yy<1180)
emit('fit','prison',pr,clean(fitmask(pr,(hue(pr,30,90,0.25)&(yy<1150))|gum),800),soft=np.where(yy>=1200,pr['a'],pr['t']),src='prison')
ha=get('halo'); emit('fit','hoodie',ha,clean(fitmask(ha,hue(ha,12,40,0.35)&(yy<1150)),800),soft=np.where(yy>=1200,ha['a'],ha['t']),src='halo')
# raincoat incl hood
glass=band&(xx>=470)&(xx<=1300)&(rc['v']<90)
inb=ba>0.5
m=((D(rc)&~inb&~hue(rc,120,180,0.2))|(inb&hue(rc,15,40,0.4))|(yy>=1200))&(rc['a']>0.02)&~glass
m=clean(m,3000,fill=False); emit('fit','raincoat',rc,m,soft=np.where(yy>=1200,rc['a'],rc['t']),src='raincoat')
knot=(xx>1080)&(yy<1250)&(blind['s']<0.14)&(blind['v']>140)
emit('fit','fleece',blind,clean(fitmask(blind,knot),800),soft=np.where(yy>=1200,blind['a'],blind['t']),src='cone')
sstrap=((yy<1135)&(su['v']<80))|((yy<1212)&(xx>590)&(xx<1180))
emit('fit','suit',su,clean(fitmask(su,sstrap|(hue(su,135,168,0.3)&(yy<1100))),800),soft=np.where(yy>=1200,su['a'],su['t']),src='suit')
badge=hue(rb,95,120,0.5)&(yy>1450)&(xx>1000); badge=ndi.binary_dilation(badge,iterations=6)
rb['c']=cv2.inpaint(np.clip(rb['c'],0,255).astype(np.uint8),badge.astype(np.uint8)*255,9,cv2.INPAINT_TELEA).astype(np.float32)
emit('fit','robe',rb,clean(fitmask(rb),800),soft=np.where(yy>=1200,rb['a'],rb['t']),src='robe')
kaz=(yy>900)&(yy<1230)&(xx>430)&(xx<1010)&~((yy>1180))
kaz|=(yy<1270)&(xx>430)&(xx<720)&(hue(vk,0,12,0.45)|hue(vk,170,180,0.45))
emit('fit','vest',vk,clean(fitmask(vk,kaz),800),soft=np.where(yy>=1200,vk['a'],vk['t']),src='viking')
ov=get('overalls'); emit('fit','overalls',ov,clean(fitmask(ov),800),soft=np.where(yy>=1200,ov['a'],ov['t']),src='overalls')
wings_m=cv2.imread('art/layers/back_wings.png',cv2.IMREAD_UNCHANGED)
wfull=np.zeros((N,N),bool); L=layers['back_wings']; wfull[L['y']:L['y']+L['h'],L['x']:L['x']+L['w']]=wings_m[...,3]>10
wfull=ndi.binary_dilation(wfull,iterations=3)
emit('fit','tattoo',ang,clean(fitmask(ang,wfull|chin|strap|((yy<1212)&(xx>590)&(xx<1180))|((ang['s']<0.16)&(ang['v']>130)&(yy<1500))),800),soft=np.where(yy>=1200,ang['a'],ang['t']),src='angel')
fo=get('foil'); anat=((D(fo)&(xx>=868)&(yy>=420)&~hue(fo,12,40,0.25))|fitmask(fo))&~(hue(fo,15,40,0.3)&(yy<1000))
emit('fit','anatomy',fo,clean(anat&~((yy<480)&(fo['s']<0.15)),800),soft=np.where(yy>=1200,fo['a'],fo['t']),src='foil')
# ---------------- HAIR (recolour layers)
hairzone=ndi.binary_dilation(ba>0.3,iterations=30)&(yy<1060)
def hairlayer(name,S,lo,hi,smin,ymin=0,ex=None):
    m=hue(S,lo,hi,smin)&hairzone&(yy>=ymin)&(S['a']>0.02)
    if ex is not None: m&=~ex
    m=clean(m,200,fill=False,close=1)
    mc=ndi.binary_closing(m,iterations=3)
    hl,nh=ndi.label(ndi.binary_fill_holes(mc)&~mc)
    small=np.zeros(nh+1,bool)
    if nh: small[1:]=ndi.sum(np.ones_like(hl),hl,range(1,nh+1))<2500
    holes=small[hl]|(mc&~m)
    mf=m|holes
    # colour hair replaces default hair: cover small base-hair tufts the colour layer misses
    bh=(ba>0.5)&(np.abs(bc[...,2]-bc[...,0])<25)&(bc.max(2)<150)&hairzone&(yy<900)
    unc=bh&~mf
    ul,un=ndi.label(unc)
    if un:
        sz=ndi.sum(np.ones_like(ul),ul,range(1,un+1))
        near=ndi.binary_dilation(mf,iterations=3)
        touch=np.zeros(un+1,bool); touch[1:]=ndi.maximum(near,ul,range(1,un+1))>0
        ok=np.zeros(un+1,bool); ok[1:]=(sz<6000)
        add_=(ok&touch)[ul]
        holes=holes|add_; mf=mf|add_
    if holes.any():
        S['c']=cv2.inpaint(np.clip(S['c'],0,255).astype(np.uint8),holes.astype(np.uint8)*255,5,cv2.INPAINT_TELEA).astype(np.float32)
        S['a']=np.where(holes,1.0,S['a'])
    emit('hair',name,S,mf,soft=S['a'],src=name)
hairlayer('green',pr,30,90,0.25)
ring=ndi.binary_dilation(D(ha)&(yy<200),iterations=4)
hairlayer('blonde',ha,12,40,0.35,ex=ring)
mt=get('math',[(150,885),(300,300),(300,1469)])
cr2=get('crown')
crownm=ndi.binary_dilation(clean(D(cr2)&(yy<520)&~hue(cr2,95,135,0.35),800),iterations=8)
bcr=hue(cr2,105,135,0.35)&~crownm
bmt=hue(mt,105,135,0.35)&crownm&(yy<590)
B=dict(cr2); B['c']=np.where(bcr[...,None],cr2['c'],mt['c']); B['a']=np.where(bcr,cr2['a'],np.where(bmt,mt['a'],cr2['a']))
B['h']=np.where(bcr,cr2['h'],mt['h']); B['s']=np.where(bcr,cr2['s'],mt['s']); B['v']=np.where(bcr,cr2['v'],mt['v'])
hairlayer('blue',B,105,135,0.35,ex=~(bcr|bmt))
json.dump(layers,open('art/layers/layers.json','w'),indent=1)
