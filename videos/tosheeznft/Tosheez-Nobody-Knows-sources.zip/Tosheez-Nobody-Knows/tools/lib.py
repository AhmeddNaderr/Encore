import cv2, numpy as np
from scipy import ndimage as ndi
P='art/aligned/'
N=1769
def load(n):
    im=cv2.imread(P+n+'.png').astype(np.float32)
    v=cv2.imread(P+n+'_valid.png',0).astype(np.float32)/255
    return im,v
def bgcolor(im,v,pts=None):
    if pts is None:
        pts=[(30,30),(30,N-30),(N//2,30),(N//2,N-30),(200,200),(200,N-200)]
    cs=[im[y,x] for (y,x) in pts if v[y,x]>0.99]
    return np.median(np.array(cs),axis=0)
def matte(im,bg,valid=None,thr=18,band=3,minarea=800):
    d=np.linalg.norm(im-bg,axis=2)
    m=d>thr
    m=ndi.binary_opening(m,iterations=1)
    lab,nl=ndi.label(m); 
    if nl:
        sizes=ndi.sum(m,lab,range(1,nl+1)); keep=np.zeros(nl+1,bool); keep[1:]=sizes>=minarea; m=keep[lab]
    m=ndi.binary_fill_holes(m)
    inner=ndi.binary_erosion(m,iterations=band); outer=~ndi.binary_dilation(m,iterations=band)
    _,(iy,ix)=ndi.distance_transform_edt(~inner,return_indices=True)
    F=im[iy,ix]
    fb=F-bg; num=((im-bg)*fb).sum(2); den=np.maximum((fb*fb).sum(2),1.0)
    a=np.clip(num/den,0,1)
    a[inner]=1; a[outer]=0
    col=np.where(inner[...,None],im,F)
    if valid is not None: a=a*np.clip((valid-0.02)/0.96,0,1)
    return a.astype(np.float32),col.astype(np.float32)
def save_rgba(path,col,a):
    out=np.dstack([np.clip(col,0,255),np.clip(a*255,0,255)]).astype(np.uint8)
    cv2.imwrite(path,out)
def load_rgba(path):
    x=cv2.imread(path,cv2.IMREAD_UNCHANGED).astype(np.float32)
    return x[...,:3],x[...,3]/255
