import sys; sys.path.insert(0,'tools')
from lib import *
def mat(n):
    im,v=load(n); bg=bgcolor(im,v); a,c=matte(im,bg,v); return im,a,c,bg
tr,ta,tc,tbg=mat('trench'); ha,haa,hac,_=mat('halo'); vk,vka,vkc,_=mat('viking'); hh,hha,hhc,_=mat('hardhat'); cr,cra,crc,_=mat('crown')
band=np.zeros((N,N),bool); band[600:880,380:1400]=True
d=np.minimum.reduce([np.linalg.norm(tc-x,axis=2) for x in [hac,vkc,hhc,crc]])
gl=band&(d>40)&(ta>0.5)
gl=ndi.binary_closing(gl,iterations=3); gl=ndi.binary_fill_holes(gl); gl=ndi.binary_dilation(gl,iterations=7)
def sat(c):
    mx=c.max(2); mn=c.min(2); return (mx-mn)/np.maximum(mx,1)
core=np.zeros((N,N),bool); core[:,560:1220]=True
hc=np.linalg.norm(hac-crc,axis=2)<30
# outside core choose least-saturated opaque candidate among viking/hardhat/halo/crown
cands=[(vkc,vka),(hhc,hha),(hac,haa),(crc,cra)]
score=np.stack([sat(c)+ (1-a)*5 for c,a in cands])
idx=score.argmin(0)
pick=np.zeros_like(tc); pa=np.zeros_like(ta)
for i,(c,a) in enumerate(cands):
    pick[idx==i]=c[idx==i]; pa[idx==i]=a[idx==i]
src=np.where((core&hc)[...,None],hac,pick); sa=np.where(core&hc,haa,pa)
glf=cv2.GaussianBlur(gl.astype(np.float32),(0,0),2)
a=ta*(1-glf)+np.minimum(ta,sa)*glf
pm=tc*(ta*(1-glf))[...,None]+src*(np.minimum(ta,sa)*glf)[...,None]
col=np.where((a>1e-3)[...,None],pm/np.maximum(a,1e-3)[...,None],tc)
# neck cut: smooth fade between y=1230..1290 (fits always cover below)
yy=np.arange(N)[:,None].astype(np.float32)
fade=np.clip((1290-yy)/60,0,1)
# remove coat/collar near neck sides above cut: keep skin-like pixels in lower zone
low=(yy>990)&np.ones((1,N),bool)
agree=np.zeros((N,N),np.int32)
for c,aa in [(hac,haa),(crc,cra),(hhc,hha),(vkc,vka)]:
    agree+=(np.linalg.norm(col-c,axis=2)<28)&(aa>0.5)
bad=low&(agree<2)
bad=ndi.binary_opening(bad,iterations=2); bad=ndi.binary_dilation(bad,iterations=2)
keepf=cv2.GaussianBlur((~bad).astype(np.float32),(0,0),1.5)
a=a*fade*keepf
save_rgba('art/base.png',col,a)
pv=col*a[...,None]+np.array([200,200,200])*(1-a[...,None])
cv2.imwrite('art/base_preview.jpg',cv2.resize(pv,(884,884)).astype(np.uint8))
cv2.imwrite('art/base_detail.jpg',pv[500:900,350:1450].astype(np.uint8))
# cleanup: cool-tinted fringe pixels (bg bleed) and non-skin pixels in neck zone
B_,G_,R_=col[...,0],col[...,1],col[...,2]
cool=(B_-R_)>10
a[cool]=0
neck=(yy>1100)&np.ones((1,N),bool)
skin=(R_>150)&(R_>G_)&(G_>B_)
a[neck&~skin]=0
save_rgba('art/base.png',col,a)
pv=col*a[...,None]+np.array([200,200,200])*(1-a[...,None])
cv2.imwrite('art/base_preview.jpg',cv2.resize(pv,(884,884)).astype(np.uint8))
