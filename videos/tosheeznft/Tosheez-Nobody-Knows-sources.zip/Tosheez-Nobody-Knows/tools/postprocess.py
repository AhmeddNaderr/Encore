# clean tiny islands, export 1024-canvas game layers, rebuild side-by-side evidence
import cv2, json, numpy as np, glob, sys
from scipy import ndimage as ndi
for f in glob.glob('art/layers/*.png'):
    x=cv2.imread(f,cv2.IMREAD_UNCHANGED); a=x[...,3]
    m=a>20; lab,n=ndi.label(m)
    if n>1:
        sz=ndi.sum(m,lab,range(1,n+1)); big=sz.max()
        small=np.zeros(n+1,bool); small[1:]=(sz<max(400,0.004*big))
        kill=ndi.binary_dilation(small[lab],iterations=2)
        x[...,3]=np.where(kill,0,a); cv2.imwrite(f,x)
S=1024/1769
L=json.load(open('art/layers/layers.json'))
def scale_rgba(x,w,h):
    a=x[...,3:4].astype(np.float32)/255; c=x[...,:3].astype(np.float32)*a
    c=cv2.resize(c,(w,h),interpolation=cv2.INTER_AREA); a2=cv2.resize(a,(w,h),interpolation=cv2.INTER_AREA)[...,None]
    c=np.where(a2>1e-3,c/np.maximum(a2,1e-3),0)
    return np.dstack([np.clip(c,0,255),np.clip(a2*255,0,255)]).astype(np.uint8)
out={}; items=dict(L); items['base']=None
for k in items:
    if k=='base':
        x=cv2.imread('art/base.png',cv2.IMREAD_UNCHANGED); ys,xs=np.where(x[...,3]>2)
        x0,y0=xs.min(),ys.min(); x=x[y0:ys.max()+1,x0:xs.max()+1]; m=dict(slot='base',name='base',x=int(x0),y=int(y0))
    else:
        x=cv2.imread(f'art/layers/{k}.png',cv2.IMREAD_UNCHANGED); m=L[k]
    X0=int(np.floor(m['x']*S)); Y0=int(np.floor(m['y']*S))
    w=max(1,int(round(x.shape[1]*S))); h=max(1,int(round(x.shape[0]*S)))
    cv2.imwrite(f'game/assets/layers/{k}.png',scale_rgba(x,w,h),[cv2.IMWRITE_PNG_COMPRESSION,9])
    out[k]=dict(slot=m['slot'],name=m['name'],x=X0,y=Y0,w=w,h=h)
json.dump(dict(canvas=1024,layers=out),open('game/assets/layers.json','w'),indent=1)
sys.path.insert(0,'tools')
from compose import *
pairs=[('crown',['hat_crown','hair_blue','fit_leather']),('halo',['hat_halo','hair_blonde','fit_hoodie']),('cone',['hat_cone','eyes_blindfold','fit_fleece']),('prison',['hair_green','eyes_3d','mouth_bubblegum','fit_prison'])]
rows=[]
for src,traits in pairs:
    o=cv2.imread(f'art/aligned/{src}.png').astype(np.float32); bg=o[30,30]
    c=compose(traits,bg=tuple(float(v) for v in bg))
    a=cv2.resize(o,(600,600),interpolation=cv2.INTER_AREA); b=cv2.resize(c,(600,600),interpolation=cv2.INTER_AREA)
    rows.append(np.hstack([a,np.full((600,20,3),255,np.float32),b]))
img=np.vstack([np.vstack([r,np.full((20,1220,3),255,np.float32)]) for r in rows]).astype(np.uint8)
hdr=np.full((60,1220,3),255,np.uint8)
cv2.putText(hdr,'OFFICIAL POST',(170,40),cv2.FONT_HERSHEY_SIMPLEX,1.0,(40,40,40),2)
cv2.putText(hdr,'REBUILT FROM EXTRACTED LAYERS',(700,40),cv2.FONT_HERSHEY_SIMPLEX,0.9,(40,40,40),2)
cv2.imwrite('art/side_by_side.jpg',np.vstack([hdr,img]),[cv2.IMWRITE_JPEG_QUALITY,88])
print('done',len(out))
