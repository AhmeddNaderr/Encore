"""Original score + SFX for TRIPPI: LAST TRAIN TOWN (game concept film). All synthesised; cues from events.json."""
import json, sys
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
from scipy.io import wavfile

SR = 48000; DUR = 46.0; N = int(SR * DUR)
rng = np.random.default_rng(2309)
L = np.zeros(N); R = np.zeros(N); SEND = np.zeros((2, N)); MUS = np.zeros((2, N))

def ta(d): return np.arange(int(d * SR)) / SR
def env(d, a=.005, curve=6.0): t = ta(d); return np.minimum(1, t / max(a, 1e-4)) * np.exp(-curve * t / d)
def put(buf, t0, sig, g, pan, rev):
    i = int(t0 * SR)
    if i >= N or i < 0: return
    n = min(len(sig), N - i); s = sig[:n] * g; lg, rg = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    buf[0][i:i + n] += s * lg * 1.414; buf[1][i:i + n] += s * rg * 1.414
    if rev: SEND[0, i:i + n] += s * lg * rev; SEND[1, i:i + n] += s * rg * rev
def add(t0, sig, g=1.0, pan=0.0, rev=0.0): put((L, R), t0, sig, g, pan, rev)
def madd(t0, sig, g=1.0, pan=0.0, rev=0.0): put((MUS[0], MUS[1]), t0, sig, g, pan, rev)
def lp(x, fc): return sosfilt(butter(2, min(fc, SR / 2 - 100) / (SR / 2), 'low', output='sos'), x)
def hp(x, fc): return sosfilt(butter(2, fc / (SR / 2), 'high', output='sos'), x)
def bp(x, lo, hi): return sosfilt(butter(2, [lo / (SR / 2), hi / (SR / 2)], 'band', output='sos'), x)
def noise(d): return rng.standard_normal(int(d * SR))
def sine(f, d): return np.sin(2 * np.pi * f * ta(d))
def sweep(f0, f1, d, kind='sin'):
    t = ta(d); f = f0 * (f1 / f0) ** (t / d); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) if kind == 'sin' else (np.sign(np.sin(ph)) * .6 if kind == 'sq' else 2 * ((ph / (2 * np.pi)) % 1) - 1)
def saw(f, d, det=0.0):
    t = ta(d); s = 2 * ((f * t) % 1) - 1
    return .5 * s + .5 * (2 * ((f * (1 + det) * t) % 1) - 1) if det else s
def sq(f, d, duty=.5): return np.where((f * ta(d)) % 1 < duty, 1.0, -1.0)
def mtof(m): return 440 * 2 ** ((m - 69) / 12)
def bell(m, d, g=1): f0 = mtof(m); return g * sum(a * sine(f0 * p, d) * np.exp(-ta(d) * dr) for p, a, dr in [(1, 1, 2), (2.76, .4, 3.5), (5.4, .2, 6)])
def whoosh(t, d=.5, g=.14, lo=500, hi=7000): add(t, bp(noise(d), lo, hi) * np.sin(np.pi * ta(d) / d) ** 2, g, rev=.2)

PENTA = [0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24]
def sfx(e):
    t, k = e['t'], e['type']
    if k == 'title_hit':
        add(t, sine(50, .9) * env(.9, .002, 4), .6, rev=.3); add(t, lp(noise(.3), 4000) * env(.3, .001, 7), .25, rev=.4)
        for m in [57, 64, 69, 72, 76]: add(t, lp(saw(mtof(m), 2.0, .006), 3000) * env(2.0, .005, 2.5), .045, rev=.5)
    elif k == 'pop_big':
        add(t, sweep(240, 900, .12) * env(.12, .002, 3), .2, rev=.3)
        for j in range(6): add(t + .05 + j * .04, sine(mtof(84 + j * 2), .2) * env(.2, .001, 6), .03, rng.uniform(-.5, .5), rev=.5)
    elif k == 'tick': add(t, sine(2400, .04) * env(.04, .001, 8), .06, rev=.2)
    elif k == 'start':
        for j, m in enumerate([72, 76, 79, 84]): add(t + j * .05, (sq(mtof(m), .25, .25) * .4 + sine(mtof(m), .25)) * env(.25, .002, 4), .07, rev=.35)
    elif k == 'whoosh': whoosh(t)
    elif k == 'tap': add(t, sine(1200, .05) * env(.05, .001, 7) + lp(noise(.05), 3000) * env(.05, .0005, 9) * .4, .1)
    elif k == 'collect':
        add(t, sweep(400, 1600, .18, 'sq') * env(.18, .002, 3) * .4 + sweep(400, 1600, .18) * env(.18, .002, 3), .07, rev=.3)
    elif k == 'coin':
        m = 84 + PENTA[e['n'] % len(PENTA)] % 12
        add(t, (sine(mtof(m), .18) + .4 * sine(mtof(m) * 2.01, .18)) * env(.18, .001, 6), .045, rng.uniform(-.5, .5), rev=.3)
    elif k == 'tray': whoosh(t, .35, .12, 800, 6000); add(t + .25, sine(90, .2) * env(.2, .002, 6), .3)
    elif k == 'pickup': add(t, sweep(500, 1100, .1) * env(.1, .002, 4), .1)
    elif k == 'drop': add(t, sweep(900, 300, .15) * env(.15, .002, 3), .1); add(t + .05, sine(70, .3) * env(.3, .002, 6), .45, rev=.2)
    elif k == 'build_start':
        for j in range(4): add(t + j * .3, lp(noise(.1), 2500) * env(.1, .001, 8) + sine(120, .1) * env(.1, .001, 8), .25, rng.uniform(-.3, .3), rev=.2)
    elif k == 'weld': add(t, hp(noise(.09), 4000) * env(.09, .002, 3), .05, rng.uniform(-.4, .4))
    elif k == 'pop': add(t, sweep(500 + e.get('n', 0) * 60, 1300 + e.get('n', 0) * 80, .06) * env(.06, .001, 4), .1, rev=.15)
    elif k == 'fanfare':
        for j, m in enumerate([72, 76, 79, 84, 88]): add(t + j * .06, (saw(mtof(m), .5, .005) * .5 + sine(mtof(m), .5)) * env(.5, .003, 3), .06, rev=.4)
        add(t, hp(noise(1.0), 6000) * env(1.0, .01, 2.5), .05, rev=.4)
    elif k == 'banner': whoosh(t - .05, .4, .12); add(t + .25, sine(60, .4) * env(.4, .002, 5), .35, rev=.25)
    elif k == 'brake':
        d = 1.4; st = ta(d); f = 2700 + 60 * np.sin(2 * np.pi * 7 * st)
        s = np.sin(2 * np.pi * np.cumsum(f) / SR) + .3 * np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR); add(t + .1, s * np.sin(np.pi * st / d) ** 2, .03, rev=.4)
        add(t + 1.3, hp(noise(.6), 1500) * env(.6, .02, 4), .07, rev=.3)
    elif k == 'doors':
        add(t, bell(81, .5, .5), .05, rev=.3); add(t + .18, bell(77, .6, .5), .05, rev=.3); add(t + .3, hp(noise(.4), 1200) * env(.4, .02, 4), .05)
    elif k == 'board':
        m = 79 + PENTA[e['n'] % 8]; add(t, sweep(mtof(m) * .8, mtof(m), .08) * env(.08, .002, 4), .05, rng.uniform(-.6, .6), rev=.25)
    elif k == 'quest':
        for j, m in enumerate([76, 79, 84]): add(t + j * .07, (sq(mtof(m), .22, .25) * .4 + sine(mtof(m), .22)) * env(.22, .002, 4), .055, rev=.35)
    elif k == 'depart': add(t, lp(np.cumsum(noise(1.5)) * .004, 300) * np.linspace(0, 1, int(1.5 * SR)), .4); whoosh(t + .8, .8, .08)
    elif k == 'alarm':
        for j in range(4): add(t + j * .36, sweep(700, 1100, .18, 'sq') * env(.18, .005, 1), .05); add(t + j * .36 + .18, sweep(1100, 700, .18, 'sq') * env(.18, .005, 1), .05)
    elif k == 'drone':
        d = 6.4; tt = ta(d); s = saw(110, d) * .5 + saw(111.5, d) * .5; s = lp(s, 600) * (1 + .3 * np.sin(2 * np.pi * 24 * tt))
        e_ = np.minimum(1, tt / .7) * np.minimum(1, (d - tt) / .8); add(t, s * e_, .05, -.4)
    elif k == 'bot_land': add(t, sine(180, .08) * env(.08, .001, 6), .12, rng.uniform(-.4, .4)); add(t, sq(1400, .04) * env(.04, .001, 6), .03)
    elif k == 'cone_slam': add(t, sine(55, .6) * env(.6, .001, 5), .7, rev=.2); add(t, lp(noise(.2), 2000) * env(.2, .001, 7), .45, rev=.3); add(t + .02, bp(noise(.3), 300, 900) * env(.3, .002, 5), .3)
    elif k == 'honey_throw': whoosh(t, .45, .1, 300, 3000)
    elif k == 'splat':
        s = lp(noise(.35), 900) * env(.35, .002, 4); add(t, s, .5, rev=.2)
        for j in range(5): add(t + .05 + j * .07, sweep(300, 120, .12) * env(.12, .005, 3), .06, rng.uniform(-.5, .5))
    elif k == 'spring': add(t, sweep(120, 900, .25) * env(.25, .005, 2), .15, rev=.2)
    elif k == 'boing':
        d = .6; tt = ta(d); f = 220 * (1 + .5 * np.exp(-tt * 6) * np.sin(2 * np.pi * 14 * tt)); add(t, np.sin(2 * np.pi * np.cumsum(f) / SR) * env(d, .003, 3), .25, rev=.3)
    elif k == 'launch':
        add(t, sweep(300 + e['n'] * 60, 1400 + e['n'] * 120, .3) * env(.3, .002, 3), .05, -.6 + e['n'] * .17, rev=.3)
        add(t + .25, bell(88 + PENTA[e['n'] % 6], .3, .6), .04, -.6 + e['n'] * .17, rev=.5)
    elif k == 'firework':
        add(t, sweep(300, 2000, .5) * np.linspace(0, 1, int(.5 * SR)) * .3, .04); d = 1.6
        add(t + .5, lp(noise(.25), 1500) * env(.25, .001, 6), .35, rng.uniform(-.5, .5), rev=.5); add(t + .55, hp(noise(d), 3000) * env(d, .01, 3) * (np.floor(ta(d) * 30) % 2), .08, rev=.4)
    elif k == 'chime_arrive':
        for j, m in enumerate([81, 77, 72, 76, 81]): add(t + j * .22, bell(m, 1.4), .06, rev=.5)
    elif k == 'climb':
        for j in range(8): add(t + j * .13, sq(mtof(72 + j * 2), .1, .3) * env(.1, .002, 4), .05, rev=.3)
    elif k == 'posted': add(t, bell(84, .8), .08, rev=.4); add(t + .1, bell(91, .8), .06, rev=.4)
    elif k == 'chime': add(t, bell(81, 3.0), .09, rev=.6); add(t + .08, bell(88, 2.5), .04, rev=.6)

# ---------------- music: 100 BPM, A minor / C major lift, grid from 3.2 s
B = 60 / 100; T0 = 3.2
CH = [[57, 60, 64, 67, 71], [53, 57, 60, 64, 67], [48, 55, 59, 62, 64], [55, 59, 62, 65, 69]]  # Am9 Fmaj9 Cmaj9 G9
ROOT = [45, 41, 48, 43]
def section(t):
    """drums, bass, keys, arp, cutoff, hat16"""
    if t < 3.2: return 0, 0, .6, 0, 1800, 0
    if t < 17.2: return .85, 1, 1, 1, 9000, 0
    if t < 18.6: return .4, .6, .9, .5, lerp_(9000, 1200, (t - 17.2) / 1.4), 0
    if t < 21.9: return .25, .4, .9, .8, 2500, 0
    if t < 23.6: return .5, .8, 1, 1, lerp_(2500, 9000, (t - 21.9) / 1.7), 1
    if t < 31.6: return 1.15, 1.15, .9, 1.1, 10000, 1
    if t < 36.4: return 1.05, 1.1, 1.25, 1, 11000, 0
    if t < 41.4: return .75, .9, 1, .9, 8000, 0
    return 0, 0, 0, 0, 3000, 0
def lerp_(a, b, k): k = min(1, max(0, k)); return a + (b - a) * k
def kick(): d = .4; t = ta(d); f = 46 + 120 * np.exp(-t * 30); return np.tanh(2.4 * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 8))
def snare(): d = .28; return bp(noise(d), 1500, 9000) * np.exp(-ta(d) * 17) + sine(200, d) * np.exp(-ta(d) * 26) * .6
def clap(): d = .2; n = bp(noise(d), 900, 5000); e = np.exp(-ta(d) * 22); e[:int(.012 * SR)] *= (np.floor(ta(.012) * 250) % 2); return n * e
def hat(o=False): d = .2 if o else .045; return hp(noise(d), 7500) * np.exp(-ta(d) * (13 if o else 75))
KICK, SNARE, CLAP, HAT, OHAT = kick(), snare(), clap(), hat(), hat(True)
for bar in range(-2, 16):
    bt = T0 + bar * 4 * B; ci = bar % 4; chord = CH[ci]
    if bt > 41.6: break
    dg, bg, kg, ag, fc, h16 = section(bt + .01)
    if kg:
        d = 4 * B + .3; pad = sum(lp(saw(mtof(m), d, .004), min(fc, 2800)) for m in chord) / len(chord)
        a = np.minimum(1, ta(d) / .3) * np.minimum(1, (d - ta(d)) / .3); madd(max(bt, 0), pad[int(max(0, -bt) * SR):] * a[int(max(0, -bt) * SR):], .1 * kg, rev=.25)
    for st in range(16):
        tt = bt + st * B / 4 + (B / 4 * .1 if st % 2 else 0)
        if tt < 0 or tt >= 41.4: continue
        dg, bg, kg, ag, fc, h16 = section(tt)
        if dg:
            if st in (0, 7, 8, 10) and not (22.9 < tt < 23.6): madd(tt, lp(KICK, fc * 1.4), .5 * dg)
            if st in (4, 12): madd(tt, lp(SNARE, fc), .22 * dg, rev=.15); madd(tt, lp(CLAP, fc), .18 * dg, .1, rev=.2)
            if st % 2 == 0 or h16: madd(tt, HAT, (.05 if st % 4 else .075) * dg, .25)
            if st == 14: madd(tt, OHAT, .045 * dg, .25)
        if bg and st in (0, 3, 6, 8, 11, 14):
            m = ROOT[ci] + (12 if st == 11 else 0) + (7 if st == 14 else 0); d = B / 2 if st in (0, 8) else B / 4
            s = np.tanh(1.8 * (sine(mtof(m), d) + .35 * sine(mtof(m) * 2, d))) * np.minimum(1, ta(d) / .004) * np.exp(-ta(d) * 3)
            madd(tt, lp(s, min(fc, 1300)), .26 * bg)
        if ag:
            pat = [0, 2, 4, 2, 1, 3, 4, 3, 0, 2, 4, 2, 1, 4, 3, 2]; m = chord[pat[st] % 5] + 12 + (12 if st in (5, 13) else 0)
            d = .2; s = lp(sq(mtof(m), d, .25) * .5 + saw(mtof(m), d) * .5, min(fc, 4500)) * np.exp(-ta(d) * 15)
            madd(tt, s, .042 * ag, -.4 + .8 * ((st * 7) % 16) / 15, rev=.3)
# lead hook over the hero shot
HOOK = [(0, 76, 1), (1, 79, .5), (1.5, 81, 1.5), (3, 84, 1), (4, 83, .5), (4.5, 81, .5), (5, 79, 1), (6, 76, 2), (8, 76, .5), (8.5, 79, .5), (9, 81, 1), (10, 88, 2)]
hs = T0 + round((31.6 - T0) / B) * B
for b, m, l in HOOK:
    tt = hs + b * B
    if tt > 36.3: continue
    d = l * B + .05; s = lp(saw(mtof(m), d, .006) * .6 + sq(mtof(m), d, .25) * .4, 3800) * np.minimum(1, ta(d) / .01) * np.exp(-ta(d) * 1.6)
    madd(tt, s, .07, .1, rev=.45)
# riser into the raid, final chord
d = 1.6; madd(22.0, bp(noise(d), 300, 9000) * (ta(d) / d) ** 3, .12); madd(23.6, sine(40, 1.2) * np.exp(-ta(1.2) * 2.5), .5)
d = 4.5; fin = sum(lp(saw(mtof(m), d, .005), 2000) for m in [45, 57, 64, 69, 72, 76]) / 6; madd(41.4, fin * np.minimum(1, ta(d) / .05) * np.exp(-ta(d) * .7), .16, rev=.5)

# ambience: rain + train rumble under gameplay
def bed(t0, t1, fn, g, fade=.4):
    d = t1 - t0; s = fn(d); e = np.minimum(1, np.minimum(ta(d) / fade, (d - ta(d)) / fade)); add(t0, s * e, g)
bed(0, 17.4, lambda d: bp(noise(d), 1500, 9000) * .5 + lp(noise(d), 600) * .4, .05)
bed(23.4, 31.8, lambda d: bp(noise(d), 1500, 9000) * .6 + lp(noise(d), 600) * .5, .07)
clack = lp(noise(.05), 900) * env(.05, .001, 7) + sine(70, .05) * env(.05, .001, 6)
for tt in np.arange(.3, 36.4, .43):
    sp = 1 if not (17.2 < tt < 23.4) else 0
    if sp: add(tt, clack, .06, .3); add(tt + .06, clack, .045, .3)

events = json.load(open(sys.argv[1]))
for e in events: sfx(e)
irt = ta(2.0); IR = np.stack([lp(rng.standard_normal(len(irt)) * np.exp(-irt * 3.4), 6000) * .05 for _ in range(2)])
WET = np.stack([fftconvolve(SEND[c], IR[c])[:N] for c in range(2)])
mix = np.stack([L, R]) + MUS * .9 + WET; mix = hp(mix, 25); mix = np.tanh(mix * 1.15) / np.tanh(1.15)
peak = np.abs(mix).max(); mix = mix / peak * .89; f = int(.4 * SR); mix[:, -f:] *= np.linspace(1, 0, f)
wavfile.write(sys.argv[2], SR, (mix.T * 32767).astype(np.int16)); print('wrote', sys.argv[2], 'peak', round(float(peak), 3))
