'use strict';
/* ART PASS for Last Train Town: baked parallax city, lit train, motion blur, bloom and grade.
   Loaded after game.js; redefines the world-drawing functions. */
const WC = mk(W, H), wx = WC.getContext('2d');       // world before post
const LC = mk(W, H), lcx = LC.getContext('2d');      // layer scratch
const AC = mk(W, H), acx = AC.getContext('2d');      // motion-blur accumulation
const BL1 = mk(270, 270), bl1 = BL1.getContext('2d'), BL2 = mk(270, 270), bl2 = BL2.getContext('2d'), BL3 = mk(135, 135), bl3 = BL3.getContext('2d');
let T_NOW = 0, SKYC, GRAFFP, L_CLOUD, L_FAR, L_MID2, L_MID, L_VIA, L_BRB, L_BRF;
function withCtx(ctx, fn) { const o = g; g = ctx; try { fn(); } finally { g = o; } }
function camOn() { g.save(); g.translate(540, 560); g.scale(CAM.z, CAM.z); g.translate(-CAM.x, -CAM.y); }
const LIT = ['#ffd98a', '#ffd98a', '#ffc66b', '#ffe9b8', '#ffd98a', '#7ff0d4', '#ff8fbd', '#cfe8ff'];

/* ------------------------------------------------------------------ bakes */
function bakeStrip(w, h, fn) { const c = mk(w, h); withCtx(c.getContext('2d'), fn); return c; }
function blurred(c, px) { const d = mk(c.width, c.height), x = d.getContext('2d'); x.filter = `blur(${px}px)`; x.drawImage(c, 0, 0); return d; }
function bakeSky() {
  return bakeStrip(W, H, () => {
    let gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#040817'); gr.addColorStop(.32, '#0a1b38'); gr.addColorStop(.66, '#15405c'); gr.addColorStop(1, '#2b6676'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    gr = g.createRadialGradient(620, 1180, 80, 620, 1180, 880); gr.addColorStop(0, 'rgba(255,120,175,.34)'); gr.addColorStop(1, 'rgba(255,120,175,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    gr = g.createRadialGradient(120, 980, 40, 120, 980, 640); gr.addColorStop(0, 'rgba(80,235,200,.2)'); gr.addColorStop(1, 'rgba(80,235,200,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    g.save(); g.filter = 'blur(46px)'; g.translate(540, 300); g.rotate(-.5); g.fillStyle = 'rgba(120,150,255,.10)'; g.fillRect(-900, -70, 1800, 140); g.restore();
    const r = mulberry(5);
    for (let i = 0; i < 300; i++) { const x = r() * W, y = Math.pow(r(), 1.5) * 760, s = .5 + r() * 1.4; g.globalAlpha = .25 + r() * .7; g.fillStyle = r() < .15 ? '#ffe9c8' : '#e6f3ff'; g.beginPath(); g.arc(x, y, s, 0, 7); g.fill(); }
    g.globalAlpha = 1;
  });
}
function bakeClouds() {
  return bakeStrip(2400, 700, () => {
    const r = mulberry(17); g.filter = 'blur(26px)';
    for (let i = 0; i < 46; i++) { const x = r() * 2400, y = 120 + r() * 460, w = 120 + r() * 260, h = 22 + r() * 46; const under = r() < .4;
      g.fillStyle = under ? 'rgba(255,150,190,.13)' : 'rgba(70,120,160,.22)';
      for (const dx of [-2400, 0, 2400]) { g.beginPath(); g.ellipse(x + dx, y, w, h, 0, 0, 7); g.fill(); } }
    g.filter = 'none';
  });
}
function tank(cx, y, s, o) {
  const w = 50 * s, h = 46 * s, leg = 20 * s; g.fillStyle = o.c1; g.fillRect(cx - w * .42, y - leg, 3 * s, leg); g.fillRect(cx + w * .42 - 3 * s, y - leg, 3 * s, leg); g.fillRect(cx - 1.5 * s, y - leg, 3 * s, leg);
  const gr = g.createLinearGradient(cx - w / 2, 0, cx + w / 2, 0); gr.addColorStop(0, o.hi); gr.addColorStop(.35, o.c0); gr.addColorStop(1, o.c1); g.fillStyle = gr; g.fillRect(cx - w / 2, y - leg - h, w, h);
  g.fillStyle = 'rgba(0,0,0,.25)'; for (let k = 1; k < 4; k++) g.fillRect(cx - w / 2, y - leg - h + k * h / 4, w, 1.5 * s);
  g.fillStyle = o.c1; g.beginPath(); g.moveTo(cx - w / 2 - 3 * s, y - leg - h); g.lineTo(cx, y - leg - h - 18 * s); g.lineTo(cx + w / 2 + 3 * s, y - leg - h); g.fill();
}
function antenna(cx, y, s, o, r) {
  const h = (70 + r() * 90) * s; g.strokeStyle = o.c1; g.lineWidth = 3 * s; g.beginPath(); g.moveTo(cx, y); g.lineTo(cx, y - h); g.moveTo(cx - 12 * s, y - h * .55); g.lineTo(cx + 12 * s, y - h * .55); g.moveTo(cx - 8 * s, y - h * .8); g.lineTo(cx + 8 * s, y - h * .8); g.stroke();
  g.save(); g.fillStyle = '#ff5a5a'; g.shadowColor = '#ff4040'; g.shadowBlur = 14 * s; g.beginPath(); g.arc(cx, y - h, 3.2 * s, 0, 7); g.fill(); g.restore();
}
function billboard(x, y, r) {
  const w = 200, h = 124, by = y - 42 - h; g.fillStyle = '#081119'; g.fillRect(x + 34, y - 44, 7, 40); g.fillRect(x + w - 41, y - 44, 7, 40); g.fillRect(x - 6, by - 6, w + 12, h + 12);
  const k = Math.floor(r() * 6); g.save(); g.beginPath(); g.rect(x, by, w, h); g.clip();
  const cover = (im) => { const sc = Math.max(w / im.width, h / im.height) * 1.02; g.drawImage(im, x + w / 2 - im.width * sc / 2, by + h / 2 - im.height * sc * .42, im.width * sc, im.height * sc); };
  if (k === 0) { g.fillStyle = '#0f8f74'; g.fillRect(x, by, w, h); const lw = 176; g.drawImage(IMG.logo, x + 12, by + 20, lw, lw * IMG.logo.height / IMG.logo.width); }
  else if (k === 1) { g.fillStyle = C.cream; g.fillRect(x, by, w, h); txt('FREE', x + 14, by + 54, { font: font(800, 46), color: C.ink }); txt('MINT', x + 14, by + 98, { font: font(800, 46), color: C.tealD }); txt('1,999', x + w - 12, by + 112, { font: font(800, 17), color: C.pink, align: 'right' }); }
  else if (k === 2) cover(IMG['postmark-wolf']);
  else if (k === 3) { g.fillStyle = C.pink; g.fillRect(x, by, w, h); txt('COLLECT', x + w / 2, by + 52, { font: font(800, 34), color: '#fff', align: 'center', stroke: C.ink, sw: 6 }); txt('THE ODD', x + w / 2, by + 96, { font: font(800, 34), color: '#fff', align: 'center', stroke: C.ink, sw: 6 }); }
  else if (k === 4) cover(IMG['postmark-frog']); else cover(IMG['postmark-axolotl']);
  const gr = g.createLinearGradient(0, by, 0, by + h); gr.addColorStop(0, 'rgba(255,255,255,.22)'); gr.addColorStop(.5, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(0,10,30,.38)'); g.fillStyle = gr; g.fillRect(x, by, w, h); g.restore();
  for (let i = 0; i < 3; i++) { const lx = x + 34 + i * 66; g.fillStyle = '#081119'; g.fillRect(lx - 2, by - 20, 4, 16); g.save(); g.fillStyle = '#fff5cf'; g.shadowColor = '#ffe9a8'; g.shadowBlur = 16; g.beginPath(); g.arc(lx, by - 8, 4, 0, 7); g.fill(); g.restore(); }
}
function neonV(x, y, word, col) {
  const h = word.length * 30 + 22; g.fillStyle = '#060d14'; g.fillRect(x - 4, y - 4, 44, h + 8);
  g.save(); g.shadowColor = col; g.shadowBlur = 20; g.strokeStyle = col; g.lineWidth = 3; g.beginPath(); g.roundRect(x, y, 36, h, 8); g.stroke(); g.stroke();
  g.font = font(800, 24); g.textAlign = 'center'; g.fillStyle = '#fff'; word.split('').forEach((ch, i) => g.fillText(ch, x + 18, y + 36 + i * 30)); g.restore();
}
function building(x, top, bw, bh, r, o) {
  const gr = g.createLinearGradient(0, top, 0, top + 900); gr.addColorStop(0, o.c0); gr.addColorStop(1, o.c1); g.fillStyle = gr; g.fillRect(x, top, bw, bh);
  const s = o.s, side = Math.min(28 * s, bw * .13); g.fillStyle = 'rgba(0,0,0,.26)'; g.fillRect(x + bw - side, top, side, bh);
  g.fillStyle = o.rim; g.fillRect(x, top, 2.5, bh);
  g.fillStyle = o.c0; g.fillRect(x - 3, top - 7 * s, bw + 6, 9 * s); g.fillStyle = o.rim; g.fillRect(x - 3, top - 7 * s, bw + 6, 2);
  const gx = 30 * s, gy = 38 * s, ww = 15 * s, wh = 21 * s, ribbon = r() > .76;
  const cols = Math.floor((bw - side - 12 * s) / gx), rows = Math.min(44, Math.floor((o.base + 300 - top) / gy)); const x0 = x + (bw - side - cols * gx) / 2 + (gx - ww) / 2; const lit = [];
  for (let cy = 0; cy < rows; cy++) { const wy = top + 16 * s + cy * gy;
    if (ribbon) { g.fillStyle = 'rgba(140,195,215,.085)'; g.fillRect(x0, wy, cols * gx - (gx - ww), wh * .78); }
    for (let cx = 0; cx < cols; cx++) { if (!ribbon) { g.fillStyle = 'rgba(140,195,215,.095)'; g.fillRect(x0 + cx * gx, wy, ww, wh); } if (r() < o.lit) lit.push([x0 + cx * gx, wy, Math.floor(r() * LIT.length), r()]); } }
  g.save(); g.shadowBlur = o.glow;
  for (const [lx, ly, ci, v] of lit) { g.shadowColor = LIT[ci]; g.fillStyle = LIT[ci]; g.globalAlpha = .5 + v * .5; g.fillRect(lx, ly, ww, ribbon ? wh * .78 : wh); if (s > .8 && v < .45) { g.shadowColor = 'transparent'; g.globalAlpha = .4; g.fillStyle = '#081420'; g.fillRect(lx, ly + wh * (.35 + v), ww, wh * (.65 - v)); } }
  g.restore();
  if (o.detail) { g.fillStyle = 'rgba(0,0,0,.2)'; for (let cy = 4; cy < rows; cy += 5) g.fillRect(x, top + 9 * s + cy * gy, bw, 3); g.fillStyle = 'rgba(255,255,255,.035)'; for (let cy = 4; cy < rows; cy += 5) g.fillRect(x, top + 12 * s + cy * gy, bw, 1.5); }
  const p = r();
  if (p < .3) tank(x + bw * (.3 + r() * .4), top - 7 * s, s, o); else if (p < .55) antenna(x + bw * (.2 + r() * .6), top - 7 * s, s, o, r);
  else if (p < .8 && o.detail && bw > 215) billboard(x + (bw - 200) / 2, top - 7, r);
  if (o.detail && bw > 150 && r() < .42) neonV(x + 10 + r() * 12, top + 60 + r() * 80, ['HONEY', 'ARCADE', 'PETS', 'ODD', '24H', 'Y2K', 'TRIPPI'][Math.floor(r() * 7)], [C.pink, C.tealL, C.honey][Math.floor(r() * 3)]);
  if (o.detail && bw > 230 && r() < .5) { g.save(); g.globalAlpha = .7; const mw = Math.min(bw - 60, 300); g.drawImage(GRAFFP, 0, 0, 1000, 400, x + 30, o.base - 190, mw, mw * .4); g.restore(); }
}
function bakeCity(o) {
  let c = bakeStrip(o.w, o.h, () => {
    const r = mulberry(o.seed); let px = 0;
    while (o.w - px > 50) { let bw = o.bw[0] + r() * (o.bw[1] - o.bw[0]); if (px + bw > o.w - o.bw[0] * .8) bw = o.w - px; const bh = o.hh[0] + r() * (o.hh[1] - o.hh[0]); building(px, o.base - bh, bw, o.h - (o.base - bh), r, o); px += bw + (px + bw < o.w - 260 ? r() * o.gap : 0); }
  });
  if (o.blur) c = blurred(c, o.blur); return c;
}
function deckBake(w, Y) {
  let gr = g.createLinearGradient(0, Y(64), 0, Y(122)); gr.addColorStop(0, '#2b3f47'); gr.addColorStop(.5, '#182730'); gr.addColorStop(1, '#0c151a'); g.fillStyle = gr; g.fillRect(0, Y(64), w, 58);
  g.fillStyle = 'rgba(107,230,198,.55)'; g.fillRect(0, Y(67), w, 3); g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(0, Y(64), w, 1.5);
  for (let x = 0; x < w; x += 130) { g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x, Y(72), 6, 48); g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(x + 6, Y(72), 2, 48); }
  g.fillStyle = 'rgba(190,220,220,.35)'; for (let x = 10; x < w; x += 20) { g.beginPath(); g.arc(x, Y(77), 1.8, 0, 7); g.arc(x, Y(116), 1.8, 0, 7); g.fill(); }
  g.fillStyle = '#0a1114'; for (let x = 0; x < w; x += 26) g.fillRect(x, Y(60), 14, 6);
  gr = g.createLinearGradient(0, Y(55), 0, Y(61)); gr.addColorStop(0, '#b9cccf'); gr.addColorStop(1, '#3d4d52'); g.fillStyle = gr; g.fillRect(0, Y(55), w, 6);
}
function bakeViaduct() {
  const w = 2080, h = 1000, Y = y => y - 40;
  return bakeStrip(w, h, () => {
    let gr = g.createLinearGradient(0, Y(118), 0, h); gr.addColorStop(0, '#263843'); gr.addColorStop(1, '#0a1318'); g.fillStyle = gr; g.fillRect(0, Y(118), w, h);
    const r = mulberry(91);
    for (let row = 0, y = Y(120); y < h; y += 17, row++) for (let x = (row % 2) * -24; x < w; x += 48) { const v = r(); g.fillStyle = v < .5 ? `rgba(255,255,255,${v * .06})` : `rgba(0,0,0,${(v - .5) * .26})`; g.fillRect(x + 1, y + 1, 46, 15); }
    const R = 212, sy = Y(385), opening = (cx, rr) => { g.beginPath(); g.moveTo(cx - rr, h); g.lineTo(cx - rr, sy); g.arc(cx, sy, rr, Math.PI, 0); g.lineTo(cx + rr, h); g.closePath(); };
    for (let k = 0; k < 4; k++) {
      const cx = k * 520 + 260;
      g.save(); g.globalCompositeOperation = 'destination-out'; opening(cx, R); g.fill(); g.restore();
      if (k === 1 || k === 3) { opening(cx, R); g.fillStyle = '#10181d'; g.fill(); }
      g.save(); opening(cx, R); g.clip();
      if (k === 1) { // honey shop
        g.save(); g.shadowColor = C.honey; g.shadowBlur = 26; g.strokeStyle = '#ffd766'; g.lineWidth = 4; g.beginPath(); g.roundRect(cx - 120, Y(430), 240, 66, 14); g.stroke(); txt('HONEY 24H', cx, Y(477), { font: font(800, 36), color: '#fff3c4', align: 'center' }); g.restore();
        for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? C.cream : C.pink; g.beginPath(); g.moveTo(cx - 180 + i * 45, Y(520)); g.lineTo(cx - 135 + i * 45, Y(520)); g.lineTo(cx - 128 + i * 47 - 8, Y(566)); g.lineTo(cx - 190 + i * 47.5, Y(566)); g.fill(); }
        gr = g.createLinearGradient(0, Y(566), 0, Y(900)); gr.addColorStop(0, '#ffd27a'); gr.addColorStop(1, '#c2742a'); g.fillStyle = gr; g.fillRect(cx - 170, Y(576), 340, 400);
        g.fillStyle = '#3a2412'; g.fillRect(cx - 4, Y(576), 8, 400); g.fillRect(cx - 170, Y(690), 340, 7);
        for (let i = 0; i < 5; i++) { g.fillStyle = C.honey; g.strokeStyle = '#3a2412'; g.lineWidth = 3; g.beginPath(); g.roundRect(cx - 150 + i * 62, Y(640), 40, 48, 8); g.fill(); g.stroke(); }
        g.save(); g.globalCompositeOperation = 'lighter'; gr = g.createRadialGradient(cx, Y(640), 20, cx, Y(640), 330); gr.addColorStop(0, 'rgba(255,190,90,.4)'); gr.addColorStop(1, 'rgba(255,190,90,0)'); g.fillStyle = gr; g.fillRect(cx - 330, Y(300), 660, 700); g.restore();
      } else if (k === 3) { // shutter with graffiti
        g.fillStyle = '#26343c'; g.fillRect(cx - R, Y(430), R * 2, 600); for (let y = Y(432); y < h; y += 12) { g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(cx - R, y, R * 2, 3); g.fillStyle = 'rgba(255,255,255,.05)'; g.fillRect(cx - R, y + 3, R * 2, 2); }
        const lw = 330; g.save(); g.globalAlpha = .95; g.translate(cx, Y(560)); g.rotate(-.05); g.drawImage(IMG.logo, -lw / 2, -lw * IMG.logo.height / IMG.logo.width / 2, lw, lw * IMG.logo.height / IMG.logo.width); g.restore();
        g.save(); g.globalAlpha = .55; g.drawImage(GRAFFP, 0, 60, 1000, 300, cx - 190, Y(690), 380, 114); g.restore();
      } else { // open arch with hanging lamp
        g.strokeStyle = '#0a1114'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx, sy - R); g.lineTo(cx, sy - R + 70); g.stroke(); g.fillStyle = '#0f8f74'; g.beginPath(); g.moveTo(cx - 30, sy - R + 92); g.lineTo(cx - 12, sy - R + 68); g.lineTo(cx + 12, sy - R + 68); g.lineTo(cx + 30, sy - R + 92); g.fill();
        g.save(); g.fillStyle = '#fff3c9'; g.shadowColor = '#ffd98a'; g.shadowBlur = 30; g.beginPath(); g.arc(cx, sy - R + 96, 9, 0, 7); g.fill(); g.restore();
        g.save(); g.globalCompositeOperation = 'lighter'; gr = g.createRadialGradient(cx, sy - R + 96, 6, cx, sy - R + 170, 240); gr.addColorStop(0, 'rgba(255,210,140,.3)'); gr.addColorStop(1, 'rgba(255,210,140,0)'); g.fillStyle = gr; g.fillRect(cx - R, sy - R, R * 2, 700); g.restore();
      }
      g.restore();
      g.strokeStyle = '#0b1419'; g.lineWidth = 18; opening(cx + 5, R - 9); g.stroke();                       // soffit depth
      g.strokeStyle = '#3a505b'; g.lineWidth = 18; opening(cx, R + 9); g.stroke();                              // ring
      g.strokeStyle = 'rgba(0,0,0,.4)'; g.lineWidth = 2; for (let a = Math.PI; a <= Math.PI * 2 + .01; a += Math.PI / 14) { g.beginPath(); g.moveTo(cx + Math.cos(a) * R, sy + Math.sin(a) * R); g.lineTo(cx + Math.cos(a) * (R + 18), sy + Math.sin(a) * (R + 18)); g.stroke(); }
      g.strokeStyle = 'rgba(190,235,235,.16)'; g.lineWidth = 2; g.beginPath(); g.arc(cx, sy, R + 18, Math.PI, 0); g.stroke();
      // pier dressing (pier centred on k*520)
      const px = k * 520; const st = ['postmark-wolf', 'postmark-frog', 'postmark-axolotl', 'postmark-traffic'][k]; const im = IMG[st];
      for (const ox of (k === 0 ? [0, w] : [px])) { g.save(); g.translate(ox, Y(600)); g.rotate(k % 2 ? .05 : -.04); g.fillStyle = 'rgba(0,0,0,.4)'; g.fillRect(-30, -34, 66, 76); g.drawImage(im, -33, -38, 66, 66 * im.height / im.width); g.restore();
        g.fillStyle = '#0a1216'; g.fillRect(ox + 30, Y(122), 7, 900); g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(ox + 30, Y(122), 2, 900); }
    }
    gr = g.createLinearGradient(0, Y(120), 0, Y(190)); gr.addColorStop(0, 'rgba(0,0,0,.6)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.globalCompositeOperation = 'source-atop'; g.fillRect(0, Y(120), w, 70); g.globalCompositeOperation = 'source-over';
    // street level
    gr = g.createLinearGradient(0, Y(880), 0, h); gr.addColorStop(0, '#2a3a43'); gr.addColorStop(.18, '#1a262d'); gr.addColorStop(.2, '#0d1519'); gr.addColorStop(1, '#070c10'); g.fillStyle = gr; g.fillRect(0, Y(880), w, h - Y(880)); g.fillStyle = 'rgba(190,235,235,.22)'; g.fillRect(0, Y(880), w, 2.5);
    g.save(); g.globalCompositeOperation = 'lighter'; for (let k = 0; k < 4; k++) { const cx = k * 520 + 260, col = k === 1 ? '255,190,90' : k === 3 ? '90,230,200' : '255,214,150'; const rg = g.createRadialGradient(cx, Y(960), 10, cx, Y(960), 230); rg.addColorStop(0, `rgba(${col},.32)`); rg.addColorStop(1, `rgba(${col},0)`); g.fillStyle = rg; g.save(); g.translate(0, Y(960)); g.scale(1, .28); g.translate(0, -Y(960)); g.fillRect(cx - 230, Y(960) - 230, 460, 460); g.restore(); } g.restore();
    deckBake(w, Y);
  });
}
function bakeBridgeBack() {
  const w = 900, h = 760, Y = y => y + 680;
  return bakeStrip(w, h, () => {
    const steel = '#1d343d', bar = (x0, y0, x1, y1, lw) => { g.strokeStyle = steel; g.lineWidth = lw; g.beginPath(); g.moveTo(x0, Y(y0)); g.lineTo(x1, Y(y1)); g.stroke(); g.strokeStyle = 'rgba(150,230,230,.16)'; g.lineWidth = 2; g.beginPath(); g.moveTo(x0 - lw * .35, Y(y0)); g.lineTo(x1 - lw * .35, Y(y1)); g.stroke(); };
    for (let k = 0; k < 3; k++) { const x = k * 300; bar(x, -620, x + 300, 64, 11); bar(x + 300, -620, x, 64, 11); }
    for (let k = 0; k <= 3; k++) bar(k * 300, -640, k * 300, 70, 24);
    let gr = g.createLinearGradient(0, Y(-650), 0, Y(-618)); gr.addColorStop(0, '#34525c'); gr.addColorStop(1, '#122229'); g.fillStyle = gr; g.fillRect(0, Y(-650), w, 32);
    g.fillStyle = 'rgba(190,225,225,.4)'; for (let x = 8; x < w; x += 18) { g.beginPath(); g.arc(x, Y(-634), 1.8, 0, 7); g.fill(); }
    for (let k = 0; k <= 3; k++) { g.fillStyle = '#2a444e'; g.beginPath(); g.arc(k * 300, Y(-622), 30, 0, Math.PI); g.fill(); }
    const cols = ['#ffe2a0', '#ff9cc4', '#8ff0d8'];
    for (let k = 0; k < 3; k++) { g.strokeStyle = 'rgba(10,18,22,.9)'; g.lineWidth = 2; g.beginPath(); for (let i = 0; i <= 30; i++) { const u = i / 30, x = k * 300 + u * 300, y = Y(-606 + Math.sin(u * Math.PI) * 54); i ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke();
      for (let i = 1; i < 12; i++) { const u = i / 12, x = k * 300 + u * 300, y = Y(-606 + Math.sin(u * Math.PI) * 54) + 6; const c = cols[(i + k) % 3]; g.save(); g.fillStyle = c; g.shadowColor = c; g.shadowBlur = 16; g.beginPath(); g.arc(x, y, 5, 0, 7); g.fill(); g.restore(); } }
  });
}
function bakeBridgeFront() {
  const w = 900, h = 900, Y = y => y - 40;
  return bakeStrip(w, h, () => {
    let gr = g.createLinearGradient(380, 0, 520, 0); gr.addColorStop(0, '#2b3f49'); gr.addColorStop(.4, '#1a2a33'); gr.addColorStop(1, '#0b1318'); g.fillStyle = gr; g.fillRect(392, Y(118), 116, h);
    g.beginPath(); g.moveTo(376, Y(206)); g.lineTo(524, Y(206)); g.lineTo(540, h); g.lineTo(360, h); g.fill();
    g.fillStyle = 'rgba(0,0,0,.25)'; for (let y = Y(134); y < h; y += 22) g.fillRect(392, y, 116, 2);
    g.save(); g.fillStyle = '#fff0c0'; g.shadowColor = '#ffd98a'; g.shadowBlur = 26; g.beginPath(); g.arc(450, Y(150), 7, 0, 7); g.fill(); g.restore();
    gr = g.createLinearGradient(0, Y(120), 0, Y(170)); gr.addColorStop(0, 'rgba(0,0,0,.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(392, Y(120), 116, 50);
    deckBake(w, Y);
  });
}
function prebuildArt() {
  GRAFFP = mk(1000, 400); GRAFFP.getContext('2d').drawImage(IMG['trippi-profile'], 0, 600, 1000, 400, 0, 0, 1000, 400);
  SKYC = bakeSky();
  L_CLOUD = { f: .05, w: 2400, top: -820, c: bakeClouds() };
  L_FAR = { f: .07, w: 3000, top: -900, c: bakeCity({ w: 3000, h: 1700, seed: 11, base: 1150, bw: [70, 170], hh: [170, 600], gap: 24, c0: '#234a6b', c1: '#1a3856', hi: '#31628a', rim: 'rgba(170,225,255,.10)', lit: .2, s: .5, glow: 5, blur: 1.5 }) };
  L_MID2 = { f: .17, w: 3600, top: -900, c: bakeCity({ w: 3600, h: 1700, seed: 23, base: 1210, bw: [120, 270], hh: [260, 700], gap: 60, c0: '#19395a', c1: '#0e233a', hi: '#27527a', rim: 'rgba(160,225,255,.13)', lit: .27, s: .72, glow: 8, blur: .7 }) };
  L_MID = { f: .36, w: 4096, top: -900, c: bakeCity({ w: 4096, h: 1700, seed: 41, base: 1260, bw: [180, 380], hh: [250, 640], gap: 110, c0: '#11304a', c1: '#061320', hi: '#1f4666', rim: 'rgba(140,235,225,.18)', lit: .32, s: 1, glow: 13, detail: 1 }) };
  L_VIA = { f: 1, w: 2080, top: 40, c: bakeViaduct() };
  L_BRB = { f: 1, w: 900, top: -680, c: bakeBridgeBack() };
  L_BRF = { f: 1, w: 900, top: 40, c: bakeBridgeFront() };
}
function drawStrip(L, t, extra = 0) {
  const zl = 1 + (CAM.z - 1) * L.f, off = Dist(t) * L.f + CAM.x * L.f + extra, y = (L.top - CAM.y * L.f) * zl + 560, w = L.w * zl, h = L.c.height * zl;
  for (let k = Math.floor((off - 540 / zl) / L.w); k <= Math.floor((off + 540 / zl) / L.w); k++) g.drawImage(L.c, (k * L.w - off) * zl + 540, y, w + 1, h);
}
function smear(fn, shift) {
  const n = Math.min(8, Math.round(Math.abs(shift) / 1.4)); if (n <= 1) { fn(); return; }
  lcx.setTransform(1, 0, 0, 1, 0, 0); lcx.globalAlpha = 1; lcx.globalCompositeOperation = 'source-over'; lcx.clearRect(0, 0, W, H); withCtx(lcx, fn);
  acx.globalCompositeOperation = 'source-over'; acx.globalAlpha = 1; acx.clearRect(0, 0, W, H); acx.globalCompositeOperation = 'lighter'; acx.globalAlpha = 1 / n;
  for (let i = 0; i < n; i++) acx.drawImage(LC, (i / (n - 1) - .5) * shift, 0);
  g.drawImage(AC, 0, 0);
}
function haze(a, col = '70,130,150') { const hy = ws(0, 70).y; const gr = g.createLinearGradient(0, hy - 760 * CAM.z, 0, hy + 300 * CAM.z); gr.addColorStop(0, `rgba(${col},0)`); gr.addColorStop(.72, `rgba(${col},${a})`); gr.addColorStop(1, `rgba(${col},${a * .2})`); g.fillStyle = gr; g.fillRect(0, 0, W, H); }

/* ------------------------------------------------------------------ sky */
function skyArt(t) {
  g.drawImage(SKYC, 0, 0);
  for (let i = 0; i < 34; i++) { const x = hash(i * 1.3) * W, y = hash(i * 2.7) * 520; g.globalAlpha = .15 + .75 * Math.abs(Math.sin(t * (.6 + hash(i * 5) * 1.6) + i)); g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, 1.5, 0, 7); g.fill(); } g.globalAlpha = 1;
  const mx = 915 - Dist(t) * .006 - CAM.x * .02, my = 262 - (CAM.y + 200) * .05, R = 76;
  let gr = g.createRadialGradient(mx, my, R * .8, mx, my, 360); gr.addColorStop(0, 'rgba(255,240,200,.34)'); gr.addColorStop(.3, 'rgba(255,225,190,.12)'); gr.addColorStop(1, 'rgba(255,225,190,0)'); g.fillStyle = gr; g.fillRect(mx - 360, my - 360, 720, 720);
  gr = g.createRadialGradient(mx - 22, my - 24, 8, mx, my, R); gr.addColorStop(0, '#fffef4'); gr.addColorStop(.7, '#ffefc4'); gr.addColorStop(1, '#f1d79c'); g.fillStyle = gr; g.beginPath(); g.arc(mx, my, R, 0, 7); g.fill();
  g.fillStyle = 'rgba(205,170,110,.32)'; [[-26, -14, 17], [24, 20, 12], [-6, 34, 8], [30, -30, 7], [-40, 26, 6]].forEach(([dx, dy, r]) => { g.beginPath(); g.arc(mx + dx, my + dy, r, 0, 7); g.fill(); });
  drawStrip(L_CLOUD, t, t * 7);
}

/* ------------------------------------------------------------------ near layers */
function catenary(t) {
  camOn(); const per = 700, off = Dist(t), v0 = CAM.x - 540 / CAM.z - 800, v1 = CAM.x + 540 / CAM.z + 800;
  for (let k = Math.floor((off + v0) / per); k <= Math.floor((off + v1) / per); k++) {
    const x = k * per - off + 200;
    g.strokeStyle = 'rgba(150,185,190,.75)'; g.lineWidth = 2.2; g.beginPath(); for (let i = 0; i <= 14; i++) { const u = i / 14; const px = x + u * per, py = -506 + Math.sin(u * Math.PI) * 38; i ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke();
    g.lineWidth = 1.4; g.beginPath(); for (let i = 1; i < 7; i++) { const u = i / 7; g.moveTo(x + u * per, -506 + Math.sin(u * Math.PI) * 38); g.lineTo(x + u * per, -452); } g.stroke();
    g.lineWidth = 2.6; g.beginPath(); g.moveTo(x, -452); g.lineTo(x + per, -452); g.stroke();
    let gr = g.createLinearGradient(x - 9, 0, x + 9, 0); gr.addColorStop(0, '#3a5058'); gr.addColorStop(.5, '#1b2a30'); gr.addColorStop(1, '#0c1418'); g.fillStyle = gr; g.fillRect(x - 9, -560, 18, 624);
    g.fillStyle = '#1b2a30'; g.fillRect(x - 9, -516, 96, 9); g.strokeStyle = '#1b2a30'; g.lineWidth = 4; g.beginPath(); g.moveTo(x, -470); g.lineTo(x + 70, -512); g.stroke();
    g.fillStyle = '#d7e4e4'; g.fillRect(x + 2, -500, 8, 14); g.fillRect(x + 62, -506, 6, 54);
    g.fillStyle = '#12201f'; g.beginPath(); g.moveTo(x - 62, -548); g.lineTo(x - 9, -556); g.lineTo(x - 9, -546); g.lineTo(x - 58, -538); g.fill();
    g.save(); g.fillStyle = '#fff1c4'; g.shadowColor = '#ffd98a'; g.shadowBlur = 26; g.beginPath(); g.ellipse(x - 50, -536, 12, 5, 0, 0, 7); g.fill(); g.restore();
    g.save(); g.globalCompositeOperation = 'lighter'; gr = g.createLinearGradient(0, -536, 0, -130); gr.addColorStop(0, 'rgba(255,214,140,.30)'); gr.addColorStop(1, 'rgba(255,214,140,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(x - 62, -536); g.lineTo(x - 38, -536); g.lineTo(x + 90, -130); g.lineTo(x - 190, -130); g.fill(); g.restore();
    if (k % 2 === 0) { const on = Math.sin(t * 4 + k) > 0; g.save(); g.fillStyle = on ? '#ff5a5a' : '#5a1c1c'; if (on) { g.shadowColor = '#ff3030'; g.shadowBlur = 20; } g.beginPath(); g.arc(x, -572, 7, 0, 7); g.fill(); g.restore(); }
  }
  g.restore();
}
function platformBG(t) {
  const x0 = D_STOP - Dist(t) - 2300, x1 = x0 + 4600, v0 = CAM.x - 540 / CAM.z - 150, v1 = CAM.x + 540 / CAM.z + 150; if (x1 < v0 || x0 > v1) return;
  camOn(); const a = Math.max(x0, v0), b = Math.min(x1, v1);
  g.fillStyle = '#0a1316'; g.fillRect(a, -730, b - a, 96); g.fillStyle = '#22343a'; g.fillRect(a, -640, b - a, 10); g.fillStyle = 'rgba(107,230,198,.5)'; g.fillRect(a, -732, b - a, 4);
  let gr = g.createLinearGradient(0, -630, 0, -150); gr.addColorStop(0, '#41575a'); gr.addColorStop(1, '#24322f'); g.fillStyle = gr; g.fillRect(a, -630, b - a, 480);
  for (let x = Math.floor((a - x0) / 46) * 46 + x0; x < b; x += 46) for (let y = -624; y < -160; y += 30) { g.fillStyle = `rgba(225,248,238,${.05 + hash(x * .37 + y) * .08})`; g.fillRect(x + 2, y + 2, 42, 26); }
  g.fillStyle = C.teal; g.fillRect(a, -332, b - a, 30); g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(a, -332, b - a, 3);
  for (let k = Math.floor((a - x0) / 500); k <= Math.floor((b - x0) / 500); k++) {
    const x = x0 + k * 500; g.fillStyle = '#17262b'; g.fillRect(x - 17, -640, 34, 490); g.fillStyle = 'rgba(255,255,255,.1)'; g.fillRect(x - 17, -640, 4, 490);
    g.save(); g.fillStyle = '#f4fffa'; g.shadowColor = '#c8ffe8'; g.shadowBlur = 34; g.beginPath(); g.roundRect(x + 130, -628, 240, 10, 5); g.fill(); g.restore();
    g.save(); g.globalCompositeOperation = 'lighter'; gr = g.createLinearGradient(0, -620, 0, -200); gr.addColorStop(0, 'rgba(200,255,235,.22)'); gr.addColorStop(1, 'rgba(200,255,235,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(x + 130, -618); g.lineTo(x + 370, -618); g.lineTo(x + 480, -200); g.lineTo(x + 20, -200); g.fill(); g.restore();
    if ((k % 3 + 3) % 3 === 1) { g.fillStyle = '#082e25'; g.strokeStyle = '#eafff7'; g.lineWidth = 5; g.beginPath(); g.roundRect(x + 70, -584, 360, 92, 14); g.fill(); g.stroke(); g.fillStyle = C.teal; g.beginPath(); g.arc(x + 118, -538, 28, 0, 7); g.fill(); g.stroke(); txt('09', x + 118, -527, { font: font(800, 28), color: '#fff', align: 'center' }); txt('RUSH HOUR', x + 162, -520, { font: font(800, 46), color: '#fff' }); }
    else { const im = IMG[['postmark-wolf', 'postmark-frog', 'postmark-axolotl', 'postmark-traffic'][((k % 4) + 4) % 4]]; g.fillStyle = '#0d1a1d'; g.fillRect(x + 172, -592, 156, 170); g.drawImage(im, x + 180, -584, 140, 140 * im.height / im.width); g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(x + 172, -592, 156, 40); }
  }
  g.fillStyle = '#617072'; g.fillRect(a, -150, b - a, 40); g.fillStyle = '#e8b62a'; g.fillRect(a, -150, b - a, 7);
  for (let i = 0; i < 46; i++) { const gone = inv(19.1 + i * .05, 19.35 + i * .05, t); if (gone >= 1) continue; const px = x0 + 300 + i * 88 + hash(i) * 30; if (px < v0 || px > v1) continue; g.save(); g.globalAlpha = 1 - gone; oddball(px, -150 - gone * 30, .95, CROWD[i], t + i, 0, i % 2 ? 1 : -1, .2); g.restore(); }
  g.restore();
}

/* ------------------------------------------------------------------ train exterior */
function wheelSet(x, t) {
  const sp = speedAt(t), ang = Dist(t) / 24, blur = clamp(sp / 500);
  g.save(); g.translate(x, 34);
  let gr = g.createLinearGradient(0, -18, 0, 8); gr.addColorStop(0, '#34444a'); gr.addColorStop(1, '#10181b'); g.fillStyle = gr; g.beginPath(); g.roundRect(-78, -18, 156, 24, 9); g.fill(); g.strokeStyle = '#070b0d'; g.lineWidth = 3; g.stroke();
  g.fillStyle = '#0b1113'; g.fillRect(-10, -14, 20, 16); g.strokeStyle = 'rgba(190,215,215,.5)'; g.lineWidth = 2; for (let k = -1; k <= 1; k++) { g.beginPath(); g.moveTo(k * 5 - 3, -12); g.lineTo(k * 5 + 3, 0); g.stroke(); }
  for (const dx of [-44, 44]) {
    g.save(); g.translate(dx, 6);
    g.fillStyle = '#12191c'; g.beginPath(); g.arc(0, 0, 24, 0, 7); g.fill();
    gr = g.createRadialGradient(-6, -6, 2, 0, 0, 22); gr.addColorStop(0, '#6d8085'); gr.addColorStop(1, '#2a363a'); g.fillStyle = gr; g.beginPath(); g.arc(0, 0, 20, 0, 7); g.fill();
    g.strokeStyle = '#a9bcbc'; g.lineWidth = 2.5; g.beginPath(); g.arc(0, 0, 21.5, 0, 7); g.stroke();
    g.save(); g.rotate(ang); g.globalAlpha = 1 - blur * .8; g.strokeStyle = '#15191b'; g.lineWidth = 4; g.beginPath(); for (let k = 0; k < 3; k++) { g.moveTo(Math.cos(k * 2.09) * 17, Math.sin(k * 2.09) * 17); g.lineTo(-Math.cos(k * 2.09) * 17, -Math.sin(k * 2.09) * 17); } g.stroke(); g.restore();
    if (blur > .2) { g.globalAlpha = blur * .5; g.strokeStyle = '#1a2023'; g.lineWidth = 8; g.beginPath(); g.arc(0, 0, 11, 0, 7); g.stroke(); g.globalAlpha = 1; }
    g.fillStyle = '#d5e2e2'; g.beginPath(); g.arc(0, 0, 4.5, 0, 7); g.fill();
    g.restore();
  }
  g.restore();
}
function acUnit(x, w, t) {
  g.save(); g.translate(x, -362);
  let gr = g.createLinearGradient(0, -28, 0, 0); gr.addColorStop(0, '#5b6f73'); gr.addColorStop(1, '#2c3a3e'); g.fillStyle = gr; g.beginPath(); g.roundRect(0, -28, w, 30, [7, 7, 0, 0]); g.fill(); g.strokeStyle = '#0f1719'; g.lineWidth = 3; g.stroke();
  g.fillStyle = 'rgba(255,255,255,.25)'; g.fillRect(6, -26, w - 12, 2);
  g.fillStyle = 'rgba(0,0,0,.4)'; for (let k = 0; k < 5; k++) g.fillRect(10, -20 + k * 4, w * .42, 2);
  const fx = w * .74; g.fillStyle = '#0f1719'; g.beginPath(); g.ellipse(fx, -13, 17, 9, 0, 0, 7); g.fill(); g.save(); g.translate(fx, -13); g.scale(1, .5); g.rotate(t * 14); g.fillStyle = 'rgba(190,215,215,.55)'; for (let k = 0; k < 3; k++) { g.rotate(2.094); g.beginPath(); g.ellipse(8, 0, 8, 3, 0, 0, 7); g.fill(); } g.restore();
  g.restore();
}
function pantograph(x, t, sp, seed) {
  const steel = (a, b, c, d, lw) => { g.strokeStyle = '#0d1416'; g.lineWidth = lw + 3; g.beginPath(); g.moveTo(a, b); g.lineTo(c, d); g.stroke(); g.strokeStyle = '#a7babb'; g.lineWidth = lw; g.beginPath(); g.moveTo(a, b); g.lineTo(c, d); g.stroke(); };
  g.fillStyle = '#d7e4e4'; g.fillRect(x - 34, -374, 8, 12); g.fillRect(x + 22, -374, 8, 12); g.fillStyle = '#243236'; g.fillRect(x - 40, -378, 76, 6);
  steel(x - 28, -378, x + 26, -416, 4); steel(x + 26, -416, x - 6, -449, 4); steel(x + 24, -378, x + 26, -416, 2.5);
  g.fillStyle = '#0d1416'; g.beginPath(); g.roundRect(x - 44, -454, 76, 7, 3); g.fill(); g.fillStyle = '#c9d6d6'; g.fillRect(x - 40, -453, 68, 2.5);
  const h = hash(Math.floor(t * 9) + seed * 13);
  if (sp > 60 && h > .72) { const sx = x - 6 + (h - .72) * 120 - 16; g.save(); g.globalCompositeOperation = 'lighter'; const gr = g.createRadialGradient(sx, -452, 1, sx, -452, 70); gr.addColorStop(0, 'rgba(210,240,255,.95)'); gr.addColorStop(.25, 'rgba(120,200,255,.45)'); gr.addColorStop(1, 'rgba(120,200,255,0)'); g.fillStyle = gr; g.fillRect(sx - 70, -522, 140, 140);
    g.strokeStyle = '#fff'; g.lineWidth = 2; for (let k = 0; k < 6; k++) { const a = hash(k + Math.floor(t * 30)) * 7, l = 10 + hash(k * 3 + Math.floor(t * 30)) * 26; g.beginPath(); g.moveTo(sx, -452); g.lineTo(sx + Math.cos(a) * l, -452 + Math.sin(a) * l); g.stroke(); } g.restore(); }
}
function shell(c, t, isEngine) {
  const sp = speedAt(t), rw = isEngine ? CW - 124 : CW;
  let gr = g.createLinearGradient(0, -364, 0, -328); gr.addColorStop(0, '#5d7276'); gr.addColorStop(.3, '#3a4b50'); gr.addColorStop(1, '#1a2529'); g.fillStyle = gr; g.beginPath();
  if (isEngine) { g.moveTo(0, -330); g.lineTo(0, -352); g.quadraticCurveTo(0, -362, 14, -362); g.lineTo(CW - 120, -362); g.quadraticCurveTo(CW - 30, -360, CW, -240); g.lineTo(CW, -330); g.closePath(); } else g.roundRect(-4, -362, CW + 8, 34, [16, 16, 0, 0]);
  g.fill(); g.strokeStyle = '#0c1315'; g.lineWidth = 3; g.stroke();
  g.fillStyle = 'rgba(255,255,255,.3)'; g.fillRect(12, -360, rw - 24, 2); g.fillStyle = 'rgba(0,0,0,.28)'; for (let x = 30; x < rw - 12; x += 44) g.fillRect(x, -356, 2, 22);
  g.save(); g.shadowColor = C.tealL; g.shadowBlur = 10; g.fillStyle = C.teal; g.fillRect(0, -335, isEngine ? CW - 62 : CW, 7); g.restore(); g.fillStyle = 'rgba(255,255,255,.4)'; g.fillRect(0, -335, isEngine ? CW - 62 : CW, 1.5);
  if (!isEngine) { acUnit(CW * .16, 132, t); acUnit(CW * .58, 104, t + 1); g.fillStyle = '#2c3a3e'; g.strokeStyle = '#0f1719'; g.lineWidth = 3; g.beginPath(); g.roundRect(CW * .43, -372, 44, 12, 4); g.fill(); g.stroke(); }
  if (c.id === 'arcade') pantograph(CW - 46, t, sp, 1); if (isEngine) pantograph(170, t, sp, 2);
  // floor slab + chassis
  g.fillStyle = c.floor; g.fillRect(0, -10, CW, 12); g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(0, -10, CW, 2); g.fillStyle = 'rgba(0,0,0,.28)'; for (let x = 0; x < CW; x += 46) g.fillRect(x, -8, 2, 10);
  gr = g.createLinearGradient(0, 2, 0, 26); gr.addColorStop(0, '#33434a'); gr.addColorStop(1, '#0d1417'); g.fillStyle = gr; g.fillRect(0, 2, CW, 24);
  g.save(); g.shadowColor = C.tealL; g.shadowBlur = 8; g.fillStyle = C.teal; g.fillRect(0, 7, CW, 4); g.restore();
  g.save(); g.beginPath(); g.rect(8, 14, 56, 10); g.clip(); for (let k = -2; k < 8; k++) { g.fillStyle = k % 2 ? '#141a1c' : C.honey; g.beginPath(); g.moveTo(8 + k * 10, 24); g.lineTo(18 + k * 10, 14); g.lineTo(28 + k * 10, 14); g.lineTo(18 + k * 10, 24); g.fill(); } g.restore();
  txt('TR-0' + (c.i + 1), CW - 14, 23, { font: font(700, 11, 'GeistMono'), color: 'rgba(190,235,225,.8)', align: 'right', ls: 1 });
  g.fillStyle = '#10181b'; g.strokeStyle = '#070b0d'; g.lineWidth = 2.5; g.beginPath(); g.roundRect(214, 26, 152, 24, 5); g.fill(); g.stroke(); g.fillStyle = 'rgba(255,255,255,.1)'; for (let k = 0; k < 9; k++) g.fillRect(224 + k * 15, 31, 2, 14);
  g.fillStyle = Math.sin(t * 5 + c.i) > 0 ? '#7dffb6' : '#1f4a36'; g.beginPath(); g.arc(352, 38, 3, 0, 7); g.fill();
  wheelSet(110, t); wheelSet(CW - 110, t);
  // cutaway section edges
  const edge = x => { const eg = g.createLinearGradient(x, 0, x + 14, 0); eg.addColorStop(0, '#3a4b50'); eg.addColorStop(1, '#141d20'); g.fillStyle = eg; g.fillRect(x, -340, 14, 366); g.save(); g.beginPath(); g.rect(x, -340, 14, 366); g.clip(); g.strokeStyle = 'rgba(107,230,198,.4)'; g.lineWidth = 2; for (let k = -366; k < 400; k += 10) { g.beginPath(); g.moveTo(x + 14, -340 + k); g.lineTo(x, -326 + k); g.stroke(); } g.restore(); g.strokeStyle = C.ink; g.lineWidth = 4; g.strokeRect(x, -340, 14, 366); };
  edge(-8); if (!isEngine) edge(CW - 6);
  // gangway bellows + coupler
  if (c.i < 5) { g.fillStyle = '#0c1214'; g.fillRect(CW + 8, -300, GAP - 16, 300); g.fillStyle = 'rgba(255,255,255,.07)'; for (let y = -296; y < 0; y += 9) g.fillRect(CW + 8, y, GAP - 16, 2); g.fillStyle = '#1b2528'; g.fillRect(CW, 4, GAP, 12); }
  if (isEngine) { g.strokeStyle = '#0c1315'; g.lineWidth = 6; g.beginPath(); g.moveTo(CW - 120, -362); g.quadraticCurveTo(CW - 30, -360, CW, -240); g.lineTo(CW, 24); g.stroke(); g.fillStyle = C.pink; g.fillRect(CW - 12, -150, 12, 60); g.fillStyle = '#1b2528'; g.fillRect(CW, -8, 20, 14); }
}
function trainGlow(t) {
  const cols = { daycare: '255,150,190', lounge: '120,240,200', arcade: '190,140,255', honey: '255,190,90', graffiti: '170,230,255', engine: '120,240,220' };
  g.save(); g.globalCompositeOperation = 'lighter';
  CARS.forEach(c => { if (c.id === 'daycare' && t < 14.6) return; const p = ws(slotX(c.i) + CW / 2, -170), R = 520 * CAM.z; if (p.x < -R || p.x > W + R) return; const gr = g.createRadialGradient(p.x, p.y, 40 * CAM.z, p.x, p.y, R); gr.addColorStop(0, `rgba(${cols[c.id]},.20)`); gr.addColorStop(1, `rgba(${cols[c.id]},0)`); g.fillStyle = gr; g.fillRect(p.x - R, p.y - R, R * 2, R * 2); });
  g.restore();
}
function headlight(t) {
  const p = ws(slotX(5) + CW, -60), z = CAM.z; if (p.x > W + 50) return; g.save(); g.globalCompositeOperation = 'lighter';
  let gr = g.createLinearGradient(p.x, 0, p.x + 1100 * z, 0); gr.addColorStop(0, 'rgba(255,240,190,.5)'); gr.addColorStop(1, 'rgba(255,240,190,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(p.x, p.y - 8 * z); g.lineTo(p.x + 1100 * z, p.y - 240 * z); g.lineTo(p.x + 1100 * z, p.y + 130 * z); g.lineTo(p.x, p.y + 8 * z); g.fill();
  gr = g.createRadialGradient(p.x, p.y, 2, p.x, p.y, 90 * z); gr.addColorStop(0, 'rgba(255,250,225,1)'); gr.addColorStop(.3, 'rgba(255,235,180,.5)'); gr.addColorStop(1, 'rgba(255,235,180,0)'); g.fillStyle = gr; g.fillRect(p.x - 90 * z, p.y - 90 * z, 180 * z, 180 * z);
  g.restore();
}

/* ------------------------------------------------------------------ interiors */
function holesPath(holes) { g.beginPath(); g.rect(0, -330, CW, 330); holes.forEach(h => g.roundRect(h[0], h[1], h[2], h[3], 14)); }
function backWall(c, holes) {
  g.save(); holesPath(holes); g.clip('evenodd'); g.fillStyle = c.wall; g.fillRect(0, -330, CW, 330);
  let gr = g.createLinearGradient(0, -330, 0, 0); gr.addColorStop(0, 'rgba(0,0,0,.34)'); gr.addColorStop(.2, 'rgba(255,255,255,.08)'); gr.addColorStop(.62, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(0,0,0,.2)'); g.fillStyle = gr; g.fillRect(0, -330, CW, 330);
  for (let x = 96; x < CW; x += 96) { g.fillStyle = 'rgba(0,0,0,.18)'; g.fillRect(x, -330, 2, 220); g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(x + 2, -330, 1.5, 220); g.fillStyle = 'rgba(255,255,255,.22)'; g.beginPath(); g.arc(x + 9, -308, 1.6, 0, 7); g.arc(x - 8, -308, 1.6, 0, 7); g.fill(); }
  gr = g.createLinearGradient(0, 0, CW, 0); gr.addColorStop(0, 'rgba(0,0,0,.42)'); gr.addColorStop(.09, 'rgba(0,0,0,0)'); gr.addColorStop(.91, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.42)'); g.fillStyle = gr; g.fillRect(0, -330, CW, 330);
  g.restore();
}
function wainscot(c, holes) {
  g.save(); holesPath(holes); g.clip('evenodd'); g.fillStyle = c.wain; g.fillRect(0, -112, CW, 104);
  let gr = g.createLinearGradient(0, -112, 0, -8); gr.addColorStop(0, 'rgba(255,255,255,.07)'); gr.addColorStop(1, 'rgba(0,0,0,.25)'); g.fillStyle = gr; g.fillRect(0, -112, CW, 104);
  g.fillStyle = 'rgba(0,0,0,.14)'; for (let x = 0; x < CW; x += 24) g.fillRect(x, -106, 1.5, 94);
  g.fillStyle = 'rgba(255,255,255,.24)'; g.fillRect(0, -116, CW, 4); g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(0, -112, CW, 3); g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(0, -20, CW, 12);
  gr = g.createLinearGradient(0, 0, CW, 0); gr.addColorStop(0, 'rgba(0,0,0,.42)'); gr.addColorStop(.09, 'rgba(0,0,0,0)'); gr.addColorStop(.91, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.42)'); g.fillStyle = gr; g.fillRect(0, -116, CW, 110);
  g.restore();
}
function windowFrames(holes) {
  holes.forEach(([x, y, w, hh]) => {
    g.save(); g.beginPath(); g.roundRect(x, y, w, hh, 14); g.clip();
    const gr = g.createLinearGradient(x, y, x + w, y + hh); gr.addColorStop(0, 'rgba(175,235,255,.17)'); gr.addColorStop(.5, 'rgba(175,235,255,.03)'); gr.addColorStop(1, 'rgba(8,18,38,.3)'); g.fillStyle = gr; g.fillRect(x, y, w, hh);
    const sx = ((T_NOW * 70 + x * 1.7) % (w + 150)) - 75; g.fillStyle = 'rgba(255,255,255,.10)'; g.beginPath(); g.moveTo(x + sx, y + hh); g.lineTo(x + sx + 36, y); g.lineTo(x + sx + 60, y); g.lineTo(x + sx + 24, y + hh); g.fill();
    g.fillStyle = 'rgba(215,242,255,.4)'; for (let i = 0; i < 10; i++) { const dx = x + hash(i + x) * w, dy = y + ((hash(i * 3 + x) * hh + T_NOW * (16 + hash(i) * 34)) % hh); g.beginPath(); g.ellipse(dx, dy, 1.6, 3.4, 0, 0, 7); g.fill(); }
    g.restore();
    g.lineWidth = 9; g.strokeStyle = '#0c1416'; g.beginPath(); g.roundRect(x, y, w, hh, 14); g.stroke(); g.lineWidth = 2; g.strokeStyle = 'rgba(255,255,255,.24)'; g.beginPath(); g.roundRect(x + 5.5, y + 5.5, w - 11, hh - 11, 9); g.stroke();
  });
}
function ceilingLights(t, col = 'rgba(255,226,170,') {
  g.fillStyle = 'rgba(0,0,0,.4)'; g.fillRect(0, -330, CW, 13);
  for (const lx of [150, 430]) {
    g.save(); g.globalCompositeOperation = 'lighter'; let gr = g.createRadialGradient(lx, -316, 6, lx, -150, 320); gr.addColorStop(0, col + '.26)'); gr.addColorStop(.5, col + '.08)'); gr.addColorStop(1, col + '0)'); g.fillStyle = gr;
    g.beginPath(); g.moveTo(lx - 46, -317); g.lineTo(lx + 46, -317); g.lineTo(lx + 260, 0); g.lineTo(lx - 260, 0); g.fill();
    gr = g.createRadialGradient(lx, -8, 4, lx, -8, 170); gr.addColorStop(0, col + '.16)'); gr.addColorStop(1, col + '0)'); g.fillStyle = gr; g.save(); g.translate(0, -8); g.scale(1, .1); g.translate(0, 8); g.fillRect(lx - 170, -178, 340, 340); g.restore(); g.restore();
    g.fillStyle = '#161e20'; g.fillRect(lx - 54, -330, 108, 9); g.save(); g.shadowColor = col + '1)'; g.shadowBlur = 24; g.fillStyle = '#fffbf2'; g.beginPath(); g.roundRect(lx - 46, -322, 92, 8, 4); g.fill(); g.restore();
  }
  g.fillStyle = 'rgba(205,220,220,.55)'; g.fillRect(0, -318.5, CW, 2.5);
  const sway = Math.sin(t * 2.6) * .14 * clamp(speedAt(t) / 300);
  for (let x = 30; x < CW; x += 78) { if (Math.abs(x - 150) < 62 || Math.abs(x - 430) < 62) continue; g.save(); g.translate(x, -317); g.rotate(sway * (1 + .4 * Math.sin(x))); g.strokeStyle = 'rgba(16,22,24,.95)'; g.lineWidth = 3.5; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, 15); g.stroke(); g.strokeStyle = 'rgba(232,224,204,.8)'; g.lineWidth = 2.6; g.beginPath(); g.arc(0, 21, 6, 0, 7); g.stroke(); g.restore(); }
  const fg = g.createLinearGradient(0, -26, 0, -8); fg.addColorStop(0, 'rgba(255,255,255,0)'); fg.addColorStop(1, 'rgba(255,255,255,.12)'); g.fillStyle = fg; g.fillRect(0, -26, CW, 18);
}

/* ------------------------------------------------------------------ fx */
function waterBase(a) { const y0 = ws(0, 240).y; if (y0 > H) return; g.save(); g.globalAlpha = a; const gr = g.createLinearGradient(0, y0, 0, Math.max(H, y0 + 10)); gr.addColorStop(0, '#1d4d66'); gr.addColorStop(.3, '#112f49'); gr.addColorStop(1, '#060d1c'); g.fillStyle = gr; g.fillRect(0, y0, W, H - y0); g.restore(); }
function reflect(t, a) {
  const y0 = Math.round(ws(0, 240).y); if (y0 >= H) return; tg.setTransform(1, 0, 0, 1, 0, 0); tg.globalAlpha = 1; tg.globalCompositeOperation = 'source-over'; tg.filter = 'blur(2.2px)'; tg.drawImage(WC, 0, 0); tg.filter = 'none';
  g.save();
  for (let dy = 0; dy < H - y0; dy += 2) { const k = dy / 420, sy = y0 - 5 - dy * 1.15; if (sy < 0) break; g.globalAlpha = a * .5 * Math.max(.06, 1 - k * .95); const ox = Math.sin(dy * .07 + t * 2.2) * (.8 + k * 4.5) + Math.sin(dy * .19 - t * 3.1) * (.5 + k * 1.6); g.drawImage(TMP, 0, sy, W, 2, ox, y0 + dy, W, 2); }
  g.globalAlpha = a; g.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 60; i++) { const yy = y0 + 8 + hash(i * 3.1) * (H - y0), w = 14 + hash(i * 5) * 60, xx = (hash(i) * 1300 - Dist(t) * .25 + i * 13) % 1300 - 100; g.fillStyle = `rgba(255,236,190,${.05 + .13 * Math.abs(Math.sin(t * 3 + i))})`; g.fillRect(xx < -100 ? xx + 1300 : xx, yy, w, 2); }
  const gr = g.createLinearGradient(0, y0 - 10, 0, y0 + 26); gr.addColorStop(0, 'rgba(150,235,230,0)'); gr.addColorStop(.4, 'rgba(150,235,230,.26)'); gr.addColorStop(1, 'rgba(150,235,230,0)'); g.fillStyle = gr; g.fillRect(0, y0 - 10, W, 36);
  g.restore();
}
function fireworks(t) {
  const cols = [C.pink, '#ffd766', C.tealL, C.lilac, '#fff'];
  [32.3, 32.9, 33.5, 34.2, 34.8, 35.5].forEach((t0, i) => {
    const cx = 150 + hash(i * 3.3) * 780, cy = 200 + hash(i * 5.1) * 210, col = cols[i % 4], col2 = cols[(i + 2) % 5];
    const rk = inv(t0 - .55, t0, t); if (rk > 0 && rk < 1) { const y = lerp(760, cy, E.out3(rk)); g.save(); g.strokeStyle = 'rgba(255,240,200,.8)'; g.lineWidth = 3; g.lineCap = 'round'; g.beginPath(); g.moveTo(cx + Math.sin(rk * 9) * 4, y + 46); g.lineTo(cx, y); g.stroke(); g.restore(); }
    const k = inv(t0, t0 + 1.5, t); if (k <= 0 || k >= 1) return; const r = mulberry(i * 17 + 3);
    g.save(); g.globalCompositeOperation = 'lighter'; g.lineCap = 'round';
    if (k < .18) { const gr = g.createRadialGradient(cx, cy, 2, cx, cy, 190); gr.addColorStop(0, `rgba(255,255,255,${1 - k / .18})`); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(cx - 190, cy - 190, 380, 380); }
    for (let j = 0; j < 54; j++) { const a = j / 54 * Math.PI * 2 + r() * .2, sp = (j % 2 ? 200 : 130) * (.8 + r() * .4); const pos = kk => { const e = E.out3(kk); return [cx + Math.cos(a) * sp * e, cy + Math.sin(a) * sp * e + 110 * kk * kk]; };
      const [x1, y1] = pos(k), [x0, y0] = pos(Math.max(0, k - .09)); g.globalAlpha = (1 - k) * (k > .6 ? (.5 + .5 * Math.sin(t * 40 + j)) : 1); g.strokeStyle = j % 2 ? col : col2; g.lineWidth = 3.2 * (1 - k * .6); g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); g.fillStyle = '#fff'; g.beginPath(); g.arc(x1, y1, 2.2 * (1 - k), 0, 7); g.fill(); }
    g.restore();
  });
}
function rain(t, a) {
  if (a <= 0) return; g.save(); g.lineCap = 'round';
  for (let i = 0; i < 230; i++) { const near = i >= 190, sp = (near ? 1700 : 1000) + hash(i * 3) * 500, L = near ? 70 + hash(i * 5) * 50 : 14 + hash(i * 5) * 26; let x = (hash(i) * 1300 - t * (near ? 420 : 250)) % 1300; if (x < -110) x += 1300; const y = (hash(i * 7) * 1300 + t * sp) % 1300 - 110;
    g.strokeStyle = `rgba(205,230,250,${(near ? .16 : .1 + hash(i * 9) * .22) * a})`; g.lineWidth = near ? 3 : 1 + hash(i * 9) * 1.3; g.beginPath(); g.moveTo(x, y); g.lineTo(x - L * .26, y + L); g.stroke(); }
  // splashes on the roofs
  for (let i = 0; i < 26; i++) { const seed = i + Math.floor(t * 12 + i * .37) * 31, k = (t * 12 + i * .37) % 1; const p = ws(-1850 + hash(seed) * 3700, roofY - 1); if (p.x < 0 || p.x > W || p.y < 150) continue; g.strokeStyle = `rgba(220,240,255,${.55 * (1 - k) * a})`; g.lineWidth = 1.5; g.beginPath(); g.ellipse(p.x, p.y, (3 + k * 9) * CAM.z, (1 + k * 3) * CAM.z, 0, Math.PI, 0); g.stroke(); }
  g.restore();
}

/* ------------------------------------------------------------------ world + post */
function world(t) {
  T_NOW = t; CAM = camAt(t); const spd = speedAt(t) / 60 * CAM.z * .5, bridge = inv(31.6, 32.4, t);
  withCtx(wx, () => {
    g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.filter = 'none';
    skyArt(t);
    drawStrip(L_FAR, t); haze(.34, '80,150,170');
    drawStrip(L_MID2, t); haze(.3);
    drawStrip(L_MID, t); haze(.2, '50,105,125');
    if (bridge > 0) waterBase(bridge);
    smear(() => { platformBG(t); if (bridge > 0) { g.globalAlpha = bridge; drawStrip(L_BRB, t); g.globalAlpha = 1; } catenary(t); }, spd);
    trainGlow(t);
    camOn(); CARS.forEach(c => drawCar(c, t)); g.restore();
    headlight(t);
    smear(() => { if (bridge < 1) { g.globalAlpha = 1 - bridge; drawStrip(L_VIA, t); const gy = ws(0, 1036).y; if (gy < H) { g.fillStyle = '#070c10'; g.fillRect(0, gy, W, H - gy); } } if (bridge > 0) { g.globalAlpha = bridge; drawStrip(L_BRF, t); } g.globalAlpha = 1; }, spd);
    camOn(); drone(t); raidWorld(t);
    { const k = inv(26.05, 26.7, t); if (k > 0 && k < 1) for (let i = 0; i < 10; i++) { const a = Math.PI + i / 9 * Math.PI, d = 60 + 130 * E.out3(k); g.fillStyle = `rgba(225,235,235,${.55 * (1 - k)})`; g.beginPath(); g.arc(WALLX + Math.cos(a) * d, roofY + Math.sin(a) * d * .35, 16 + 22 * k, 0, 7); g.fill(); } }
    g.restore();
    fireworks(t);
    if (bridge > 0) reflect(t, bridge);
    rain(t, (t < 17 ? .75 : t < 23.6 ? .45 : t < 31.6 ? 1 : 0) * (1 - inv(31.4, 32, t)));
    for (const ft of [26.05, 28.85]) { const k = inv(ft, ft + .14, t); if (k > 0 && k < 1) { g.fillStyle = `rgba(255,255,255,${.5 * (1 - k)})`; g.fillRect(0, 0, W, H); } }
  });
  post(t);
}
function post(t) {
  for (const c of [bl1, bl2, bl3]) { c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; c.filter = 'none'; }
  bl1.drawImage(WC, 0, 0, 270, 270); bl1.globalCompositeOperation = 'multiply'; bl1.drawImage(WC, 0, 0, 270, 270); bl1.globalCompositeOperation = 'source-over';   // squared luminance = soft threshold
  bl2.clearRect(0, 0, 270, 270); bl2.filter = 'blur(3px)'; bl2.drawImage(BL1, 0, 0);
  bl3.clearRect(0, 0, 135, 135); bl3.filter = 'blur(7px)'; bl3.drawImage(BL1, 0, 0, 135, 135);
  g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over';
  g.filter = 'contrast(1.07) saturate(1.16)'; g.drawImage(WC, 0, 0); g.filter = 'none';
  g.globalCompositeOperation = 'screen'; g.globalAlpha = .4; g.drawImage(BL2, 0, 0, W, H); g.globalAlpha = .4; g.drawImage(BL3, 0, 0, W, H); g.globalAlpha = .12; g.drawImage(BL3, -W * .75, 0, W * 2.5, H);
  g.globalAlpha = 1; g.globalCompositeOperation = 'soft-light'; const gr = g.createLinearGradient(0, 0, W, H); gr.addColorStop(0, 'rgba(70,215,200,.2)'); gr.addColorStop(.55, 'rgba(120,120,160,0)'); gr.addColorStop(1, 'rgba(255,95,165,.2)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
  g.restore();
}
