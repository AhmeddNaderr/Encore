'use strict';
/* TRIPPI: LAST TRAIN TOWN — game concept film. 1080×1080 @ 60fps. Deterministic: frame(f). */
const W = 1080, H = 1080, FPS = 60, DUR = 46;
const cv = document.getElementById('c'), g = cv.getContext('2d');
const IMG = {};
const IMGN = ['logo', 'cone', 'train', 'mushroom', 'honey', 'axolotl', 'wolf', 'postmark-axolotl', 'postmark-frog', 'postmark-traffic', 'postmark-wolf', 'trippi-profile', 'nft-1', 'nft-2', 'streetlight'];

/* ---------------- math ---------------- */
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const inv = (a, b, t) => clamp((t - a) / (b - a));
const E = {
  out3: t => 1 - Math.pow(1 - t, 3), in3: t => t * t * t, io3: t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
  out5: t => 1 - Math.pow(1 - t, 5), io2: t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2,
  back: t => { const c1 = 1.9, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  bounce: t => { const n = 7.5625, d = 2.75; if (t < 1 / d) return n * t * t; if (t < 2 / d) return n * (t -= 1.5 / d) * t + .75; if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + .9375; return n * (t -= 2.625 / d) * t + .984375; },
};
function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function hash(n) { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }
const fmtN = v => Math.round(v).toLocaleString('en-US');

const C = { teal: '#16a687', tealD: '#0b6b56', tealL: '#6be6c6', pink: '#ff7eb0', honey: '#ffc12e', orange: '#ff7a2a', cream: '#fff3dc', ink: '#141414', lilac: '#b49bff', sky: '#7fd6ff', mint: '#9ff0c8', red: '#ff4848' };

/* ---------------- helpers ---------------- */
function font(w, s, f = 'Poppins') { return `${w} ${s}px ${f}`; }
function txt(s, x, y, o = {}) {
  g.save(); g.font = o.font || font(700, 24); g.fillStyle = o.color || '#fff'; g.textAlign = o.align || 'left'; g.textBaseline = o.base || 'alphabetic'; g.letterSpacing = (o.ls || 0) + 'px';
  if (o.alpha != null) g.globalAlpha *= o.alpha;
  if (o.shadow) { g.shadowColor = o.shadow; g.shadowBlur = o.blur || 0; g.shadowOffsetX = o.sx || 0; g.shadowOffsetY = o.sy || 0; }
  if (o.stroke) { g.lineWidth = o.sw || 6; g.strokeStyle = o.stroke; g.lineJoin = 'round'; g.strokeText(s, x, y); g.shadowColor = 'transparent'; }
  g.fillText(s, x, y); g.restore();
}
function measure(s, f, ls = 0) { g.save(); g.font = f; g.letterSpacing = ls + 'px'; const w = g.measureText(s).width; g.restore(); return w; }
function sprite(img, cx, by, h, o = {}) {
  const w = img.width * h / img.height; g.save(); g.translate(cx, by); if (o.rot) g.rotate(o.rot); g.scale((o.sx || 1) * (o.flip ? -1 : 1), o.sy || 1);
  if (o.alpha != null) g.globalAlpha *= o.alpha; g.drawImage(img, -w / 2, -h, w, h); g.restore();
}
function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
// sticker panel: cream fill, thick ink outline, hard drop shadow
function sticker(x, y, w, h, r, fill = C.cream, o = {}) {
  g.save(); g.fillStyle = o.shadowCol || 'rgba(0,0,0,.85)'; g.beginPath(); g.roundRect(x + (o.dx ?? 5), y + (o.dy ?? 6), w, h, r); g.fill();
  g.fillStyle = fill; g.beginPath(); g.roundRect(x, y, w, h, r); g.fill(); g.lineWidth = o.lw || 4; g.strokeStyle = C.ink; g.stroke(); g.restore();
}
function check(x, y, s, col = '#fff', lw = 4) { g.save(); g.strokeStyle = col; g.lineWidth = lw; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); g.moveTo(x - s * .5, y); g.lineTo(x - s * .12, y + s * .38); g.lineTo(x + s * .55, y - s * .4); g.stroke(); g.restore(); }
function heart(x, y, s, col) { g.save(); g.translate(x, y); g.scale(s / 20, s / 20); g.beginPath(); g.moveTo(0, 6); g.bezierCurveTo(-14, -4, -10, -16, 0, -9); g.bezierCurveTo(10, -16, 14, -4, 0, 6); g.fillStyle = col; g.fill(); g.restore(); }
function star(x, y, r, col, rot = 0) { g.save(); g.translate(x, y); g.rotate(rot); g.beginPath(); for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 - Math.PI / 2, rr = i % 2 ? r * .45 : r; g.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } g.closePath(); g.fillStyle = col; g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); g.restore(); }

/* ---------------- resource icons ---------------- */
function icon(kind, x, y, s) {
  g.save(); g.translate(x, y); g.scale(s / 40, s / 40); g.lineWidth = 3.5; g.strokeStyle = C.ink; g.lineJoin = 'round';
  if (kind === 'paint') { g.fillStyle = C.pink; g.beginPath(); g.roundRect(-11, -12, 22, 30, 5); g.fill(); g.stroke(); g.fillStyle = C.teal; g.fillRect(-9.5, -2, 19, 8); g.fillStyle = '#ddd'; g.beginPath(); g.roundRect(-7, -20, 14, 9, 3); g.fill(); g.stroke(); g.fillStyle = C.ink; g.fillRect(-2, -24, 4, 5); g.fillStyle = 'rgba(255,255,255,.6)'; g.fillRect(-7, -9, 3, 22); }
  else if (kind === 'honey') { g.fillStyle = C.honey; g.beginPath(); g.roundRect(-14, -10, 28, 28, 10); g.fill(); g.stroke(); g.fillStyle = '#8a5a2b'; g.beginPath(); g.roundRect(-12, -18, 24, 9, 3); g.fill(); g.stroke(); g.fillStyle = '#ffe28a'; g.beginPath(); g.ellipse(-6, 0, 3, 7, 0, 0, 7); g.fill(); g.fillStyle = C.honey; g.beginPath(); g.arc(8, -9, 4, 0, Math.PI); g.fill(); }
  else if (kind === 'ticket') { g.rotate(-.25); g.fillStyle = C.cream; g.beginPath(); g.roundRect(-18, -11, 36, 22, 4); g.fill(); g.stroke(); g.fillStyle = C.teal; g.fillRect(-16, -9, 9, 18); g.fillStyle = C.ink; g.fillRect(-2, -4, 14, 3); g.fillRect(-2, 2, 10, 3); }
  else if (kind === 'crew') { g.fillStyle = C.tealL; g.beginPath(); g.ellipse(0, 2, 15, 16, 0, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#fff'; g.beginPath(); g.ellipse(-5, 0, 4, 5, 0, 0, 7); g.ellipse(5, 0, 4, 5, 0, 0, 7); g.fill(); g.fillStyle = C.ink; g.beginPath(); g.arc(-4, 1, 2, 0, 7); g.arc(6, 1, 2, 0, 7); g.fill(); }
  else if (kind === 'stamp') { const im = IMG['postmark-frog']; g.rotate(.1); g.drawImage(im, -17, -19, 34, 34 * im.height / im.width); }
  g.restore();
}

/* ---------------- prebuilt ---------------- */
let NOISE = [], VIG, TMP, tg;
function prebuild() {
  for (let k = 0; k < 3; k++) { const c = mk(512, 512), x = c.getContext('2d'); const id = x.createImageData(512, 512); const r = mulberry(k * 77 + 3); for (let i = 0; i < id.data.length; i += 4) { const v = r() * 255 | 0; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; } x.putImageData(id, 0, 0); NOISE.push(c); }
  VIG = mk(W, H); { const x = VIG.getContext('2d'); const gr = x.createRadialGradient(540, 540, 380, 540, 540, 790); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.55)'); x.fillStyle = gr; x.fillRect(0, 0, W, H); }
  TMP = mk(W, H); tg = TMP.getContext('2d');
}
function grain(a, f) { g.save(); g.globalAlpha = a; g.globalCompositeOperation = 'overlay'; const n = NOISE[f % 3]; const ox = (hash(f) * 512) | 0, oy = (hash(f + .3) * 512) | 0; for (let x = -ox; x < W; x += 512) for (let y = -oy; y < H; y += 512) g.drawImage(n, x, y); g.restore(); }

/* =====================================================================
   TIMELINE
   ===================================================================== */
const T = { title: 0, gather: 3.2, build: 10.2, station: 17.2, raid: 23.6, hero: 31.6, board: 36.4, end: 41.4 };
// train speed (world px / s) and travelled distance
function speedAt(t) {
  if (t < 17.2) return 430;
  if (t < 18.6) return lerp(430, 0, E.out3(inv(17.2, 18.6, t)));
  if (t < 21.9) return 0;
  if (t < 23.4) return lerp(0, 640, E.io2(inv(21.9, 23.4, t)));
  if (t < 31.6) return 640;
  return lerp(640, 480, inv(31.6, 33, t));
}
const DT = []; { let d = 0; for (let i = 0; i <= DUR * FPS + 2; i++) { DT.push(d); d += speedAt(i / FPS) / FPS; } }
const Dist = t => { const i = clamp(t * FPS, 0, DT.length - 2); const a = Math.floor(i); return lerp(DT[a], DT[a + 1], i - a); };
const D_STOP = Dist(19);
function clockAt(t) { const s = 4 * 60 + Math.max(0, t - 3.2) * (300 / 29.8); const m = Math.min(9, Math.floor(s / 60)); const ss = m >= 9 ? 0 : Math.floor(s % 60); return `23:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`; }

/* ---------------- camera ---------------- */
const CAMS = [
  { a: 2.55, b: 3.55, x: 909, y: -238, z: 1.2 },
  { a: 4.55, b: 5.3, x: 303, y: -238, z: 1.2 },
  { a: 6.2, b: 6.95, x: -303, y: -238, z: 1.16 },
  { a: 7.55, b: 8.3, x: 606, y: -260, z: .86 },
  { a: 10.2, b: 11.0, x: -1000, y: -150, z: .56 },
  { a: 12.45, b: 13.2, x: -1515, y: -185, z: 1.02 },
  { a: 15.0, b: 17.1, x: -1440, y: -180, z: 1.12 },
  { a: 17.15, b: 18.3, x: -150, y: -230, z: .5 },
  { a: 22.3, b: 23.7, x: 470, y: -330, z: .92 },
  { a: 31.6, b: 33.1, x: 0, y: -90, z: .33 },
];
function camAt(t) {
  let c = { x: 300, y: -60, z: .34 };
  for (const m of CAMS) { const k = E.io3(inv(m.a, m.b, t)); if (k <= 0) break; c = { x: lerp(c.x, m.x, k), y: lerp(c.y, m.y, k), z: lerp(c.z, m.z, k) }; }
  c.x += Math.sin(t * .8) * 4; c.y += Math.cos(t * .6) * 3;
  // raid impact shake
  for (const s of [26.05, 27.45, 28.85]) { const k = inv(s, s + .35, t); if (k > 0 && k < 1) { c.x += Math.sin(t * 90) * 10 * (1 - k); c.y += Math.cos(t * 77) * 8 * (1 - k); } }
  return c;
}
let CAM = { x: 0, y: 0, z: 1 };
const ws = (x, y) => ({ x: (x - CAM.x) * CAM.z + 540, y: (y - CAM.y) * CAM.z + 560 });

/* ---------------- train layout ---------------- */
const CW = 580, GAP = 26, P = CW + GAP;
const slotX = i => (i - 2.5) * P - CW / 2; // left edge of slot i
const CARS = [
  { id: 'daycare', name: 'PET DAYCARE', lv: 1, wall: '#f0c9d6', wain: '#d79ab0', floor: '#a7678a', built: 15.0 },
  { id: 'lounge', name: 'LAST STOP LOUNGE', lv: 2, wall: '#1d4d47', wain: '#163833', floor: '#7a4d34' },
  { id: 'arcade', name: 'ARCADE', lv: 3, wall: '#271c46', wain: '#1b1333', floor: '#3b2b5c', res: 'ticket' },
  { id: 'honey', name: 'HONEY BAR', lv: 3, wall: '#5a3a24', wain: '#432a19', floor: '#8a5a33', res: 'honey' },
  { id: 'graffiti', name: 'GRAFFITI STUDIO', lv: 4, wall: '#34495a', wain: '#26363f', floor: '#5d6a6e', res: 'paint' },
  { id: 'engine', name: 'LINE 01', lv: 5, wall: '#1b2a2c', wain: '#122022', floor: '#3a4446' },
];
const CAR = Object.fromEntries(CARS.map((c, i) => [c.id, Object.assign(c, { i })]));
const roofY = -362;

/* ---------------- gather taps & economy ---------------- */
const TAPS = [ // world taps on ready bubbles
  { t: 4.0, car: 'graffiti', res: 'paint', amt: 150 }, { t: 5.6, car: 'honey', res: 'honey', amt: 130 }, { t: 7.2, car: 'arcade', res: 'ticket', amt: 90 },
  { t: 8.45, car: 'graffiti', res: 'paint', amt: 80 }, { t: 9.05, car: 'honey', res: 'honey', amt: 70 },
];
const READY = { graffiti: [[0, 4.0], [7.7, 8.45]], honey: [[0, 5.6], [8.1, 9.05]], arcade: [[0, 7.2]] };
const RESEV = []; TAPS.forEach(tp => RESEV.push({ t: tp.t + .75, res: tp.res, amt: tp.amt }));
RESEV.push({ t: 12.4, res: 'paint', amt: -300 }, { t: 12.4, res: 'honey', amt: -200 }, { t: 30.9, res: 'stamp', amt: 5 }, { t: 30.9, res: 'ticket', amt: 200 });
const START = { paint: 120, honey: 80, ticket: 40, crew: 64, stamp: 3 };
function res(kind, t) {
  let v = START[kind]; for (const e of RESEV) if (e.res === kind) v += e.amt * E.out3(inv(e.t, e.t + .5, t));
  if (kind === 'crew') v += 128 * E.io2(inv(19.1, 21.4, t));
  return v;
}
const pulseOf = (kind, t) => { let p = 0; for (const e of RESEV) if (e.res === kind) { const k = t - e.t; if (k > 0 && k < .35) p = Math.max(p, 1 - k / .35); } if (kind === 'crew' && t > 19.1 && t < 21.4) p = .4 + .3 * Math.sin(t * 20); return p; };

/* ---------------- passengers (procedural oddballs in Trippi's bold-outline style) ---------------- */
const ODD_COLS = ['#ff8fb8', '#43c9a8', '#ffc93c', '#ff8a3d', '#b89cff', '#a6f0c6', '#7fd3ff', '#fff1d6', '#ff6b6b'];
const SHAPES = ['bean', 'pill', 'box', 'onion', 'ghost', 'blob'];
const HATS = [null, 'beanie', 'cap', null, 'sprout', 'bow', null, 'phones'];
function mkOdd(seed) { const r = mulberry(seed); return { shape: SHAPES[Math.floor(r() * SHAPES.length)], col: ODD_COLS[Math.floor(r() * ODD_COLS.length)], hat: HATS[Math.floor(r() * HATS.length)], hatCol: ODD_COLS[Math.floor(r() * ODD_COLS.length)], ph: r() * 7, eye: r() < .25 ? 'one' : r() < .5 ? 'sleepy' : 'two', s: .82 + r() * .3 }; }
function oddball(x, y, s, o, t, walking = 0, flip = 1, tint = 0) {
  const bob = walking ? Math.abs(Math.sin(t * 9 + o.ph)) * 5 : Math.sin(t * 2.4 + o.ph) * 1.6; const sq = walking ? 1 + .04 * Math.sin(t * 18 + o.ph) : 1 + .025 * Math.sin(t * 2.4 + o.ph);
  g.save(); g.translate(x, y); g.scale(s * o.s * flip, s * o.s);
  g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(0, 0, 26, 6, 0, 0, 7); g.fill();
  // feet
  const st = walking ? Math.sin(t * 9 + o.ph) * 6 : 0; g.fillStyle = C.ink; g.beginPath(); g.ellipse(-10 + st, -4, 9, 6, 0, 0, 7); g.ellipse(10 - st, -4, 9, 6, 0, 0, 7); g.fill();
  g.translate(0, -bob); g.scale(1 / sq, sq);
  g.lineWidth = 4.5; g.strokeStyle = C.ink; g.fillStyle = o.col; g.lineJoin = 'round'; g.beginPath();
  const sh = o.shape;
  if (sh === 'bean') g.ellipse(0, -40, 27, 36, 0, 0, 7);
  else if (sh === 'pill') g.roundRect(-24, -82, 48, 78, 24);
  else if (sh === 'box') g.roundRect(-30, -70, 60, 64, 14);
  else if (sh === 'onion') { g.moveTo(0, -90); g.bezierCurveTo(10, -70, 34, -60, 32, -34); g.bezierCurveTo(30, -8, -30, -8, -32, -34); g.bezierCurveTo(-34, -60, -10, -70, 0, -90); }
  else if (sh === 'ghost') { g.moveTo(-28, -8); g.lineTo(-28, -50); g.arc(0, -50, 28, Math.PI, 0); g.lineTo(28, -8); for (let k = 0; k < 4; k++) g.quadraticCurveTo(21 - k * 14, 2, 14 - k * 14, -8); }
  else { g.moveTo(-30, -12); g.bezierCurveTo(-38, -60, -12, -78, 4, -72); g.bezierCurveTo(30, -70, 40, -40, 30, -12); g.closePath(); }
  g.fill(); if (tint) { g.save(); g.fillStyle = `rgba(10,20,40,${tint})`; g.fill(); g.restore(); } g.stroke();
  // shine
  g.save(); g.clip(); g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.ellipse(-12, -58, 6, 12, -.4, 0, 7); g.fill(); g.restore();
  // face
  const ey = sh === 'box' ? -44 : sh === 'pill' ? -54 : -46;
  if (o.eye === 'one') { g.fillStyle = '#fff'; g.beginPath(); g.ellipse(2, ey, 11, 12, 0, 0, 7); g.fill(); g.lineWidth = 3; g.stroke(); g.fillStyle = C.ink; g.beginPath(); g.arc(4, ey + 1, 5, 0, 7); g.fill(); }
  else if (o.eye === 'sleepy') { g.lineWidth = 3.5; g.beginPath(); g.arc(-9, ey, 6, .2, Math.PI - .2); g.moveTo(15, ey); g.arc(9, ey, 6, .2, Math.PI - .2); g.stroke(); }
  else { const blink = (Math.floor(t * 1.3 + o.ph) % 5 === 0) && ((t * 1.3 + o.ph) % 1 < .12); g.fillStyle = '#fff'; g.beginPath(); g.ellipse(-9, ey, 7, blink ? 1.5 : 8.5, 0, 0, 7); g.ellipse(9, ey, 7, blink ? 1.5 : 8.5, 0, 0, 7); g.fill(); g.lineWidth = 2.5; g.stroke(); if (!blink) { g.fillStyle = C.ink; g.beginPath(); g.arc(-7, ey + 1, 3.6, 0, 7); g.arc(11, ey + 1, 3.6, 0, 7); g.fill(); } }
  g.fillStyle = 'rgba(255,90,130,.45)'; g.beginPath(); g.ellipse(-17, ey + 12, 5, 3, 0, 0, 7); g.ellipse(17, ey + 12, 5, 3, 0, 0, 7); g.fill();
  g.lineWidth = 3; g.beginPath(); g.arc(1, ey + 12, 4, .3, Math.PI - .3); g.stroke();
  // hats
  const top = sh === 'bean' ? -76 : sh === 'pill' ? -82 : sh === 'box' ? -70 : sh === 'onion' ? -78 : sh === 'ghost' ? -78 : -72;
  g.lineWidth = 3.5; g.fillStyle = o.hatCol;
  if (o.hat === 'beanie') { g.beginPath(); g.arc(0, top + 6, 20, Math.PI, 0); g.closePath(); g.fill(); g.stroke(); g.beginPath(); g.arc(0, top - 15, 6, 0, 7); g.fill(); g.stroke(); }
  else if (o.hat === 'cap') { g.beginPath(); g.arc(0, top + 6, 19, Math.PI, 0); g.closePath(); g.fill(); g.stroke(); g.beginPath(); g.roundRect(4, top + 1, 30, 7, 3); g.fill(); g.stroke(); }
  else if (o.hat === 'sprout') { g.strokeStyle = '#2f8a3a'; g.lineWidth = 4; g.beginPath(); g.moveTo(0, top + 4); g.lineTo(0, top - 12); g.stroke(); g.fillStyle = '#5fd36a'; g.strokeStyle = C.ink; g.lineWidth = 3; g.beginPath(); g.ellipse(-8, top - 14, 9, 5, -.5, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.ellipse(8, top - 14, 9, 5, .5, 0, 7); g.fill(); g.stroke(); }
  else if (o.hat === 'bow') { g.beginPath(); g.moveTo(0, top + 2); g.lineTo(-14, top - 8); g.lineTo(-14, top + 10); g.closePath(); g.moveTo(0, top + 2); g.lineTo(14, top - 8); g.lineTo(14, top + 10); g.closePath(); g.fill(); g.stroke(); }
  else if (o.hat === 'phones') { g.strokeStyle = C.ink; g.lineWidth = 4; g.beginPath(); g.arc(0, ey, 30, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); g.fillStyle = o.hatCol; g.beginPath(); g.roundRect(-34, ey - 6, 10, 18, 4); g.roundRect(24, ey - 6, 10, 18, 4); g.fill(); g.lineWidth = 3; g.stroke(); }
  g.restore();
}
// passengers per car
const PAX = [];
(function () {
  const r = mulberry(31); let seed = 100;
  const add = (car, n, appear = -1, sit = false) => { for (let k = 0; k < n; k++) PAX.push({ car, o: mkOdd(seed++), x0: 70 + r() * 440, range: 40 + r() * 90, sp: .25 + r() * .35, appear: appear < 0 ? -1 : appear + k * .22 + r() * .1, sit }); };
  add('lounge', 2); add('arcade', 1); add('honey', 2); add('graffiti', 1); add('daycare', 0);
  // boarding at the station (19.1 – 21.4)
  add('lounge', 4, 19.2); add('arcade', 4, 19.4); add('honey', 4, 19.3); add('graffiti', 3, 19.5); add('daycare', 3, 19.6);
})();
const BABIES = [mkOdd(900), mkOdd(901), mkOdd(902), mkOdd(903)];

/* =====================================================================
   BACKGROUND (parallax night city)
   ===================================================================== */
function layerXY(gx, gy, f, t) { const zl = 1 + (CAM.z - 1) * f; return { x: (gx - Dist(t) * f - CAM.x * f) * zl + 540, y: (gy - CAM.y * f) * zl + 560, z: zl }; }
function sky(t) {
  const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#07101f'); gr.addColorStop(.55, '#132a40'); gr.addColorStop(1, '#1f3f4f'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
  g.save(); for (let i = 0; i < 90; i++) { const x = hash(i) * W, y = hash(i + 9) * H * .55; g.globalAlpha = .3 + .5 * Math.abs(Math.sin(t * (.5 + hash(i * 3)) + i)); g.fillStyle = '#e8f6ff'; g.fillRect(x, y, 2, 2); } g.restore();
  const m = layerXY(900, -1400, .03, t); const mz = Math.max(.5, m.z);
  g.save(); g.shadowColor = '#fff6d8'; g.shadowBlur = 60; g.fillStyle = '#fff3d0'; g.beginPath(); g.arc(m.x, m.y, 90 * mz, 0, 7); g.fill(); g.shadowBlur = 0;
  g.fillStyle = 'rgba(200,180,140,.35)'; [[-25, -20, 18], [30, 15, 12], [-10, 40, 9]].forEach(([dx, dy, r]) => { g.beginPath(); g.arc(m.x + dx * mz, m.y + dy * mz, r * mz, 0, 7); g.fill(); }); g.restore();
}
function buildingRow(t, f, period, base, col, hmin, hmax, seed, lit, opts = {}) {
  const zl = 1 + (CAM.z - 1) * f; const off = Dist(t) * f + CAM.x * f; const k0 = Math.floor((off - 540 / zl - 400) / period), k1 = Math.floor((off + 540 / zl + 400) / period);
  for (let k = k0; k <= k1; k++) {
    const r = mulberry(seed + k * 13); let x = k * period;
    while (x < (k + 1) * period) {
      const bw = 120 + r() * 220, bh = hmin + r() * (hmax - hmin); const p = layerXY(x, base - bh, f, t); const w = bw * zl, h = bh * zl;
      g.fillStyle = col; g.fillRect(p.x, p.y, w + 1, h + 2000 * zl);
      if (r() < .35) { g.fillRect(p.x + w * .2, p.y - 30 * zl, w * .15, 30 * zl); }
      if (opts.tank && r() < .3) { g.fillStyle = col; g.beginPath(); g.roundRect(p.x + w * .55, p.y - 60 * zl, 50 * zl, 44 * zl, 6 * zl); g.fill(); g.fillRect(p.x + w * .58, p.y - 16 * zl, 4 * zl, 16 * zl); g.fillRect(p.x + w * .55 + 42 * zl, p.y - 16 * zl, 4 * zl, 16 * zl); }
      if (lit) { const cols = Math.floor(bw / 34), rows = Math.floor(bh / 40); for (let cx = 0; cx < cols; cx++) for (let cy = 0; cy < rows; cy++) { const hh = hash(seed + k * 7 + x * .01 + cx * 3.1 + cy * 7.7); if (hh < .38) { const on = hh < .3 || Math.sin(t * 2 + hh * 50) > 0; if (!on) continue; g.fillStyle = hh < .08 ? 'rgba(255,140,190,.75)' : hh < .16 ? 'rgba(120,240,210,.6)' : 'rgba(255,214,140,.7)'; g.fillRect(p.x + (12 + cx * 34) * zl, p.y + (18 + cy * 40) * zl, 14 * zl, 18 * zl); } } }
      if (opts.signs && r() < .28) { const sx = p.x + w * .3, sy = p.y + h * .25; const sc = ['#ff7eb0', '#6be6c6', '#ffc12e'][Math.floor(r() * 3)]; g.save(); g.shadowColor = sc; g.shadowBlur = 22 * zl; g.strokeStyle = sc; g.lineWidth = 4 * zl; g.beginPath(); g.roundRect(sx, sy, 90 * zl, 40 * zl, 8 * zl); g.stroke(); g.fillStyle = sc; g.font = `800 ${20 * zl}px Poppins`; g.fillText(['24H', 'PETS', 'HONEY', 'ODD', 'Y2K', 'ARCADE'][Math.floor(r() * 6)], sx + 10 * zl, sy + 28 * zl); g.restore(); }
      if (opts.logo && r() < .12) { const lw = 260 * zl; g.save(); g.globalAlpha = .9; g.drawImage(IMG.logo, p.x + w * .1, p.y + h * .35, lw, lw * IMG.logo.height / IMG.logo.width); g.restore(); }
      x += bw + 8 + r() * 30;
    }
  }
}
function viaduct(t, bridge) {
  const zl = CAM.z; const off = Dist(t); const p0 = ws(0, 62);
  // deck
  g.fillStyle = '#0f1d22'; const top = ws(0, 64).y, bot = ws(0, 118).y; g.fillRect(0, top, W, bot - top);
  g.fillStyle = 'rgba(107,230,198,.35)'; g.fillRect(0, top, W, Math.max(1, 3 * zl));
  g.fillStyle = '#3a4a4e'; g.fillRect(0, ws(0, 58).y, W, Math.max(1.5, 6 * zl)); // rail
  const per = bridge ? 900 : 520; const k0 = Math.floor((off + CAM.x - 540 / zl - per) / per), k1 = Math.floor((off + CAM.x + 540 / zl + per) / per);
  for (let k = k0; k <= k1; k++) {
    const x = k * per - off; const a = ws(x, 118); const b = ws(x + per, 118);
    if (bridge) { // truss bridge
      g.strokeStyle = '#1d3238'; g.lineWidth = 7 * zl; g.beginPath(); g.moveTo(a.x, ws(0, 64).y); g.lineTo((a.x + b.x) / 2, ws(0, -420).y); g.lineTo(b.x, ws(0, 64).y); g.stroke();
      g.beginPath(); g.moveTo(a.x, ws(0, -420).y); g.lineTo(b.x, ws(0, -420).y); g.stroke();
      g.fillStyle = '#122328'; g.fillRect(a.x - 18 * zl, ws(0, 118).y, 36 * zl, 900 * zl);
    } else {
      g.fillStyle = '#0c181c'; g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(a.x, ws(0, 900).y); g.lineTo(a.x + 60 * zl, ws(0, 900).y); g.lineTo(a.x + 60 * zl, ws(0, 260).y); g.arc((a.x + b.x) / 2 + 30 * zl, ws(0, 260).y, (b.x - a.x - 60 * zl) / 2, Math.PI, 0); g.lineTo(b.x, ws(0, 900).y); g.lineTo(b.x, a.y); g.closePath(); g.fill();
      g.strokeStyle = 'rgba(107,230,198,.12)'; g.lineWidth = 2; g.stroke();
    }
  }
  if (!bridge) { const sl = ws(0, 560).y; const gr = g.createLinearGradient(0, sl, 0, sl + 200 * zl); gr.addColorStop(0, 'rgba(255,170,90,.18)'); gr.addColorStop(1, 'rgba(255,170,90,0)'); g.fillStyle = gr; g.fillRect(0, sl, W, 300 * zl); }
}
function river(t) {
  const y0 = ws(0, 240).y; const gr = g.createLinearGradient(0, y0, 0, H); gr.addColorStop(0, '#16324a'); gr.addColorStop(1, '#0a1828'); g.fillStyle = gr; g.fillRect(0, y0, W, H - y0);
  g.save(); for (let i = 0; i < 70; i++) { const x = (hash(i) * W * 1.3 - (Dist(t) * .3) % 300 + i * 17) % (W + 100) - 50; const y = y0 + 10 + hash(i * 3) * (H - y0); g.globalAlpha = .25 + .3 * Math.sin(t * 3 + i); g.fillStyle = ['#ffc12e', '#ff7eb0', '#6be6c6', '#fff3d0'][i % 4]; g.fillRect(x, y, 20 + hash(i * 5) * 50, 2); } g.restore();
}
function catenary(t) {
  const per = 700; const off = Dist(t); const zl = CAM.z; const k0 = Math.floor((off + CAM.x - 540 / zl - per) / per), k1 = Math.floor((off + CAM.x + 540 / zl + per) / per);
  const wy = ws(0, -452).y; g.strokeStyle = 'rgba(160,190,190,.6)'; g.lineWidth = Math.max(1, 2 * zl); g.beginPath(); g.moveTo(0, wy); g.lineTo(W, wy); g.stroke();
  for (let k = k0; k <= k1; k++) { const x = k * per - off + 200; const a = ws(x, -500), b = ws(x, 64); g.fillStyle = '#18272b'; g.fillRect(a.x - 6 * zl, a.y, 12 * zl, b.y - a.y); g.fillRect(a.x - 6 * zl, a.y, 70 * zl, 8 * zl); g.fillStyle = '#ff5050'; if (Math.sin(t * 4 + k) > 0) { g.save(); g.shadowColor = '#ff4040'; g.shadowBlur = 14; g.beginPath(); g.arc(a.x, a.y + 30 * zl, 5 * zl, 0, 7); g.fill(); g.restore(); } }
}
function platformBG(t) { // Rush Hour station, behind the train (y raised = further back)
  const x0 = D_STOP - Dist(t) - 2300, x1 = x0 + 4600; const a = ws(x0, -150), b = ws(x1, -150); if (b.x < -50 || a.x > W + 50) return;
  const zl = CAM.z;
  g.fillStyle = '#2d3c3e'; g.fillRect(a.x, ws(0, -560).y, b.x - a.x, ws(0, -150).y - ws(0, -560).y); // back wall
  for (let x = x0; x < x1; x += 60) { const p = ws(x, -560); g.fillStyle = `rgba(200,230,220,${.04 + hash(x) * .05})`; g.fillRect(p.x + 2, p.y, 56 * zl, (410) * zl); }
  g.fillStyle = C.teal; g.fillRect(a.x, ws(0, -300).y, b.x - a.x, 26 * zl);
  g.fillStyle = '#596869'; g.fillRect(a.x, ws(0, -150).y, b.x - a.x, 30 * zl); g.fillStyle = '#e1ae25'; g.fillRect(a.x, ws(0, -150).y, b.x - a.x, 6 * zl);
  // hanging station signs above the roofs
  for (const sx of [-1500, 0, 1500]) { const p = ws(x0 + 2300 + sx, -540); const w = 330 * zl, h = 70 * zl; g.fillStyle = '#0a3d31'; g.strokeStyle = '#e8fff7'; g.lineWidth = 3 * zl; g.beginPath(); g.roundRect(p.x - w / 2, p.y, w, h, 10 * zl); g.fill(); g.stroke(); g.fillStyle = '#fff'; g.font = `800 ${38 * zl}px Poppins`; g.textAlign = 'center'; g.fillText('RUSH HOUR', p.x, p.y + 50 * zl); g.textAlign = 'left'; g.fillStyle = '#1b2422'; g.fillRect(p.x - w * .3, p.y - 60 * zl, 4 * zl, 60 * zl); g.fillRect(p.x + w * .3, p.y - 60 * zl, 4 * zl, 60 * zl); }
  // waiting crowd (they board 19.1 – 21.4)
  for (let i = 0; i < 46; i++) {
    const o = CROWD[i]; const gone = inv(19.1 + i * .05, 19.35 + i * .05, t); if (gone >= 1) continue;
    const p = ws(x0 + 300 + i * 88 + hash(i) * 30, -150); g.save(); g.globalAlpha = 1 - gone; oddball(p.x, p.y - gone * 30 * zl, .95 * zl, o, t + i, 0, i % 2 ? 1 : -1, .25); g.restore();
  }
}
const CROWD = Array.from({ length: 46 }, (_, i) => mkOdd(500 + i));

/* =====================================================================
   TRAIN CARS (cutaway, dollhouse style)
   ===================================================================== */
function wheelSet(x, t) { const ang = Dist(t) / 24; g.save(); g.translate(x, 34); g.fillStyle = '#151d1f'; g.beginPath(); g.roundRect(-70, -16, 140, 22, 8); g.fill(); for (const dx of [-40, 40]) { g.save(); g.translate(dx, 6); g.rotate(ang); g.fillStyle = '#2a3437'; g.beginPath(); g.arc(0, 0, 22, 0, 7); g.fill(); g.strokeStyle = '#8fa3a3'; g.lineWidth = 3; g.stroke(); g.beginPath(); for (let k = 0; k < 3; k++) { g.moveTo(Math.cos(k * 2.09) * 18, Math.sin(k * 2.09) * 18); g.lineTo(-Math.cos(k * 2.09) * 18, -Math.sin(k * 2.09) * 18); } g.stroke(); g.restore(); } g.restore(); }
function backWall(c, holes) { g.beginPath(); g.rect(0, -330, CW, 330); holes.forEach(h => g.roundRect(h[0], h[1], h[2], h[3], 12)); g.fillStyle = c.wall; g.fill('evenodd'); }
function windowFrames(holes) { holes.forEach(h => { g.save(); g.fillStyle = 'rgba(150,220,255,.07)'; g.beginPath(); g.roundRect(h[0], h[1], h[2], h[3], 12); g.fill(); g.strokeStyle = '#11181a'; g.lineWidth = 7; g.stroke(); g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 3; g.beginPath(); g.moveTo(h[0] + 16, h[1] + h[3] - 14); g.lineTo(h[0] + h[2] * .55, h[1] + 14); g.stroke(); g.restore(); }); }
function ceilingLights(t, col = 'rgba(255,226,170,') { for (const lx of [150, 430]) { const gr = g.createRadialGradient(lx, -315, 4, lx, -160, 260); gr.addColorStop(0, col + '.32)'); gr.addColorStop(1, col + '0)'); g.fillStyle = gr; g.fillRect(lx - 260, -330, 520, 330); g.fillStyle = '#fff6dc'; g.beginPath(); g.roundRect(lx - 40, -322, 80, 8, 4); g.fill(); } }
function doorHole(t) { const open = E.io2(inv(18.7, 19.1, t)) * (1 - E.io2(inv(21.5, 21.9, t))); return open; }
function shell(c, t, isEngine) {
  // roof
  g.fillStyle = '#2f3d3f'; g.beginPath(); if (isEngine) { g.moveTo(0, -330); g.lineTo(0, -352); g.quadraticCurveTo(0, -362, 14, -362); g.lineTo(CW - 120, -362); g.quadraticCurveTo(CW - 30, -360, CW, -240); g.lineTo(CW, -330); g.closePath(); } else g.roundRect(-4, -362, CW + 8, 34, [16, 16, 0, 0]); g.fill();
  g.fillStyle = C.teal; g.fillRect(0, -334, isEngine ? CW - 60 : CW, 6);
  if (!isEngine) { g.fillStyle = '#3b4b4e'; g.beginPath(); g.roundRect(CW * .25, -384, 120, 24, 6); g.roundRect(CW * .6, -380, 90, 20, 6); g.fill(); g.strokeStyle = '#1b2527'; g.lineWidth = 3; g.stroke(); }
  // floor + chassis
  g.fillStyle = c.floor; g.fillRect(0, -10, CW, 12); g.fillStyle = 'rgba(0,0,0,.25)'; for (let x = 0; x < CW; x += 46) g.fillRect(x, -10, 2, 12);
  g.fillStyle = '#1a2325'; g.fillRect(0, 2, CW, 22); g.fillStyle = C.teal; g.fillRect(0, 6, CW, 4);
  wheelSet(110, t); wheelSet(CW - 110, t);
  // cutaway section edges (hatched)
  const hatch = (x, y, w, h) => { g.save(); g.fillStyle = '#1c2729'; g.fillRect(x, y, w, h); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.strokeStyle = 'rgba(107,230,198,.35)'; g.lineWidth = 2; for (let k = -h; k < w + h; k += 9) { g.beginPath(); g.moveTo(x + k, y); g.lineTo(x + k - h, y + h); g.stroke(); } g.restore(); };
  hatch(-6, -340, 14, 345); if (!isEngine) hatch(CW - 8, -340, 14, 345);
  g.strokeStyle = C.ink; g.lineWidth = 5; g.beginPath(); g.moveTo(-6, -340); g.lineTo(-6, 24); g.stroke(); if (!isEngine) { g.beginPath(); g.moveTo(CW + 6, -340); g.lineTo(CW + 6, 24); g.stroke(); }
}
function nameTag(c, t, a) {
  if (a <= 0) return; const f = font(800, 22), w = measure(c.name, f) + 96;
  g.save(); g.globalAlpha = a; g.translate(CW / 2, -420); sticker(-w / 2, -24, w, 44, 22, C.cream, { dx: 3, dy: 4, lw: 3.5 });
  txt(c.name, -w / 2 + 18, 7, { font: f, color: C.ink }); g.fillStyle = C.teal; g.beginPath(); g.roundRect(w / 2 - 70, -14, 56, 26, 13); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke();
  txt('LV ' + c.lv, w / 2 - 42, 6, { font: font(800, 15), color: '#fff', align: 'center' }); g.restore();
}
function readyBubble(c, t) {
  const rd = READY[c.id]; if (!rd) return; let vis = 0, pop = 0;
  for (const [a, b] of rd) { if (t >= a && t < b + .25) { vis = E.back(inv(a, a + .3, t)) * (1 - E.in3(inv(b, b + .2, t))); if (t > b) pop = inv(b, b + .25, t); } }
  if (vis <= 0.01) return; const bob = Math.sin(t * 4) * 6;
  g.save(); g.translate(CW / 2, -548 + bob); g.scale(vis * (1 + pop * .4), vis * (1 + pop * .4));
  g.fillStyle = 'rgba(0,0,0,.8)'; g.beginPath(); g.arc(4, 5, 40, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(0, 0, 40, 0, 7); g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
  g.beginPath(); g.moveTo(-10, 36); g.lineTo(0, 54); g.lineTo(10, 36); g.fillStyle = '#fff'; g.fill(); g.stroke(); g.fillStyle = '#fff'; g.fillRect(-12, 30, 24, 8);
  icon(c.res, 0, 0, 50); const ring = (t * 1.2) % 1; g.globalAlpha = 1 - ring; g.strokeStyle = C.honey; g.lineWidth = 4; g.beginPath(); g.arc(0, 0, 44 + ring * 26, 0, 7); g.stroke();
  g.restore();
}
function pax(c, t, xmin = 40, xmax = CW - 40, y = -12) {
  PAX.filter(p => p.car === c.id).forEach((p, i) => {
    if (p.appear > 0 && t < p.appear) return; const ap = p.appear > 0 ? E.back(inv(p.appear, p.appear + .35, t)) : 1;
    const ph = t * p.sp + p.o.ph; const x = clamp(p.x0 + Math.sin(ph) * p.range, xmin, xmax); const dir = Math.cos(ph) >= 0 ? 1 : -1; const walking = Math.abs(Math.cos(ph)) > .25;
    g.save(); g.translate(x, y); g.scale(ap, ap); oddball(0, 0, .95, p.o, t, walking ? 1 : 0, dir); g.restore();
    if (p.appear > 0 && t < p.appear + 1.1) { const k = inv(p.appear + .1, p.appear + 1.1, t); g.save(); g.globalAlpha = 1 - k; heart(x, y - 110 - k * 40, 20, C.pink); g.restore(); }
  });
}
/* ---- per-car interiors ---- */
function carGraffiti(c, t) {
  const holes = [[26, -270, 100, 116], [456, -270, 100, 116]]; const dop = doorHole(t); if (dop > 0) holes.push([240, -250, 100 * dop, 240]);
  backWall(c, holes); windowFrames(holes.slice(0, 2));
  g.fillStyle = c.wain; g.fillRect(0, -110, CW, 100);
  // the piece being painted: Trippi logo revealed left→right with drips
  const prog = clamp(.25 + (t - 2) / 12, 0, 1); const lw = 290, lh = lw * IMG.logo.height / IMG.logo.width;
  g.save(); g.beginPath(); g.rect(145, -300, lw * prog + 4, 200); g.clip(); g.drawImage(IMG.logo, 145, -292, lw, lh); g.restore();
  g.save(); g.fillStyle = C.teal; for (let k = 0; k < 7; k++) { const dx = 160 + k * 38; if (dx - 145 > lw * prog) break; const dl = 10 + hash(k) * 30 + Math.min(30, (t - 2) * 3) * hash(k + 4); g.fillRect(dx, -292 + lh - 12, 4, dl); } g.restore();
  // spray mist
  const sx = 145 + lw * prog, sy = -240 + Math.sin(t * 3) * 30; g.save(); for (let k = 0; k < 16; k++) { const a = hash(k + Math.floor(t * 30)) * 1.2 - .6; const d = hash(k * 3 + Math.floor(t * 30)) * 60; g.globalAlpha = .5 * (1 - d / 60); g.fillStyle = C.tealL; g.beginPath(); g.arc(sx + 30 + Math.cos(a) * d * .3, sy + Math.sin(a) * d * .4, 3 + hash(k) * 4, 0, 7); g.fill(); } g.restore();
  // paint cans + crate + mushroom artist
  [[40, C.pink], [72, C.honey], [104, C.teal], [56, C.lilac]].forEach(([x, col], k) => { const y = k === 3 ? -54 : -12; g.save(); g.fillStyle = col; g.beginPath(); g.roundRect(x, y - 40, 28, 40, 4); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); g.fillStyle = '#ddd'; g.fillRect(x + 4, y - 46, 20, 6); g.restore(); });
  ceilingLights(t);
  sprite(IMG.mushroom, 470, -58, 170, { rot: Math.sin(t * 3) * .05, sy: 1 + .02 * Math.sin(t * 6) });
  g.save(); g.fillStyle = '#8a5a33'; g.fillRect(400, -80, 150, 70); g.strokeStyle = C.ink; g.lineWidth = 4; g.strokeRect(400, -80, 150, 70); g.strokeStyle = '#6b4224'; g.lineWidth = 3; g.beginPath(); g.moveTo(400, -45); g.lineTo(550, -45); g.moveTo(400, -80); g.lineTo(550, -10); g.stroke(); g.restore();
  // spray can in mushroom's "hand"
  g.save(); g.translate(395, -150 + Math.sin(t * 3) * 26); g.rotate(-.5); icon('paint', 0, 0, 46); g.restore();
  pax(c, t, 60, 380);
}
function carHoney(c, t) {
  const holes = [[30, -276, 110, 110], [440, -276, 110, 110]]; const dop = doorHole(t); if (dop > 0) holes.push([240, -250, 100 * dop, 240]);
  backWall(c, holes); windowFrames(holes.slice(0, 2));
  g.fillStyle = c.wain; g.fillRect(0, -110, CW, 100);
  // shelves of jars
  for (const sy of [-150, -200]) { g.fillStyle = '#3a2414'; g.fillRect(160, sy, 260, 8); for (let k = 0; k < 6; k++) { const x = 172 + k * 42; g.save(); g.fillStyle = C.honey; g.beginPath(); g.roundRect(x, sy - 34, 28, 34, 7); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); g.fillStyle = '#8a5a2b'; g.fillRect(x + 2, sy - 40, 24, 7); g.fillStyle = 'rgba(255,255,255,.45)'; g.fillRect(x + 5, sy - 28, 4, 20); g.restore(); } }
  // neon HONEY sign
  g.save(); const fl = .85 + .15 * Math.sin(t * 20) * (hash(Math.floor(t * 6)) > .85 ? 1 : 0); g.globalAlpha = fl; g.shadowColor = C.honey; g.shadowBlur = 24; txt('HONEY', 290, -238, { font: font(800, 44), align: 'center', color: '#ffe08a' }); g.restore();
  ceilingLights(t);
  // bartender honey (bust behind counter)
  sprite(IMG.honey, 300, -60, 170, { rot: Math.sin(t * 2.2) * .04, sy: 1 + .02 * Math.sin(t * 4) });
  // counter
  g.save(); g.fillStyle = '#7a4a28'; g.beginPath(); g.roundRect(150, -96, 330, 88, 6); g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke(); g.fillStyle = '#a9693a'; g.fillRect(146, -102, 338, 14); g.strokeRect(146, -102, 338, 14);
  g.fillStyle = C.honey; for (let k = 0; k < 5; k++) { const dx = 170 + k * 70, dl = 6 + 10 * (.5 + .5 * Math.sin(t * 2 + k)); g.beginPath(); g.roundRect(dx, -88, 10, dl, 5); g.fill(); } g.restore();
  // honey tap drip
  const dk = (t * 1.4) % 1; g.fillStyle = C.honey; g.beginPath(); g.arc(436, -110 + dk * 70, 5, 0, 7); g.fill();
  // stools with seated oddballs
  [[90, 0], [520, 1]].forEach(([x, k]) => { g.fillStyle = '#2b2b2b'; g.fillRect(x - 3, -60, 6, 50); g.fillStyle = C.pink; g.beginPath(); g.ellipse(x, -62, 22, 7, 0, 0, 7); g.fill(); g.strokeStyle = C.ink; g.lineWidth = 3; g.stroke(); oddball(x, -64, .72, mkOdd(700 + k), t, 0, k ? -1 : 1); });
  pax(c, t, 40, 540);
}
function arcadeScreen(x, y, w, h, t, k) {
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.fillStyle = '#0a0f1f'; g.fillRect(x, y, w, h);
  if (k === 0) { for (let i = 0; i < 6; i++) { const yy = y + ((t * 60 + i * 30) % h); g.fillStyle = [C.pink, C.honey, C.teal, C.lilac][i % 4]; g.fillRect(x + 8 + (i * 13) % (w - 24), yy, 14, 10); } }
  else if (k === 1) { g.fillStyle = C.tealL; g.fillRect(x + 6, y + h - 14, w - 12, 4); const bx = x + w / 2 + Math.sin(t * 4) * (w / 2 - 14); const by = y + h - 24 - Math.abs(Math.sin(t * 6)) * (h - 40); g.fillStyle = C.honey; g.beginPath(); g.arc(bx, by, 6, 0, 7); g.fill(); }
  else { g.drawImage(IMG.logo, x + 4, y + h / 2 - 16 + Math.sin(t * 3) * 6, w - 8, (w - 8) * IMG.logo.height / IMG.logo.width); }
  g.fillStyle = 'rgba(255,255,255,.08)'; for (let yy = y; yy < y + h; yy += 3) g.fillRect(x, yy, w, 1); g.restore();
}
function carArcade(c, t) {
  const holes = [[440, -276, 110, 110]]; const dop = doorHole(t); if (dop > 0) holes.push([330, -250, 90 * dop, 240]);
  backWall(c, holes); windowFrames(holes.slice(0, 1));
  // neon grid floor/wall
  g.save(); g.strokeStyle = 'rgba(180,155,255,.18)'; g.lineWidth = 2; for (let x = 0; x < CW; x += 40) { g.beginPath(); g.moveTo(x, -330); g.lineTo(x, -110); g.stroke(); } for (let y = -330; y < -110; y += 40) { g.beginPath(); g.moveTo(0, y); g.lineTo(CW, y); g.stroke(); } g.restore();
  g.fillStyle = c.wain; g.fillRect(0, -110, CW, 100);
  g.save(); g.shadowColor = C.pink; g.shadowBlur = 20; txt('ARCADE', 160, -282, { font: font(800, 36), align: 'center', color: '#ffc0dc' }); g.restore();
  ceilingLights(t, 'rgba(200,170,255,');
  [40, 160, 280].forEach((x, k) => {
    const col = [C.pink, C.teal, C.honey][k]; g.save(); g.fillStyle = '#1d1630'; g.beginPath(); g.moveTo(x, -10); g.lineTo(x, -190); g.lineTo(x + 14, -230); g.lineTo(x + 96, -230); g.lineTo(x + 104, -190); g.lineTo(x + 104, -10); g.closePath(); g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
    g.shadowColor = col; g.shadowBlur = 18; g.fillStyle = col; g.fillRect(x + 14, -226, 82, 18); g.shadowBlur = 0; arcadeScreen(x + 14, -196, 76, 70, t + k, k);
    g.fillStyle = '#2a2244'; g.fillRect(x + 6, -120, 92, 26); g.fillStyle = C.red; g.beginPath(); g.arc(x + 30, -108, 6, 0, 7); g.fill(); g.fillStyle = C.honey; g.beginPath(); g.arc(x + 70, -108, 6, 0, 7); g.fill(); g.restore();
  });
  // wolf at the end cabinet, ticket strip spilling
  sprite(IMG.wolf, 470, -10, 180, { rot: Math.sin(t * 7) * .03, sy: 1 + .02 * Math.abs(Math.sin(t * 7)) });
  g.save(); g.fillStyle = C.cream; g.strokeStyle = C.ink; g.lineWidth = 2; for (let k = 0; k < 6; k++) { g.beginPath(); g.roundRect(372 + k * 8, -90 + k * 12, 24, 12, 2); g.fill(); g.stroke(); } g.restore();
  pax(c, t, 60, 330);
}
function carLounge(c, t) {
  const holes = [[30, -276, 110, 110]]; const dop = doorHole(t); if (dop > 0) holes.push([170, -250, 90 * dop, 240]);
  backWall(c, holes); windowFrames(holes.slice(0, 1));
  g.fillStyle = c.wain; g.fillRect(0, -110, CW, 100);
  // framed flower poster
  g.save(); g.fillStyle = C.ink; g.fillRect(318, -296, 136, 136); g.drawImage(IMG['trippi-profile'], 324, -290, 124, 124); g.restore();
  ceilingLights(t);
  // sofa
  g.save(); g.fillStyle = C.pink; g.strokeStyle = C.ink; g.lineWidth = 4; g.beginPath(); g.roundRect(40, -110, 230, 60, 18); g.fill(); g.stroke(); g.beginPath(); g.roundRect(30, -70, 250, 56, 16); g.fill(); g.stroke(); g.fillStyle = '#ff9fc4'; g.beginPath(); g.roundRect(60, -96, 70, 34, 12); g.roundRect(170, -96, 70, 34, 12); g.fill(); g.stroke(); g.restore();
  oddball(110, -64, .78, mkOdd(801), t); oddball(200, -64, .78, mkOdd(802), t, 0, -1);
  // record player + axolotl dancing
  g.save(); g.fillStyle = '#6b4224'; g.fillRect(470, -70, 90, 60); g.strokeStyle = C.ink; g.lineWidth = 4; g.strokeRect(470, -70, 90, 60); g.translate(515, -78); g.scale(1, .3); g.rotate(t * 5); g.fillStyle = '#111'; g.beginPath(); g.arc(0, 0, 34, 0, 7); g.fill(); g.fillStyle = C.honey; g.beginPath(); g.arc(0, 0, 10, 0, 7); g.fill(); g.restore();
  const beat = Math.abs(Math.sin(t * Math.PI * 1.6)); sprite(IMG.axolotl, 390, -12 - beat * 16, 160, { rot: Math.sin(t * Math.PI * 1.6) * .12, sy: 1 - beat * .04 });
  // music notes
  for (let k = 0; k < 3; k++) { const p = (t * .6 + k / 3) % 1; g.save(); g.globalAlpha = 1 - p; txt('♪', 520 + Math.sin(p * 6 + k) * 16, -110 - p * 120, { font: font(800, 30), color: C.honey, stroke: C.ink, sw: 4 }); g.restore(); }
  pax(c, t, 300, 460);
}
function carDaycare(c, t, build) {
  const holes = [[230, -276, 110, 100]]; const dop = doorHole(t); if (dop > 0) holes.push([400, -250, 90 * dop, 240]);
  backWall(c, holes); windowFrames(holes.slice(0, 1));
  g.fillStyle = c.wain; g.fillRect(0, -110, CW, 100);
  // wallpaper dots
  g.save(); g.fillStyle = 'rgba(255,255,255,.35)'; for (let x = 20; x < CW; x += 40) for (let y = -310; y < -120; y += 40) { if (x > 220 && x < 350 && y > -290 && y < -170) continue; g.beginPath(); g.arc(x + ((y / 40) % 2) * 20, y, 4, 0, 7); g.fill(); } g.restore();
  const pop = k => build ? E.back(inv(13.8 + k * .18, 14.15 + k * .18, t)) : 1;
  [['nft-1', 40], ['nft-2', 420]].forEach(([n, x], k) => { const s = pop(k); if (s <= 0) return; g.save(); g.translate(x + 60, -230); g.scale(s, s); g.rotate(k ? .05 : -.05); g.fillStyle = C.ink; g.fillRect(-64, -64, 128, 128); g.drawImage(IMG[n], -60, -60, 120, 120); g.restore(); });
  ceilingLights(t, 'rgba(255,220,235,');
  if (pop(2) > 0) { g.save(); g.translate(290, -14); g.scale(pop(2), pop(2)); g.fillStyle = '#fff'; g.strokeStyle = C.ink; g.lineWidth = 4; g.beginPath(); g.roundRect(-150, -46, 300, 40, 18); g.fill(); g.stroke(); g.fillStyle = C.mint; g.beginPath(); g.roundRect(-140, -40, 120, 26, 12); g.fill(); g.fillStyle = C.sky; g.beginPath(); g.roundRect(20, -40, 120, 26, 12); g.fill(); g.restore(); }
  // mobile
  if (pop(3) > 0) { g.save(); g.translate(290, -320); g.rotate(Math.sin(t * 1.5) * .1); g.strokeStyle = C.ink; g.lineWidth = 3; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, 20); g.moveTo(-60, 20); g.lineTo(60, 20); g.stroke(); [-60, 0, 60].forEach((x, k) => { g.beginPath(); g.moveTo(x, 20); g.lineTo(x, 44); g.stroke(); star(x, 54, 11, [C.honey, C.pink, C.tealL][k], t + k); }); g.restore(); }
  // babies
  BABIES.forEach((o, k) => { const s = pop(4 + k); if (s <= 0) return; const hop = Math.abs(Math.sin(t * 5 + k * 1.3)) * 22; g.save(); g.translate(150 + k * 95, -52 - hop); g.scale(s, s); oddball(0, 0, .5, o, t + k); g.restore(); });
  if (!build || t > 15) pax(c, t, 60, 520);
  g.save(); g.shadowColor = C.pink; g.shadowBlur = 16; txt('PET DAYCARE', 290, -296, { font: font(800, 26), align: 'center', color: '#fff', stroke: '#b4567d', sw: 6 }); g.restore();
}
function carEngine(c, t) {
  // cab with sloped nose
  g.save(); g.beginPath(); g.moveTo(0, -330); g.lineTo(CW - 120, -330); g.quadraticCurveTo(CW - 40, -320, CW, -230); g.lineTo(CW, 0); g.lineTo(0, 0); g.closePath(); g.clip();
  g.fillStyle = c.wall; g.fillRect(0, -340, CW, 340);
  // windshield
  g.fillStyle = 'rgba(140,220,255,.12)'; g.beginPath(); g.moveTo(CW - 150, -320); g.quadraticCurveTo(CW - 60, -310, CW - 20, -230); g.lineTo(CW - 20, -150); g.lineTo(CW - 150, -150); g.closePath(); g.fill(); g.strokeStyle = '#0d1416'; g.lineWidth = 8; g.stroke();
  g.fillStyle = c.wain; g.fillRect(0, -110, CW, 110);
  // console
  g.fillStyle = '#2a3a3d'; g.beginPath(); g.moveTo(250, -10); g.lineTo(250, -120); g.lineTo(540, -150); g.lineTo(560, -10); g.closePath(); g.fill(); g.strokeStyle = C.ink; g.lineWidth = 4; g.stroke();
  for (let k = 0; k < 4; k++) { const x = 290 + k * 60, y = -112; g.fillStyle = '#0c1416'; g.beginPath(); g.arc(x, y, 18, 0, 7); g.fill(); g.strokeStyle = C.tealL; g.lineWidth = 3; g.stroke(); const a = -2.4 + (Math.sin(t * (1 + k * .3)) * .5 + .5) * 1.8; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * 14, y + Math.sin(a) * 14); g.strokeStyle = [C.honey, C.pink, C.tealL, C.honey][k]; g.stroke(); }
  for (let k = 0; k < 8; k++) { g.fillStyle = Math.sin(t * 6 + k) > 0 ? [C.red, C.honey, C.tealL][k % 3] : '#333'; g.fillRect(290 + k * 26, -70, 14, 8); }
  // LINE 01 plate + posters
  g.fillStyle = '#0a3d31'; g.beginPath(); g.roundRect(40, -290, 170, 60, 10); g.fill(); g.strokeStyle = '#e8fff7'; g.lineWidth = 3; g.stroke(); txt('LINE 01', 125, -250, { font: font(800, 30), align: 'center', color: '#fff' });
  const im = IMG['postmark-traffic']; g.save(); g.translate(120, -170); g.rotate(-.06); g.drawImage(im, -44, -48, 88, 88 * im.height / im.width); g.restore();
  ceilingLights(t);
  g.restore();
  // driver: Cone
  sprite(IMG.cone, 330, -118, 160, { rot: Math.sin(t * 1.4) * .03 });
  // outer nose
  g.save(); g.strokeStyle = C.ink; g.lineWidth = 6; g.beginPath(); g.moveTo(CW - 120, -330); g.quadraticCurveTo(CW - 40, -320, CW, -230); g.lineTo(CW, 24); g.stroke();
  g.fillStyle = '#ffe9a8'; g.shadowColor = '#fff2b0'; g.shadowBlur = 30; g.beginPath(); g.arc(CW - 6, -60, 12, 0, 7); g.fill(); g.restore();
}
function headlight(t) { const p = ws(slotX(5) + CW, -60); const z = CAM.z; const gr = g.createLinearGradient(p.x, 0, p.x + 900 * z, 0); gr.addColorStop(0, 'rgba(255,240,190,.45)'); gr.addColorStop(1, 'rgba(255,240,190,0)'); g.save(); g.fillStyle = gr; g.beginPath(); g.moveTo(p.x, p.y - 10 * z); g.lineTo(p.x + 900 * z, p.y - 200 * z); g.lineTo(p.x + 900 * z, p.y + 120 * z); g.closePath(); g.fill(); g.restore(); }
function drawCar(c, t) {
  const x = slotX(c.i); g.save(); g.translate(x, 0);
  const isEngine = c.id === 'engine';
  if (c.id === 'daycare') {
    if (t < 12.5) { // empty slot ghost
      const a = inv(9.8, 10.6, t); g.save(); g.globalAlpha = .35 + .35 * a * (.6 + .4 * Math.sin(t * 6)); g.setLineDash([18, 14]); g.strokeStyle = C.honey; g.lineWidth = 6; g.beginPath(); g.roundRect(0, -362, CW, 386, 22); g.stroke(); g.setLineDash([]);
      txt('+', CW / 2, -130, { font: font(800, 140), align: 'center', color: C.honey }); txt('EMPTY SLOT', CW / 2, -60, { font: font(800, 26), align: 'center', color: C.honey, ls: 2 }); g.restore();
      g.restore(); return;
    }
    if (t < 15.0) { buildSite(c, t); g.restore(); return; }
  }
  if (c.id === 'graffiti') carGraffiti(c, t); else if (c.id === 'honey') carHoney(c, t); else if (c.id === 'arcade') carArcade(c, t); else if (c.id === 'lounge') carLounge(c, t); else if (c.id === 'daycare') carDaycare(c, t, false); else carEngine(c, t);
  shell(c, t, isEngine);
  // coupler
  if (c.i < 5) { g.fillStyle = '#151d1f'; g.fillRect(CW, -4, GAP, 14); }
  const tagA = (t > 3.6 && t < 23.0 && CAM.z > .7) ? 1 : 0; nameTag(c, t, tagA * (c.id === 'daycare' ? inv(15.2, 15.6, t) : 1));
  readyBubble(c, t);
  g.restore();
}
function buildSite(c, t) {
  const k = inv(12.5, 14.9, t);
  // scaffold
  g.save(); g.strokeStyle = C.honey; g.lineWidth = 6; g.lineCap = 'round'; const sk = E.out3(inv(12.5, 13.1, t));
  for (let i = 0; i <= 4; i++) { const x = i * CW / 4; g.beginPath(); g.moveTo(x, 24); g.lineTo(x, 24 - 400 * sk); g.stroke(); }
  for (let j = 1; j <= 3; j++) { const y = 24 - j * 120; g.beginPath(); g.moveTo(0, y); g.lineTo(CW * sk, y); g.stroke(); }
  g.restore();
  // car rising from the floor up (clip)
  const rk = E.io2(inv(12.9, 14.6, t)); g.save(); g.beginPath(); g.rect(-20, 30 - 420 * rk, CW + 40, 420 * rk); g.clip(); carDaycare(c, t, true); shell(c, t, false); g.restore();
  // sparks
  g.save(); const r = mulberry(Math.floor(t * 30)); for (let i = 0; i < 18; i++) { const px = r() * CW, py = 30 - 420 * rk + (r() - .5) * 20; const a = -r() * Math.PI, sp = 20 + r() * 50; g.fillStyle = r() < .5 ? '#fff6b0' : C.honey; g.fillRect(px + Math.cos(a) * sp, py + Math.sin(a) * sp, 4, 4); } g.restore();
  // foreman cone with hard hat
  const cx = CW / 2 + Math.sin(t * 2) * 140; sprite(IMG.cone, cx, 24, 130, { rot: Math.sin(t * 8) * .06 });
  g.save(); g.fillStyle = C.honey; g.strokeStyle = C.ink; g.lineWidth = 4; g.beginPath(); g.arc(cx, -98, 34, Math.PI, 0); g.closePath(); g.fill(); g.stroke(); g.beginPath(); g.roundRect(cx - 44, -102, 88, 10, 5); g.fill(); g.stroke(); g.restore();
  // progress bar
  sticker(CW / 2 - 170, -480, 340, 56, 28, C.cream, { dx: 4, dy: 5 }); txt('BUILDING...', CW / 2 - 150, -444, { font: font(800, 22), color: C.ink });
  g.fillStyle = '#e4d6bb'; g.beginPath(); g.roundRect(CW / 2 - 10, -464, 160, 24, 12); g.fill(); g.fillStyle = C.teal; g.beginPath(); g.roundRect(CW / 2 - 10, -464, 160 * k, 24, 12); g.fill(); g.strokeStyle = C.ink; g.lineWidth = 3; g.beginPath(); g.roundRect(CW / 2 - 10, -464, 160, 24, 12); g.stroke();
  txt(Math.round(k * 100) + '%', CW / 2 + 70, -446, { font: font(800, 17), color: '#fff', align: 'center', stroke: C.ink, sw: 4 });
}

/* =====================================================================
   RAID: bots, drone, crew powers
   ===================================================================== */
const BOTS = Array.from({ length: 8 }, (_, i) => ({ x0: -260 + i * 85 + hash(i) * 30, td: 24.4 + i * .17, ph: hash(i * 3) * 7 }));
const WALLX = 930, TRAP = [26.8, 27.45], BOUNCE = 28.85;
function botPos(b, i, t) {
  const fall = E.bounce(inv(b.td, b.td + .55, t)); let x = b.x0 + Math.max(0, t - b.td - .55) * 120; const wallUp = t > 26.05;
  const lim = wallUp ? WALLX - 70 - i * 46 : 1e9; if (x > lim) x = lim - Math.abs(Math.sin((t - 26.05) * 6)) * 14 * inv(26.05, 26.4, t);
  if (t > 27.45) x = Math.min(x, botPos.cache?.[i] ?? x);
  let y = lerp(-900, roofY, fall);
  if (t > BOUNCE) { const k = t - BOUNCE - i * .05; if (k > 0) { x += k * (180 + i * 30); y = roofY - (900 * k - 900 * k * k * .5 * 1.2); } }
  return { x, y, stuck: t > 27.45 && t < BOUNCE + i * .05, rot: t > BOUNCE + i * .05 ? (t - BOUNCE) * (6 + i) : 0 };
}
// freeze positions when the honey lands
botPos.cache = BOTS.map((b, i) => { const t = 27.45; const fall = 1; let x = b.x0 + Math.max(0, t - b.td - .55) * 120; const lim = WALLX - 70 - i * 46; return Math.min(x, lim); });
function bot(x, y, s, t, o = {}) {
  g.save(); g.translate(x, y); g.rotate(o.rot || 0); g.scale(s, s);
  const walk = o.stuck ? 0 : Math.sin(t * 12 + (o.ph || 0)); g.fillStyle = C.ink; g.fillRect(-14 + walk * 4, -14, 10, 14); g.fillRect(4 - walk * 4, -14, 10, 14);
  g.fillStyle = '#b8c4c8'; g.strokeStyle = C.ink; g.lineWidth = 4.5; g.beginPath(); g.roundRect(-30, -74, 60, 62, 14); g.fill(); g.stroke();
  g.fillStyle = '#1b2428'; g.beginPath(); g.roundRect(-22, -64, 44, 22, 10); g.fill(); g.fillStyle = C.red; g.shadowColor = C.red; g.shadowBlur = 12; g.beginPath(); g.arc(-8 + Math.sin(t * 5) * 4, -53, 5, 0, 7); g.arc(8 + Math.sin(t * 5) * 4, -53, 5, 0, 7); g.fill(); g.shadowBlur = 0;
  heart(0, -26, 16, C.pink); g.strokeStyle = C.ink; g.lineWidth = 3; g.beginPath(); g.moveTo(0, -74); g.lineTo(0, -92); g.stroke(); g.fillStyle = Math.sin(t * 8) > 0 ? C.red : '#ff9a9a'; g.beginPath(); g.arc(0, -96, 6, 0, 7); g.fill(); g.stroke();
  if (o.stuck) { g.fillStyle = C.honey; g.globalAlpha = .9; g.beginPath(); g.ellipse(0, -2, 40, 10, 0, 0, 7); g.fill(); for (let k = 0; k < 3; k++) { g.beginPath(); g.roundRect(-24 + k * 20, -34, 9, 28 + 6 * Math.sin(t * 3 + k), 5); g.fill(); } }
  g.restore();
}
function drone(t) {
  if (t < 23.7 || t > 30.4) return; const inA = E.out3(inv(23.7, 24.4, t)), out = E.in3(inv(29.2, 30.2, t));
  const x = lerp(-900, 100, inA) + Math.sin(t * 1.3) * 120 + out * 1400, y = -760 + Math.sin(t * 2.2) * 20 - out * 600;
  g.save(); g.translate(x, y); g.rotate(Math.sin(t * 1.3) * .06);
  g.strokeStyle = C.ink; g.lineWidth = 6; g.beginPath(); g.moveTo(-150, -20); g.lineTo(150, -20); g.stroke();
  for (const dx of [-150, 150]) { g.save(); g.translate(dx, -36); g.scale(1, .22); g.rotate(t * 40); g.fillStyle = 'rgba(200,220,220,.5)'; g.beginPath(); g.ellipse(0, 0, 80, 14, 0, 0, 7); g.ellipse(0, 0, 14, 80, 0, 0, 7); g.fill(); g.restore(); g.fillStyle = '#333'; g.fillRect(dx - 6, -40, 12, 20); }
  g.fillStyle = '#4a5458'; g.beginPath(); g.roundRect(-110, -40, 220, 80, 30); g.fill(); g.lineWidth = 5; g.stroke();
  g.fillStyle = '#121a1c'; g.beginPath(); g.roundRect(-60, -18, 120, 36, 18); g.fill(); g.fillStyle = C.red; g.shadowColor = C.red; g.shadowBlur = 20; g.beginPath(); g.arc(Math.sin(t * 3) * 30, 0, 10, 0, 7); g.fill(); g.shadowBlur = 0;
  heart(-80, 6, 26, C.pink); heart(80, 6, 26, C.pink);
  g.fillStyle = 'rgba(255,72,72,.15)'; g.beginPath(); g.moveTo(-40, 40); g.lineTo(40, 40); g.lineTo(140, 380); g.lineTo(-140, 380); g.closePath(); g.fill();
  g.restore();
}
function raidWorld(t) {
  if (t < 24.2 || t > 31.2) return;
  // cone wall
  if (t > 26.0) { const k = E.bounce(inv(26.0, 26.4, t)); const y = lerp(-1100, roofY + 6, k); sprite(IMG.cone, WALLX, y, 190); if (t < 26.9) { const p = inv(26.05, 26.8, t); txt('BLOCKED!', WALLX, roofY - 230 - p * 40, { font: font(800, 46), align: 'center', color: C.orange, stroke: C.ink, sw: 9, alpha: 1 - E.in3(p) }); } }
  // honey trap puddle
  if (t > TRAP[0]) { const k = E.out3(inv(TRAP[0], TRAP[1], t)) * (1 - E.in3(inv(30.4, 31.0, t))); g.save(); g.fillStyle = C.honey; g.strokeStyle = C.ink; g.lineWidth = 4; g.beginPath(); g.ellipse(560, roofY + 2, 360 * k, 22 * k, 0, 0, 7); g.fill(); g.stroke(); for (let i = 0; i < 9; i++) { const dx = 230 + i * 80; const dl = (20 + hash(i) * 70) * k * (1 + .3 * Math.sin(t * 2 + i)); g.beginPath(); g.roundRect(dx, roofY + 8, 12, dl, 6); g.fill(); g.stroke(); } g.restore();
    if (t < TRAP[0] + 1.0) { const p = inv(TRAP[0], TRAP[0] + 1.0, t); txt('STUCK!', 560, roofY - 210 - p * 40, { font: font(800, 46), align: 'center', color: C.honey, stroke: C.ink, sw: 9, alpha: 1 - E.in3(p) }); }
    // flying honey blob before landing
    if (t < TRAP[1]) { const p = inv(TRAP[0] - .4, TRAP[1], t); g.fillStyle = C.honey; g.beginPath(); g.arc(lerp(560, 560, p), lerp(-900, roofY, E.in3(p)), 40, 0, 7); g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke(); } }
  // spore bounce: mushroom springs from a roof hatch
  if (t > BOUNCE - .25 && t < 30.4) { const k = Math.sin(Math.PI * inv(BOUNCE - .25, 30.2, t)); const up = E.back(inv(BOUNCE - .25, BOUNCE + .1, t)) * (1 - E.in3(inv(29.9, 30.3, t)));
    g.save(); g.beginPath(); g.rect(300, -1400, 600, 1400 + roofY + 4); g.clip(); sprite(IMG.mushroom, 600, roofY + 170 - 260 * up, 230, { rot: Math.sin(t * 14) * .08 * k }); g.restore();
    g.fillStyle = '#2a3537'; g.strokeStyle = C.ink; g.lineWidth = 4; g.beginPath(); g.roundRect(480, roofY - 8, 240, 14, 6); g.fill(); g.stroke();
    const r = mulberry(7); for (let i = 0; i < 40; i++) { const a = -Math.PI * (r()), sp = 80 + r() * 400; const p = inv(BOUNCE, BOUNCE + 1.1, t); if (p <= 0 || p >= 1) continue; g.save(); g.globalAlpha = 1 - p; g.fillStyle = ['#fff3d0', C.orange, '#ffd6a0'][i % 3]; g.beginPath(); g.arc(600 + Math.cos(a) * sp * E.out3(p), roofY - 120 + Math.sin(a) * sp * E.out3(p), 7 + r() * 9, 0, 7); g.fill(); g.restore(); } }
  BOTS.forEach((b, i) => { if (t < b.td) return; const p = botPos(b, i, t); if (p.y < -2200) return; bot(p.x, p.y, 1.0, t, { stuck: p.stuck, rot: p.rot, ph: b.ph }); if (t > BOUNCE + i * .05 && t < BOUNCE + i * .05 + .8) { const k = inv(BOUNCE + i * .05, BOUNCE + i * .05 + .8, t); star(p.x + 40, p.y - 80, 14 * (1 - k), C.honey, t * 5); } });
}

/* =====================================================================
   HUD (sticker style)
   ===================================================================== */
const PILLS = [{ k: 'paint', x: 18 }, { k: 'honey', x: 222 }, { k: 'ticket', x: 426 }, { k: 'crew', x: 630 }];
const pillPos = k => k === 'stamp' ? { x: 880, y: 50 } : { x: PILLS.find(p => p.k === k).x + 38, y: 50 };
function hudTop(t, a) {
  if (a <= 0) return; g.save(); g.translate(0, -120 * (1 - a));
  PILLS.forEach(p => { const pu = pulseOf(p.k, t); g.save(); g.translate(p.x + 96, 50); g.scale(1 + pu * .08, 1 + pu * .08); g.translate(-(p.x + 96), -50);
    sticker(p.x, 20, 192, 60, 30, C.cream, { dx: 4, dy: 5 }); g.fillStyle = '#fff'; g.beginPath(); g.arc(p.x + 32, 50, 24, 0, 7); g.fill(); g.lineWidth = 3.5; g.strokeStyle = C.ink; g.stroke(); icon(p.k, p.x + 32, 51, 36);
    txt(fmtN(res(p.k, t)), p.x + 66, 61, { font: font(800, 30), color: pu > .1 ? C.tealD : C.ink }); g.restore(); });
  // stamps + clock
  sticker(834, 20, 228, 60, 30, C.ink, { dx: 4, dy: 5, shadowCol: 'rgba(0,0,0,.6)' }); icon('stamp', 868, 51, 40); txt(fmtN(res('stamp', t)), 896, 61, { font: font(800, 30), color: C.honey });
  g.fillStyle = C.teal; g.beginPath(); g.roundRect(950, 30, 102, 40, 20); g.fill(); txt(clockAt(t).slice(0, 5), 1001, 58, { font: font(800, 22), align: 'center', color: '#fff' });
  // route bar
  const rx = 18, rw = 1044, ry = 102; sticker(rx, ry, rw, 40, 20, 'rgba(255,243,220,.95)', { dx: 3, dy: 4, lw: 3 });
  const stops = ['RUSH HOUR', 'NIGHT TRAIN', 'LAST STOP', 'PLATFORM 09']; const prog = clamp((t - 3.2) / (33 - 3.2));
  const lx0 = rx + 150, lx1 = rx + rw - 150; g.strokeStyle = '#d9c9a8'; g.lineWidth = 6; g.lineCap = 'round'; g.beginPath(); g.moveTo(lx0, ry + 20); g.lineTo(lx1, ry + 20); g.stroke(); g.strokeStyle = C.teal; g.beginPath(); g.moveTo(lx0, ry + 20); g.lineTo(lerp(lx0, lx1, prog), ry + 20); g.stroke();
  txt('LAST TRAIN', rx + 18, ry + 27, { font: font(700, 14, 'GeistMono'), color: C.ink, ls: 1 }); txt('23:09', rx + rw - 18, ry + 28, { font: font(800, 18), color: C.pink, align: 'right' });
  stops.forEach((s, i) => { const x = lerp(lx0, lx1, [.18, .45, .72, 1][i]); const done = prog >= [.18, .45, .72, 1][i] - .001; g.fillStyle = done ? C.teal : '#fff'; g.beginPath(); g.arc(x, ry + 20, 8, 0, 7); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); txt(s, x, ry + 37, { font: font(700, 9, 'GeistMono'), align: 'center', color: '#5c544a' }); });
  const tx = lerp(lx0, lx1, prog); g.save(); g.translate(tx, ry + 20); g.fillStyle = C.pink; g.beginPath(); g.roundRect(-16, -11, 32, 22, 8); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); g.fillStyle = '#fff'; g.fillRect(-9, -6, 7, 6); g.fillRect(2, -6, 7, 6); g.restore();
  g.restore();
}
const QUESTS = [
  { s: 'Collect 300 paint', p: t => res('paint', t) / 300, done: 9.2, show: [0, 23.6] },
  { s: 'Build the Pet Daycare', p: t => inv(12.5, 15, t), done: 15.0, show: [0, 99] },
  { s: 'Board 100 oddballs', p: t => (res('crew', t) - 64) / 100, done: 21.0, show: [0, 99] },
  { s: 'Stop the bot raid', p: t => inv(26, 30.2, t), done: 30.2, show: [23.6, 99] },
];
function questPanel(t, a) {
  if (a <= 0) return; g.save(); g.translate(-360 * (1 - a), 0);
  const list = QUESTS.filter(q => t >= q.show[0] - .01 && t < q.show[1] + .5);
  const h = 54 + list.length * 46; sticker(18, 158, 300, h, 18, C.cream, { dx: 4, dy: 5 });
  txt('QUESTS', 36, 190, { font: font(800, 20), color: C.ink, ls: 1 }); txt(clockAt(t).slice(0, 5), 300, 190, { font: font(700, 14, 'GeistMono'), color: '#8a7b63', align: 'right' });
  list.forEach((q, i) => {
    const y = 214 + i * 46; const out = q.show[1] < 99 ? inv(q.show[1], q.show[1] + .4, t) : 0; const inn = q.show[0] > 0 ? E.back(inv(q.show[0], q.show[0] + .4, t)) : 1;
    g.save(); g.globalAlpha = (1 - out) * inn; g.translate(-out * 40, 0);
    const done = t >= q.done; const fl = Math.max(0, 1 - Math.abs(t - q.done - .15) / .35);
    if (fl > 0) { g.fillStyle = `rgba(22,166,135,${fl * .25})`; g.beginPath(); g.roundRect(26, y - 4, 284, 42, 10); g.fill(); }
    g.fillStyle = done ? C.teal : '#fff'; g.beginPath(); g.roundRect(32, y + 4, 24, 24, 6); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); if (done) check(44, y + 16, 15, '#fff', 3.5);
    txt(q.s, 66, y + 19, { font: font(700, 16), color: done ? '#7f8a84' : C.ink });
    g.fillStyle = '#eadcc0'; g.beginPath(); g.roundRect(66, y + 26, 230, 6, 3); g.fill(); g.fillStyle = done ? C.teal : C.pink; g.beginPath(); g.roundRect(66, y + 26, 230 * clamp(q.p(t)), 6, 3); g.fill();
    g.restore();
  });
  g.restore();
}
function minimap(t, a) {
  if (a <= 0) return; g.save(); g.translate(0, 160 * (1 - a)); const x = 842, y = 956, w = 220, h = 96;
  sticker(x, y, w, h, 16, C.cream, { dx: 4, dy: 5 }); txt('TRAIN', x + 14, y + 24, { font: font(800, 14), color: C.ink, ls: 1 });
  const sc = (w - 28) / (6 * P); const cx = x + 14 + (3 * P) * sc;
  CARS.forEach(c => { const built = c.id !== 'daycare' || t > 15; const bx = cx + slotX(c.i) * sc, bw = CW * sc; g.fillStyle = built ? (c.id === 'engine' ? C.pink : C.teal) : 'rgba(0,0,0,0)'; g.beginPath(); g.roundRect(bx, y + 46, bw, 22, 4); g.fill(); g.strokeStyle = C.ink; g.lineWidth = 2.5; if (!built) g.setLineDash([4, 3]); g.stroke(); g.setLineDash([]); });
  const vw = 540 / CAM.z * sc, vx = cx + CAM.x * sc; g.strokeStyle = C.pink; g.lineWidth = 3; g.beginPath(); g.roundRect(clamp(vx - vw, x + 6, x + w - 10), y + 38, Math.min(vw * 2, w - 12), 38, 6); g.stroke();
  g.restore();
}
function buildButton(t, a) {
  if (a <= 0) return; const pulse = t > 9.4 && t < 10.4 ? .06 * Math.sin(t * 14) : 0; g.save(); g.translate(540, 1010 + 160 * (1 - a)); g.scale(1 + pulse, 1 + pulse);
  sticker(-110, -38, 220, 76, 38, C.pink, { dx: 5, dy: 6 }); txt('BUILD', 18, 13, { font: font(800, 34), align: 'center', color: '#fff', stroke: C.ink, sw: 6 });
  g.save(); g.translate(-66, 0); g.rotate(-.6); g.fillStyle = '#8a5a33'; g.fillRect(-4, -6, 8, 34); g.fillStyle = '#ccd'; g.strokeStyle = C.ink; g.lineWidth = 3; g.beginPath(); g.roundRect(-16, -18, 32, 14, 3); g.fill(); g.stroke(); g.restore();
  if (t > 9.4 && t < 10.6) { g.fillStyle = C.red; g.beginPath(); g.arc(96, -32, 14, 0, 7); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); txt('!', 96, -26, { font: font(800, 18), align: 'center', color: '#fff' }); }
  g.restore();
}
const CARDS = [{ n: 'PET DAYCARE', img: 'nft-1', cost: [['paint', 300], ['honey', 200]], ok: 1 }, { n: 'ROOFTOP GARDEN', img: 'trippi-profile', lock: 'Unlocks at 200 crew' }, { n: 'KARAOKE CAR', img: 'postmark-wolf', lock: 'Unlocks at Last Stop' }];
function buildTray(t) {
  const a = E.out5(inv(10.3, 10.75, t)) * (1 - E.in3(inv(12.4, 12.8, t))); if (a <= 0) return;
  g.save(); g.translate(0, 420 * (1 - a));
  g.fillStyle = 'rgba(10,18,24,.55)'; g.fillRect(0, 700, W, 380);
  sticker(30, 716, 1020, 340, 30, C.cream, { dx: 6, dy: 7 }); txt('BUILD A NEW CAR', 64, 760, { font: font(800, 28), color: C.ink, ls: .5 }); txt('SLOT 6 / 6', 1016, 760, { font: font(700, 15, 'GeistMono'), color: '#8a7b63', align: 'right' });
  CARDS.forEach((cd, i) => {
    const x = 60 + i * 330, y = 784; const sel = cd.ok && t > 11.2; const lift = sel ? -14 * E.out3(inv(11.2, 11.4, t)) : 0; if (cd.ok && t > 11.3) { g.save(); g.globalAlpha = .35; }
    g.save(); g.translate(0, lift); sticker(x, y, 300, 246, 20, cd.lock ? '#e9e0cc' : '#fff', { dx: 4, dy: 5 });
    g.save(); g.beginPath(); g.roundRect(x + 14, y + 14, 272, 118, 12); g.clip(); g.fillStyle = cd.lock ? '#cdbfa3' : '#f6c6d6'; g.fillRect(x + 14, y + 14, 272, 118); const im = IMG[cd.img]; const ih = 118, iw = ih * im.width / im.height; g.globalAlpha = cd.lock ? .35 : 1; g.drawImage(im, x + 150 - iw / 2, y + 14, iw, ih); g.restore();
    txt(cd.n, x + 18, y + 162, { font: font(800, 22), color: C.ink });
    if (cd.lock) { txt(cd.lock, x + 18, y + 192, { font: font(600, 16), color: '#7f735f' }); g.save(); g.translate(x + 262, y + 166); g.strokeStyle = C.ink; g.lineWidth = 4; g.beginPath(); g.arc(0, -8, 10, Math.PI, 0); g.stroke(); g.fillStyle = C.ink; g.beginPath(); g.roundRect(-14, -8, 28, 22, 4); g.fill(); g.restore(); }
    else { cd.cost.forEach(([k, v], j) => { const cx = x + 18 + j * 136; g.fillStyle = '#fff3dc'; g.beginPath(); g.roundRect(cx, y + 180, 124, 40, 20); g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke(); icon(k, cx + 22, y + 200, 28); txt(String(v), cx + 44, y + 209, { font: font(800, 22), color: C.ink }); }); if (t < 11.2) { g.strokeStyle = C.pink; g.lineWidth = 5; g.globalAlpha = .5 + .5 * Math.sin(t * 8); g.beginPath(); g.roundRect(x - 6, y - 6, 312, 258, 24); g.stroke(); } }
    g.restore(); if (cd.ok && t > 11.3) g.restore();
  });
  g.restore();
}
// dragged card ghost (screen space)
function dragGhost(t) {
  if (t < 11.3 || t > 12.5) return; const p = cursorPos(t); const k = inv(11.3, 11.5, t);
  g.save(); g.translate(p.x - 40, p.y - 60); g.rotate(-.08); g.globalAlpha = .95; sticker(-110, -70, 220, 120, 16, '#fff', { dx: 5, dy: 7 }); const im = IMG['nft-1']; g.drawImage(im, -40, -64, 80, 80); txt('PET DAYCARE', 0, 38, { font: font(800, 18), align: 'center', color: C.ink }); g.restore();
}
const ABIL = [{ n: 'WALL', img: 'cone', col: C.orange, t: 26.0 }, { n: 'TRAP', img: 'honey', col: C.honey, t: 27.4 }, { n: 'BOUNCE', img: 'mushroom', col: C.pink, t: 28.8 }];
function abilityBar(t) {
  const a = E.out5(inv(23.9, 24.4, t)) * (1 - E.in3(inv(30.9, 31.3, t))); if (a <= 0) return;
  g.save(); g.translate(0, 200 * (1 - a));
  ABIL.forEach((ab, i) => {
    const x = 380 + i * 160, y = 990; const used = t > ab.t; const press = Math.max(0, 1 - Math.abs(t - ab.t) / .12); const cd = used ? clamp(1 - (t - ab.t) / 3.2) : 0; const ready = !used;
    g.save(); g.translate(x, y); g.scale(1 - press * .12, 1 - press * .12);
    g.fillStyle = 'rgba(0,0,0,.85)'; g.beginPath(); g.arc(5, 6, 58, 0, 7); g.fill(); g.fillStyle = ab.col; g.beginPath(); g.arc(0, 0, 58, 0, 7); g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
    g.save(); g.beginPath(); g.arc(0, 0, 50, 0, 7); g.clip(); g.fillStyle = '#fff3dc'; g.fill(); const im = IMG[ab.img]; const ih = ab.img === 'cone' ? 84 : 96; g.drawImage(im, -ih * im.width / im.height / 2, -ih / 2 + 6, ih * im.width / im.height, ih); g.restore();
    if (cd > 0) { g.fillStyle = 'rgba(10,18,24,.55)'; g.beginPath(); g.moveTo(0, 0); g.arc(0, 0, 50, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * cd); g.closePath(); g.fill(); }
    if (ready && t > 25.2) { g.strokeStyle = '#fff'; g.lineWidth = 4; g.globalAlpha = .5 + .5 * Math.sin(t * 9 + i); g.beginPath(); g.arc(0, 0, 64, 0, 7); g.stroke(); g.globalAlpha = 1; }
    g.restore();
    sticker(x - 52, y + 46, 104, 30, 15, C.cream, { dx: 3, dy: 3, lw: 3 }); txt(ab.n, x, y + 68, { font: font(800, 17), align: 'center', color: C.ink, ls: 1 });
  });
  // combo
  const hits = BOTS.filter((b, i) => t > BOUNCE + i * .05).length; if (hits > 0 && t < 31) { const k = E.back(inv(BOUNCE, BOUNCE + .2, t)); g.save(); g.translate(860, 960); g.rotate(.08); g.scale(k, k); txt('COMBO', 0, -34, { font: font(800, 22), align: 'center', color: '#fff', stroke: C.ink, sw: 6 }); txt('x' + hits, 0, 22, { font: font(800, 64), align: 'center', color: C.honey, stroke: C.ink, sw: 10 }); g.restore(); }
  g.restore();
}
function bannerSticker(t, t0, t1, title, sub, col, y = 300, rot = -.04) {
  if (t < t0 || t > t1) return; const a = E.back(inv(t0, t0 + .35, t)), b = E.in3(inv(t1 - .25, t1, t)); const s = a * (1 - b);
  const f = font(800, 64); const w = Math.max(measure(title, f, -1), measure(sub || '', font(700, 24))) + 90;
  g.save(); g.translate(540, y); g.rotate(rot); g.scale(s, s); sticker(-w / 2, -66, w, sub ? 130 : 96, 26, col, { dx: 7, dy: 9, lw: 5 });
  txt(title, 0, sub ? 0 : 6, { font: f, align: 'center', color: '#fff', stroke: C.ink, sw: 10, ls: -1 }); if (sub) txt(sub, 0, 44, { font: font(700, 24), align: 'center', color: C.ink });
  g.restore();
}
/* ---------------- cursor (cartoon glove) ---------------- */
const CUR = [ // {t: arrive time, at: fn(t)->screen pt, tap}
  { t: 2.35, at: () => ({ x: 560, y: 830 }), tap: 1 },
  ...TAPS.map(tp => ({ t: tp.t, at: () => { const c = CAR[tp.car]; const p = ws(slotX(c.i) + CW / 2, -548); return { x: p.x + 16, y: p.y + 20 }; }, tap: 1 })),
  { t: 10.15, at: () => ({ x: 560, y: 1020 }), tap: 1 },
  { t: 11.2, at: () => ({ x: 230, y: 880 }), tap: 1 },
  { t: 12.4, at: () => { const p = ws(slotX(0) + CW / 2, -170); return { x: p.x, y: p.y }; }, tap: 1 },
  ...ABIL.map((ab, i) => ({ t: ab.t - .05, at: () => ({ x: 400 + i * 160, y: 1010 }), tap: 1 })),
  { t: 40.2, at: () => ({ x: 740, y: 828 }), tap: 1 },
];
function cursorPos(t) {
  let i = CUR.findIndex(c => c.t > t); if (i === -1) i = CUR.length; const prev = CUR[i - 1], next = CUR[i];
  if (!prev) return next.at(t); if (!next) return prev.at(t);
  const span = Math.min(.6, next.t - prev.t - .1); const k = E.io3(inv(next.t - span, next.t, t)); const a = prev.at(t), b = next.at(t);
  const arc = Math.sin(Math.PI * k) * -40; return { x: lerp(a.x, b.x, k), y: lerp(a.y, b.y, k) + arc };
}
function cursorVisible(t) { return (t > 1.6 && t < 13.0) || (t > 25.2 && t < 29.3) || (t > 39.4 && t < 40.9); }
function cursor(t) {
  if (!cursorVisible(t)) return; const p = cursorPos(t); let press = 0, ring = -1;
  CUR.forEach(c => { const d = t - c.t; if (d > -.08 && d < .12) press = Math.max(press, 1 - Math.abs(d - .02) / .1); if (d > 0 && d < .45) ring = d / .45; });
  const fade = Math.min(inv(1.6, 1.9, t), 1);
  if (ring >= 0) { g.save(); g.globalAlpha = (1 - ring) * fade; g.strokeStyle = '#fff'; g.lineWidth = 6 * (1 - ring) + 1; g.beginPath(); g.arc(p.x, p.y, 20 + ring * 50, 0, 7); g.stroke(); g.restore(); }
  g.save(); g.globalAlpha = fade; g.translate(p.x, p.y); g.rotate(-.35); g.scale(1 - press * .15, 1 - press * .15);
  g.fillStyle = 'rgba(0,0,0,.5)'; g.save(); g.translate(5, 7); gloveP(); g.fill(); g.restore(); gloveP(); g.fillStyle = '#fff'; g.fill(); g.lineWidth = 4.5; g.strokeStyle = C.ink; g.lineJoin = 'round'; g.stroke();
  g.strokeStyle = C.ink; g.lineWidth = 3; g.beginPath(); g.moveTo(-6, 34); g.lineTo(-6, 46); g.moveTo(6, 34); g.lineTo(6, 46); g.stroke();
  g.restore();
}
function gloveP() { g.beginPath(); g.moveTo(-6, 0); g.quadraticCurveTo(-6, -8, 0, -8); g.quadraticCurveTo(7, -8, 7, 0); g.lineTo(7, 22); g.quadraticCurveTo(22, 16, 24, 30); g.quadraticCurveTo(26, 56, 6, 62); g.lineTo(-10, 62); g.quadraticCurveTo(-26, 56, -24, 36); g.lineTo(-22, 26); g.quadraticCurveTo(-16, 20, -6, 26); g.closePath(); }
/* flying resource icons (screen space) */
function flyers(t) {
  TAPS.forEach(tp => {
    const c = CAR[tp.car]; for (let j = 0; j < 9; j++) {
      const t0 = tp.t + .05 + j * .045, k = inv(t0, t0 + .62, t); if (k <= 0 || k >= 1) continue;
      const a = ws(slotX(c.i) + CW / 2, -548); const b = pillPos(tp.res); const r = mulberry(j * 9 + tp.t * 10);
      const mx = lerp(a.x, b.x, .3) + (r() - .5) * 360, my = Math.min(a.y, b.y) - 120 - r() * 120; const e = E.io2(k);
      const x = (1 - e) * (1 - e) * a.x + 2 * (1 - e) * e * mx + e * e * b.x, y = (1 - e) * (1 - e) * a.y + 2 * (1 - e) * e * my + e * e * b.y;
      g.save(); g.globalAlpha = k < .1 ? k / .1 : 1; icon(tp.res, x, y, 40 - 12 * e); g.restore();
    }
    const k2 = inv(tp.t, tp.t + .9, t); if (k2 > 0 && k2 < 1) { const p = ws(slotX(c.i) + CW / 2, -560); txt('+' + tp.amt, p.x, p.y - 70 - 50 * E.out3(k2), { font: font(800, 46), align: 'center', color: '#fff', stroke: C.ink, sw: 9, alpha: 1 - E.in3(k2) }); }
  });
  // raid rewards
  for (let j = 0; j < 10; j++) { const kind = j % 2 ? 'stamp' : 'ticket'; const t0 = 30.2 + j * .05, k = inv(t0, t0 + .7, t); if (k <= 0 || k >= 1) continue; const a = { x: 540, y: 400 }, b = pillPos(kind); const e = E.io2(k); g.save(); icon(kind, lerp(a.x, b.x, e), lerp(a.y, b.y, e) - Math.sin(Math.PI * e) * 120, 44 - 14 * e); g.restore(); }
}
function confetti(t, t0, cx, cy, n = 60) {
  const k = inv(t0, t0 + 1.8, t); if (k <= 0 || k >= 1) return; const r = mulberry(Math.floor(t0 * 100));
  for (let i = 0; i < n; i++) { const a = -Math.PI * r(), sp = 300 + r() * 600; const x = cx + Math.cos(a) * sp * k, y = cy + Math.sin(a) * sp * k + 900 * k * k; g.save(); g.globalAlpha = 1 - k * k; g.translate(x, y); g.rotate(k * 12 * r()); g.fillStyle = [C.pink, C.honey, C.teal, C.lilac, '#fff'][i % 5]; g.fillRect(-7, -4, 14, 8); g.restore(); }
}
function fireworks(t) {
  [32.3, 32.9, 33.5, 34.2, 34.8, 35.5].forEach((t0, i) => { const k = inv(t0, t0 + 1.3, t); if (k <= 0 || k >= 1) return; const cx = 160 + hash(i * 3) * 760, cy = 160 + hash(i * 5) * 260; const col = [C.pink, C.honey, C.tealL, C.lilac][i % 4];
    for (let j = 0; j < 36; j++) { const a = j / 36 * Math.PI * 2; const r = 160 * E.out3(k); g.save(); g.globalAlpha = 1 - k; g.fillStyle = col; g.shadowColor = col; g.shadowBlur = 12; g.beginPath(); g.arc(cx + Math.cos(a) * r, cy + Math.sin(a) * r + 60 * k * k, 4, 0, 7); g.fill(); g.restore(); } });
}
function rain(t, a) { if (a <= 0) return; g.save(); g.strokeStyle = `rgba(200,225,245,${.28 * a})`; g.lineCap = 'round'; for (let i = 0; i < 150; i++) { const sp = 1000 + hash(i * 3) * 600; const L = 16 + hash(i * 5) * 30; const x = (hash(i) * 1300 - t * 260) % 1300; const xx = x < -110 ? x + 1300 : x; const y = (hash(i * 7) * 1300 + t * sp) % 1300 - 110; g.lineWidth = 1 + hash(i * 9) * 1.5; g.beginPath(); g.moveTo(xx, y); g.lineTo(xx - L * .3, y + L); g.stroke(); } g.restore(); }

/* =====================================================================
   SCREENS
   ===================================================================== */
function world(t) {
  CAM = camAt(t);
  sky(t);
  const bridge = inv(31.6, 32.4, t);
  buildingRow(t, .12, 2200, 280, '#0f2436', 260, 620, 11, true, { tank: 1 });
  buildingRow(t, .32, 2600, 330, '#14303f', 180, 480, 23, true, { signs: 1, logo: 1, tank: 1 });
  { const hy = ws(0, -200).y; const hz = g.createLinearGradient(0, hy - 500 * CAM.z, 0, hy + 300 * CAM.z); hz.addColorStop(0, 'rgba(40,80,95,0)'); hz.addColorStop(1, 'rgba(40,80,95,.45)'); g.fillStyle = hz; g.fillRect(0, 0, W, H); }
  if (bridge > 0) { g.save(); g.globalAlpha = bridge; river(t); g.restore(); }
  platformBG(t);
  catenary(t);
  g.save(); g.translate(540, 560); g.scale(CAM.z, CAM.z); g.translate(-CAM.x, -CAM.y); CARS.forEach(c => drawCar(c, t)); g.restore();
  headlight(t);
  if (bridge < 1) { g.save(); g.globalAlpha = 1 - bridge; viaduct(t, false); g.restore(); }
  if (bridge > 0) { g.save(); g.globalAlpha = bridge; viaduct(t, true); g.restore(); }
  // world-space raid
  g.save(); g.translate(540, 560); g.scale(CAM.z, CAM.z); g.translate(-CAM.x, -CAM.y); drone(t); raidWorld(t); g.restore();
  // foreground speed poles
  if (0) { const per = 3400; const off = Dist(t) * 1.7; const k0 = Math.floor((off - 1200) / per), k1 = Math.floor((off + 1200) / per); for (let k = k0; k <= k1; k++) { const x = (k * per - off) * CAM.z + 540; if (x < -200 || x > W + 200) continue; g.save(); g.fillStyle = 'rgba(4,8,10,.9)'; g.fillRect(x - 24 * CAM.z, 0, 48 * CAM.z, H); g.fillStyle = 'rgba(255,72,72,.8)'; g.beginPath(); g.arc(x, 300, 10 * CAM.z, 0, 7); g.fill(); g.restore(); } }
}
function sTitle(t) {
  const a = 1 - E.in3(inv(2.45, 2.9, t)); if (a <= 0) return;
  g.save(); g.globalAlpha = a; g.fillStyle = 'rgba(6,12,20,.35)'; g.fillRect(0, 0, W, H);
  const k = E.back(inv(.2, .75, t)); const lw = 560, lh = lw * IMG.logo.height / IMG.logo.width;
  g.save(); g.translate(540, 300); g.scale(k, k); g.rotate(-.03 + Math.sin(t * 2) * .01); g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowBlur = 0; g.shadowOffsetY = 12; g.drawImage(IMG.logo, -lw / 2, -lh / 2, lw, lh); g.restore();
  const k2 = E.back(inv(.55, 1.0, t)); g.save(); g.translate(540, 470); g.scale(k2, k2); g.rotate(-.03);
  sticker(-300, -58, 600, 100, 50, C.pink, { dx: 7, dy: 9, lw: 5 }); txt('LAST TRAIN TOWN', 0, 12, { font: font(800, 54), align: 'center', color: '#fff', stroke: C.ink, sw: 10, ls: -1 }); g.restore();
  txt('Build your crew. Make the 23:09.', 540, 560, { font: font(700, 28), align: 'center', color: '#fff', alpha: inv(.9, 1.2, t), stroke: C.ink, sw: 6 });
  if (t > 1.2) { const bl = .55 + .45 * Math.sin(t * 7); sticker(390, 790, 300, 74, 37, C.cream, { dx: 5, dy: 6 }); txt('TAP TO START', 540, 838, { font: font(800, 30), align: 'center', color: C.ink, alpha: bl }); }
  g.restore();
  if (t > 2.35 && t < 2.6) { g.fillStyle = `rgba(255,255,255,${(1 - inv(2.35, 2.6, t)) * .6})`; g.fillRect(0, 0, W, H); }
}
function hud(t) {
  const top = E.out3(inv(2.8, 3.4, t)) * (1 - E.in3(inv(36.2, 36.6, t)));
  const side = E.out3(inv(3.0, 3.6, t)) * (1 - E.in3(inv(31.4, 31.9, t)));
  hudTop(t, top); questPanel(t, side); minimap(t, side);
  buildButton(t, E.out3(inv(3.2, 3.7, t)) * (1 - E.in3(inv(10.25, 10.5, t))) + E.out3(inv(15.6, 16.0, t)) * (1 - E.in3(inv(23.7, 24.0, t))) * (t > 15 ? 1 : 0));
  buildTray(t); abilityBar(t);
}
function sBoard(t) {
  const a = E.out3(inv(36.4, 36.9, t)); if (a <= 0) return;
  g.fillStyle = `rgba(6,12,20,${.62 * a})`; g.fillRect(0, 0, W, H);
  const k = E.back(inv(36.5, 36.95, t)) * (1 - E.in3(inv(41.1, 41.4, t)));
  g.save(); g.translate(540, 520); g.scale(k, k); g.rotate(-.02);
  sticker(-390, -370, 780, 700, 34, C.cream, { dx: 8, dy: 10, lw: 5 });
  g.fillStyle = C.teal; g.beginPath(); g.roundRect(-390, -370, 780, 96, [34, 34, 0, 0]); g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.beginPath(); g.moveTo(-390, -274); g.lineTo(390, -274); g.stroke();
  txt('WEEKLY CREW BOARD', -350, -306, { font: font(800, 38), color: '#fff', stroke: C.ink, sw: 8 }); txt('RESETS IN 2D 14H', 352, -310, { font: font(700, 16, 'GeistMono'), color: '#eafff8', align: 'right' });
  const rows = [['NIGHT OWLS', 9, 412], ['HONEY HEADS', 8, 377], ['CONE ZONE', 8, 351], ['SPORE SQUAD', 7, 214], ['YOU · LAST TRAIN CREW', 6, 192]];
  // you climb from #12 to #4
  const climb = E.io3(inv(37.3, 38.4, t)); const youRank = Math.round(lerp(12, 4, climb));
  const order = [0, 1, 2, 4, 3]; // final display order (you at 4th)
  rows.forEach((r, i) => {
    const isYou = i === 4; let slot = isYou ? lerp(5.6, 3, climb) : (i === 3 ? lerp(3, 4, climb) : i); const y = -230 + slot * 88;
    g.save(); g.globalAlpha = E.out3(inv(36.8 + i * .08, 37.1 + i * .08, t));
    g.fillStyle = isYou ? C.pink : (i % 2 ? '#f6ead2' : '#fff'); g.beginPath(); g.roundRect(-350, y, 700, 74, 18); g.fill(); g.lineWidth = isYou ? 5 : 3; g.strokeStyle = C.ink; g.stroke();
    const rank = isYou ? youRank : (i === 3 ? (climb > .5 ? 5 : 4) : i + 1);
    g.fillStyle = rank === 1 ? C.honey : rank === 2 ? '#d7dde0' : rank === 3 ? '#e09a5a' : '#fff'; g.beginPath(); g.arc(-306, y + 37, 24, 0, 7); g.fill(); g.lineWidth = 3; g.stroke(); txt('#' + rank, -306, y + 46, { font: font(800, rank > 9 ? 17 : 22), align: 'center', color: C.ink });
    oddball(-240, y + 66, .55, mkOdd(950 + i), t);
    txt(r[0], -200, y + 47, { font: font(800, 26), color: isYou ? '#fff' : C.ink, stroke: isYou ? C.ink : null, sw: 6 });
    txt(r[1] + ' cars', 170, y + 47, { font: font(700, 22), color: isYou ? '#fff' : '#6b5f4c', align: 'right' }); txt(fmtN(r[2]), 330, y + 47, { font: font(800, 26), color: isYou ? '#fff' : C.ink, align: 'right' });
    g.restore();
  });
  const rk = E.out3(inv(37.9, 38.3, t)); g.save(); g.globalAlpha = rk;
  g.fillStyle = C.ink; g.beginPath(); g.roundRect(-350, 222, 700, 78, 18); g.fill();
  icon('stamp', -300, 262, 48); txt('TOP 50 CREWS EARN GTD', -260, 256, { font: font(800, 24), color: C.honey }); txt('NEXT 200 EARN WL  ·  SAMPLE DATA', -260, 284, { font: font(700, 16, 'GeistMono'), color: '#cfe' });
  g.restore();
  g.restore();
  // run card share
  const s = E.out5(inv(38.9, 39.4, t)) * (1 - E.in3(inv(41.1, 41.4, t))); if (s <= 0) return;
  g.save(); g.translate(lerp(1400, 720, s), 690); g.rotate(.06);
  sticker(-230, -250, 460, 430, 28, '#fff', { dx: 8, dy: 10, lw: 5 }); txt('MY RUN', -200, -200, { font: font(800, 22), color: C.pink, ls: 2 }); txt('#4 THIS WEEK', 200, -200, { font: font(800, 22), color: C.ink, align: 'right' });
  g.save(); g.beginPath(); g.roundRect(-206, -184, 412, 140, 16); g.clip(); const gr = g.createLinearGradient(0, -184, 0, -44); gr.addColorStop(0, '#0e2236'); gr.addColorStop(1, '#22465a'); g.fillStyle = gr; g.fillRect(-206, -184, 412, 140); const tw = 400; g.drawImage(IMG.train, -tw / 2, -170, tw, tw * IMG.train.height / IMG.train.width); g.restore();
  [['6', 'CARS'], ['192', 'CREW'], ['8', 'BOTS BOUNCED']].forEach(([v, l], i) => { const x = -200 + i * 140; txt(v, x, 10, { font: font(800, 40), color: C.ink }); txt(l, x, 34, { font: font(700, 13, 'GeistMono'), color: '#6b5f4c' }); });
  const posted = t > 40.25; const bp = Math.max(0, 1 - Math.abs(t - 40.2) / .12);
  g.save(); g.translate(20, 120); g.scale(1 - bp * .08, 1 - bp * .08); sticker(-190, -34, 380, 68, 34, posted ? C.teal : C.ink, { dx: 4, dy: 5 }); txt(posted ? 'POSTED TO X' : 'SHARE ON X', posted ? 18 : 0, 12, { font: font(800, 28), align: 'center', color: '#fff' }); if (posted) check(-120, 0, 24, '#fff', 5); g.restore();
  txt('Runs on any phone. No download.', 0, 176, { font: font(700, 18), align: 'center', color: '#6b5f4c' });
  g.restore();
}
function sEnd(t) {
  const lt = t - 41.4;
  if (lt < 2.4) {
    g.fillStyle = `rgba(6,12,20,${.6 + .2 * inv(0, .3, lt)})`; g.fillRect(0, 0, W, H);
    const k = E.back(inv(.05, .5, lt)); const lw = 600, lh = lw * IMG.logo.height / IMG.logo.width;
    g.save(); g.translate(540, 360); g.scale(k, k); g.drawImage(IMG.logo, -lw / 2, -lh / 2, lw, lh); g.restore();
    const k2 = E.back(inv(.3, .7, lt)); g.save(); g.translate(540, 540); g.scale(k2, k2); g.rotate(-.03); sticker(-320, -60, 640, 104, 52, C.pink, { dx: 8, dy: 10, lw: 5 }); txt('LAST TRAIN TOWN', 0, 14, { font: font(800, 58), align: 'center', color: '#fff', stroke: C.ink, sw: 11, ls: -1 }); g.restore();
    txt('Collect the odd. Make the 23:09.', 540, 660, { font: font(800, 34), align: 'center', color: '#fff', stroke: C.ink, sw: 7, alpha: inv(.6, .9, lt) });
    const ck = E.out3(inv(.5, .9, lt)); sprite(IMG.cone, 540, 1080 + 40 + 220 * (1 - ck), 230); sprite(IMG.axolotl, 300, 1100 + 260 * (1 - ck), 260, { rot: Math.sin(t * 5) * .08 }); sprite(IMG.wolf, 790, 1100 + 260 * (1 - ck), 280, { rot: -Math.sin(t * 5) * .06 });
    sprite(IMG.honey, 110, 1120 + 260 * (1 - ck), 260, { rot: .15 }); sprite(IMG.mushroom, 980, 1130 + 260 * (1 - ck), 270, { rot: -.15 });
    if (lt > 2.1) { g.fillStyle = `rgba(0,0,0,${inv(2.1, 2.4, lt)})`; g.fillRect(0, 0, W, H); }
    return;
  }
  const e = lt - 2.4; g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const fa = (a, b) => E.out3(inv(a, b, e));
  // chrome bar mark
  const cw = 46, chh = 150, step = 34, x0 = 540 - (cw + step * 5) / 2;
  for (let i = 0; i < 6; i++) { const k = fa(i * .05, .4 + i * .05); if (k <= 0) continue; g.save(); g.globalAlpha = k; const y = 250 + 30 * (1 - k); const gr = g.createLinearGradient(0, y, 0, y + chh); gr.addColorStop(0, '#fff'); gr.addColorStop(.2, '#e2e2e2'); gr.addColorStop(.52, '#262626'); gr.addColorStop(.75, '#0c0c0c'); gr.addColorStop(1, '#a0a0a0'); g.fillStyle = gr; g.beginPath(); g.roundRect(x0 + i * step, y, cw, chh, cw / 2); g.fill(); g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1.5; g.stroke(); g.restore(); }
  txt('A game concept for Trippi', 540, 500, { font: font(600, 40, 'Geist'), align: 'center', color: '#fff', alpha: fa(.3, .6), ls: -1 });
  txt('BY ENCORE STUDIO', 540, 544, { font: font(500, 20, 'GeistMono'), align: 'center', color: '#a8a8a8', ls: 6, alpha: fa(.4, .7) });
  txt('Book a call  ·  calendly.com/encorestudiohq/30min', 540, 640, { font: font(500, 28, 'Geist'), align: 'center', color: '#fff', alpha: fa(.6, .9) });
  txt('@EncoreStudiohq  ·  encorestudio.xyz', 540, 682, { font: font(500, 22, 'Geist'), align: 'center', color: '#9a9a9a', alpha: fa(.7, 1.0) });
  txt('Unofficial concept. Not affiliated with or endorsed by Trippi. Trippi art © Trippi. Sample data.', 540, 800, { font: font(400, 18, 'Geist'), align: 'center', color: '#7f7f7f', alpha: fa(.8, 1.1) });
  txt('Every launch deserves an encore.', 540, 960, { font: font(500, 18, 'GeistMono'), align: 'center', color: '#6f6f6f', ls: 2, alpha: fa(.9, 1.2) });
  if (e > 1.85) { g.fillStyle = `rgba(0,0,0,${inv(1.85, 2.2, e)})`; g.fillRect(0, 0, W, H); }
}

/* ---------------- frame ---------------- */
function frame(fi) {
  const t = fi / FPS;
  g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.shadowBlur = 0; g.shadowColor = 'transparent'; g.letterSpacing = '0px'; g.setLineDash([]);
  if (t < 43.8) {
    world(t);
    rain(t, (t < 17 ? .7 : t < 23.6 ? .4 : t < 31.6 ? 1 : 0) * (1 - inv(31.4, 32, t)));
    fireworks(t);
    // raid alert vignette
    if (t > 23.6 && t < 31) { const al = (.5 + .5 * Math.sin(t * 10)) * (1 - inv(29.5, 31, t)) * inv(23.6, 23.8, t); const gr = g.createRadialGradient(540, 540, 360, 540, 540, 760); gr.addColorStop(0, 'rgba(255,40,60,0)'); gr.addColorStop(1, `rgba(255,40,60,${.35 * al})`); g.fillStyle = gr; g.fillRect(0, 0, W, H); }
    g.drawImage(VIG, 0, 0);
    flyers(t); confetti(t, 15.0, ws(slotX(0) + CW / 2, -200).x, ws(0, -200).y); confetti(t, 30.2, 540, 520);
    hud(t);
    dragGhost(t);
    bannerSticker(t, 15.05, 16.7, 'NEW CAR!', 'Pet Daycare is open · +3 baby oddballs', C.teal, 290);
    bannerSticker(t, 19.0, 20.9, 'ALL ABOARD!', 'Rush Hour crew is boarding', C.honey, 300, .03);
    bannerSticker(t, 23.6, 25.0, 'BOT RAID!', 'Fake fans incoming. Defend the train.', C.red, 300);
    bannerSticker(t, 29.75, 31.45, 'RAID CLEARED!', "Bots can like a post. They can't board this train.", C.teal, 300, .02);
    bannerSticker(t, 33.1, 36.2, 'MADE THE 23:09!', '6 cars · 192 crew · 0 bots aboard', C.pink, 300);
    sTitle(t);
    sBoard(t);
    cursor(t);
  }
  if (t >= 41.4) sEnd(t);
  grain(.06, fi);
}

/* ---------------- sound cues ---------------- */
function buildEvents() {
  const ev = []; const P = (t, type, o = {}) => ev.push({ t: +t.toFixed(3), type, ...o });
  P(.2, 'title_hit'); P(.55, 'pop_big'); P(1.2, 'tick'); P(2.35, 'start'); P(2.6, 'whoosh');
  TAPS.forEach((tp, i) => { P(tp.t, 'tap'); P(tp.t + .02, 'collect', { n: i }); for (let j = 0; j < 9; j++) P(tp.t + .67 + j * .045, 'coin', { n: j }); });
  P(10.15, 'tap'); P(10.3, 'tray'); P(11.2, 'tap'); P(11.3, 'pickup'); P(12.4, 'drop'); P(12.5, 'build_start');
  for (let k = 0; k < 18; k++) P(12.6 + k * .13, 'weld', { n: k }); for (let k = 0; k < 8; k++) P(13.8 + k * .18, 'pop', { n: k });
  P(15.0, 'fanfare'); P(15.05, 'banner');
  P(17.2, 'brake'); P(18.7, 'doors'); P(19.0, 'banner'); for (let k = 0; k < 18; k++) P(19.2 + k * .12, 'board', { n: k }); P(21.0, 'quest'); P(21.5, 'doors'); P(21.9, 'depart');
  P(23.6, 'alarm'); P(23.6, 'banner'); P(23.7, 'drone'); BOTS.forEach(b => P(b.td + .3, 'bot_land'));
  ABIL.forEach(a => P(a.t - .05, 'tap')); P(26.05, 'cone_slam'); P(27.0, 'honey_throw'); P(27.45, 'splat'); P(28.6, 'spring'); P(28.85, 'boing'); BOTS.forEach((b, i) => P(28.85 + i * .05, 'launch', { n: i }));
  P(29.75, 'banner'); P(30.2, 'fanfare'); P(30.3, 'quest');
  P(31.6, 'whoosh'); [32.3, 32.9, 33.5, 34.2, 34.8, 35.5].forEach(x => P(x, 'firework')); P(33.0, 'chime_arrive'); P(33.1, 'banner');
  P(36.5, 'whoosh'); P(37.3, 'climb'); P(38.4, 'quest'); P(38.9, 'whoosh'); P(40.2, 'tap'); P(40.25, 'posted');
  P(41.45, 'title_hit'); P(41.75, 'pop_big'); P(43.85, 'chime');
  return ev.sort((a, b) => a.t - b.t);
}

window.READY = (async () => {
  await Promise.all(IMGN.map(n => new Promise((res, rej) => { const i = new Image(); i.onload = () => { IMG[n] = i; res(); }; i.onerror = rej; i.src = 'img/' + n + '.png'; })));
  await Promise.all(['500 20px Geist', '600 20px Geist', '400 20px Geist', '500 20px GeistMono', '700 20px GeistMono', '600 20px Poppins', '700 20px Poppins', '800 20px Poppins'].map(f => document.fonts.load(f)));
  prebuild();
  window.EVENTS = buildEvents(); window.TOTAL = Math.round(DUR * FPS);
  window.grab = (fi, q) => { frame(fi); return cv.toDataURL('image/jpeg', q || .95); };
  return true;
})();
