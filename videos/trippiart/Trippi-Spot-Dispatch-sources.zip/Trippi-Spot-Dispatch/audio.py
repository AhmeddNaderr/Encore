"""Original score + sound design for the Trippi × Encore 'Spot Dispatch' film.
Everything is synthesised here from oscillators and seeded noise; cue times come from the film's events.json."""
import json, sys
import numpy as np
from scipy.signal import lfilter, butter, sosfilt, fftconvolve
from scipy.io import wavfile

SR = 48000
DUR = 53.0
N = int(SR * DUR)
rng = np.random.default_rng(1999)
L = np.zeros(N); R = np.zeros(N)
SEND = np.zeros((2, N))  # reverb bus

def t_arr(d): return np.arange(int(d * SR)) / SR
def env(d, a=.005, rel=None, curve=6.0):
    t = t_arr(d); e = np.minimum(1, t / max(a, 1e-4)); dec = np.exp(-curve * t / d)
    return e * dec
def add(t0, sig, g=1.0, pan=0.0, rev=0.0):
    i = int(t0 * SR)
    if i >= N or i + len(sig) <= 0: return
    if i < 0: sig = sig[-i:]; i = 0
    n = min(len(sig), N - i); s = sig[:n] * g
    lg, rg = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    L[i:i + n] += s * lg * 1.414; R[i:i + n] += s * rg * 1.414
    if rev: SEND[0, i:i + n] += s * lg * rev; SEND[1, i:i + n] += s * rg * rev
def lp(x, fc, order=2): return sosfilt(butter(order, min(fc, SR / 2 - 100) / (SR / 2), 'low', output='sos'), x)
def hp(x, fc, order=2): return sosfilt(butter(order, fc / (SR / 2), 'high', output='sos'), x)
def bp(x, lo, hi, order=2): return sosfilt(butter(order, [lo / (SR / 2), hi / (SR / 2)], 'band', output='sos'), x)
def noise(d): return rng.standard_normal(int(d * SR))
def sine(f, d, ph=0): t = t_arr(d); return np.sin(2 * np.pi * f * t + ph)
def sweep(f0, f1, d, kind='sin'):
    t = t_arr(d); f = f0 * (f1 / f0) ** (t / d); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.sin(ph) if kind == 'sin' else np.sign(np.sin(ph)) * .6 if kind == 'sq' else 2 * ((ph / (2 * np.pi)) % 1) - 1
def saw(f, d, det=0.0):
    t = t_arr(d); s = 2 * ((f * t) % 1) - 1
    if det: s = .5 * s + .5 * (2 * ((f * (1 + det) * t) % 1) - 1)
    return s
def sq(f, d, duty=.5): t = t_arr(d); return np.where((f * t) % 1 < duty, 1.0, -1.0)
def mtof(m): return 440 * 2 ** ((m - 69) / 12)

# ---------------------------------------------------------------- sound effects
def sfx(e):
    t, k = e['t'], e['type']
    if k == 'key':
        s = hp(noise(.014), 2500) * env(.014, .0005, curve=8) * .5 + sq(1700 + rng.random() * 300, .014) * env(.014, .001, curve=7) * .25
        add(t, s, .10, rng.uniform(-.2, .2))
    elif k == 'key2':
        add(t, sq(1150, .03) * env(.03, .001, curve=6), .07)
    elif k == 'tick':
        add(t, sine(2600, .03) * env(.03, .001, curve=9), .08, rev=.2)
    elif k == 'beep_ok':
        add(t, sq(880, .09) * env(.09, .002, curve=3), .07, rev=.15)
    elif k == 'beep_bad':
        add(t, lp(sq(196, .18), 2000) * env(.18, .002, curve=2), .08)
    elif k == 'proc':
        for j in range(9): add(t + j * .05, sq(600 + rng.random() * 1400, .03) * env(.03, .001, curve=5), .05)
    elif k == 'granted':
        add(t, (sq(660, .12) * .5 + sine(660, .12)) * env(.12, .002, curve=2), .1, rev=.3)
        add(t + .12, (sq(990, .35) * .4 + sine(990, .35)) * env(.35, .002, curve=4), .1, rev=.35)
    elif k == 'load':
        add(t, lp(sweep(180, 1400, .95, 'sq'), 3000) * np.linspace(.4, 1, int(.95 * SR)), .05)
    elif k == 'crt_off':
        add(t, sweep(1800, 60, .25) * env(.25, .001, curve=2), .14)
        add(t + .2, lp(noise(.12), 900) * env(.12, .001, curve=5), .25)
        add(t + .19, sine(48, .3) * env(.3, .002, curve=5), .5)
    elif k == 'glitch':
        d = e['d']; n = noise(d); gate = (np.floor(t_arr(d) * 38) % 3 != 0).astype(float)
        crushed = np.round(n * 3) / 3; s = (crushed * gate) * env(d, .005, curve=1.2)
        add(t, bp(s, 400, 9000), .16)
        add(t, sweep(2200, 300, d, 'sq') * env(d, .002, curve=2), .04)
    elif k == 'train':
        d = 3.4; tt = t_arr(d)
        rumble = lp(np.cumsum(noise(d)) * .01, 220); rumble /= np.abs(rumble).max()
        envr = np.minimum(1, tt / 1.2) * np.exp(-np.maximum(0, tt - 2.4) * 2.5)
        add(t, rumble * envr, .55, .5)
        # wheel clacks slowing down
        pos = 0.15; gap = .09
        while pos < 2.4:
            c = lp(noise(.06), 900) * env(.06, .001, curve=7) + sine(70, .06) * env(.06, .001, curve=6)
            add(t + pos, c, .35 * min(1, pos / .6), .6 - pos * .4); add(t + pos + .045, c, .25 * min(1, pos / .6), .6 - pos * .4)
            pos += gap; gap *= 1.11
        # brake squeal
        sd = 1.1; st = t_arr(sd); f = 2900 + 60 * np.sin(2 * np.pi * 7 * st)
        sq_ = np.sin(2 * np.pi * np.cumsum(f) / SR) + .4 * np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR)
        add(t + 1.5, sq_ * np.sin(np.pi * st / sd) ** 2, .045, -.1, rev=.4)
        add(t + 2.55, hp(noise(.6), 1500) * env(.6, .02, curve=4), .09, rev=.3)  # air hiss
    elif k == 'signal':
        d = .75; s = bp(noise(d), 800, 5000) * .6 + sine(1000, d) * (np.floor(t_arr(d) * 10) % 2)
        add(t, s * np.linspace(0, 1, len(s)), .08)
    elif k == 'pop':
        add(t, sweep(500, 1300, .05) * env(.05, .001, curve=4), .12, rev=.1)
    elif k == 'talk':
        base = [170, 290, 235][e['who']]; f0 = base * 2 ** (rng.integers(-3, 5) / 12)
        s = lp(saw(f0, .055, .01), 1400 + rng.random() * 900) * env(.055, .004, curve=3)
        add(t, s, .07, [-.35, 0, .35][e['who']])
    elif k == 'ui_on':
        add(t, lp(sweep(80, 900, .6, 'saw'), 2500) * np.linspace(0, 1, int(.6 * SR)) ** 2, .07, rev=.3)
        for j, m in enumerate([57, 64, 69, 72]): add(t + .55 + j * .03, sine(mtof(m + 12), .8) * env(.8, .003, curve=4), .045, rev=.4)
    elif k == 'draw':
        d = 1.2; add(t, bp(noise(d), 1500, 6000) * np.linspace(0, 1, int(d * SR)) ** 2 * env(d, .01, curve=.8), .05)
    elif k in ('banner', 'banner_big'):
        d = .5; add(t - .1, bp(noise(d), 600, 7000) * np.sin(np.pi * t_arr(d) / d) ** 2, .14, -.3, rev=.2)
        add(t + .3, sine(55, .5) * env(.5, .002, curve=5), .4, rev=.25); add(t + .3, lp(noise(.2), 3000) * env(.2, .001, curve=8), .16, rev=.25)
        if k == 'banner_big':
            for j, m in enumerate([57, 60, 64, 67, 71]): add(t + .3, lp(saw(mtof(m + 12), 1.6, .006), 2600) * env(1.6, .004, curve=3), .05, rev=.5)
    elif k == 'dispatch':
        add(t, sweep(320, 820, .07, 'sq') * env(.07, .002, curve=4), .04, e.get('pan', 0) * .8)
        add(t, lp(noise(.25), 2500) * env(.25, .01, curve=4), .05, e.get('pan', 0) * .8)
    elif k == 'arrive':
        scale = [0, 3, 5, 7, 10, 12, 15, 17, 19, 22]; m = 76 + scale[e['n'] % 10]
        s = (sine(mtof(m), .45) + .35 * sine(mtof(m) * 2.01, .45)) * env(.45, .002, curve=6)
        add(t, s, .08 if e['kind'] == 'collab' else .06, rng.uniform(-.4, .4), rev=.35)
        add(t + .07, sine(mtof(m + 7), .3) * env(.3, .002, curve=7), .04, rev=.4)
    elif k == 'absorb':
        add(t, lp(noise(.35), 900) * np.sin(np.pi * t_arr(.35) / .35), .03)
    elif k == 'card':
        add(t, bp(noise(.3), 900, 6000) * np.sin(np.pi * t_arr(.3) / .3) ** 2, .12, -.3)
    elif k == 'stamp':
        add(t, sine(85, .35) * env(.35, .001, curve=7), .6, rev=.15)
        add(t, lp(noise(.08), 2500) * env(.08, .0005, curve=9), .5, rev=.2)
        add(t + .01, bp(noise(.06), 300, 1200) * env(.06, .001, curve=8), .4)
    elif k == 'chip':
        add(t, (sine(1320, .12) + sine(1760, .12)) * env(.12, .001, curve=5), .05, .4, rev=.3)
    elif k == 'quest':
        for j, m in enumerate([72, 76, 79, 84]): add(t + j * .07, (sq(mtof(m), .22, .25) * .4 + sine(mtof(m), .22)) * env(.22, .002, curve=4), .055, rev=.35)
    elif k == 'whoosh':
        d = .55; add(t, bp(noise(d), 500, 6000) * np.sin(np.pi * t_arr(d) / d) ** 2, .16, rev=.2)
    elif k == 'pop_big':
        add(t, sweep(240, 900, .12) * env(.12, .002, curve=3), .2, rev=.3)
        for j in range(6): add(t + .05 + j * .04, sine(mtof(84 + j * 2), .2) * env(.2, .001, curve=6), .03, rng.uniform(-.5, .5), rev=.5)
    elif k == 'chime':
        f0 = mtof(81); d = 3.5
        s = sum(a * sine(f0 * p, d) * np.exp(-t_arr(d) * dr) for p, a, dr in [(1, 1, 1.4), (2.76, .45, 2.5), (5.4, .25, 4), (8.93, .12, 6)])
        add(t, s, .07, rev=.6)
    elif k == 'shine':
        for j in range(10): add(t + j * .035, sine(mtof(88 + j), .25) * env(.25, .001, curve=6), .018, -.5 + j * .1, rev=.6)

# ---------------------------------------------------------------- music (96 BPM, A minor)
BPM = 96; B = 60 / BPM; T0 = 13.0  # drop on bar line at 13.0
CH = [[57, 60, 64, 67, 71], [53, 57, 60, 64, 67], [48, 55, 59, 62, 64], [52, 55, 59, 62, 66]]  # Am9 Fmaj9 Cmaj9 Em9(add)
ROOT = [45, 41, 48, 40]
def beat_t(n): return T0 + n * B  # n may be negative
def sec_gain(t):
    """(drums, bass, keys, filter cutoff) by section"""
    if t < 5.2: return 0, 0, 0, 800
    if t < 13.0: return (0 if t < 9.25 else .35), 0, min(1, (t - 5.4) / 2.0) * .8, 1400 + (t - 5.2) * 260
    if t < 31.5: return 1, 1, 1, 9000
    if t < 39.5: return .55, .7, .55, 900
    if t < 46.6: return 1, 1, 1.1, 10000
    return 0, 0, 0, 3000
MUS = np.zeros((2, N)); MUS_DRY = np.zeros((2, N))
def madd(t0, sig, g, pan=0, rev=0):
    i = int(t0 * SR)
    if i >= N or i < 0: return
    n = min(len(sig), N - i); s = sig[:n] * g; lg, rg = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
    MUS[0, i:i + n] += s * lg * 1.414; MUS[1, i:i + n] += s * rg * 1.414
    if rev: SEND[0, i:i + n] += s * lg * rev; SEND[1, i:i + n] += s * rg * rev
def kick(): d = .42; t = t_arr(d); f = 48 + 110 * np.exp(-t * 28); return np.tanh(2.2 * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7.5))
def snare(): d = .3; return (bp(noise(d), 1200, 9000) * np.exp(-t_arr(d) * 16) * .9 + sine(190, d) * np.exp(-t_arr(d) * 25) * .6)
def hat(o=False): d = .22 if o else .05; return hp(noise(d), 7000) * np.exp(-t_arr(d) * (12 if o else 70))
KICK, SNARE, HAT, OHAT = kick(), snare(), hat(), hat(True)
# drums + bass + chords + arp, bar by bar from the first intro bar
first_bar = -3  # bar -3 starts at 13 - 7.5 = 5.5
for bar in range(first_bar, 14):
    bt = T0 + bar * 4 * B; ci = bar % 4; chord = CH[ci]
    if bt > 49: break
    # pad / keys per bar
    dg, bg, kg, fc = sec_gain(bt + .01)
    if kg > 0:
        d = 4 * B + .4; pad = sum(lp(saw(mtof(m), d, .004), min(fc, 2600)) for m in chord) / len(chord)
        a = np.minimum(1, t_arr(d) / .25) * np.minimum(1, (d - t_arr(d)) / .4)
        madd(bt, pad * a, .11 * kg, 0, rev=.25)
    for st in range(16):  # 16th steps
        tt = bt + st * B / 4 + (B / 4 * .12 if st % 2 else 0)  # swing
        dg, bg, kg, fc = sec_gain(tt)
        if tt >= 46.6: continue
        if dg:
            if st in (0, 6, 8, 11) and not (tt > 30.9 and tt < 31.5): madd(tt, lp(KICK, fc * 1.5), .55 * dg)
            if st in (4, 12): madd(tt, lp(SNARE, fc * 1.2), .3 * dg, .05, rev=.15)
            if st % 2 == 0: madd(tt, HAT, (.06 if st % 4 else .09) * dg, .25)
            if st == 14 and bar % 2: madd(tt, OHAT, .05 * dg, .25)
        if bg and st in (0, 3, 6, 8, 10, 14):
            m = ROOT[ci] + (12 if st in (10,) else 0) + (7 if st == 14 else 0); d = B / 2 if st in (0, 8) else B / 4
            s = np.tanh(1.6 * (sine(mtof(m), d) + .3 * sine(mtof(m) * 2, d))) * np.minimum(1, t_arr(d) / .005) * np.exp(-t_arr(d) * 3)
            madd(tt, lp(s, min(fc, 1200)), .28 * bg)
        if kg and tt >= 13.0:  # arp plucks only after the drop
            pat = [0, 2, 1, 3, 4, 3, 2, 1, 0, 2, 4, 3, 1, 2, 3, 4]; m = chord[pat[st] % len(chord)] + 12
            d = .22; s = lp(sq(mtof(m), d, .3) * .5 + saw(mtof(m), d) * .5, min(fc, 4200)) * np.exp(-t_arr(d) * 14)
            madd(tt, s, .05 * kg, -.35 + .7 * ((st * 5) % 16) / 15, rev=.3)
# lead hook in the ticket section
HOOK = [(0, 76, 1), (1.5, 79, .5), (2, 81, 1), (3, 79, .5), (3.5, 76, .5), (4, 74, 1.5), (6, 72, .5), (6.5, 74, .5), (7, 76, 1),
        (8, 76, 1), (9.5, 79, .5), (10, 84, 1), (11, 81, .5), (11.5, 79, .5), (12, 81, 2.5)]
hook_start = T0 + 42 * B  # beat 42 after drop
for b, m, l in HOOK:
    tt = hook_start + b * B
    if tt > 46.4: continue
    d = l * B; s = (saw(mtof(m), d, .006) * .6 + sq(mtof(m), d, .25) * .4)
    s = lp(s, 3500) * np.minimum(1, t_arr(d) / .01) * np.exp(-t_arr(d) * 1.8)
    madd(tt, s, .07, .1, rev=.4)
# final chord + riser into the drop
d = 6.0; fin = sum(lp(saw(mtof(m), d, .005), 1800) for m in [45, 57, 64, 67, 71, 76]) / 6
madd(46.6, fin * np.minimum(1, t_arr(d) / .05) * np.exp(-t_arr(d) * .55), .16, rev=.5)
madd(46.6, KICK, .5)
d = 2.0; madd(11.0, bp(noise(d), 300, 8000) * (t_arr(d) / d) ** 3, .12)  # riser
madd(13.0, sine(41, 1.2) * np.exp(-t_arr(1.2) * 2.5), .5)  # sub drop

# muffle music during the exit-B CCTV section (it's heard "through the wall")
a, b = int(31.5 * SR), int(39.5 * SR)
for c in range(2): MUS[c, a:b] = lp(MUS[c, a:b], 900)

# ---------------------------------------------------------------- ambiences
def bed(t0, t1, sig_fn, g, fade=.3):
    d = t1 - t0; s = sig_fn(d); e = np.minimum(1, np.minimum(t_arr(d) / fade, (d - t_arr(d)) / fade)); add(t0, s * e, g)
bed(0, 5.15, lambda d: sine(60, d) * .6 + sine(120, d) * .3 + lp(noise(d), 300) * .3, .05)
bed(5.2, 13.0, lambda d: lp(np.cumsum(noise(d)) * .004, 400) + sine(120, d) * .15 * (1 + .3 * np.sin(2 * np.pi * .7 * t_arr(d))), .12)
def rain(d):
    r = bp(noise(d), 1500, 9000) * .6 + lp(noise(d), 700) * .4
    for j in range(260): i = rng.integers(0, int(d * SR) - 2000); r[i:i + 600] += hp(noise(.0125), 3000) * env(.0125, .0005, curve=8) * rng.uniform(.5, 2)
    return r
bed(31.45, 39.55, rain, .16, .25)

# ---------------------------------------------------------------- render
events = json.load(open(sys.argv[1]))
for e in events: sfx(e)
ir_d = 2.2; irt = t_arr(ir_d)
IR = np.stack([rng.standard_normal(len(irt)) * np.exp(-irt * 3.2), rng.standard_normal(len(irt)) * np.exp(-irt * 3.2)])
IR = np.stack([lp(IR[0], 6000), lp(IR[1], 6000)]) * .05
WET = np.stack([fftconvolve(SEND[c], IR[c])[:N] for c in range(2)])
# light sidechain duck of music under the kick isn't needed; glue with gentle saturation
mix = np.stack([L, R]) + MUS * .9 + WET
mix = hp(mix, 25)
mix = np.tanh(mix * 1.15) / np.tanh(1.15)
peak = np.abs(mix).max(); mix = mix / peak * .89
fade = int(.4 * SR); mix[:, -fade:] *= np.linspace(1, 0, fade)
wavfile.write(sys.argv[2], SR, (mix.T * 32767).astype(np.int16))
print('wrote', sys.argv[2], 'peak was', round(float(peak), 3))
