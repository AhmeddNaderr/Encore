'use strict';
/* TRIPPI × ENCORE — "Spot Dispatch" offer film. 1080×1080, 60 fps, deterministic: frame(f) draws frame f. */
const W = 1080, H = 1080, FPS = 60, DUR = 53;
const cv = document.getElementById('c');
const g = cv.getContext('2d');
const IMG = {};
const IMGN = ['logo', 'cone', 'train', 'station-bench-wide', 'streetlight', 'mushroom', 'honey', 'banner',
  'postmark-axolotl', 'postmark-frog', 'postmark-traffic', 'postmark-wolf', 'code-drop-pass-fcfs', 'trippi-profile'];

/* ---------- math ---------- */
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const inv = (a, b, t) => clamp((t - a) / (b - a));
const E = {
  out3: t => 1 - Math.pow(1 - t, 3), in3: t => t * t * t, io3: t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
  out5: t => 1 - Math.pow(1 - t, 5), io2: t => t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2,
  back: t => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  back2: t => { const c1 = 2.6, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
};
function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function hash(n) { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }
const fmtK = v => v >= 1e6 ? (v / 1e6).toFixed(2) + 'M' : v >= 1e3 ? Math.round(v / 1e3) + 'K' : String(Math.round(v));
const fmtN = v => Math.round(v).toLocaleString('en-US');

/* ---------- palette (sampled from Trippi art) ---------- */
const C = {
  teal: '#12a283', tealD: '#0b6b56', tealL: '#5fe0c0', pink: '#ff6fa5', honey: '#ffbd2e', green: '#97d84a',
  cyan: '#3fdcef', orange: '#ff7a2a', cream: '#f1e8d4', ink: '#121614', red: '#d8402f', cash: '#6dffb2',
};

/* ---------- draw helpers ---------- */
function font(w, s, f = 'Geist') { return `${w} ${s}px ${f}`; }
function txt(s, x, y, o = {}) {
  g.save(); g.font = o.font || font(600, 24); g.fillStyle = o.color || '#fff';
  g.textAlign = o.align || 'left'; g.textBaseline = o.base || 'alphabetic'; g.letterSpacing = (o.ls || 0) + 'px';
  if (o.alpha != null) g.globalAlpha *= o.alpha;
  if (o.shadow) { g.shadowColor = o.shadow; g.shadowBlur = o.blur || 0; g.shadowOffsetX = o.sx || 0; g.shadowOffsetY = o.sy || 0; }
  if (o.stroke) { g.lineWidth = o.sw || 6; g.strokeStyle = o.stroke; g.lineJoin = 'round'; g.strokeText(s, x, y); }
  g.fillText(s, x, y); g.restore();
}
function measure(s, f, ls = 0) { g.save(); g.font = f; g.letterSpacing = ls + 'px'; const w = g.measureText(s).width; g.restore(); return w; }
function wrap(s, maxW, f) {
  const words = s.split(' '); const lines = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (measure(t, f) > maxW && cur) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur); return lines;
}
function sprite(img, cx, by, h, o = {}) {
  const w = img.width * h / img.height; g.save(); g.translate(cx, by); if (o.rot) g.rotate(o.rot);
  g.scale((o.sx || 1) * (o.flip ? -1 : 1), o.sy || 1); if (o.alpha != null) g.globalAlpha *= o.alpha;
  g.drawImage(img, -w / 2, -h, w, h); g.restore();
}
function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function shadowEllipse(x, y, rx, ry, a = .35) { g.save(); g.fillStyle = `rgba(0,0,0,${a})`; g.beginPath(); g.ellipse(x, y, rx, ry, 0, 0, 7); g.fill(); g.restore(); }

/* ---------- prebuilt textures ---------- */
let NOISE = [], SCAN, SCAN2, VIG, TMP, tg, STAMP, TICKET, GRAFF;
function prebuild() {
  for (let k = 0; k < 4; k++) {
    const c = mk(512, 512), x = c.getContext('2d'); const id = x.createImageData(512, 512); const r = mulberry(k * 99 + 7);
    for (let i = 0; i < id.data.length; i += 4) { const v = r() * 255 | 0; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; }
    x.putImageData(id, 0, 0); NOISE.push(c);
  }
  SCAN = mk(W, H); { const x = SCAN.getContext('2d'); x.fillStyle = 'rgba(0,0,0,0.26)'; for (let y = 0; y < H; y += 4) x.fillRect(0, y, W, 2); }
  SCAN2 = mk(W, H); { const x = SCAN2.getContext('2d'); x.fillStyle = 'rgba(0,0,0,0.10)'; for (let y = 0; y < H; y += 3) x.fillRect(0, y, W, 1); }
  VIG = mk(W, H); { const x = VIG.getContext('2d'); const gr = x.createRadialGradient(540, 540, 330, 540, 540, 780); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,0.72)'); x.fillStyle = gr; x.fillRect(0, 0, W, H); }
  TMP = mk(W, H); tg = TMP.getContext('2d');
  STAMP = buildStamp('PAID IN SPOTS  ✦  PLATFORM 09  ✦  ', '$0', 'ZERO CASH');
  TICKET = buildTicket();
  GRAFF = buildGraff();
}
function noise(alpha, f, mode = 'overlay') {
  g.save(); g.globalAlpha = alpha; g.globalCompositeOperation = mode; const n = NOISE[f % 4];
  const ox = (hash(f) * 512) | 0, oy = (hash(f + .5) * 512) | 0;
  for (let x = -ox; x < W; x += 512) for (let y = -oy; y < H; y += 512) g.drawImage(n, x, y);
  g.restore();
}
function buildStamp(ring, center, sub) {
  const S = 360, c = mk(S, S), x = c.getContext('2d'); const R = 160;
  x.translate(S / 2, S / 2); x.strokeStyle = C.red; x.fillStyle = C.red;
  x.lineWidth = 9; x.beginPath(); x.arc(0, 0, R, 0, 7); x.stroke();
  x.lineWidth = 4; x.beginPath(); x.arc(0, 0, R - 50, 0, 7); x.stroke();
  x.font = font(800, 27, 'GeistMono'); x.textAlign = 'center'; x.textBaseline = 'middle';
  const chars = ring.split(''); const step = (Math.PI * 2) / chars.length;
  chars.forEach((ch, i) => { x.save(); x.rotate(i * step); x.translate(0, -R + 25); x.fillText(ch, 0, 0); x.restore(); });
  x.font = font(800, 96); x.fillText(center, 0, -8); x.font = font(700, 22, 'GeistMono'); x.letterSpacing = '3px'; x.fillText(sub, 0, 52);
  // ink wear
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'destination-out';
  const r = mulberry(42); for (let i = 0; i < 900; i++) { x.globalAlpha = .25 + r() * .6; x.beginPath(); x.arc(r() * S, r() * S, r() * 2.6, 0, 7); x.fill(); }
  return c;
}
function buildTicket() {
  const w = 900, h = 610, c = mk(w, h), x = c.getContext('2d');
  x.fillStyle = C.cream; x.beginPath(); x.roundRect(0, 0, w, h, 26); x.fill();
  // paper grain
  const r = mulberry(5); for (let i = 0; i < 5000; i++) { x.fillStyle = `rgba(90,70,40,${r() * .07})`; x.fillRect(r() * w, r() * h, 1.5, 1.5); }
  const gr = x.createLinearGradient(0, 0, w, h); gr.addColorStop(0, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(120,90,40,.12)'); x.fillStyle = gr; x.fillRect(0, 0, w, h);
  // perforation notches + inner frame
  x.globalCompositeOperation = 'destination-out';
  for (let i = 0; i <= 30; i++) { x.beginPath(); x.arc(i * w / 30, 0, 9, 0, 7); x.fill(); x.beginPath(); x.arc(i * w / 30, h, 9, 0, 7); x.fill(); }
  x.beginPath(); x.arc(0, 430, 26, 0, 7); x.fill(); x.beginPath(); x.arc(w, 430, 26, 0, 7); x.fill();
  x.globalCompositeOperation = 'source-over';
  x.strokeStyle = 'rgba(11,107,86,.55)'; x.lineWidth = 3; x.beginPath(); x.roundRect(22, 26, w - 44, h - 52, 14); x.stroke();
  x.setLineDash([12, 10]); x.lineWidth = 3; x.beginPath(); x.moveTo(40, 430); x.lineTo(w - 40, 430); x.stroke();
  return c;
}
function buildGraff() { // white throw-up graffiti strip from Trippi's own PFP background
  const p = IMG['trippi-profile']; const c = mk(1000, 400), x = c.getContext('2d');
  x.drawImage(p, 0, 600, 1000, 400, 0, 0, 1000, 400); return c;
}

/* ---------- shared overlays ---------- */
function clockStr(t) { const s = Math.floor(540 + t); return `2026-11-14  23:${String(Math.floor(s / 60) % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; }
function cctv(t, f, cam) {
  g.save(); g.globalCompositeOperation = 'saturation'; g.fillStyle = 'rgba(128,128,128,0.30)'; g.fillRect(0, 0, W, H); g.restore();
  g.save(); g.globalCompositeOperation = 'soft-light'; g.fillStyle = 'rgba(40,110,95,0.45)'; g.fillRect(0, 0, W, H); g.restore();
  noise(0.11, f); g.drawImage(SCAN2, 0, 0); g.drawImage(VIG, 0, 0);
  const by = ((t * 150) % 1400) - 220; const gr = g.createLinearGradient(0, by, 0, by + 140);
  gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(.5, 'rgba(255,255,255,0.05)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, by, W, 140);
  const sh = { shadow: 'rgba(0,0,0,.95)', blur: 5 };
  txt(clockStr(t), 40, 66, { font: font(500, 30, 'GeistMono'), color: '#f4f4f4', ...sh });
  txt(cam, 40, 102, { font: font(500, 22, 'GeistMono'), color: '#dcdcdc', ls: 1.5, ...sh });
  if (Math.floor(t * 1.6) % 2 === 0) { g.save(); g.fillStyle = '#ff2b2b'; g.shadowColor = '#ff2b2b'; g.shadowBlur = 14; g.beginPath(); g.arc(W - 128, 56, 11, 0, 7); g.fill(); g.restore(); }
  txt('REC', W - 108, 67, { font: font(700, 30, 'GeistMono'), color: '#f4f4f4', ...sh });
  g.save(); g.strokeStyle = 'rgba(255,255,255,.75)'; g.lineWidth = 3; const m = 22, L = 48;
  [[m, m, 1, 1], [W - m, m, -1, 1], [m, H - m, 1, -1], [W - m, H - m, -1, -1]].forEach(([x, y, a, b]) => { g.beginPath(); g.moveTo(x, y + L * b); g.lineTo(x, y); g.lineTo(x + L * a, y); g.stroke(); });
  g.restore();
}
function bezel() { g.save(); g.fillStyle = '#000'; g.beginPath(); g.rect(0, 0, W, H); g.roundRect(12, 12, W - 24, H - 24, 64); g.fill('evenodd'); g.restore(); }
function glitch(f, amt) {
  if (amt <= 0) return;
  tg.setTransform(1, 0, 0, 1, 0, 0); tg.globalAlpha = 1; tg.clearRect(0, 0, W, H); tg.drawImage(cv, 0, 0);
  const r = mulberry(f * 7919 + 3); const n = 4 + Math.floor(amt * 18);
  for (let i = 0; i < n; i++) { const y = Math.floor(r() * H), h = Math.floor(6 + r() * 90 * amt), dx = Math.floor((r() - .5) * 240 * amt); g.drawImage(TMP, 0, y, W, h, dx, y, W, h); }
  g.save(); g.globalCompositeOperation = 'lighter'; g.globalAlpha = .3 * amt; g.drawImage(TMP, -14 * amt, 0); g.restore();
  noise(.45 * amt, f + 1, 'source-over');
  g.save(); for (let i = 0; i < 4; i++) { g.globalAlpha = .35 * amt; g.fillStyle = ['#ff2a6d', '#29f0ff', '#ffffff', C.teal][i]; g.fillRect(0, r() * H, W, 2 + r() * 8); } g.restore();
}

/* ---------- speech bubble (reference style) ---------- */
const BUBBLES = []; // filled per scene for event export
function bubble(text, x, y, t0, t1, t, o = {}) {
  if (t < t0 || t > t1 + .2) return;
  const s = E.back(inv(t0, t0 + .28, t)) * (1 - E.in3(inv(t1, t1 + .18, t))); if (s <= .001) return;
  const size = o.size || 31, f = font(700, size, 'Poppins'); const lines = wrap(text, o.maxW || 380, f); const lh = size * 1.2;
  let w = 0; lines.forEach(l => { w = Math.max(w, measure(l, f)); }); w += 50; const h = lines.length * lh + 30; const tl = 30;
  const shift = o.shift || 0; const bx = -w / 2 + shift, by = -tl - h;
  g.save(); g.translate(x, y); g.rotate(o.rot || 0); g.scale(s, s);
  const path = () => { g.beginPath(); g.roundRect(bx, by, w, h, 24); g.moveTo(-16 + (o.tail || 0) * .35, -tl - 12); g.lineTo(o.tail || 0, 0); g.lineTo(16 + (o.tail || 0) * .35, -tl - 12); g.closePath(); };
  g.save(); g.translate(0, 7); path(); g.fillStyle = 'rgba(0,0,0,.35)'; g.fill(); g.restore();
  path(); g.lineJoin = 'round'; g.lineWidth = 9; g.strokeStyle = '#151515'; g.stroke(); g.fillStyle = '#fff'; g.fill();
  let n = Math.floor((t - t0) * 52); g.font = f; g.fillStyle = '#161616'; g.textAlign = 'center'; g.textBaseline = 'middle';
  lines.forEach((l, i) => { const shown = l.slice(0, clamp(n, 0, l.length)); n -= l.length + 1;
    const lw = measure(l, f); g.textAlign = 'left'; g.fillText(shown, shift - lw / 2, by + 15 + lh * (i + .5) + 1); });
  g.restore();
}
const talk = (t, t0, t1) => (t > t0 && t < t1) ? 1 + .035 * Math.abs(Math.sin((t - t0) * 15)) : 1;

/* =========================================================================================
   SCENE 1 — CRT boot (0 – 5.2)
   ========================================================================================= */
const BOOT = [
  { t: .15, s: 'TRIPPI TRANSIT CONTROL    v1.999' },
  { t: .38, s: '(C) 1999 TRIPPI TOWN TRANSIT AUTHORITY', dim: 1 },
  { t: .62, rule: 1 },
  { t: .75, s: 'SPOT VAULT ......... 300 WL/GTD', r: 'OK' },
  { t: 1.0, s: 'CASH BUDGET ........ $0', r: 'NONE', rc: '#ff6262' },
  { t: 1.25, s: 'COLLAB LINE ........', r: 'OFFLINE', rc: '#ffd04d' },
  { t: 1.5, s: 'KOL LINE ...........', r: 'OFFLINE', rc: '#ffd04d' },
  { t: 1.75, rule: 1 },
  { t: 1.9, s: 'OPERATOR LOGIN - ENCORE STUDIO' },
  { t: 2.15, s: 'PASSCODE ... ', type: '*******', tt: 2.32 },
  { t: 2.95, s: 'VERIFYING', dots: 1 },
];
function sBoot(t, f) {
  g.fillStyle = '#010805'; g.fillRect(0, 0, W, H);
  const gr = g.createRadialGradient(540, 520, 40, 540, 540, 720); gr.addColorStop(0, 'rgba(18,84,48,.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
  const GR = '#73ffab', DIM = '#34c470'; const x0 = 92; let y = 176; const LH = 50;
  g.save(); g.globalAlpha = .9 + .1 * hash(f * 3.1); g.shadowColor = 'rgba(90,255,160,.85)'; g.shadowBlur = 16; g.font = font(400, 46, 'VT');
  for (const r of BOOT) {
    if (t >= r.t) {
      if (r.rule) { g.fillStyle = DIM; g.fillRect(x0, y - 18, 880 * E.out3(inv(r.t, r.t + .25, t)), 3); }
      else {
        const n = Math.floor((t - r.t) * 80); g.fillStyle = r.dim ? DIM : GR; g.fillText(r.s.slice(0, n), x0, y);
        const w = g.measureText(r.s).width;
        if (r.r && n >= r.s.length + 3) { g.fillStyle = r.rc || GR; g.fillText(r.r, 830, y); }
        if (r.type) { const m = clamp(Math.floor((t - r.tt) / .08), 0, r.type.length); g.fillStyle = GR; g.fillText(r.type.slice(0, m), x0 + w, y);
          if (t < 2.95 && Math.floor(t * 4) % 2 === 0) g.fillRect(x0 + w + g.measureText(r.type.slice(0, m)).width + 4, y - 34, 22, 38); }
        if (r.dots && t < 3.45) g.fillText('.'.repeat(1 + Math.floor((t - r.t) * 7) % 3), x0 + w, y);
        if (r.dots && t >= 3.45) g.fillText('... OK', x0 + w, y);
      }
    }
    y += LH;
  }
  if (t > 3.45) {
    const k = E.back2(inv(3.45, 3.68, t)); const bl = t < 3.95 ? (Math.floor(t * 12) % 2 ? 1 : .55) : 1;
    g.save(); g.translate(540, y + 32); g.scale(k, k); g.globalAlpha *= bl; g.fillStyle = GR; g.shadowBlur = 34; g.fillRect(-330, -46, 660, 92);
    g.shadowBlur = 0; g.fillStyle = '#03140a'; g.font = font(400, 70, 'VT'); g.textAlign = 'center'; g.fillText('ACCESS GRANTED', 0, 22); g.restore();
  }
  if (t > 3.92) {
    const yy = y + 138; const k = inv(3.95, 4.85, t); const N = 22; const fill = Math.floor(k * N);
    g.fillStyle = DIM; g.fillText('LOADING SPOT DISPATCH', x0, yy); const w = g.measureText('LOADING SPOT DISPATCH ').width;
    g.fillStyle = GR; g.fillText('[' + '#'.repeat(fill) + '.'.repeat(N - fill) + ']', x0 + w, yy);
  }
  g.restore();
  g.drawImage(SCAN, 0, 0); noise(.07, f); g.drawImage(VIG, 0, 0); bezel();
  if (t > 4.92) { // CRT collapse
    const k = E.in3(inv(4.92, 5.14, t)); tg.setTransform(1, 0, 0, 1, 0, 0); tg.clearRect(0, 0, W, H); tg.drawImage(cv, 0, 0);
    g.fillStyle = '#000'; g.fillRect(0, 0, W, H); const sy = Math.max(.003, 1 - k); g.drawImage(TMP, 0, 540 - 540 * sy, W, H * sy);
    g.save(); g.globalAlpha = k; g.fillStyle = '#dfffe9'; g.shadowColor = '#7dffb0'; g.shadowBlur = 30; const lw = W * (1 - k * .7); g.fillRect(540 - lw / 2, 538, lw, 4); g.restore();
  }
}

/* =========================================================================================
   SCENE 2 — CAM 09 · PLATFORM 09 (5.2 – 13.0)
   ========================================================================================= */
const PL = { mush: [1.7, 4.0], honey: [3.85, 5.75], cone: [5.6, 7.3] };
function sPlatform(t, f) {
  const lt = t - 5.2;
  g.save(); const z = 1.0 + .045 * E.io2(inv(0, 7.8, lt)); g.translate(540, 620); g.scale(z, z); g.translate(-540, -620);
  // wall
  let gr = g.createLinearGradient(0, 0, 0, 660); gr.addColorStop(0, '#0f1716'); gr.addColorStop(1, '#25332f'); g.fillStyle = gr; g.fillRect(-60, -60, W + 120, 740);
  for (let row = 0, y = 168; y < 660; y += 34, row++) for (let x = -60 + (row % 2) * 34; x < W + 60; x += 68) {
    const h = hash(row * 31 + x * .17); g.fillStyle = `rgba(${170 + h * 30 | 0},${200 + h * 20 | 0},${190},${.07 + h * .07})`; g.beginPath(); g.roundRect(x + 2, y + 2, 64, 30, 3); g.fill();
  }
  g.fillStyle = '#0d7a62'; g.fillRect(-60, 520, W + 120, 38); g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(-60, 520, W + 120, 4);
  // grime drips
  for (let i = 0; i < 26; i++) { const x = hash(i * 7.3) * W; const hh = 40 + hash(i * 3.1) * 160; const gg = g.createLinearGradient(0, 168, 0, 168 + hh); gg.addColorStop(0, 'rgba(0,0,0,.35)'); gg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gg; g.fillRect(x, 168, 6 + hash(i) * 14, hh); }
  // wall graffiti (Trippi tag) + small tags
  g.save(); g.translate(250, 405); g.rotate(-.06); g.globalAlpha = .93; const lw = 380; g.drawImage(IMG.logo, -lw / 2, -lw * IMG.logo.height / IMG.logo.width / 2, lw, lw * IMG.logo.height / IMG.logo.width); g.restore();
  g.save(); g.globalAlpha = .55; g.drawImage(GRAFF, 0, 0, 1000, 400, 560, 300, 520, 208); g.restore();
  // ceiling + lights
  g.fillStyle = '#070b0b'; g.fillRect(-60, -60, W + 120, 120);
  [150, 540, 930].forEach((lx, i) => {
    const fl = i === 2 ? (hash(Math.floor(t * 9)) > .8 ? .25 : 1) : 1;
    g.save(); g.globalAlpha = fl; const cone = g.createRadialGradient(lx, 60, 10, lx, 260, 420); cone.addColorStop(0, 'rgba(210,255,240,.22)'); cone.addColorStop(1, 'rgba(210,255,240,0)'); g.fillStyle = cone; g.fillRect(lx - 420, 40, 840, 700);
    g.shadowColor = '#d8fff2'; g.shadowBlur = 40; g.fillStyle = '#f0fffa'; g.beginPath(); g.roundRect(lx - 120, 52, 240, 14, 7); g.fill(); g.restore();
  });
  // station sign
  g.save(); g.translate(612, 122); g.strokeStyle = '#1b2422'; g.lineWidth = 4; g.beginPath(); g.moveTo(-180, -50); g.lineTo(-180, -20); g.moveTo(180, -50); g.lineTo(180, -20); g.stroke();
  g.fillStyle = '#0a3d31'; g.beginPath(); g.roundRect(-262, -26, 524, 62, 12); g.fill(); g.strokeStyle = '#d7efe6'; g.lineWidth = 3; g.stroke();
  txt('PLATFORM 09  •  LAST TRAIN 23:09', 0, 15, { font: font(700, 29), align: 'center', color: '#f1fff9', ls: 1 }); g.restore();
  // clock
  g.save(); g.translate(946, 128); g.fillStyle = '#e9efe9'; g.beginPath(); g.arc(0, 0, 44, 0, 7); g.fill(); g.strokeStyle = '#222'; g.lineWidth = 5; g.stroke();
  const sec = 540 + t; g.lineCap = 'round'; g.strokeStyle = '#111'; g.lineWidth = 5; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -24); g.stroke(); // 23h ~ near 12
  g.lineWidth = 4; const ma = (sec / 3600) * Math.PI * 2; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.sin(ma) * 34, -Math.cos(ma) * 34); g.stroke();
  g.strokeStyle = '#d33'; g.lineWidth = 2; const sa = (sec % 60) / 60 * Math.PI * 2; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.sin(sa) * 36, -Math.cos(sa) * 36); g.stroke(); g.restore();
  // track pit
  g.fillStyle = '#080b0b'; g.fillRect(-60, 600, W + 120, 64); g.fillStyle = 'rgba(200,220,215,.25)'; g.fillRect(-60, 640, W + 120, 3);
  // train
  const tw = 900, th = tw * IMG.train.height / IMG.train.width; const ty = 664 - th;
  const xAt = l => lerp(1700, 90, E.out3(inv(0, 2.5, l)));
  const x0 = xAt(lt), v = x0 - xAt(lt - 1 / 60); const shake = Math.sin(lt * 40) * 2 * (1 - inv(2.3, 2.9, lt)) * inv(1.6, 2.2, lt);
  const drawTrain = (x, a) => { g.save(); g.globalAlpha = a; for (let k = -1; k <= 1; k++) g.drawImage(IMG.train, x + k * (tw + 10), ty + shake, tw, th); g.restore(); };
  if (Math.abs(v) > 2) for (let k = 5; k >= 1; k--) drawTrain(x0 - v * k * .9, .12);
  drawTrain(x0, 1);
  if (lt < 2.6) { g.save(); g.globalAlpha = .8 * (1 - inv(2.0, 2.6, lt)); const hl = g.createRadialGradient(x0 - (tw + 10), ty + th * .7, 5, x0 - (tw + 10), ty + th * .7, 260); hl.addColorStop(0, 'rgba(255,240,200,.9)'); hl.addColorStop(1, 'rgba(255,240,200,0)'); g.fillStyle = hl; g.fillRect(x0 - tw - 280, ty, 560, th); g.restore(); }
  // platform floor
  gr = g.createLinearGradient(0, 664, 0, 1140); gr.addColorStop(0, '#6e7471'); gr.addColorStop(1, '#2a2e2d'); g.fillStyle = gr; g.fillRect(-60, 664, W + 120, 520);
  g.save(); g.globalAlpha = .12; g.translate(0, 1328); g.scale(1, -1); for (let k = -1; k <= 1; k++) g.drawImage(IMG.train, x0 + k * (tw + 10), ty, tw, th); g.restore();
  g.fillStyle = '#e1ae25'; g.fillRect(-60, 664, W + 120, 44); g.fillStyle = 'rgba(120,80,0,.45)';
  for (let x = -40; x < W + 60; x += 18) for (let yy = 672; yy < 704; yy += 14) { g.beginPath(); g.arc(x + ((yy / 14) % 2) * 9, yy, 3.2, 0, 7); g.fill(); }
  g.fillStyle = '#f4f4ee'; g.fillRect(-60, 662, W + 120, 4);
  g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 2; for (let i = -8; i <= 8; i++) { g.beginPath(); g.moveTo(540 + i * 90, 708); g.lineTo(540 + i * 260, 1140); g.stroke(); }
  // characters behind bench
  const bw = 620, bh = bw * IMG['station-bench-wide'].height / IMG['station-bench-wide'].width;
  shadowEllipse(400, 998, 330, 26, .35); shadowEllipse(868, 968, 120, 20, .4);
  const breath = k => 1 + .012 * Math.sin(t * 2.2 + k);
  sprite(IMG.mushroom, 255, 772, 332, { sy: breath(0) * talk(t, 5.2 + PL.mush[0], 5.2 + PL.mush[0] + 1.3) });
  sprite(IMG.honey, 572, 735, 300, { sy: breath(1.7) * talk(t, 5.2 + PL.honey[0], 5.2 + PL.honey[0] + 1.0), rot: Math.sin(t * 1.3) * .015 });
  g.drawImage(IMG['station-bench-wide'], 90, 992 - bh, bw, bh);
  sprite(IMG.cone, 868, 968, 238, { sy: breath(3) * talk(t, 5.2 + PL.cone[0], 5.2 + PL.cone[0] + .9), rot: Math.sin(t * 1.1) * .02 });
  // dust motes
  g.save(); for (let i = 0; i < 46; i++) { const px = (hash(i * 1.7) * W + t * (8 + hash(i) * 14)) % W; const py = 120 + ((hash(i * 2.3) * 560 + t * 10 * hash(i * 5)) % 560); g.globalAlpha = .18 + .25 * hash(i * 9); g.fillStyle = '#e8fff8'; g.beginPath(); g.arc(px, py, 1 + hash(i * 4) * 2, 0, 7); g.fill(); } g.restore();
  // dialogue
  bubble('Free mint. 1,999 of us. And nobody outside town knows we exist.', 262, 438, PL.mush[0], PL.mush[1], lt, { maxW: 420, tail: -10, shift: 70 });
  bubble("We've got spots. We've got zero budget.", 580, 428, PL.honey[0], PL.honey[1], lt, { maxW: 360, tail: 0 });
  bubble('Bro... spots ARE the budget.', 850, 728, PL.cone[0], PL.cone[1], lt, { maxW: 300, tail: 14, shift: -40 });
  g.restore();
  cctv(t, f, 'CAM 09 · PLATFORM 09');
  // incoming signal
  if (lt > 7.05) {
    const k = inv(7.05, 7.25, lt); g.save(); g.globalAlpha = k; g.fillStyle = 'rgba(0,0,0,.72)'; g.fillRect(0, 470, W, 140);
    const bl = Math.floor(t * 8) % 2 ? 1 : .35;
    txt('INCOMING SIGNAL', 540, 532, { font: font(700, 44, 'GeistMono'), align: 'center', color: '#ffffff', ls: 6, alpha: bl });
    txt('ENCORE STUDIO  ·  SPOT DISPATCH ONLINE', 540, 578, { font: font(500, 24, 'GeistMono'), align: 'center', color: C.tealL, ls: 3 });
    g.restore(); glitch(f, inv(7.3, 7.8, lt) * .8);
  }
}

/* =========================================================================================
   SCENE 3 — THE GAME: SPOT DISPATCH (13.0 – 31.5), local time u
   ========================================================================================= */
const HUB = { x: 540, y: 557 };
const RING = { x: 835, y: 557, r: 185 };
const LINES = [
  { id: 'A', color: C.pink, pts: [[540, 557], [450, 467], [300, 467], [220, 387], [220, 300]] },
  { id: 'B', color: C.honey, pts: [[540, 557], [120, 557]] },
  { id: 'C', color: C.green, pts: [[540, 557], [450, 647], [300, 647], [220, 727], [220, 832]] },
  { id: 'T', color: C.cyan, pts: [[540, 557], [650, 557]] },
];
const LINE = Object.fromEntries(LINES.map(l => [l.id, l]));
function mkPath(pts) { const c = [0]; for (let i = 1; i < pts.length; i++) c.push(c[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])); return { pts, c, len: c[c.length - 1] }; }
function pAt(p, s) {
  s = clamp(s, 0, p.len); let i = 1; while (i < p.c.length - 1 && p.c[i] < s) i++;
  const a = p.pts[i - 1], b = p.pts[i]; const seg = (p.c[i] - p.c[i - 1]) || 1; const k = (s - p.c[i - 1]) / seg;
  return { x: lerp(a[0], b[0], k), y: lerp(a[1], b[1], k), ang: Math.atan2(b[1] - a[1], b[0] - a[0]) };
}
function tracePath(p, upto) {
  g.beginPath(); g.moveTo(p.pts[0][0], p.pts[0][1]);
  for (let i = 1; i < p.pts.length; i++) {
    if (p.c[i] <= upto) g.lineTo(p.pts[i][0], p.pts[i][1]);
    else { const q = pAt(p, upto); g.lineTo(q.x, q.y); break; }
  }
}
LINES.forEach(l => { l.path = mkPath(l.pts); });
function truncate(line, pt) { // path from hub to station on that line
  const out = [line.pts[0]];
  for (let i = 1; i < line.pts.length; i++) {
    const a = line.pts[i - 1], b = line.pts[i];
    const cross = (pt[0] - a[0]) * (b[1] - a[1]) - (pt[1] - a[1]) * (b[0] - a[0]);
    const within = Math.min(a[0], b[0]) - 1 <= pt[0] && pt[0] <= Math.max(a[0], b[0]) + 1 && Math.min(a[1], b[1]) - 1 <= pt[1] && pt[1] <= Math.max(a[1], b[1]) + 1;
    if (Math.abs(cross) < 1 && within) { out.push(pt); return mkPath(out); }
    out.push(b);
  }
  return mkPath(out);
}
const PARTNERS = [
  { n: '01', line: 'A', at: [370, 467], lab: 'up', sub: 'PFP · 6.1K', t0: 2.0, cost: 20, reach: 52000, apps: 500 },
  { n: '02', line: 'C', at: [370, 647], lab: 'down', sub: 'ART · 4.8K', t0: 2.45, cost: 15, reach: 61000, apps: 560 },
  { n: '03', line: 'B', at: [390, 557], lab: 'up', sub: 'PFP · 9.4K', t0: 3.6, cost: 25, reach: 94000, apps: 980 },
  { n: '04', line: 'B', at: [200, 557], lab: 'up', sub: 'GAME · 3.2K', t0: 6.55, cost: 15, reach: 38000, apps: 380 },
  { n: '05', line: 'A', at: [220, 387], lab: 'left', sub: 'PFP · 5.5K', t0: 6.75, cost: 20, reach: 57000, apps: 620 },
  { n: '06', line: 'C', at: [220, 727], lab: 'left', sub: 'DAO · 2.9K', t0: 6.95, cost: 15, reach: 41000, apps: 420 },
  { n: '07', line: 'A', at: [220, 300], lab: 'left', sub: 'ART · 7.0K', t0: 7.15, cost: 25, reach: 60000, apps: 640 },
  { n: '08', line: 'C', at: [220, 832], lab: 'left', sub: 'PFP · 3.9K', t0: 7.35, cost: 15, reach: 44000, apps: 500 },
];
const KFOL = [38, 52, 21, 96, 44, 18, 71, 29, 63, 35, 88, 24];
const KOLS = KFOL.map((fk, i) => {
  const th = (210 + i * 300 / 11) * Math.PI / 180; let d = th - Math.PI; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
  return { n: String(i + 1).padStart(2, '0'), th, d, f: fk, cost: 4, reach: fk * 1400, apps: 3812 * fk / 579, at: [RING.x + RING.r * Math.cos(th), RING.y + RING.r * Math.sin(th)] };
});
KOLS.slice().sort((a, b) => Math.abs(a.d) - Math.abs(b.d) || a.d - b.d).forEach((k, j) => { k.t0 = 10.0 + j * .34; });
const DEALS = [];
PARTNERS.forEach((p, i) => { const path = truncate(LINE[p.line], p.at); const dur = .5 + path.len / 450; DEALS.push({ kind: 'collab', i, ref: p, path, t0: p.t0, dur, arrive: p.t0 + dur, cost: p.cost, reach: p.reach, apps: p.apps, color: LINE[p.line].color, tag: '−' + p.cost + ' GTD', label: 'P' + p.n }); });
KOLS.forEach((k, i) => {
  const pts = [[540, 557], [RING.x - RING.r, 557]]; const N = Math.max(2, Math.ceil(Math.abs(k.d) / .12));
  for (let s = 1; s <= N; s++) { const a = Math.PI + k.d * s / N; pts.push([RING.x + RING.r * Math.cos(a), RING.y + RING.r * Math.sin(a)]); }
  const path = mkPath(pts); const dur = .5 + path.len / 520;
  DEALS.push({ kind: 'kol', i, ref: k, path, t0: k.t0, dur, arrive: k.t0 + dur, cost: k.cost, reach: k.reach, apps: k.apps, color: C.cyan, tag: '−4 WL', label: 'KOL ' + k.n });
});
const COLLAB_DONE = Math.max(...DEALS.filter(d => d.kind === 'collab').map(d => d.arrive));
const KOL_DONE = Math.max(...DEALS.filter(d => d.kind === 'kol').map(d => d.arrive));
const LOG = DEALS.slice().sort((a, b) => a.arrive - b.arrive);
const CAMS = [
  { a: 1.6, b: 2.7, x: 365, y: 560, z: 1.35 },
  { a: 3.2, b: 3.95, x: 262, y: 557, z: 1.85 },
  { a: 6.45, b: 7.3, x: 335, y: 566, z: 1.28 },
  { a: 8.9, b: 9.95, x: 895, y: 557, z: 1.15 },
  { a: 15.7, b: 16.8, x: 598, y: 565, z: .88 },
];
function camAt(u) {
  let c = { x: 540, y: 557, z: 1 };
  for (const m of CAMS) { const k = E.io3(inv(m.a, m.b, u)); if (k <= 0) break; c = { x: lerp(c.x, m.x, k), y: lerp(c.y, m.y, k), z: lerp(c.z, m.z, k) }; }
  c.x += Math.sin(u * .7) * 3; c.y += Math.cos(u * .55) * 2; return c;
}
function stats(u) {
  let spots = 0, reach = 0, apps = 0, col = 0, kol = 0;
  for (const d of DEALS) {
    if (u >= d.arrive) { spots += d.cost * E.out3(inv(d.arrive, d.arrive + .35, u)); if (d.kind === 'collab') col++; else kol++; }
    reach += d.reach * E.out3(inv(d.arrive, d.arrive + 2.2, u)); apps += d.apps * E.out3(inv(d.arrive + .4, d.arrive + 2.0, u));
  }
  return { spots, reach, apps, col, kol };
}
const MAPY = 222, MAPH = 670;
const BLOCKS = (() => { const r = mulberry(77), b = []; for (let i = 0; i < 70; i++) b.push([60 + r() * 960, 240 + r() * 640, 30 + r() * 70, 20 + r() * 50]); return b; })();

function drawLine(l, upto, u) {
  const p = l.path; g.lineCap = 'round'; g.lineJoin = 'round';
  g.save(); tracePath(p, upto); g.strokeStyle = l.color; g.globalAlpha = .22; g.lineWidth = 26; g.shadowColor = l.color; g.shadowBlur = 24; g.stroke(); g.restore();
  tracePath(p, upto); g.strokeStyle = '#0b1719'; g.lineWidth = 15; g.stroke();
  tracePath(p, upto); g.strokeStyle = l.color; g.lineWidth = 10; g.stroke();
  tracePath(p, upto); g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 2.5; g.stroke();
}
function flowOverlay(path, color, u, alpha) { // energy dashes on an active route
  g.save(); g.globalAlpha = alpha; tracePath(path, path.len); g.setLineDash([5, 23]); g.lineDashOffset = u * 70; g.strokeStyle = '#ffffff'; g.lineWidth = 4; g.lineCap = 'round'; g.shadowColor = color; g.shadowBlur = 12; g.stroke(); g.restore();
}
function drawRing(k) {
  const a0 = Math.PI, a1 = Math.PI + Math.PI * 2 * k;
  const R = () => { g.beginPath(); g.arc(RING.x, RING.y, RING.r, a0, a1); };
  g.save(); R(); g.strokeStyle = C.cyan; g.globalAlpha = .22; g.lineWidth = 26; g.shadowColor = C.cyan; g.shadowBlur = 24; g.stroke(); g.restore();
  R(); g.strokeStyle = '#0b1719'; g.lineWidth = 15; g.stroke(); R(); g.strokeStyle = C.cyan; g.lineWidth = 10; g.stroke(); R(); g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 2.5; g.stroke();
}
function check(x, y, s, col = '#fff', lw = 3.5) { g.save(); g.strokeStyle = col; g.lineWidth = lw; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); g.moveTo(x - s * .5, y); g.lineTo(x - s * .12, y + s * .38); g.lineTo(x + s * .55, y - s * .4); g.stroke(); g.restore(); }
function personGlyph(x, y, s, col) { g.save(); g.fillStyle = col; g.beginPath(); g.arc(x, y - s * .25, s * .3, 0, 7); g.fill(); g.beginPath(); g.ellipse(x, y + s * .45, s * .52, s * .38, 0, Math.PI, 0); g.fill(); g.restore(); }
function labelBox(x, y, title, sub, color, alpha, align) {
  const f1 = font(700, 15, 'GeistMono'), f2 = font(500, 13, 'GeistMono');
  const w = Math.max(measure(title, f1, 1), measure(sub, f2)) + 22, h = sub ? 42 : 26;
  let bx = align === 'right' ? x - w : align === 'left' ? x : x - w / 2; const by = y - h / 2;
  g.save(); g.globalAlpha *= alpha; g.fillStyle = 'rgba(7,18,21,.9)'; g.beginPath(); g.roundRect(bx, by, w, h, 8); g.fill(); g.strokeStyle = color; g.lineWidth = 1.6; g.stroke();
  txt(title, bx + 11, by + 18, { font: f1, ls: 1, color: '#f2fffb' }); if (sub) txt(sub, bx + 11, by + 35, { font: f2, color: '#8eb7ad' }); g.restore();
}
function trainCar(x, y, ang, color, s = 1) {
  g.save(); g.translate(x, y); g.rotate(ang); g.scale(s, s);
  g.shadowColor = color; g.shadowBlur = 18; g.fillStyle = '#eaf6f2'; g.beginPath(); g.roundRect(-20, -9, 40, 18, 8); g.fill(); g.shadowBlur = 0;
  g.fillStyle = color; g.fillRect(-20, 2, 40, 4); g.fillStyle = '#0d2a2a'; for (let i = -1; i <= 1; i++) { g.beginPath(); g.roundRect(i * 11 - 4, -6, 8, 6, 2); g.fill(); }
  g.fillStyle = '#fff6c8'; g.shadowColor = '#fff3b0'; g.shadowBlur = 16; g.beginPath(); g.arc(19, 0, 3, 0, 7); g.fill(); g.restore();
}
function costChip(x, y, text, color) {
  const f = font(800, 13, 'GeistMono'); const w = measure(text, f) + 14;
  g.save(); g.fillStyle = color; g.beginPath(); g.roundRect(x - w / 2, y - 10, w, 20, 6); g.fill(); txt(text, x, y + 5, { font: f, align: 'center', color: '#111' }); g.restore();
}

function sGame(t, f) {
  const u = t - 13; const st = stats(u); const cam = camAt(u);
  // background
  g.fillStyle = '#051013'; g.fillRect(0, 0, W, H);
  g.save(); g.beginPath(); g.rect(0, MAPY, W, MAPH); g.clip();
  const hubS = { x: 540 + (HUB.x - cam.x) * cam.z, y: 557 + (HUB.y - cam.y) * cam.z };
  let gr = g.createRadialGradient(hubS.x, hubS.y, 10, hubS.x, hubS.y, 620 * cam.z); gr.addColorStop(0, 'rgba(18,162,131,.22)'); gr.addColorStop(1, 'rgba(18,162,131,0)'); g.fillStyle = gr; g.fillRect(0, MAPY, W, MAPH);
  g.save(); g.translate(540, 557); g.scale(cam.z, cam.z); g.translate(-cam.x, -cam.y);
  const ga = E.out3(inv(0, .6, u));
  // grid + city blocks + watermark
  g.save(); g.globalAlpha = ga;
  for (let x = -400; x <= 1500; x += 45) { g.strokeStyle = x % 180 === 0 ? 'rgba(80,220,190,.10)' : 'rgba(80,220,190,.045)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x, -200); g.lineTo(x, 1300); g.stroke(); }
  for (let y = -200; y <= 1300; y += 45) { g.strokeStyle = y % 180 === 0 ? 'rgba(80,220,190,.10)' : 'rgba(80,220,190,.045)'; g.beginPath(); g.moveTo(-400, y); g.lineTo(1500, y); g.stroke(); }
  g.fillStyle = 'rgba(120,230,200,.035)'; BLOCKS.forEach(b => { g.beginPath(); g.roundRect(b[0], b[1], b[2], b[3], 6); g.fill(); });
  g.globalAlpha = ga * .05; g.drawImage(IMG.logo, 140, 380, 800, 800 * IMG.logo.height / IMG.logo.width); g.restore();
  // lines draw-on
  LINES.forEach((l, i) => { const k = E.io2(inv(.45 + i * .12, 1.35 + i * .12, u)); if (k > 0) drawLine(l, l.path.len * k, u); });
  const rk = E.io2(inv(.9, 1.7, u)); if (rk > 0) drawRing(rk);
  // active-route energy
  DEALS.forEach(d => { if (u > d.arrive) flowOverlay(d.path, d.color, u + d.i * .3, .55 * inv(d.arrive, d.arrive + .5, u)); });
  // stations — partners
  PARTNERS.forEach((p, i) => {
    const d = DEALS[i]; const line = LINE[p.line]; const appear = E.back(inv(.9 + i * .06, 1.25 + i * .06, u)); if (appear <= 0) return;
    const signed = u >= d.arrive; const [x, y] = p.at;
    g.save(); g.translate(x, y); g.scale(appear, appear);
    if (signed) { const pk = inv(d.arrive, d.arrive + .9, u); if (pk < 1) { g.save(); g.globalAlpha = 1 - pk; g.strokeStyle = line.color; g.lineWidth = 4; g.beginPath(); g.arc(0, 0, 16 + pk * 46, 0, 7); g.stroke(); g.restore(); }
      g.shadowColor = line.color; g.shadowBlur = 20 + 8 * Math.sin(u * 4 + i); g.fillStyle = line.color; g.beginPath(); g.arc(0, 0, 17, 0, 7); g.fill(); g.shadowBlur = 0; g.strokeStyle = '#fff'; g.lineWidth = 4; g.stroke(); check(0, 0, 14, '#0b1719', 4); }
    else { g.fillStyle = '#f5fffc'; g.beginPath(); g.arc(0, 0, 15, 0, 7); g.fill(); g.strokeStyle = line.color; g.lineWidth = 6; g.stroke(); }
    g.restore();
    const title = 'PARTNER ' + p.n; const lx = p.lab === 'left' ? x - 28 : x, ly = p.lab === 'up' ? y - 46 : p.lab === 'down' ? y + 46 : y;
    labelBox(lx, ly, title, signed ? 'SIGNED · ' + p.cost + ' GTD' : p.sub, signed ? line.color : 'rgba(150,200,190,.5)', appear * (signed ? 1 : .85), p.lab === 'left' ? 'right' : 'center');
  });
  // stations — KOLs
  KOLS.forEach((k, i) => {
    const d = DEALS[8 + i]; const appear = E.back(inv(1.3 + i * .035, 1.65 + i * .035, u)); if (appear <= 0) return;
    const live = u >= d.arrive; const [x, y] = k.at;
    g.save(); g.translate(x, y); g.scale(appear, appear);
    if (live) { const pk = inv(d.arrive, d.arrive + .9, u); if (pk < 1) { g.save(); g.globalAlpha = 1 - pk; g.strokeStyle = C.cyan; g.lineWidth = 4; g.beginPath(); g.arc(0, 0, 20 + pk * 44, 0, 7); g.stroke(); g.restore(); } g.shadowColor = C.cyan; g.shadowBlur = 22; }
    const grd = g.createLinearGradient(0, -20, 0, 20); grd.addColorStop(0, live ? '#7cf3ff' : '#40585a'); grd.addColorStop(1, live ? '#139fb3' : '#22383a');
    g.fillStyle = grd; g.beginPath(); g.arc(0, 0, 21, 0, 7); g.fill(); g.shadowBlur = 0; g.strokeStyle = live ? '#fff' : 'rgba(160,220,220,.6)'; g.lineWidth = 3; g.stroke();
    g.save(); g.beginPath(); g.arc(0, 0, 19, 0, 7); g.clip(); personGlyph(0, 3, 26, live ? '#063a42' : '#7c9c9c'); g.restore();
    g.restore();
    const lx = RING.x + (RING.r + 44) * Math.cos(k.th), ly = RING.y + (RING.r + 40) * Math.sin(k.th); const c = Math.cos(k.th);
    labelBox(lx + (c > .3 ? -14 : c < -.3 ? 14 : 0), ly, 'KOL ' + k.n, live ? 'LIVE · ' + k.f + 'K' : k.f + 'K', live ? C.cyan : 'rgba(150,200,190,.5)', appear * (live ? 1 : .8), c > .3 ? 'left' : c < -.3 ? 'right' : 'center');
  });
  // trains + chips + trails
  DEALS.forEach(d => {
    if (u < d.t0 || u > d.arrive) return; const k = E.io2((u - d.t0) / d.dur); const s = k * d.path.len; const q = pAt(d.path, s);
    for (let j = 1; j <= 10; j++) { const qq = pAt(d.path, s - j * 7); g.save(); g.globalAlpha = .45 * (1 - j / 10); g.fillStyle = d.color; g.beginPath(); g.arc(qq.x, qq.y, 5 - j * .35, 0, 7); g.fill(); g.restore(); }
    const back = pAt(d.path, s - 34); costChip(back.x, back.y - 20, d.tag, C.honey);
    trainCar(q.x, q.y, q.ang, d.color, 1.05);
  });
  // arrival fx + returning crew
  DEALS.forEach(d => {
    const end = pAt(d.path, d.path.len);
    const ak = inv(d.arrive, d.arrive + 1.0, u);
    if (ak > 0 && ak < 1) {
      const r = mulberry(d.i * 31 + (d.kind === 'kol' ? 500 : 0));
      for (let j = 0; j < 14; j++) { const a = r() * 7, sp = 30 + r() * 60; const e = E.out3(ak); g.save(); g.globalAlpha = 1 - ak; g.fillStyle = j % 3 ? d.color : '#fff'; g.beginPath(); g.arc(end.x + Math.cos(a) * sp * e, end.y + Math.sin(a) * sp * e, 3.2 * (1 - ak) + 1, 0, 7); g.fill(); g.restore(); }
      txt(d.tag, end.x, end.y - 36 - 40 * E.out3(ak), { font: font(800, 22), align: 'center', color: C.honey, alpha: 1 - E.in3(ak), stroke: '#071214', sw: 5 });
    }
    for (let j = 0; j < 12; j++) {
      const k0 = d.arrive + .2 + j * .08; const kk = inv(k0, k0 + .95, u); if (kk <= 0 || kk >= 1) continue;
      const q = pAt(d.path, d.path.len * (1 - E.io2(kk))); g.save(); g.fillStyle = '#fff'; g.shadowColor = d.color; g.shadowBlur = 10; g.beginPath(); g.arc(q.x, q.y, 3.4, 0, 7); g.fill(); g.restore();
    }
  });
  // hub
  {
    const hk = E.back(inv(.15, .55, u)); const beat = Math.pow(1 - ((u + 13 - 13) % .625) / .625, 3);
    let absorb = 0; DEALS.forEach(d => { const a = d.arrive + 1.1; if (u > a && u < a + .9) absorb = Math.max(absorb, 1 - (u - a) / .9); });
    g.save(); g.translate(HUB.x, HUB.y); g.scale(hk, hk);
    for (let j = 0; j < 2; j++) { const pk = ((u * .8 + j * .5) % 1); g.save(); g.globalAlpha = (1 - pk) * .5; g.strokeStyle = C.teal; g.lineWidth = 3; g.beginPath(); g.roundRect(-80 - pk * 40, -34 - pk * 40, 160 + pk * 80, 68 + pk * 80, 34 + pk * 40); g.stroke(); g.restore(); }
    g.shadowColor = C.teal; g.shadowBlur = 26 + 20 * beat + 30 * absorb; g.fillStyle = '#071a1c'; g.beginPath(); g.roundRect(-80, -34, 160, 68, 34); g.fill(); g.shadowBlur = 0;
    g.strokeStyle = C.tealL; g.lineWidth = 3.5; g.stroke();
    const lw = 116, lh = lw * IMG.logo.height / IMG.logo.width; g.drawImage(IMG.logo, -lw / 2, -lh / 2 - 2, lw, lh);
    g.restore();
    if (hk > .5) labelBox(HUB.x, HUB.y + 58, 'PLATFORM 09', 'HUB', C.teal, inv(.5, .8, u), 'center');
  }
  g.restore(); // camera
  g.restore(); // clip
  // map band edges
  g.fillStyle = 'rgba(80,220,190,.25)'; g.fillRect(0, MAPY, W, 1.5); g.fillRect(0, MAPY + MAPH, W, 1.5);
  hud(u, st, t, f);
  dealCard(u); phoneCard(u);
  banner(u, 1.25, 3.05, '01', 'COLLAB MANAGEMENT', 'We find, pitch, sign and track partner communities.', C.pink);
  banner(u, 8.95, 10.75, '02', 'KOL MANAGEMENT', 'We shortlist, brief, schedule and track every KOL.', C.cyan);
  banner(u, 16.5, 18.45, '$0', 'CASH SPENT: $0', 'Every collab and every KOL paid in spots. Only spots.', C.cash);
  g.drawImage(SCAN2, 0, 0); noise(.05, f); g.drawImage(VIG, 0, 0);
  if (u < .25) { g.save(); g.globalAlpha = 1 - u / .25; g.fillStyle = '#000'; g.fillRect(0, 0, W, H); g.restore(); }
}

function hud(u, st, t, f) {
  const hk = E.out3(inv(.1, .7, u));
  // top bar
  g.save(); g.translate(0, -60 * (1 - hk));
  g.fillStyle = 'rgba(3,12,14,.95)'; g.fillRect(0, 0, W, 56); g.fillStyle = C.teal; g.fillRect(0, 55, W, 2);
  const lw = 66, lh = lw * IMG.logo.height / IMG.logo.width; g.drawImage(IMG.logo, 22, 28 - lh / 2, lw, lh);
  txt('TRANSIT  ·  SPOT DISPATCH', 100, 36, { font: font(700, 20, 'GeistMono'), ls: 2.5, color: '#eafff8' });
  const pul = .5 + .5 * Math.sin(u * 6); g.save(); g.fillStyle = '#ff3b3b'; g.globalAlpha = .6 + .4 * pul; g.shadowColor = '#ff3b3b'; g.shadowBlur = 10; g.beginPath(); g.arc(676, 29, 7, 0, 7); g.fill(); g.restore();
  txt('LIVE', 690, 36, { font: font(700, 18, 'GeistMono'), color: '#fff', ls: 2 });
  txt(clockStr(t).slice(12), 760, 36, { font: font(500, 18, 'GeistMono'), color: '#bfe7dc' });
  g.fillStyle = 'rgba(255,189,46,.15)'; g.beginPath(); g.roundRect(890, 15, 172, 28, 7); g.fill(); g.strokeStyle = 'rgba(255,189,46,.7)'; g.lineWidth = 1.5; g.stroke();
  txt('SAMPLE DATA', 976, 35, { font: font(700, 15, 'GeistMono'), align: 'center', color: C.honey, ls: 2 });
  g.restore();
  // stat tiles
  const tiles = [
    { l: 'SPOT VAULT', v: fmtN(300 - st.spots), sub: 'WL / GTD LEFT', bar: (300 - st.spots) / 300, col: C.honey, icon: 'postmark-frog' },
    { l: 'CASH SPENT', v: '$0.00', sub: 'PAID IN SPOTS ONLY', col: C.cash, cash: 1 },
    { l: 'REACH', v: fmtK(st.reach), sub: 'IMPRESSIONS', col: C.cyan, spark: 1 },
    { l: 'WL APPLICATIONS', v: fmtN(st.apps), sub: 'NEW CREW', col: C.pink, icon: 'postmark-axolotl' },
  ];
  tiles.forEach((tl, i) => {
    const k = E.back(inv(.2 + i * .08, .65 + i * .08, u)); if (k <= 0) return;
    const x = 14 + i * 264, y = 66; g.save(); g.translate(x + 126, y + 50); g.scale(k, k); g.translate(-(x + 126), -(y + 50));
    g.fillStyle = 'rgba(7,22,26,.94)'; g.beginPath(); g.roundRect(x, y, 252, 100, 14); g.fill(); g.strokeStyle = 'rgba(95,224,192,.28)'; g.lineWidth = 1.5; g.stroke();
    g.fillStyle = tl.col; g.fillRect(x + 14, y + 14, 4, 18);
    txt(tl.l, x + 26, y + 29, { font: font(700, 14, 'GeistMono'), ls: 2, color: '#9cc6bb' });
    const flash = tl.cash ? Math.max(0, ...DEALS.map(d => (u > d.arrive && u < d.arrive + .5) ? 1 - (u - d.arrive) / .5 : 0)) : 0;
    txt(tl.v, x + 18, y + 76, { font: font(800, 42), color: tl.cash ? C.cash : '#fff', shadow: tl.cash ? 'rgba(109,255,178,' + (.5 + flash * .5) + ')' : null, blur: tl.cash ? 12 + flash * 20 : 0 });
    txt(tl.sub, x + 20, y + 93, { font: font(500, 11, 'GeistMono'), ls: 1.5, color: tl.col, alpha: .85 });
    if (tl.bar != null) { g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(x + 150, y + 82, 86, 6); g.fillStyle = tl.col; g.fillRect(x + 150, y + 82, 86 * tl.bar, 6); }
    if (tl.icon) { const im = IMG[tl.icon]; const ih = 54; g.save(); g.translate(x + 214, y + 44); g.rotate(i ? .12 : -.12); g.drawImage(im, -ih * im.width / im.height / 2, -ih / 2, ih * im.width / im.height, ih); g.restore(); }
    if (tl.spark) { g.save(); g.strokeStyle = C.cyan; g.lineWidth = 2.5; g.shadowColor = C.cyan; g.shadowBlur = 8; g.beginPath(); for (let j = 0; j <= 20; j++) { const uu = u * (j / 20); const v = stats(uu).reach / 1.3e6; const px = x + 150 + j * 4.3, py = y + 82 - v * 50 - Math.sin(j * 1.7) * 1.5; j ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke(); g.restore(); }
    if (tl.cash) { g.save(); g.translate(x + 216, y + 46); g.strokeStyle = C.cash; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, 20, 0, 7); g.stroke(); g.beginPath(); g.moveTo(-14, 14); g.lineTo(14, -14); g.stroke(); txt('$', 0, 8, { font: font(800, 22), align: 'center', color: C.cash }); g.restore(); }
    g.restore();
  });
  // quest strip
  const quests = [
    { s: 'SIGN 8 PARTNER COLLABS', n: st.col, of: 8, col: C.pink, done: u >= COLLAB_DONE, dt: COLLAB_DONE },
    { s: 'BRIEF 12 KOLS', n: st.kol, of: 12, col: C.cyan, done: u >= KOL_DONE, dt: KOL_DONE },
    { s: 'KEEP CASH AT $0', n: 1, of: 1, col: C.cash, done: true, dt: -9, txt: '$0' },
  ];
  quests.forEach((q, i) => {
    const k = E.out3(inv(.45 + i * .08, .9 + i * .08, u)); if (k <= 0) return; const x = 14 + i * 352, y = 174;
    g.save(); g.globalAlpha = k; const fl = q.dt > 0 ? Math.max(0, 1 - Math.abs(u - q.dt - .2) / .4) : 0;
    g.fillStyle = q.done ? 'rgba(14,44,36,.95)' : 'rgba(7,22,26,.92)'; g.beginPath(); g.roundRect(x, y, 340, 40, 10); g.fill();
    g.strokeStyle = q.done ? q.col : 'rgba(95,224,192,.22)'; g.lineWidth = 1.5 + fl * 3; g.shadowColor = q.col; g.shadowBlur = fl * 30; g.stroke(); g.shadowBlur = 0;
    g.strokeStyle = q.col; g.lineWidth = 2; g.beginPath(); g.roundRect(x + 12, y + 11, 18, 18, 4); g.stroke(); if (q.done) { g.fillStyle = q.col; g.fill(); check(x + 21, y + 20, 11, '#062018', 3); }
    txt(q.s, x + 40, y + 26, { font: font(700, 14, 'GeistMono'), ls: 1, color: '#e8fff8' });
    txt(q.txt || `${q.n}/${q.of}`, x + 326, y + 26, { font: font(800, 17), align: 'right', color: q.col });
    g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(x + 12, y + 35, 316, 2); g.fillStyle = q.col; g.fillRect(x + 12, y + 35, 316 * q.n / q.of, 2);
    g.restore();
  });
  // bottom panel
  const bk = E.out3(inv(.3, .9, u)); g.save(); g.translate(0, 180 * (1 - bk));
  g.fillStyle = 'rgba(3,12,14,.95)'; g.fillRect(0, 898, W, 182); g.fillStyle = 'rgba(95,224,192,.25)'; g.fillRect(0, 898, W, 1.5);
  // log
  txt('DISPATCH LOG', 24, 928, { font: font(700, 13, 'GeistMono'), ls: 2.5, color: '#7faea2' });
  const done = LOG.filter(d => u >= d.arrive).slice(-4);
  done.forEach((d, j) => {
    const yy = 954 + (j - (done.length - 4)) * 26 - 26 * (1 - E.out3(inv(d.arrive, d.arrive + .25, u))) * (j === done.length - 1 ? 1 : 0) + (4 - Math.min(4, done.length)) * 0;
    const sec = Math.floor(540 + 13 + d.arrive) % 60; const a = j === done.length - 1 ? E.out3(inv(d.arrive, d.arrive + .25, u)) : 1;
    txt(`23:09:${String(sec).padStart(2, '0')}`, 24, yy + 18, { font: font(500, 13, 'GeistMono'), color: '#6f9a90', alpha: a });
    txt(d.kind === 'collab' ? `${d.label} SIGNED` : `${d.label} LIVE`, 104, yy + 18, { font: font(700, 13, 'GeistMono'), color: d.color, alpha: a });
    txt(d.tag, 300, yy + 18, { font: font(700, 13, 'GeistMono'), color: C.honey, align: 'right', alpha: a });
  });
  // hotbar
  const vaultG = 160 - DEALS.filter(d => d.kind === 'collab').reduce((s, d) => s + d.cost * E.out3(inv(d.arrive, d.arrive + .35, u)), 0);
  const vaultW = 80 - DEALS.filter(d => d.kind === 'kol').reduce((s, d) => s + d.cost * E.out3(inv(d.arrive, d.arrive + .35, u)), 0);
  const slots = [{ k: 'GTD', im: 'postmark-frog', n: vaultG, key: '1' }, { k: 'FCFS', im: 'code-drop-pass-fcfs', n: 60, key: '2' }, { k: 'WL', im: 'postmark-axolotl', n: vaultW, key: '3' }, { k: 'CASH', lock: 1, key: '4' }];
  const sel = u < 9.0 ? 0 : 2;
  slots.forEach((s, i) => {
    const x = 330 + i * 108, y = 914; const on = i === sel; const lift = on ? 6 : 0;
    g.save(); g.translate(0, -lift);
    g.fillStyle = on ? 'rgba(40,34,10,.95)' : 'rgba(8,26,30,.95)'; g.beginPath(); g.roundRect(x, y, 96, 116, 14); g.fill();
    g.strokeStyle = on ? C.honey : 'rgba(95,224,192,.25)'; g.lineWidth = on ? 3 : 1.5; if (on) { g.shadowColor = C.honey; g.shadowBlur = 18; } g.stroke(); g.shadowBlur = 0;
    txt(s.k, x + 10, y + 20, { font: font(700, 12, 'GeistMono'), ls: 1.5, color: on ? C.honey : '#8fb8ae' });
    txt(s.key, x + 86, y + 20, { font: font(700, 12, 'GeistMono'), align: 'right', color: '#5d8077' });
    if (s.lock) {
      g.save(); g.globalAlpha = .55; g.strokeStyle = '#9bb'; g.lineWidth = 4; g.beginPath(); g.arc(x + 48, y + 52, 12, Math.PI, 0); g.stroke(); g.fillStyle = '#9bb'; g.beginPath(); g.roundRect(x + 32, y + 52, 32, 26, 5); g.fill(); g.restore();
      txt('LOCKED', x + 48, y + 104, { font: font(700, 12, 'GeistMono'), align: 'center', color: '#7c9590', ls: 1.5 });
    } else {
      const im = IMG[s.im]; const ih = 58, iw = Math.min(78, ih * im.width / im.height); g.drawImage(im, x + 48 - iw / 2, y + 28, iw, iw * im.height / im.width > ih ? ih : iw * im.height / im.width);
      txt(fmtN(s.n), x + 86, y + 106, { font: font(800, 22), align: 'right', color: '#fff', stroke: '#061214', sw: 4 });
    }
    g.restore();
  });
  // minimap
  const mx = 776, my = 912, mw = 290, mh = 154; g.fillStyle = 'rgba(8,26,30,.95)'; g.beginPath(); g.roundRect(mx, my, mw, mh, 12); g.fill(); g.strokeStyle = 'rgba(95,224,192,.25)'; g.lineWidth = 1.5; g.stroke();
  txt('NETWORK', mx + 12, my + 20, { font: font(700, 12, 'GeistMono'), ls: 2, color: '#8fb8ae' });
  const sc = .2, ox = mx + 145 - 570 * sc, oy = my + 92 - 566 * sc;
  g.save(); g.translate(ox, oy); g.scale(sc, sc); g.lineCap = 'round';
  LINES.forEach(l => { tracePath(l.path, l.path.len * E.io2(inv(.45, 1.5, u))); g.strokeStyle = l.color; g.lineWidth = 12; g.stroke(); });
  g.beginPath(); g.arc(RING.x, RING.y, RING.r, Math.PI, Math.PI + Math.PI * 2 * E.io2(inv(.9, 1.7, u))); g.strokeStyle = C.cyan; g.lineWidth = 12; g.stroke();
  DEALS.forEach(d => { if (u > d.t0 && u < d.arrive) { const q = pAt(d.path, d.path.len * E.io2((u - d.t0) / d.dur)); g.fillStyle = '#fff'; g.beginPath(); g.arc(q.x, q.y, 14, 0, 7); g.fill(); } });
  g.fillStyle = C.tealL; g.beginPath(); g.arc(HUB.x, HUB.y, 20, 0, 7); g.fill();
  const vw = 540 / cam0(u).z, vh = 335 / cam0(u).z; g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 6; g.strokeRect(cam0(u).x - vw, cam0(u).y - vh, vw * 2, vh * 2);
  g.restore();
  g.restore();
}
function cam0(u) { return camAt(u); }

function banner(u, t0, t1, num, title, sub, col) {
  if (u < t0 || u > t1) return;
  const a = E.out5(inv(t0, t0 + .38, u)), b = E.in3(inv(t1 - .32, t1, u)); const dx = lerp(-1150, 0, a) + lerp(0, 1150, b);
  g.save(); g.translate(dx, 0);
  g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.moveTo(0, 470); g.lineTo(W, 452); g.lineTo(W, 666); g.lineTo(0, 684); g.closePath(); g.fill();
  g.fillStyle = 'rgba(4,13,15,.96)'; g.beginPath(); g.moveTo(0, 462); g.lineTo(W, 446); g.lineTo(W, 656); g.lineTo(0, 672); g.closePath(); g.fill();
  g.fillStyle = col; g.beginPath(); g.moveTo(0, 462); g.lineTo(W, 446); g.lineTo(W, 452); g.lineTo(0, 468); g.fill(); g.beginPath(); g.moveTo(0, 666); g.lineTo(W, 650); g.lineTo(W, 656); g.lineTo(0, 672); g.fill();
  const sw = ((u - t0) * 1.4) % 1.6 - .3; const sg = g.createLinearGradient(sw * W - 200, 0, sw * W + 200, 0); sg.addColorStop(0, 'rgba(255,255,255,0)'); sg.addColorStop(.5, 'rgba(255,255,255,.07)'); sg.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = sg; g.fillRect(0, 446, W, 226);
  g.save(); g.translate(126, 559); g.rotate(-.015); g.shadowColor = col; g.shadowBlur = 30; g.fillStyle = col; g.beginPath(); g.roundRect(-66, -66, 132, 132, 22); g.fill(); g.shadowBlur = 0;
  txt(num, 0, 24, { font: font(800, num.length > 2 ? 56 : 66), align: 'center', color: '#08130f' }); g.restore();
  const tf = font(800, 68); let tw = measure(title, tf); const ts = Math.min(1, 820 / tw);
  g.save(); g.translate(224, 572); g.rotate(-.015); g.scale(ts, ts); txt(title, 0, 0, { font: tf, color: '#fff', ls: -1 }); g.restore();
  g.save(); g.translate(228, 622); g.rotate(-.015); txt(sub, 0, 0, { font: font(500, 27), color: '#bfe9dd' }); g.restore();
  g.restore();
}

function dealCard(u) {
  const t0 = 3.45, t1 = 6.55; if (u < t0 || u > t1) return; const d = DEALS[2];
  const a = E.out5(inv(t0, t0 + .4, u)), b = E.in3(inv(t1 - .3, t1, u));
  const x = lerp(-520, 36, a) - 560 * b, y = 262; const w = 452, h = 470;
  g.save(); g.translate(x + w / 2, y + h / 2); g.rotate(lerp(-.08, -.012, a)); const shake = u > d.arrive + .1 && u < d.arrive + .35 ? Math.sin(u * 120) * 6 * (1 - (u - d.arrive - .1) / .25) : 0; g.translate(-w / 2 + shake, -h / 2);
  g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.roundRect(8, 14, w, h, 20); g.fill();
  g.fillStyle = '#0a1b1f'; g.beginPath(); g.roundRect(0, 0, w, h, 20); g.fill(); g.strokeStyle = C.pink; g.lineWidth = 3; g.stroke();
  g.save(); g.beginPath(); g.roundRect(0, 0, w, 58, [20, 20, 0, 0]); g.clip(); g.fillStyle = C.pink; g.fillRect(0, 0, w, 58); g.restore();
  txt('COLLAB DEAL #03', 22, 38, { font: font(800, 22, 'GeistMono'), color: '#1a0710', ls: 1.5 });
  const signed = u >= d.arrive; txt(signed ? 'SIGNED' : 'NEGOTIATING' + '.'.repeat(1 + Math.floor(u * 5) % 3), w - 20, 37, { font: font(800, 16, 'GeistMono'), color: '#1a0710', align: 'right' });
  txt('PARTNER 03', 22, 112, { font: font(800, 46), color: '#fff', ls: -1 });
  txt('PFP community · 9.4K holders', 24, 144, { font: font(500, 21), color: '#8fb8ae' });
  const rows = [['TRIPPI GIVES', '25 GTD spots', C.honey], ['PARTNER GIVES', 'Joint quest + AMA + pinned post', '#ffffff'], ['CASH', '$0', C.cash], ['TRACKING', 'Every spot logged live', C.tealL]];
  rows.forEach((r, i) => {
    const k = E.out3(inv(t0 + .35 + i * .18, t0 + .6 + i * .18, u)); if (k <= 0) return; const yy = 192 + i * 68;
    g.save(); g.globalAlpha = k; g.translate(20 * (1 - k), 0);
    g.fillStyle = 'rgba(255,255,255,.04)'; g.beginPath(); g.roundRect(18, yy - 2, w - 36, 58, 10); g.fill();
    txt(r[0], 32, yy + 19, { font: font(700, 13, 'GeistMono'), ls: 2, color: '#7fa79d' });
    txt(r[1], 32, yy + 46, { font: font(r[0] === 'CASH' ? 800 : 700, r[0] === 'CASH' ? 26 : 22), color: r[2] });
    g.restore();
  });
  if (u > d.arrive + .1) { const k = inv(d.arrive + .1, d.arrive + .3, u); const s = lerp(2.3, 1, E.out3(k)); g.save(); g.translate(w - 110, h - 105); g.rotate(-.32); g.scale(s, s); g.globalAlpha = Math.min(1, k * 1.6) * .92; g.drawImage(STAMP, -100, -100, 200, 200); g.restore(); }
  g.restore();
}

function phoneCard(u) {
  const t0 = 10.55, t1 = 15.35; if (u < t0 || u > t1) return;
  const a = E.out5(inv(t0, t0 + .45, u)), b = E.in3(inv(t1 - .3, t1, u));
  const w = 292, h = 600, x = lerp(1120, 772, a) + 400 * b, y = 252;
  g.save(); g.translate(x + w / 2, y + h / 2); g.rotate(lerp(.1, .025, a)); g.translate(-w / 2, -h / 2);
  g.fillStyle = 'rgba(0,0,0,.5)'; g.beginPath(); g.roundRect(10, 16, w, h, 44); g.fill();
  g.fillStyle = '#0c0f12'; g.beginPath(); g.roundRect(0, 0, w, h, 44); g.fill(); g.strokeStyle = '#3c5452'; g.lineWidth = 3; g.stroke();
  g.fillStyle = '#121a1d'; g.beginPath(); g.roundRect(10, 10, w - 20, h - 20, 36); g.fill();
  g.fillStyle = '#000'; g.beginPath(); g.roundRect(w / 2 - 48, 20, 96, 24, 12); g.fill();
  txt('SAMPLE POST', w / 2, 70, { font: font(700, 12, 'GeistMono'), align: 'center', color: C.honey, ls: 2 });
  // author
  const ag = g.createLinearGradient(24, 86, 74, 136); ag.addColorStop(0, '#7cf3ff'); ag.addColorStop(1, '#0f8fa3'); g.fillStyle = ag; g.beginPath(); g.arc(48, 110, 24, 0, 7); g.fill();
  g.save(); g.beginPath(); g.arc(48, 110, 22, 0, 7); g.clip(); personGlyph(48, 114, 30, '#063a42'); g.restore();
  txt('KOL 07', 82, 106, { font: font(800, 20), color: '#fff' }); txt('@kol_07 · 71K followers', 82, 127, { font: font(500, 14), color: '#8aa' });
  const body = 'found a tiny graffiti town on Robinhood. 1,999 oddballs. free mint. weird is welcome.';
  const f = font(500, 19); const lines = wrap(body, 246, f); const nchar = Math.floor((u - t0 - .4) * 70);
  let rem = nchar; lines.forEach((l, i) => { if (rem > 0) txt(l.slice(0, rem), 24, 168 + i * 25, { font: f, color: '#eef' }); rem -= l.length + 1; });
  const iy = 168 + lines.length * 25 - 6; const ia = E.out3(inv(t0 + 1.1, t0 + 1.5, u));
  g.save(); g.globalAlpha = ia; g.beginPath(); g.roundRect(22, iy, w - 44, 134, 14); g.clip(); g.drawImage(IMG.banner, 350, 40, 760, 400, 22, iy, w - 44, 134 * 1.0); g.restore();
  const mk0 = t0 + 1.5; const p = E.out3(inv(mk0, mk0 + 2.6, u));
  const met = [['VIEWS', fmtK(212000 * p)], ['REPOSTS', fmtK(3100 * p)], ['LIKES', fmtK(9800 * p)]];
  met.forEach((m, i) => { const mx = 24 + i * 84; txt(m[0], mx, iy + 166, { font: font(700, 11, 'GeistMono'), color: '#7fa79d', ls: 1.5 }); txt(m[1], mx, iy + 192, { font: font(800, 22), color: '#fff' }); });
  const ck = E.back(inv(mk0 + .5, mk0 + .8, u));
  if (ck > 0) { g.save(); g.translate(w / 2, iy + 236); g.scale(ck, ck); g.fillStyle = 'rgba(255,189,46,.16)'; g.beginPath(); g.roundRect(-122, -20, 244, 40, 10); g.fill(); g.strokeStyle = C.honey; g.lineWidth = 2; g.stroke(); txt('PAID: 4 WL SPOTS · $0', 0, 7, { font: font(800, 17, 'GeistMono'), align: 'center', color: C.honey }); g.restore(); }
  const tk = E.back(inv(mk0 + 1.3, mk0 + 1.6, u));
  if (tk > 0) { g.save(); g.translate(w / 2, iy + 286); g.scale(tk, tk); g.fillStyle = 'rgba(109,255,178,.14)'; g.beginPath(); g.roundRect(-100, -18, 200, 36, 10); g.fill(); g.strokeStyle = C.cash; g.lineWidth = 2; g.stroke(); txt('TRACKED', 10, 7, { font: font(800, 16, 'GeistMono'), align: 'center', color: C.cash, ls: 2 }); check(-52, -1, 13, C.cash, 3); g.restore(); }
  g.restore();
}

/* =========================================================================================
   SCENE 4 — CAM 03 · EXIT B · STAIRS (31.5 – 39.5)
   ========================================================================================= */
const EX = { honey: [1.0, 2.95], cone: [3.15, 5.2], mush: [5.25, 7.45] };
const CROWD = (() => { const r = mulberry(909); const cols = [C.pink, C.honey, C.green, C.cyan, C.orange, C.teal]; const a = [];
  for (let i = 0; i < 44; i++) { const c = Math.floor(r() * cols.length); a.push({ s: -1.2 + i * .19 + r() * .1, lane: (r() - .5) * 2, col: cols[c], tag: c === 3 ? 'WL' : r() < .5 ? 'GTD' : 'WL', ph: r() * 7, sp: 5.2 + r() * 1.2 }); } return a; })();
function stairL(y) { return 340 - (y - 300) * (500 / 780); }
function stairR(y) { return 740 + (y - 300) * (500 / 780); }
function person(x, y, s, p, lt) {
  const bob = Math.abs(Math.sin(lt * 7 + p.ph)) * 5 * s; const sw = Math.sin(lt * 7 + p.ph);
  g.save(); g.translate(x, y - bob); g.scale(s, s);
  g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(0, 0, 30, 8, 0, 0, 7); g.fill();
  g.fillStyle = '#0a1013'; g.beginPath(); g.roundRect(-16 + sw * 4, -62, 13, 62, 6); g.roundRect(3 - sw * 4, -62, 13, 62, 6); g.fill();
  g.beginPath(); g.roundRect(-27, -134, 54, 84, 22); g.fill();
  g.beginPath(); g.arc(0, -150, 19, 0, 7); g.fill();
  g.strokeStyle = 'rgba(120,235,215,.35)'; g.lineWidth = 2.5; g.beginPath(); g.arc(0, -150, 19, -2.7, -.5); g.stroke(); g.beginPath(); g.moveTo(-27, -100); g.lineTo(-27, -70); g.stroke();
  g.fillStyle = 'rgba(255,255,255,.9)'; g.beginPath(); g.arc(-7, -152, 3, 0, 7); g.arc(7, -152, 3, 0, 7); g.fill();
  // umbrella
  g.strokeStyle = '#1b1f22'; g.lineWidth = 3.5; g.beginPath(); g.moveTo(16, -108); g.lineTo(16, -200); g.stroke();
  g.fillStyle = p.col; g.beginPath(); g.arc(16, -198, 64, Math.PI, 0); for (let k = 0; k < 4; k++) g.arc(80 - 16 - 32 * k, -198, 16, 0, Math.PI, true); g.closePath(); g.fill();
  g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 2; for (let k = 1; k < 4; k++) { g.beginPath(); g.moveTo(16, -262); g.lineTo(-48 + 32 * k, -198); g.stroke(); }
  g.strokeStyle = 'rgba(255,255,255,.45)'; g.lineWidth = 4; g.beginPath(); g.arc(16, -198, 54, Math.PI * 1.15, Math.PI * 1.45); g.stroke();
  // ticket tag
  g.fillStyle = '#f1e8d4'; g.beginPath(); g.roundRect(-14, -300, 60, 30, 6); g.fill(); g.strokeStyle = p.col; g.lineWidth = 3; g.stroke();
  txt(p.tag, 16, -279, { font: font(800, 17, 'GeistMono'), align: 'center', color: '#13201c' });
  g.restore();
}
function sExit(t, f) {
  const lt = t - 31.5;
  g.save(); const z = 1.02 + .03 * E.io2(inv(0, 8, lt)); g.translate(540, 560); g.scale(z, z); g.translate(-540, -560);
  // sky / street opening
  let gr = g.createLinearGradient(0, 100, 0, 320); gr.addColorStop(0, '#0b1a28'); gr.addColorStop(1, '#1f3440'); g.fillStyle = gr; g.fillRect(300, 80, 480, 260);
  const glow = g.createRadialGradient(560, 210, 10, 560, 210, 330); glow.addColorStop(0, 'rgba(255,214,150,.55)'); glow.addColorStop(1, 'rgba(255,214,150,0)'); g.fillStyle = glow; g.fillRect(200, 60, 700, 400);
  sprite(IMG.streetlight, 690, 312, 190, { alpha: .9 });
  g.fillStyle = 'rgba(20,30,34,.9)'; g.fillRect(300, 280, 480, 30);
  // ceiling
  g.fillStyle = '#080c0e'; g.beginPath(); g.moveTo(-40, -40); g.lineTo(1120, -40); g.lineTo(740, 120); g.lineTo(340, 120); g.closePath(); g.fill();
  // walls
  const wallL = () => { g.beginPath(); g.moveTo(-60, -40); g.lineTo(340, 120); g.lineTo(340, 300); g.lineTo(-240, 1200); g.lineTo(-60, 1200); g.closePath(); };
  const wallR = () => { g.beginPath(); g.moveTo(1140, -40); g.lineTo(740, 120); g.lineTo(740, 300); g.lineTo(1320, 1200); g.lineTo(1140, 1200); g.closePath(); };
  gr = g.createLinearGradient(0, 0, 340, 0); gr.addColorStop(0, '#1a2422'); gr.addColorStop(1, '#3a4a46'); g.fillStyle = gr; wallL(); g.fill();
  gr = g.createLinearGradient(1080, 0, 740, 0); gr.addColorStop(0, '#141c1b'); gr.addColorStop(1, '#33423e'); g.fillStyle = gr; wallR(); g.fill();
  const VP = [540, 215];
  [wallL, wallR].forEach((wfn, side) => {
    g.save(); wfn(); g.clip(); g.strokeStyle = 'rgba(200,230,220,.08)'; g.lineWidth = 2;
    for (let yy = -600; yy < 1800; yy += 70) { g.beginPath(); g.moveTo(side ? 1080 : 0, yy); g.lineTo(VP[0], VP[1]); g.stroke(); }
    for (let k = 0; k < 9; k++) { const xx = side ? 740 + k * k * 9 + k * 30 : 340 - k * k * 9 - k * 30; g.beginPath(); g.moveTo(xx, -100); g.lineTo(xx, 1300); g.stroke(); }
    g.restore();
  });
  // Trippi graffiti on left wall, in perspective
  g.save(); wallL(); g.clip(); g.setTransform(1, 0, 0, 1, 0, 0); g.translate(540, 560); g.scale(z, z); g.translate(-540, -560);
  g.transform(.78, -.36, 0, 1, 18, 470); g.globalAlpha = .95; g.drawImage(IMG.logo, 0, 0, 330, 330 * IMG.logo.height / IMG.logo.width);
  g.globalAlpha = .45; g.drawImage(GRAFF, 0, 0, 1000, 400, -20, 200, 380, 152); g.restore();
  // exit sign
  g.save(); g.translate(431, 128); g.fillStyle = '#0d8c5c'; g.shadowColor = '#3dff9e'; g.shadowBlur = 24; g.beginPath(); g.roundRect(0, 0, 218, 58, 8); g.fill(); g.shadowBlur = 0;
  g.strokeStyle = '#d9ffe9'; g.lineWidth = 3; g.stroke(); txt('EXIT B', 66, 41, { font: font(800, 32), color: '#fff', ls: 1 });
  g.strokeStyle = '#fff'; g.lineWidth = 6; g.lineCap = 'round'; g.beginPath(); g.moveTo(30, 44); g.lineTo(30, 16); g.moveTo(18, 27); g.lineTo(30, 14); g.lineTo(42, 27); g.stroke(); g.restore();
  // stairs
  const N = 13; const ys = []; for (let i = 0; i <= N; i++) ys.push(300 + 800 * Math.pow(i / N, 1.45));
  for (let i = 0; i < N; i++) {
    const y0 = ys[i], y1 = ys[i + 1], hh = y1 - y0, ym = y0 + hh * .48; const dk = i / N;
    g.fillStyle = `rgb(${88 + dk * 20},${98 + dk * 18},${100 + dk * 16})`; g.beginPath(); g.moveTo(stairL(y0), y0); g.lineTo(stairR(y0), y0); g.lineTo(stairR(ym), ym); g.lineTo(stairL(ym), ym); g.closePath(); g.fill();
    g.fillStyle = `rgb(${38 + dk * 14},${44 + dk * 14},${48 + dk * 12})`; g.beginPath(); g.moveTo(stairL(ym), ym); g.lineTo(stairR(ym), ym); g.lineTo(stairR(y1), y1); g.lineTo(stairL(y1), y1); g.closePath(); g.fill();
    g.fillStyle = '#d6a92a'; g.fillRect(stairL(ym), ym - Math.max(2, hh * .05), stairR(ym) - stairL(ym), Math.max(2, hh * .05));
    // wet sheen
    const sh = .06 + .06 * Math.sin(t * 2 + i * 1.3); g.fillStyle = `rgba(255,220,170,${sh})`; const cx = 540 + Math.sin(i * 2.1) * 60; g.beginPath(); g.ellipse(cx, (y0 + ym) / 2, (stairR(y0) - stairL(y0)) * .22, Math.max(2, hh * .14), 0, 0, 7); g.fill();
  }
  g.save(); g.globalCompositeOperation = 'source-over'; const tg2 = g.createLinearGradient(0, 300, 0, 620); tg2.addColorStop(0, 'rgba(255,214,150,.18)'); tg2.addColorStop(1, 'rgba(255,214,150,0)'); g.fillStyle = tg2; g.fillRect(0, 300, W, 320); g.restore();
  // handrails
  [[340, 300, -240, 1100], [740, 300, 1320, 1100]].forEach(([x0, y0, x1, y1], s) => { g.strokeStyle = '#8c9a98'; g.lineWidth = 9; g.lineCap = 'round'; g.beginPath(); g.moveTo(x0 + (s ? 10 : -10), y0 - 70); g.lineTo(x1 + (s ? 30 : -30), y1 - 420); g.stroke(); g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 2.5; g.stroke(); });
  // crowd (far → near)
  const ppl = [];
  CROWD.forEach(p => { const k = (lt - p.s) / p.sp; if (k <= 0 || k >= 1) return; const y = lerp(318, 1240, Math.pow(k, 1.55)); const s = lerp(.24, 1.45, (y - 318) / 922); const x = 540 + p.lane * (stairR(Math.min(y, 1080)) - 540) * .55; ppl.push({ p, x, y, s }); });
  ppl.sort((a, b) => a.y - b.y).forEach(o => person(o.x, o.y, o.s, o.p, lt));
  // rain
  g.save(); g.strokeStyle = 'rgba(200,225,240,.33)'; g.lineCap = 'round';
  for (let i = 0; i < 260; i++) { const sp = 900 + hash(i * 3) * 700; const L = 18 + hash(i * 5) * 34; const x = (hash(i) * 1300 + t * 70) % 1300 - 110; const y = (hash(i * 7) * 1300 + t * sp) % 1300 - 110; g.lineWidth = 1 + hash(i * 9) * 1.6; g.beginPath(); g.moveTo(x, y); g.lineTo(x - L * .12, y + L); g.stroke(); }
  g.restore();
  // foreground crew
  sprite(IMG.honey, 196, 1112, 390, { sy: talk(lt, EX.honey[0], EX.honey[0] + 1.1) * (1 + .01 * Math.sin(t * 2)), rot: -.04 });
  shadowEllipse(404, 1016, 100, 16, .45); sprite(IMG.cone, 404, 1018, 205, { sy: talk(lt, EX.cone[0], EX.cone[0] + 1.6), rot: Math.sin(t * 1.4) * .03 });
  sprite(IMG.mushroom, 890, 1122, 410, { sy: talk(lt, EX.mush[0], EX.mush[0] + .9) * (1 + .01 * Math.sin(t * 2 + 1)), rot: .03 });
  bubble('Yo... who are all these people?', 214, 726, EX.honey[0], EX.honey[1], lt, { maxW: 330, tail: -6, shift: 40 });
  bubble('Partner crews. KOL followers. All paid in spots.', 420, 806, EX.cone[0], EX.cone[1], lt, { maxW: 360, tail: -8, shift: 60 });
  bubble('And we spent... nothing?', 872, 712, EX.mush[0], EX.mush[1], lt, { maxW: 300, tail: 10, shift: -40 });
  g.restore();
  cctv(t, f, 'CAM 03 · EXIT B · STAIRS');
  // crowd counter
  const n = 8412 * E.out3(inv(.3, 6.5, lt));
  g.save(); g.fillStyle = 'rgba(0,0,0,.55)'; g.beginPath(); g.roundRect(W - 312, 118, 272, 92, 10); g.fill();
  txt('CROWD COUNT', W - 294, 146, { font: font(700, 15, 'GeistMono'), color: '#dcdcdc', ls: 2.5 });
  txt(fmtN(n), W - 294, 192, { font: font(900, 40, 'Doto'), color: '#7dffb6', shadow: 'rgba(125,255,182,.6)', blur: 12 });
  txt('SAMPLE', W - 58, 192, { font: font(700, 12, 'GeistMono'), color: '#bbb', align: 'right' }); g.restore();
}

/* =========================================================================================
   SCENE 5 — the offer as a Trippi Transit ticket (39.5 – 46.6)
   ========================================================================================= */
function sTicket(t, f) {
  const lt = t - 39.5;
  let gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#13a185'); gr.addColorStop(1, '#0a6a55'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
  g.save(); g.globalAlpha = .55; const gx = -(lt * 40) % 1000; for (let k = -1; k < 3; k++) g.drawImage(GRAFF, gx + k * 1000, 700, 1000, 400); g.globalAlpha = .25; g.save(); g.translate(0, 380); g.scale(1, -1); for (let k = -1; k < 3; k++) g.drawImage(GRAFF, -gx + k * 1000 - 500, 0, 1000, 400); g.restore(); g.restore();
  noise(.08, f);
  // floating stamps
  const fl = [['postmark-wolf', 120, 150, -.2], ['postmark-frog', 960, 170, .18], ['postmark-traffic', 110, 930, .15], ['postmark-axolotl', 975, 925, -.16]];
  fl.forEach(([n, x, y, r], i) => { const im = IMG[n]; const h = 190; const k = E.back(inv(.1 + i * .08, .5 + i * .08, lt)); const out = 1 - E.in3(inv(4.15, 4.5, lt)); g.save(); g.translate(x, y + Math.sin(t * 1.5 + i) * 10); g.rotate(r + Math.sin(t + i) * .04); g.scale(k * (out * .3 + .7), k * (out * .3 + .7)); g.shadowColor = 'rgba(0,0,0,.35)'; g.shadowBlur = 20; g.shadowOffsetY = 10; g.drawImage(im, -h * im.width / im.height / 2, -h / 2, h * im.width / im.height, h); g.restore(); });
  // ticket card
  if (lt < 4.6) {
    const a = E.out5(inv(0, .55, lt)); const out = E.in3(inv(4.1, 4.6, lt));
    const slam = lt > 2.45 && lt < 2.75 ? Math.sin(lt * 130) * 7 * (1 - (lt - 2.45) / .3) : 0;
    g.save(); g.translate(540 + slam, lerp(1500, 545, a) - 1400 * out); g.rotate(lerp(.18, -.025, a) + out * .5);
    g.shadowColor = 'rgba(0,0,0,.45)'; g.shadowBlur = 40; g.shadowOffsetY = 18; g.drawImage(TICKET, -450, -305); g.shadowColor = 'transparent';
    const X = -450, Y = -305;
    txt('TRIPPI TRANSIT  ·  LINE 01 SERVICE', X + 56, Y + 80, { font: font(700, 19, 'GeistMono'), ls: 2.5, color: C.tealD });
    txt('PLATFORM 09', X + 844, Y + 80, { font: font(700, 19, 'GeistMono'), ls: 2.5, color: C.tealD, align: 'right' });
    // lockup: encore STUDIO × [Trippi logo]
    const f1 = font(700, 50), f2 = font(600, 20, 'GeistMono'); const w1 = measure('encore', f1), w2 = measure('STUDIO', f2, 5);
    txt('encore', X + 56, Y + 158, { font: f1, color: '#101413', ls: -1 }); txt('STUDIO', X + 64 + w1, Y + 158, { font: f2, color: '#101413', ls: 5 });
    txt('×', X + 84 + w1 + w2, Y + 156, { font: font(500, 42), color: '#6b6b6b' });
    const lw = 190, lh = lw * IMG.logo.height / IMG.logo.width; g.drawImage(IMG.logo, X + 128 + w1 + w2, Y + 112, lw, lh);
    for (let i = 0; i < 26; i++) { g.fillStyle = '#16211e'; g.fillRect(X + 690 + i * 6, Y + 116, (i * 7 % 3) + 1.5, 46); }
    const rows = [['01', 'COLLAB MANAGEMENT', 'Find, pitch, sign and track partner communities.', C.pink, .55], ['02', 'KOL MANAGEMENT', 'Shortlist, brief, schedule and track every post.', C.cyan, .85]];
    rows.forEach(([n, ti, sub, col, at], i) => {
      const k = E.out3(inv(at, at + .35, lt)); if (k <= 0) return; const yy = Y + 236 + i * 96;
      g.save(); g.globalAlpha = k; g.translate(30 * (1 - k), 0);
      g.fillStyle = col; g.beginPath(); g.arc(X + 86, yy + 2, 28, 0, 7); g.fill(); g.strokeStyle = '#101413'; g.lineWidth = 3; g.stroke();
      txt(n, X + 86, yy + 11, { font: font(800, 24), align: 'center', color: '#101413' });
      txt(ti, X + 132, yy + 10, { font: font(800, 40), color: '#101413', ls: -.5 });
      txt(sub, X + 133, yy + 44, { font: font(500, 24), color: '#4d5c57' });
      g.restore();
    });
    const bk = E.out3(inv(1.35, 1.7, lt));
    g.save(); g.globalAlpha = bk;
    txt('PARTNERS PAID IN', X + 60, Y + 486, { font: font(700, 17, 'GeistMono'), ls: 2.5, color: '#5b6a65' });
    txt('WL / GTD SPOTS', X + 58, Y + 540, { font: font(800, 46), color: C.tealD, ls: -1 });
    txt('CASH', X + 520, Y + 486, { font: font(700, 17, 'GeistMono'), ls: 2.5, color: '#5b6a65' });
    txt('$0', X + 518, Y + 546, { font: font(800, 60), color: '#101413' });
    g.restore();
    if (lt > 2.4) { const k = inv(2.4, 2.62, lt); const s = lerp(2.6, 1, E.out3(k)); g.save(); g.translate(X + 760, Y + 470); g.rotate(-.28); g.scale(s, s); g.globalAlpha = Math.min(1, k * 1.5) * .9; g.drawImage(STAMP, -125, -125, 250, 250); g.restore(); }
    g.restore();
  }
  // closing line in Trippi's voice
  if (lt > 4.3) {
    const k = E.back(inv(4.35, 4.75, lt)); const lw = 560, lh = lw * IMG.logo.height / IMG.logo.width;
    g.save(); g.translate(540, 360); g.scale(k, k); g.rotate(Math.sin(t * 2) * .02); g.shadowColor = 'rgba(0,0,0,.4)'; g.shadowBlur = 30; g.shadowOffsetY = 14; g.drawImage(IMG.logo, -lw / 2, -lh / 2, lw, lh); g.restore();
    const k2 = E.out3(inv(4.65, 5.0, lt));
    txt('COLLECT THE ODD.', 540, 618 + 30 * (1 - k2), { font: font(800, 84, 'Poppins'), align: 'center', color: '#fff', alpha: k2, stroke: '#073f33', sw: 14, ls: -1 });
    const k3 = E.out3(inv(4.95, 5.3, lt));
    txt("We'll bring the crowd. You keep the cash.", 540, 690 + 20 * (1 - k3), { font: font(600, 34), align: 'center', color: '#eafff8', alpha: k3, shadow: 'rgba(0,0,0,.35)', blur: 10 });
    const ck = E.out3(inv(5.0, 5.5, lt));
    sprite(IMG.honey, 190, 1080 + 380 * (1 - ck) + 60, 380, { rot: .12 }); sprite(IMG.mushroom, 890, 1080 + 380 * (1 - ck) + 70, 400, { rot: -.12 });
    sprite(IMG.cone, 540, 1080 + 260 * (1 - E.out3(inv(5.2, 5.7, lt))) - 10, 230, { rot: Math.sin(t * 3) * .04 });
  }
  g.drawImage(VIG, 0, 0);
  if (lt > 6.75) { g.fillStyle = `rgba(0,0,0,${inv(6.75, 7.1, lt)})`; g.fillRect(0, 0, W, H); }
}

/* =========================================================================================
   SCENE 6 — Encore end card (46.6 – 53)
   ========================================================================================= */
function capsule(x, y, w, h) {
  const gr = g.createLinearGradient(0, y, 0, y + h); gr.addColorStop(0, '#ffffff'); gr.addColorStop(.18, '#e6e6e6'); gr.addColorStop(.5, '#2a2a2a'); gr.addColorStop(.72, '#0c0c0c'); gr.addColorStop(.9, '#4a4a4a'); gr.addColorStop(1, '#a8a8a8');
  g.fillStyle = gr; g.beginPath(); g.roundRect(x, y, w, h, w / 2); g.fill();
  const hl = g.createLinearGradient(x, 0, x + w, 0); hl.addColorStop(0, 'rgba(255,255,255,.55)'); hl.addColorStop(.35, 'rgba(255,255,255,0)'); hl.addColorStop(.8, 'rgba(0,0,0,0)'); hl.addColorStop(1, 'rgba(0,0,0,.45)');
  g.fillStyle = hl; g.fill(); g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1.5; g.stroke();
}
function sEnd(t, f) {
  const lt = t - 46.6;
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const gr = g.createRadialGradient(540, 300, 10, 540, 300, 520); gr.addColorStop(0, 'rgba(255,255,255,.07)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
  const cw = 60, chh = 196, step = 44, x0 = 540 - (cw + step * 5) / 2;
  for (let i = 0; i < 6; i++) { const k = E.out5(inv(.15 + i * .07, .75 + i * .07, lt)); if (k <= 0) continue; g.save(); g.globalAlpha = k; capsule(x0 + i * step, 150 + 40 * (1 - k), cw, chh); g.restore(); }
  { const sw = inv(1.2, 2.0, lt); if (sw > 0 && sw < 1) { g.save(); g.beginPath(); for (let i = 0; i < 6; i++) g.roundRect(x0 + i * step, 150, cw, chh, cw / 2); g.clip(); const sx = lerp(x0 - 120, x0 + 400, sw); const sg = g.createLinearGradient(sx - 60, 0, sx + 60, 0); sg.addColorStop(0, 'rgba(255,255,255,0)'); sg.addColorStop(.5, 'rgba(255,255,255,.75)'); sg.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = sg; g.fillRect(x0 - 200, 150, 700, chh); g.restore(); } }
  const fa = (a, b) => E.out3(inv(a, b, lt));
  // lockup
  { const k = fa(.7, 1.1); const f1 = font(600, 50), f2 = font(500, 20, 'GeistMono'); const w1 = measure('encore', f1, -1), w2 = measure('STUDIO', f2, 6), wx = measure('×', font(400, 40));
    const lw = 160, lh = lw * IMG.logo.height / IMG.logo.width; const tot = w1 + 10 + w2 + 26 + wx + 26 + lw; const sx = 540 - tot / 2; const y = 448 + 14 * (1 - k);
    g.save(); g.globalAlpha = k; txt('encore', sx, y, { font: f1, color: '#fff', ls: -1 }); txt('STUDIO', sx + w1 + 10, y, { font: f2, color: '#bdbdbd', ls: 6 });
    txt('×', sx + w1 + 10 + w2 + 26, y - 3, { font: font(400, 40), color: '#8a8a8a' }); g.drawImage(IMG.logo, sx + w1 + 10 + w2 + 26 + wx + 26, y - lh / 2 - 16, lw, lh); g.restore(); }
  { const k = fa(1.0, 1.4); const chrome = g.createLinearGradient(0, 520, 0, 680); chrome.addColorStop(0, '#ffffff'); chrome.addColorStop(.5, '#d4d4d4'); chrome.addColorStop(1, '#9a9a9a');
    g.save(); g.globalAlpha = k; g.font = font(800, 60); g.textAlign = 'center'; g.letterSpacing = '-1.5px'; g.fillStyle = chrome; g.fillText('Collab + KOL management.', 540, 578 + 16 * (1 - k)); g.fillText('Paid in spots, not cash.', 540, 650 + 16 * (1 - k)); g.restore(); }
  { const k = fa(1.5, 1.9); txt('Book a call  ·  calendly.com/encorestudiohq/30min', 540, 742, { font: font(500, 29), align: 'center', color: '#fff', alpha: k });
    txt('@EncoreStudiohq  ·  encorestudio.xyz', 540, 784, { font: font(500, 23), align: 'center', color: '#a9a9a9', alpha: k }); }
  { const k = fa(1.9, 2.3); g.save(); g.globalAlpha = k; g.fillStyle = '#2b2b2b'; g.fillRect(200, 826, 680, 1.5); g.restore();
    txt('Unofficial concept by Encore Studio. Not affiliated with or endorsed by Trippi.', 540, 868, { font: font(400, 20), align: 'center', color: '#9a9a9a', alpha: k });
    txt('Trippi characters and art © Trippi. All numbers shown are sample data.', 540, 898, { font: font(400, 20), align: 'center', color: '#9a9a9a', alpha: k });
    txt('Every launch deserves an encore.', 540, 990, { font: font(500, 19, 'GeistMono'), align: 'center', color: '#7a7a7a', ls: 2, alpha: k }); }
  { const k = fa(2.2, 2.6); g.save(); g.globalAlpha = k; const cx = W - 352, cy = 34; g.strokeStyle = '#3a4250'; g.lineWidth = 2; g.fillStyle = '#05070a'; g.beginPath(); g.rect(cx, cy, 320, 50); g.fill(); g.stroke();
    g.fillStyle = '#ff2b2b'; g.fillRect(cx + 14, cy + 22, 7, 7); txt('CONCEPT · UNOFFICIAL', cx + 32, cy + 35, { font: font(900, 23, 'Doto'), color: '#f1f1f1', ls: 1 }); g.restore(); }
  noise(.04, f);
  if (lt > 6.0) { g.fillStyle = `rgba(0,0,0,${inv(6.0, 6.4, lt)})`; g.fillRect(0, 0, W, H); }
}

/* ---------- frame dispatcher ---------- */
const GW = [[5.1, 5.36], [12.8, 13.14], [31.3, 31.66], [39.32, 39.6]];
function frame(fi) {
  const t = fi / FPS;
  g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.shadowBlur = 0; g.shadowColor = 'transparent'; g.letterSpacing = '0px';
  if (t < 5.2) sBoot(t, fi); else if (t < 13) sPlatform(t, fi); else if (t < 31.5) sGame(t, fi); else if (t < 39.5) sExit(t, fi); else if (t < 46.6) sTicket(t, fi); else sEnd(t, fi);
  for (const [a, b] of GW) if (t >= a && t <= b) { const m = (a + b) / 2; glitch(fi, 1 - Math.abs(t - m) / ((b - a) / 2)); }
}

/* ---------- sound cue list (for the audio build) ---------- */
function buildEvents() {
  const ev = []; const P = (t, type, o = {}) => ev.push({ t: +t.toFixed(3), type, ...o });
  BOOT.forEach(r => { if (r.s) { for (let i = 0; i < r.s.length; i += 2) P(r.t + i / 80, 'key'); if (r.r) P(r.t + (r.s.length + 3) / 80, r.r === 'OK' ? 'beep_ok' : 'beep_bad'); }
    if (r.type) for (let k = 0; k < r.type.length; k++) P(r.tt + k * .08, 'key2'); if (r.rule) P(r.t, 'tick'); });
  P(2.95, 'proc'); P(3.45, 'granted'); P(3.95, 'load'); P(4.92, 'crt_off');
  GW.forEach(([a, b]) => P(a, 'glitch', { d: +(b - a).toFixed(3) }));
  P(5.2, 'train'); P(12.25, 'signal');
  const talkEv = (t0, txtLen, who) => { P(t0, 'pop'); for (let i = 0; i < txtLen; i += 3) P(t0 + .05 + i / 52, 'talk', { who }); };
  talkEv(5.2 + PL.mush[0], 62, 0); talkEv(5.2 + PL.honey[0], 40, 1); talkEv(5.2 + PL.cone[0], 28, 2);
  P(13.0, 'ui_on'); P(13.45, 'draw');
  PARTNERS.forEach((p, i) => P(13 + .9 + i * .06, 'tick')); KOLS.forEach((k, i) => P(13 + 1.3 + i * .035, 'tick'));
  P(13 + 1.25, 'banner'); P(13 + 8.95, 'banner'); P(13 + 16.5, 'banner_big');
  DEALS.forEach((d, j) => { P(13 + d.t0, 'dispatch', { pan: +((d.ref.at[0] - 540) / 540).toFixed(2) }); P(13 + d.arrive, 'arrive', { n: j, kind: d.kind }); P(13 + d.arrive + 1.1, 'absorb'); });
  P(13 + 3.45, 'card'); P(13 + DEALS[2].arrive + .1, 'stamp'); P(13 + 10.55, 'card');
  P(13 + 10.55 + 1.5 + .5, 'chip'); P(13 + 10.55 + 1.5 + 1.3, 'chip');
  P(13 + COLLAB_DONE + .1, 'quest'); P(13 + KOL_DONE + .1, 'quest');
  talkEv(31.5 + EX.honey[0], 31, 1); talkEv(31.5 + EX.cone[0], 48, 2); talkEv(31.5 + EX.mush[0], 24, 0);
  P(39.5, 'whoosh'); P(39.5 + .55, 'tick'); P(39.5 + .85, 'tick'); P(39.5 + 1.35, 'tick'); P(39.5 + 2.4, 'stamp'); P(39.5 + 4.1, 'whoosh'); P(39.5 + 4.35, 'pop_big'); P(39.5 + 5.0, 'pop'); P(39.5 + 5.2, 'pop');
  P(46.75, 'chime'); P(47.8, 'shine');
  return ev.sort((a, b) => a.t - b.t);
}

window.READY = (async () => {
  await Promise.all(IMGN.map(n => new Promise((res, rej) => { const i = new Image(); i.onload = () => { IMG[n] = i; res(); }; i.onerror = rej; i.src = 'img/' + n + '.png'; })));
  const fonts = ['400 20px Geist', '500 20px Geist', '600 20px Geist', '700 20px Geist', '800 20px Geist', '400 20px GeistMono', '500 20px GeistMono', '700 20px GeistMono', '700 20px Doto', '900 20px Doto', '700 20px Poppins', '800 20px Poppins', '400 20px VT'];
  await Promise.all(fonts.map(f => document.fonts.load(f)));
  prebuild();
  window.EVENTS = buildEvents();
  window.TOTAL = Math.round(DUR * FPS);
  window.renderFrame = fi => { frame(fi); };
  window.grab = (fi, q) => { frame(fi); return cv.toDataURL('image/jpeg', q || .95); };
  return true;
})();
