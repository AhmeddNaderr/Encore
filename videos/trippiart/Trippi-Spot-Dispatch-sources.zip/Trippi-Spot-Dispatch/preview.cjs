const { chromium } = require('playwright');
(async()=>{
const fs = require('fs');
const times = process.argv.slice(3).map(Number); const out = process.argv[2];
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1080, height: 1080 } });
const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
await p.goto('http://127.0.0.1:8765/index.html'); await p.evaluate(() => window.READY);
fs.mkdirSync(out, { recursive: true });
for (const t of times) { const d = await p.evaluate(f => window.grab(f, .9), Math.round(t * 60)); fs.writeFileSync(`${out}/t${t.toFixed(2)}.jpg`, Buffer.from(d.split(',')[1], 'base64')); }
if (errs.length) console.log('ERRORS', errs.slice(0, 5));
await b.close();
})();
