const { chromium } = require('playwright');
const { spawn } = require('child_process');
const [,, outDir, startS, endS, workersS] = process.argv;
const fs = require('fs'); fs.mkdirSync(outDir, { recursive: true });
(async () => {
  const b = await chromium.launch();
  const probe = await b.newPage(); await probe.goto('http://127.0.0.1:8765/index.html'); await probe.evaluate(() => window.READY);
  const total = await probe.evaluate(() => window.TOTAL); fs.writeFileSync(outDir + '/events.json', JSON.stringify(await probe.evaluate(() => window.EVENTS))); await probe.close();
  const s0 = startS ? +startS : 0, s1 = endS ? Math.min(+endS, total) : total; const N = +(workersS || 4);
  const per = Math.ceil((s1 - s0) / N); const t0 = Date.now();
  await Promise.all([...Array(N).keys()].map(async w => {
    const a = s0 + w * per, z = Math.min(s1, a + per); if (a >= z) return;
    const p = await b.newPage({ viewport: { width: 1080, height: 1080 } }); const errs = []; p.on('pageerror', e => errs.push(e.message));
    await p.goto('http://127.0.0.1:8765/index.html'); await p.evaluate(() => window.READY);
    const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', '60', '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '10', '-pix_fmt', 'yuv420p', `${outDir}/chunk_${String(w).padStart(2, '0')}.mp4`], { stdio: ['pipe', 'inherit', 'inherit'] });
    for (let f = a; f < z; f++) {
      const d = await p.evaluate(fi => window.grab(fi, .96), f);
      if (!ff.stdin.write(Buffer.from(d.slice(23), 'base64'))) await new Promise(r => ff.stdin.once('drain', r));
      if (w === 0 && (f - a) % 120 === 0) console.log(`w0 ${f - a}/${z - a}  ${((Date.now() - t0) / 1000).toFixed(0)}s`);
    }
    ff.stdin.end(); await new Promise(r => ff.on('close', r)); if (errs.length) console.log('ERR', w, errs.slice(0, 3));
  }));
  console.log('done', ((Date.now() - t0) / 1000).toFixed(0) + 's'); await b.close();
})();
