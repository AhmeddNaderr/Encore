# YORI: COLOR CUT — source package

| Folder / file | Contents |
|---|---|
| `research_brief.md`, `art_bible.md`, `concepts.md`, `storyboard.md`, `quality_report.md`, `progress.md`, `DM-description.txt` | Phase outputs of the Encore master brief |
| `AUDIO-SOURCES.md` | Original score and effects: provenance and reproduction |
| `research/` | Public profile/post JSON (FxTwitter API) and notes from the public yoricolors.xyz page |
| `art/raw/` | Official YORI media as downloaded: PFP, banner, both X videos and their thumbnails. URLs and SHA-256 in `art/sources.csv` |
| `art/` | Reference board, Gate A side-by-side, sampled palette, frame-extraction manifest |
| `assets/` | Game sprites keyed from the official frames (WebP), stickers, cut-in frames, rival panels, logos |
| `game/` | Game source (`engine.js`, `render.js`, `app.js`, `shell.html`) and the 229-note `chart.json` |
| `audio/` | Original game music, the results loop and 16 effects (WAV) |
| `video/` | Trailer mixes, the captured run, shot timing, mapped SFX events, MP4 validation reports |
| `trailer/` | Timeline specs for the 42 s main cut and the 15 s vertical cut |
| `tools/` | Keyer, sprite builder, composer, game builder, deterministic capture, mixer, encoder/validator, smoke test |
| `fonts/` | Fredoka and Nunito woff2 files used in the game, with their SIL OFL 1.1 licences |

The final MP4s and the playable HTML are separate downloads next to this archive. The extracted full-resolution source frames (≈160 MB) are left out; `tools/extract_frames.py` regenerates them exactly from `art/raw/` videos.

## Rebuild
```bash
python3 tools/extract_frames.py        # official frames by exact 60 fps index (run inside art/)
python3 tools/build_sprites.py && python3 tools/build_misc.py
python3 tools/compose.py song && python3 tools/compose.py loop && python3 tools/compose.py sfx
python3 tools/build_game.py            # -> dist/yori-color-cut.html (needs fonts via npm @fontsource/fredoka @fontsource/nunito)
node tools/capture.cjs trailer/main.json build/cap-main
python3 tools/mix_trailer.py trailer/main.json build/cap-main
python3 tools/encode_validate.py build/cap-main out/YORI-Color-Cut-main.mp4 1920 1080 2520
```
Unofficial concept by Encore Studio. YORI's art and branding belong to their owners.
