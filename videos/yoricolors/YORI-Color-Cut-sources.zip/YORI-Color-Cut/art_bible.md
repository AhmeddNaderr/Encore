# YORI: COLOR CUT — art bible

## Source of truth
Every character pixel in the game and the trailers comes from YORI's own published art: the PFP, the X banner, and frames of the two official videos (WL post at 60 fps, 1950×1080; GTD post at 60 fps, 1956×1080). Frames were extracted losslessly by exact 60 fps index (`art/src/manifest.json`). Nothing was AI-generated, redrawn or invented. The only processing is background keying, recolouring the *background* behind the cut-outs, scaling and cropping.

Canonical references per character (reused for every asset):
- **YORI (orange):** WL `smirk-005`, `one-180`, `wave-215`; GTD `maskon-045`, `peace-160`.
- **Blue variant:** WL `bluesmirk-260`.
- **Cap variant:** WL `cap-320`.
- **Wordmark:** X banner (`banner.webp`) and the WL end card `logoend-410`.

## Palette (pixel-sampled medians, `art/palette-sampled.json`)
| Role | Hex | Sampled from |
|---|---|---|
| Stage blue (idle / dodge / bait) | #2E5590 | WL smirk background |
| Stage red (ONE) | #AC392C | WL "one" background |
| Stage yellow-orange (WAVE) | #DD8F1C | WL pout background |
| Rival panel orange | #C3703B | WL blue-kid background |
| Fever purple (edge to centre) | #201B3E → #362F58, lit to ~#54489A | GTD peace frames |
| Mask-off magenta | #A61576 | GTD tongue frames |
| Night teal (COLORS LIE / mask cut-in) | #0D2125 | GTD mask-tie frames |
| Cap-kid cyan glow | #3AE1DC | WL cap frames |
| Banner yellow (captions, title) | #FDDC03 | X banner |
| Hair orange | #ED9913 | WL frames |
| Site accents (result card) | #FF5FB0 · #FFC14D · #19D3A8 · #7A6BFF | yoricolors.xyz CSS |
| Ink (outlines, UI strokes) | #151116 | matched to line art |

## Style notes
- **Line:** thick near-black outlines of varying weight, closed around every shape. UI uses the same ink weight (8–12 px at 1080p).
- **Shading:** clean cel-shading with soft gradient shadows. No texture except a faint canvas grain and a soft vignette on the backgrounds.
- **Proportions:** close-up busts, with heads filling most of the frame. Big white eyes, small black pupils, heavy dark circles, fangs, spiky hair overlapping the forehead.
- **Framing:** tight close-ups on flat colour, cut hard on the beat. The game copies this: every hit is a new "shot" (new pose and a new flat colour).
- **Type:** Fredoka 600/700 (bubble letters: white fill, thick ink outline, like the banner). Nunito 700/800 for small copy. Both are the fonts YORI's own site loads (OFL).
- **Motion vocabulary from the source:** speed lines (purple), the radial 色より burst (red), drifting embers (teal mask scene), the neon ring (magenta). All four appear in the game in the same contexts.

## Invariants (never change)
Face, eye and eye-bag shapes. Hair silhouette and colour. Skin tone. Vest, gaiter and mask designs. The red cord. The outline weight. The 色より / yori wordmark (used as supplied: banner plaque or keyed white-on-ink letters, never retyped). Character pixels are never recoloured; only backgrounds change.

## Forbidden
Glossy 3D, pixel art, generic anime sparkles, halftone comic dots, neon cyber grids, emoji glyphs in rendered UI, invented characters or costumes, retyped logos. Also: any use of the ambiguous GTD finger-on-mask frames (3.5–4.9 s), which could read as a rude gesture.

## Asset inventory
| Use | Source frames |
|---|---|
| ONE pose (4-frame anim) | WL 170/180/190/195 |
| WAVE pose (3 frames) | WL 210/215/220 |
| Idle smirk (3) | WL 0/5/10 |
| Miss, pout (3) | WL 115/125/135 |
| Took the bait, head-pat (3) | WL 40/55/70 |
| Fever, masked peace (3) | GTD 160/175/185 |
| MASK ON cut-in (18 frames, 12 fps) | GTD 0–85 |
| MASK OFF cut-in | GTD 315/320/325 |
| Rival panel | WL blue 255/260 + reach 270/275; cap 315/320/325 |
| Palm transition | GTD 105/110/115 |
| 色より burst | WL 365/375 |
| Card stickers | crops of `one-180`, `wave-215`, `bluesmirk-260`, `peace-185`, `smirk-005` |

Gate A evidence is in `art/side_by_side.png` (game frames next to the official frames).
