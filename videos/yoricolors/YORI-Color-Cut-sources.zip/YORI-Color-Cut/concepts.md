# YORI — game concepts

## Brainstorm (one-liners)
1. **COLOR CUT.** You hit YORI's own moves on the beat to colour-cut the screen, while the colours try to fool you.
2. **MASK QUICK DRAW.** You tie the oni mask on the instant the screen flashes the right colour, while fake colours bait early pulls.
3. **CAMO.** You swap the background colour so YORI blends in while a watcher scans the room. *(needs full-body art the project hasn't published)*
4. **MORE THAN COLORS (shell game).** You track the real YORI through shuffling colour clones while the colours themselves swap.
5. **GESTURE DUEL.** You copy the blue kid's gesture phrases call-and-response style.
6. **HEAD-PAT DODGE.** You keep your cool while the bandaged hand tries to pat your head.
7. **COLOR DRAIN.** You keep the world coloured by cutting on the beat while grayscale creeps in.
8. **CORD SWING.** You swing on the red cord between colour anchors. *(no full-body art)*
9. **TAG THE TOWN.** You spray colour tags as a masked operative. *(invents a setting)*
10. **PANEL EDIT.** You edit YORI's hype video by cutting shots on the beat.
11. **STICKER SLAP.** You slap matching YORI stickers onto a scrolling wall.
12. **RED CORD CONNECT.** You draw the cord between same-colour masks. *(Flow-style reskin)*
13. **WINK CATCH.** You snap the photo in the frame YORI winks.
14. **NIGHT SHIFT.** You keep the eye-bag kid awake by reacting to night noises.
15. **SHH STEALTH.** Rejected after art review: the only "shh" frames are ambiguous gestures.
16–20. The obvious set (runner, fighter, match-3, flappy, platformer) was thrown out; no twist from YORI's own material.

## Top five
| | Rule | 30-second loop | Lore fit | Score / share moment |
|---|---|---|---|---|
| **COLOR CUT** | Hit the move on the beat; blue cards are bait; later, card colours lie. | Cards fly from the rival → hit ONE / WAVE on the ring → each hit becomes a colour-cut shot of YORI → fill MASK → MASK ON ×2 at the drop → COLORS LIE → result. | Their videos *are* beat-cut colour shots of his gestures; "More than colors" becomes the twist; the mask reveal becomes the fever; the blue variant throws the bait. | Score, combo, accuracy rank ("MORE THAN COLORS" … "GRAYSCALE"), a "YOUR CUT" colour barcode, a card in their WL-card style. |
| **MASK QUICK DRAW** | Pull the mask the moment the screen cuts to red. | Wait → colour flashes → slam → ms time; fakes punish early pulls. | Uses the mask-tie frames and the colour cuts. | Reaction ms. Bots would trivially win, which weakens the WL angle. |
| **CAMO** | Match the background to hide. | Watcher sweeps → swap colour → survive. | Plays on colours. | Survival time. Needs art that doesn't exist. |
| **GESTURE DUEL** | Repeat the rival's gesture phrase in rhythm. | Rival phrase → your phrase → longer phrases. | Gestures plus the blue variant. | Phrase length. Hard to read with the sound off. |
| **SHELL GAME** | Find the real YORI among colour clones. | Mask on → clones shuffle → colours swap → pick. | The literal tagline. | Streak. Short sessions, weak trailer motion. |

## Scores (1–10)
| Concept | Lore fit | Originality | 5-s clarity | Replay | Share | Trailer | 5-day build | **Total** |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **COLOR CUT** | 9 | 7 | 8 | 8 | 8 | 9 | 9 | **58** |
| MASK QUICK DRAW | 8 | 6 | 9 | 6 | 7 | 7 | 10 | 53 |
| GESTURE DUEL | 8 | 7 | 6 | 7 | 7 | 8 | 8 | 51 |
| SHELL GAME | 9 | 7 | 7 | 5 | 6 | 6 | 9 | 49 |
| CAMO | 7 | 8 | 6 | 6 | 6 | 6 | 6 | 45 |

**Winner: COLOR CUT (58/70).**
1. It turns YORI's own editing language (one flat colour per shot, cut on the beat, a new gesture each cut) into the core feedback loop.
2. The project's only tagline, "More than colors", becomes the escalation rule: colours lie, read the move.
3. Every pose, the mask reveal, the bait thrower and the result card come straight from their published art and site.

**Honest originality note (7, not 8).** The base verb is a familiar rhythm-reading loop. YORI-specific identity lives in the moves, the colour-cut presentation, the bait from the blue variant, MASK ON from the GTD video, and the COLORS LIE rule. A different collection could reuse the base rhythm loop, but not the rest.
