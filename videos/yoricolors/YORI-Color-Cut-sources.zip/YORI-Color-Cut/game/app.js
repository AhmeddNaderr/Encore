/* YORI: COLOR CUT — app shell: assets, screens, input, audio, capture API. */
'use strict';

const SAMPLE_BOARD = [
  ['holder_01', 331920], ['holder_02', 324480], ['holder_03', 297460], ['holder_04', 288020], ['holder_05', 276300],
  ['holder_06', 263950], ['holder_07', 251480], ['holder_08', 240210], ['holder_09', 229870], ['holder_10', 214640],
];

function b64ToBuf(dataUrl) {
  const b64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
  const bin = atob(b64); const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

async function loadAssets() {
  const M = window.__YORI;
  const img = {};
  await Promise.all(Object.entries(M.images).map(([k, src]) => new Promise((res) => {
    const im = new Image(); im.onload = () => { img[k] = im; res(); }; im.onerror = () => { console.warn('asset failed', k); res(); }; im.src = src;
  })));
  for (const f of M.fonts) {
    try { const ff = new FontFace(f.family, `url(${f.src})`, { weight: String(f.weight) }); await ff.load(); document.fonts.add(ff); } catch (e) { console.warn('font', f.family, e); }
  }
  return { img, meta: M.meta };
}

/* ---------------------------------------------------------------- cards */
class Cards {
  constructor(R) { this.R = R; }
  get ctx() { return this.R.ctx; }
  bg(L, col1, col2, t) {
    const ctx = this.ctx, W = L.W, H = L.H;
    const g = ctx.createLinearGradient(0, 0, W, H); g.addColorStop(0, col1); g.addColorStop(1, col2);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    this.R.drawSpeedLines(L, t, 'rgba(255,255,255,0.09)');
    for (let i = 0; i < 34; i++) {
      const sp = 0.04 + 0.06 * hash32(i, 11), ph = (t * sp + hash32(i, 12)) % 1;
      const x = (hash32(i, 13) * 1.1 - 0.05) * W + Math.sin(t * 0.9 + i) * 26 * L.u, y = H * (ph * 1.2 - 0.1);
      ctx.save(); ctx.translate(x, y); ctx.rotate(t * (0.6 + hash32(i, 14)) + i); ctx.globalAlpha = 0.55;
      ctx.fillStyle = PAL.site[i % 4]; ctx.fillRect(-9 * L.u, -5 * L.u, 18 * L.u, 10 * L.u); ctx.restore();
    }
    ctx.save(); ctx.globalAlpha = 0.05; ctx.globalCompositeOperation = 'overlay'; ctx.fillStyle = ctx.createPattern(this.R.noise, 'repeat'); ctx.fillRect(0, 0, W, H); ctx.restore();
  }
  fourDots(x, y, r, gap) { const ctx = this.ctx; PAL.site.forEach((c, i) => { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x + i * gap, y, r, 0, Math.PI * 2); ctx.fill(); }); }
  gradText(s, x, y, size, align = 'left') {
    const ctx = this.ctx; ctx.save(); ctx.font = FONT(700, size); ctx.textAlign = align;
    const w = ctx.measureText(s).width; const x0 = align === 'left' ? x : align === 'center' ? x - w / 2 : x - w;
    const g = ctx.createLinearGradient(x0, 0, x0 + w, 0); g.addColorStop(0, '#FF5FB0'); g.addColorStop(0.55, '#7A6BFF'); g.addColorStop(1, '#19D3A8');
    ctx.fillStyle = g; ctx.fillText(s, x, y); ctx.restore();
  }

  /* Result card in the visual language of YORI's own WL status card. */
  resultCard(cx, cy, w, res, t, opts = {}) {
    const ctx = this.ctx, h = w * 0.62, u = w / 1000;
    ctx.save(); ctx.translate(cx, cy); if (opts.rot) ctx.rotate(opts.rot); if (opts.scale) ctx.scale(opts.scale, opts.scale);
    const x = -w / 2, y = -h / 2;
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, x + 14 * u, y + 18 * u, w, h, 46 * u); ctx.fill();
    const g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, '#FF5FB0'); g.addColorStop(0.55, '#7A6BFF'); g.addColorStop(1, '#19D3A8');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, 46 * u); ctx.fill();
    if (opts.shine != null) {
      const sp = ((opts.shine * 0.55) % 1) * 1.6 - 0.3;
      ctx.save(); rr(ctx, x, y, w, h, 46 * u); ctx.clip();
      const sg = ctx.createLinearGradient(x + sp * w - 120 * u, y, x + sp * w + 120 * u, y + h * 0.4);
      sg.addColorStop(0, 'rgba(255,255,255,0)'); sg.addColorStop(0.5, 'rgba(255,255,255,0.55)'); sg.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = sg; ctx.fillRect(x, y, w, h); ctx.restore();
    }
    const ix = x + 34 * u, iy = y + 34 * u, iw = w - 68 * u, ih = h - 68 * u;
    ctx.fillStyle = '#FFFFFF'; rr(ctx, ix, iy, iw, ih, 34 * u); ctx.fill();
    this.fourDots(ix + iw - 150 * u, iy + 46 * u, 11 * u, 32 * u);
    // avatar
    const ax = ix + 104 * u, ay = iy + 112 * u, ar = 66 * u;
    ctx.save(); ctx.beginPath(); ctx.arc(ax, ay, ar + 6 * u, 0, Math.PI * 2); ctx.fillStyle = g; ctx.fill();
    ctx.beginPath(); ctx.arc(ax, ay, ar, 0, Math.PI * 2); ctx.clip();
    const av = this.R.img('avatar'); if (av) ctx.drawImage(av, ax - ar, ay - ar, ar * 2, ar * 2);
    ctx.restore();
    txt(ctx, res.player || 'PLAYER ONE', ix + 200 * u, iy + 100 * u, { size: 44 * u, align: 'left', fill: '#2B1F4A', font: FONT(700, 44 * u) });
    txt(ctx, 'COLOR CUT · result', ix + 200 * u, iy + 142 * u, { size: 26 * u, align: 'left', fill: '#7D7296', font: NFONT(700, 26 * u) });
    // score
    const sc = opts.tally != null ? Math.round(res.score * opts.tally) : res.score;
    txt(ctx, sc.toLocaleString('en-US'), ix + 50 * u, iy + 300 * u, { size: 112 * u, align: 'left', fill: '#2B1F4A' });
    this.gradText(res.rank.title, ix + 54 * u, iy + 352 * u, 46 * u);
    // stats
    const stats = [['PERFECT', res.stats.perfect], ['MAX COMBO', res.maxCombo + 'x'], ['ACCURACY', (res.accuracy * 100).toFixed(1) + '%']];
    stats.forEach(([k, v], i) => {
      const sx = ix + 50 * u + i * 205 * u;
      txt(ctx, String(v), sx, iy + 432 * u, { size: 40 * u, align: 'left', fill: '#2B1F4A' });
      txt(ctx, k, sx, iy + 462 * u, { size: 20 * u, align: 'left', fill: '#7D7296', font: NFONT(800, 20 * u) });
    });
    // rank letter badge
    const bx = ix + iw - 140 * u, by = iy + 250 * u;
    ctx.save(); ctx.translate(bx, by); ctx.rotate(-0.12);
    const stamp = opts.stamp != null ? opts.stamp : 1;
    const ss = stamp < 1 ? 2.2 - 1.2 * easeOutBack(stamp) : 1; ctx.scale(ss, ss); ctx.globalAlpha = clamp(stamp * 3);
    ctx.fillStyle = '#FFC14D'; ctx.beginPath(); ctx.arc(0, 0, 88 * u, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#2B1F4A'; ctx.lineWidth = 8 * u; ctx.stroke();
    txt(ctx, res.rank.letter, 0, 44 * u, { size: 130 * u, fill: '#2B1F4A' });
    ctx.restore();
    // your cut — colour barcode of the run (one stripe per bar)
    const cutX = ix + iw - 330 * u, cutY = iy + 392 * u, cutW = 290 * u, cutH = 54 * u;
    txt(ctx, 'YOUR CUT', cutX, cutY - 10 * u, { size: 20 * u, align: 'left', fill: '#7D7296', font: NFONT(800, 20 * u) });
    const bars = res.cut || [];
    const n = Math.max(1, bars.length);
    ctx.save(); rr(ctx, cutX, cutY, cutW, cutH, 12 * u); ctx.clip();
    bars.forEach((c, i) => { ctx.fillStyle = c; ctx.fillRect(cutX + (i / n) * cutW, cutY, cutW / n + 1, cutH); });
    ctx.restore();
    ctx.strokeStyle = '#2B1F4A'; ctx.lineWidth = 4 * u; rr(ctx, cutX, cutY, cutW, cutH, 12 * u); ctx.stroke();
    // status pill like the WL card
    if (res.rankNo) {
      const px = ix + iw - 330 * u, py = iy + 470 * u;
      ctx.fillStyle = '#FFC14D'; rr(ctx, px, py, 290 * u, 64 * u, 32 * u); ctx.fill();
      txt(ctx, 'SAMPLE WL RANK', px + 30 * u, py + 27 * u, { size: 17 * u, align: 'left', fill: '#2B1F4A', font: NFONT(800, 17 * u) });
      txt(ctx, '#' + res.rankNo, px + 30 * u, py + 56 * u, { size: 30 * u, align: 'left', fill: '#2B1F4A' });
    }
    ctx.restore();
    return h;
  }

  leaderboard(L, res, lt, opts = {}) {
    const ctx = this.ctx, W = L.W, H = L.H, u = L.u;
    this.bg(L, '#2B1F4A', '#151116', lt);
    if (!L.portrait && !opts.hideSmirk) {
      const name = ['smirk-000', 'smirk-005', 'smirk-010', 'smirk-005'][Math.floor(lt * 2.6) % 4];
      const im = this.R.img(name), m = this.R.spriteMeta[name];
      if (im && m) { const sc = H / 1080 * 0.78; const cx = W * 0.8 + Math.sin(lt * 1.4) * 6 * u; ctx.drawImage(im, cx - m.frameW / 2 * sc + m.x0 * sc, H - m.h * sc + (1 - easeOut(lt / 0.5)) * 80 * u, m.w * sc, m.h * sc); }
    }
    const listX = W * 0.06, listW = L.portrait ? W * 0.88 : W * 0.5;
    const top = L.portrait ? H * 0.075 : H * 0.07;
    const titleSize = L.portrait ? 0.085 * W : 0.07 * H;
    const cx = listX + listW / 2;
    txt(ctx, 'WL LEADERBOARD', cx, top + titleSize, { size: titleSize, fill: '#FFFFFF', stroke: PAL.ink, sw: titleSize * 0.16, shadow: '#7A6BFF' });
    const tagS = titleSize * 0.32;
    ctx.save(); ctx.font = FONT(700, tagS); const tw = ctx.measureText('SAMPLE DATA · NO REAL ALLOCATION').width; ctx.restore();
    ctx.fillStyle = '#FFC14D'; rr(ctx, cx - tw / 2 - 18 * u, top + titleSize * 1.32, tw + 36 * u, tagS * 1.7, tagS * 0.85); ctx.fill();
    txt(ctx, 'SAMPLE DATA · NO REAL ALLOCATION', cx, top + titleSize * 1.32 + tagS * 1.22, { size: tagS, fill: '#2B1F4A' });
    const climb = opts.climb != null ? clamp(opts.climb) : 1;
    const ps = Math.round(res.score * (0.72 + 0.28 * climb));
    const opp = SAMPLE_BOARD.map(([h, sc]) => ({ h, s: sc }));
    let pos = 0; opp.forEach((o) => { pos += clamp((o.s - ps) / 2600 + 0.5); });
    const rowH = L.portrait ? H * 0.052 : H * 0.064, gap = 8 * u;
    const y0 = top + titleSize * 2.3;
    const drawRow = (label, score, rankNo, y, you, alpha) => {
      if (alpha <= 0) return;
      ctx.save(); ctx.globalAlpha = clamp(alpha);
      if (you) { ctx.shadowColor = 'rgba(253,220,3,0.6)'; ctx.shadowBlur = 24 * u; }
      ctx.fillStyle = you ? '#FDDC03' : 'rgba(255,255,255,0.94)'; rr(ctx, listX, y, listW, rowH, rowH * 0.3); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = PAL.ink; ctx.lineWidth = (you ? 6 : 3) * u; rr(ctx, listX, y, listW, rowH, rowH * 0.3); ctx.stroke();
      const fs = rowH * 0.42;
      txt(ctx, '#' + rankNo, listX + 26 * u, y + rowH * 0.66, { size: fs, align: 'left', fill: '#2B1F4A' });
      ctx.fillStyle = PAL.site[(rankNo + 1) % 4]; ctx.beginPath(); ctx.arc(listX + rowH * 2.0, y + rowH / 2, rowH * 0.3, 0, Math.PI * 2); ctx.fill();
      if (you) { ctx.save(); ctx.beginPath(); ctx.arc(listX + rowH * 2.0, y + rowH / 2, rowH * 0.3, 0, Math.PI * 2); ctx.clip(); const av = this.R.img('avatar'); if (av) ctx.drawImage(av, listX + rowH * 1.7, y + rowH * 0.2, rowH * 0.6, rowH * 0.6); ctx.restore(); }
      ctx.save(); ctx.font = NFONT(800, fs); const lw = ctx.measureText(label).width; ctx.font = FONT(700, fs); const sw2 = ctx.measureText(score.toLocaleString('en-US')).width; ctx.restore();
      if (you && rowH * 2.55 + lw + sw2 + 60 * u > listW) label = 'YOU';
      txt(ctx, label, listX + rowH * 2.55, y + rowH * 0.66, { size: fs, align: 'left', fill: '#2B1F4A', font: NFONT(800, fs) });
      txt(ctx, score.toLocaleString('en-US'), listX + listW - 26 * u, y + rowH * 0.66, { size: fs, align: 'right', fill: '#2B1F4A' });
      ctx.restore();
    };
    opp.forEach((o, j) => {
      const shift = clamp((ps - o.s) / 2600 + 0.5);   // 1 once the player has passed this row
      const p = j + shift;
      const appear = clamp((lt - 0.045 * j) / 0.25);
      const fade = clamp(10 - p);
      drawRow(o.h, o.s, Math.round(p) + 1, y0 + p * (rowH + gap) + (1 - easeOut(appear)) * 40 * u, false, appear * fade);
    });
    const pa = clamp((lt - 0.5) / 0.25);
    const py = y0 + Math.min(pos, 9.6) * (rowH + gap) + (1 - easeOut(pa)) * 40 * u - Math.sin(lt * 6) * 2 * u;
    drawRow((res.player || 'you') + '  (YOU)', ps, Math.round(Math.min(pos, 10)) + 1, py, true, pa);
    return { listX, listW, bottom: y0 + 10 * (rowH + gap) };
  }

  postMock(L, res, lt) {
    const ctx = this.ctx, W = L.W, H = L.H, u = L.u;
    this.bg(L, '#151116', '#2B1F4A', lt);
    const pw = L.portrait ? W * 0.9 : W * 0.46, ph = pw * 1.0;
    const k = easeOut(lt / 0.35);
    ctx.save(); const push = 1 + 0.02 * lt; ctx.translate(W / 2, H / 2); ctx.scale(push, push); ctx.translate(-W / 2, -H / 2);
    const px = W / 2 - pw / 2, py = (L.portrait ? H * 0.2 : H * 0.06) + (1 - k) * 60 * u;
    ctx.save(); ctx.globalAlpha = k;
    ctx.fillStyle = '#FFFFFF'; rr(ctx, px, py, pw, ph, 30 * u); ctx.fill();
    const s = pw / 1000;
    ctx.fillStyle = PAL.site[2]; ctx.beginPath(); ctx.arc(px + 80 * s, py + 84 * s, 42 * s, 0, Math.PI * 2); ctx.fill();
    txt(ctx, 'H', px + 80 * s, py + 100 * s, { size: 44 * s, fill: '#FFFFFF' });
    txt(ctx, 'holder_03', px + 140 * s, py + 76 * s, { size: 36 * s, align: 'left', fill: '#151116', font: NFONT(800, 36 * s) });
    txt(ctx, '@holder_03 · now', px + 140 * s, py + 114 * s, { size: 28 * s, align: 'left', fill: '#6B6B7B', font: NFONT(700, 28 * s) });
    const lines = [`Read the move. Hit ${res.maxCombo}x on YORI: COLOR CUT.`, 'More than colors @yoricolors'];
    lines.forEach((l, i) => txt(ctx, l, px + 50 * s, py + 190 * s + i * 48 * s, { size: 34 * s, align: 'left', fill: '#151116', font: NFONT(700, 34 * s) }));
    ctx.restore();
    // result card flies in
    const ck = easeOutBack(clamp((lt - 0.25) / 0.45));
    const cw = pw - 100 * s;
    const startY = H * 1.2, endY = py + 300 * s + cw * 0.31;
    this.resultCard(W / 2, lerp(startY, endY, ck), cw, res, lt, { rot: lerp(0.25, 0, ck), stamp: 1 });
    // engagement row + mock label
    const ey = py + ph - 50 * s;
    ctx.save(); ctx.globalAlpha = k;
    const likes = Math.round(1200 + 160 * clamp((lt - 0.6) / 1.2)), rts = Math.round(318 + 41 * clamp((lt - 0.7) / 1.2)), rep2 = Math.round(96 + 14 * clamp((lt - 0.8) / 1.2));
    [`♡  ${(likes / 1000).toFixed(2)}K`, `↻  ${rts}`, `◯  ${rep2}`].forEach((l, i) => txt(ctx, l, px + 70 * s + i * 230 * s, ey, { size: 30 * s, align: 'left', fill: '#6B6B7B', font: NFONT(700, 30 * s) }));
    ctx.restore();
    ctx.restore();
    const tagS = (L.portrait ? 0.032 * W : 0.026 * H);
    txt(ctx, 'POST MOCK-UP · NOTHING IS POSTED', W / 2, Math.min(H - tagS * 0.8, py + ph + tagS * 1.9), { size: tagS, fill: '#FFFFFF', font: FONT(600, tagS), ls: 3 * u });
  }

  endCard(L, lt) {
    const ctx = this.ctx, W = L.W, H = L.H, u = L.u;
    ctx.fillStyle = '#000000'; ctx.fillRect(0, 0, W, H);
    ctx.save(); const push = 1 + 0.012 * lt; ctx.translate(W / 2, H / 2); ctx.scale(push, push); ctx.translate(-W / 2, -H / 2);
    const k1 = easeOut(lt / 0.4);
    const ban = this.R.img('banner');
    const bw = L.portrait ? W * 0.82 : W * 0.40, bh = bw / 3;
    const by = L.portrait ? H * 0.16 : H * 0.07;
    ctx.save(); ctx.globalAlpha = k1; ctx.translate(W / 2, by + bh / 2 + (1 - k1) * 30 * u);
    ctx.save(); rr(ctx, -bw / 2, -bh / 2, bw, bh, 26 * u); ctx.clip(); if (ban) ctx.drawImage(ban, -bw / 2, -bh / 2, bw, bh); ctx.restore();
    ctx.restore();
    const k2 = easeOut((lt - 0.15) / 0.4);
    const ts = L.portrait ? 0.13 * W : 0.105 * H;
    ctx.save(); ctx.globalAlpha = clamp(k2);
    txt(ctx, 'COLOR CUT', W / 2, by + bh + ts * 1.15, { size: ts, fill: '#FFFFFF', stroke: '#000', sw: 0, shadow: '#E04A35', sx: ts * 0.05, sy: ts * 0.06 });
    txt(ctx, 'a YORI game concept · More than colors', W / 2, by + bh + ts * 1.75, { size: ts * 0.26, fill: '#FDDC03', font: FONT(600, ts * 0.26), ls: 2 * u });
    ctx.restore();
    const k3 = easeOut((lt - 0.35) / 0.45);
    ctx.save(); ctx.globalAlpha = clamp(k3);
    const gy = by + bh + ts * 2.55;
    const small = L.portrait ? 0.03 * W : 0.022 * H;
    txt(ctx, 'A GAME CONCEPT BY', W / 2, gy, { size: small, fill: '#BDBDBD', font: NFONT(800, small), ls: 5 * u });
    const em = this.R.img('encore-mark');
    const ew = L.portrait ? W * 0.18 : H * 0.15, eh = em ? ew * em.height / em.width : 0;
    if (em) ctx.drawImage(em, W / 2 - ew / 2, gy + small * 0.9, ew, eh);
    const ny = gy + small * 0.9 + eh + small * 2.0;
    txt(ctx, 'ENCORE STUDIO', W / 2, ny, { size: small * 1.35, fill: '#FFFFFF', font: NFONT(800, small * 1.35), ls: 4 * u });
    txt(ctx, 'One crew for your whole launch.', W / 2, ny + small * 2.6, { size: small * 1.7, fill: '#FFFFFF', font: NFONT(700, small * 1.7) });
    txt(ctx, 'encorestudio.xyz  ·  @EncoreStudiohq', W / 2, ny + small * 4.6, { size: small * 1.25, fill: '#DADADA', font: NFONT(700, small * 1.25) });
    txt(ctx, 'Book a free 30-min call', W / 2, ny + small * 6.2, { size: small * 1.05, fill: '#BDBDBD', font: NFONT(700, small * 1.05) });
    ctx.restore();
    ctx.restore();
    ctx.save(); ctx.globalAlpha = clamp(k3); txt(ctx, 'UNOFFICIAL CONCEPT · ORIGINAL YORI ART · NOT AFFILIATED WITH OR ENDORSED BY YORI', W / 2, H - small * 1.6, { size: small * 0.62, fill: '#8A8A8A', font: NFONT(800, small * 0.62), ls: 2 * u }); ctx.restore();
  }

  title(L, t) {
    const ctx = this.ctx, W = L.W, H = L.H, u = L.u;
    ctx.fillStyle = PAL.bannerYellow; ctx.fillRect(0, 0, W, H);
    this.R.drawSpeedLines(L, t * 0.4, 'rgba(255,255,255,0.22)');
    const name = ['smirk-000', 'smirk-005', 'smirk-010', 'smirk-005'][Math.floor(t * 2.6) % 4];
    const im = this.R.img(name), m = this.R.spriteMeta[name];
    if (im && m) {
      const s = L.portrait ? (W / 1080) * 0.86 : H / 1080 * 1.0;
      const cx = L.portrait ? W * 0.5 : W * 0.74;
      ctx.drawImage(im, cx - m.frameW / 2 * s + m.x0 * s, H - m.h * s, m.w * s, m.h * s);
    }
    const logo = this.R.img('logo-keyed');
    const lw = L.portrait ? W * 0.56 : W * 0.25;
    const colX = L.portrait ? W / 2 : W * 0.06 + lw / 2;
    const ly = L.portrait ? H * 0.045 : H * 0.06;
    const lh = logo ? lw * logo.height / logo.width : lw * 0.6;
    if (logo) ctx.drawImage(logo, colX - lw / 2, ly, lw, lh);
    const tsz = L.portrait ? 0.14 * W : 0.105 * H;
    const ty = ly + lh + tsz * 0.95;
    txt(ctx, 'COLOR CUT', colX, ty, { size: tsz, fill: '#FFFFFF', stroke: PAL.ink, sw: tsz * 0.18, shadow: PAL.red });
    txt(ctx, 'Read the move. Hit the beat.', colX, ty + tsz * 0.55, { size: tsz * 0.3, fill: PAL.ink, font: FONT(700, tsz * 0.3) });
    const rows = [['one', '◀ / A', 'ONE'], ['wave', '▶ / D', 'WAVE'], ['bait', 'BLUE CARD', "DON'T TOUCH"]];
    const cs = L.portrait ? 0.15 * W : 0.1 * H;
    const gap = L.portrait ? W * 0.29 : cs * 1.9;
    const ry = ty + tsz * 0.62 + cs * 0.85;
    rows.forEach(([ty2, keys, label], i) => {
      const x = colX + (i - 1) * gap;
      this.R.drawCard({ type: ty2, i }, x, ry, cs, ty2 === 'one' ? PAL.red : ty2 === 'wave' ? PAL.yellow : PAL.blue, 1, (i - 1) * 0.06, null, 0);
      txt(ctx, label, x, ry + cs * 0.92, { size: cs * 0.25, fill: '#FFFFFF', stroke: PAL.ink, sw: cs * 0.07 });
      txt(ctx, keys, x, ry + cs * 1.2, { size: cs * 0.19, fill: PAL.ink, font: FONT(700, cs * 0.19) });
    });
    const py = ry + cs * 1.62;
    const bw = L.portrait ? W * 0.64 : W * 0.28, bh = L.portrait ? 0.075 * W : 0.075 * H;
    const pulse = 1 + 0.03 * Math.sin(t * 5);
    ctx.save(); ctx.translate(colX, py + bh / 2); ctx.scale(pulse, pulse);
    ctx.fillStyle = PAL.ink; rr(ctx, -bw / 2, -bh / 2, bw, bh, bh / 2); ctx.fill();
    txt(ctx, L.portrait ? 'TAP TO PLAY' : 'PRESS SPACE  ·  TAP', 0, bh * 0.17, { size: bh * 0.42, fill: '#FFFFFF' });
    ctx.restore();
    const fs = L.portrait ? 0.024 * W : 0.019 * H;
    const tip1 = 'Fill the MASK meter before the drop for ×2.';
    const tip2 = 'Later, colors lie: trust the move, not the color.';
    txt(ctx, tip1, colX, py + bh + fs * 2.0, { size: fs * 1.15, fill: '#FFFFFF', stroke: PAL.ink, sw: fs * 0.32, font: NFONT(800, fs * 1.15) });
    txt(ctx, tip2, colX, py + bh + fs * 3.5, { size: fs * 1.15, fill: '#FFFFFF', stroke: PAL.ink, sw: fs * 0.32, font: NFONT(800, fs * 1.15) });
    const foot = 'Unofficial concept by Encore Studio  ·  Character art © YORI (@yoricolors)  ·  Original music & SFX  ·  P = watch demo';
    if (L.portrait) {
      txt(ctx, 'Unofficial concept by Encore Studio · Art © YORI (@yoricolors)', W / 2, H - fs * 2.6, { size: fs * 0.95, fill: '#FFFFFF', stroke: PAL.ink, sw: fs * 0.3, font: NFONT(800, fs * 0.95) });
      txt(ctx, 'Original music & SFX · P = watch demo', W / 2, H - fs * 1.2, { size: fs * 0.95, fill: '#FFFFFF', stroke: PAL.ink, sw: fs * 0.3, font: NFONT(800, fs * 0.95) });
    } else txt(ctx, foot, W * 0.03, H - fs * 1.2, { size: fs, align: 'left', fill: '#FFFFFF', stroke: PAL.ink, sw: fs * 0.3, font: NFONT(800, fs) });
  }
}

/* ---------------------------------------------------------------- app */
const App = {
  async boot(opts = {}) {
    this.canvas = document.getElementById('c');
    this.ctx = this.canvas.getContext('2d');
    this.assets = await loadAssets();
    this.chart = window.__YORI.chart;
    this.R = new Renderer(this.ctx, this.assets, this.chart);
    this.C = new Cards(this.R);
    this.mode = 'title'; this.t0 = performance.now();
    this.offset = 0;
    try { this.offset = Number(localStorage.getItem('yori-offset') || 0); } catch (e) {}
    if (!opts.capture) {
      this.resize(); addEventListener('resize', () => this.resize());
      this.bindInput();
      requestAnimationFrame(() => this.loop());
    }
    return this;
  },
  resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = Math.round(innerWidth * dpr), h = Math.round(innerHeight * dpr);
    const maxSide = 1920; const k = Math.min(1, maxSide / Math.max(w, h));
    this.canvas.width = Math.round(w * k); this.canvas.height = Math.round(h * k);
    this.canvas.style.width = innerWidth + 'px'; this.canvas.style.height = innerHeight + 'px';
  },
  async initAudio() {
    if (this.ac) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ac = new AC({ latencyHint: 'interactive' });
    const A = window.__YORI.audio;
    const dec = async (src) => await this.ac.decodeAudioData(b64ToBuf(src));
    this.song = await dec(A.song);
    this.loopBuf = await dec(A.loop);
    this.sfx = {};
    await Promise.all(Object.entries(A.sfx).map(async ([k, v]) => { this.sfx[k] = await dec(v); }));
    this.master = this.ac.createGain(); this.master.gain.value = 0.9; this.master.connect(this.ac.destination);
    this.sfxGain = this.ac.createGain(); this.sfxGain.gain.value = 0.55; this.sfxGain.connect(this.master);
  },
  audioNow() {
    const ac = this.ac;
    if (ac.getOutputTimestamp) { const ts = ac.getOutputTimestamp(); if (ts.contextTime > 0 && ts.performanceTime > 0) return ts.contextTime + (performance.now() - ts.performanceTime) / 1000; }
    return ac.currentTime - (ac.outputLatency || ac.baseLatency || 0);
  },
  play(name, gain = 1) {
    if (!this.ac || !this.sfx[name]) return;
    const s = this.ac.createBufferSource(); s.buffer = this.sfx[name];
    const g = this.ac.createGain(); g.gain.value = gain; s.connect(g); g.connect(this.sfxGain); s.start();
  },
  startLoopMusic() {
    this.stopMusic();
    const s = this.ac.createBufferSource(); s.buffer = this.loopBuf; s.loop = true;
    const g = this.ac.createGain(); g.gain.value = 0.7; s.connect(g); g.connect(this.master); s.start(); this.musicNode = s;
  },
  stopMusic() { if (this.musicNode) { try { this.musicNode.stop(); } catch (e) {} this.musicNode = null; } },
  async startRun(demo = false) {
    await this.initAudio();
    if (this.ac.state === 'suspended') await this.ac.resume();
    this.stopMusic();
    this.E = new Engine(this.chart);
    this.demoInputs = demo ? autoplayInputs(this.chart, { seed: (Date.now() & 0xffff) }) : null; this.demoIdx = 0;
    this.demo = demo;
    this.evSeen = 0;
    const s = this.ac.createBufferSource(); s.buffer = this.song; s.connect(this.master);
    const when = this.ac.currentTime + 0.35; s.start(when); this.musicNode = s;
    this.songStart = when; this.mode = 'play'; this.queue = [];
    this.hintT = 0;
  },
  songTime() { return this.audioNow() - this.songStart + this.offset / 1000; },
  bindInput() {
    const laneOf = (code) => ({ ArrowLeft: 'one', KeyA: 'one', KeyF: 'one', ArrowRight: 'wave', KeyD: 'wave', KeyJ: 'wave', KeyK: 'wave' })[code];
    addEventListener('keydown', (e) => {
      if (e.repeat) return;
      const lane = laneOf(e.code);
      if (this.mode === 'play' && lane && !this.demo) { this.queue.push({ lane, ts: e.timeStamp }); e.preventDefault(); return; }
      if (e.code === 'BracketLeft' || e.code === 'BracketRight') { this.offset += e.code === 'BracketLeft' ? -5 : 5; try { localStorage.setItem('yori-offset', this.offset); } catch (x) {} this.toast = { text: `timing offset ${this.offset} ms`, t: performance.now() }; return; }
      if (this.mode === 'title') { if (e.code === 'KeyP') this.startRun(true); else if (e.code === 'Space' || e.code === 'Enter' || lane) this.startRun(false); e.preventDefault(); return; }
      if (this.mode === 'results' || this.mode === 'board') {
        if (e.code === 'KeyL') { this.mode = this.mode === 'board' ? 'results' : 'board'; this.play('whoosh'); }
        else if (e.code === 'KeyS') this.share();
        else if (e.code === 'Space' || e.code === 'Enter') this.startRun(false);
        else if (e.code === 'Escape') { this.mode = 'title'; this.startLoopMusic(); }
        e.preventDefault(); return;
      }
      if (this.mode === 'play' && e.code === 'Escape') { this.stopMusic(); this.mode = 'title'; this.startLoopMusic(); }
    });
    this.canvas.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      const r = this.canvas.getBoundingClientRect(); const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      if (this.mode === 'play' && !this.demo) { this.queue.push({ lane: x < 0.5 ? 'one' : 'wave', ts: e.timeStamp }); return; }
      if (this.mode === 'title') { this.startRun(false); return; }
      if (this.mode === 'results' || this.mode === 'board') {
        const hit = (this.btns || []).find((b) => x >= b.x0 && x <= b.x1 && y >= b.y0 && y <= b.y1);
        if (hit) hit.fn();
      }
    }, { passive: false });
    document.addEventListener('visibilitychange', () => { if (document.hidden && this.mode === 'play' && this.ac) { this.stopMusic(); this.mode = 'title'; } });
  },
  share() {
    const r = this.result; if (!r) return;
    const text = `I hit ${r.score.toLocaleString('en-US')} (${r.maxCombo}x combo, ${r.rank.title}) in YORI: COLOR CUT. More than colors @yoricolors  [unofficial fan-made concept]`;
    const done = () => { this.toast = { text: 'Share text copied — nothing was posted', t: performance.now() }; this.play('click'); };
    try { navigator.clipboard.writeText(text).then(done, done); } catch (e) { done(); }
  },
  buildResult() {
    const E = this.E;
    const cut = [];
    const bars = this.chart.bars; const BAR = this.chart.bar;
    for (let b = 0; b < bars; b++) {
      const t = (b + 0.98) * BAR; const V = this.R.vstate(E, t);
      cut.push(this.R.stageColor(V, t));
    }
    const all = SAMPLE_BOARD.map((x) => x[1]).concat([E.score]).sort((a, b) => b - a);
    return { score: E.score, maxCombo: E.maxCombo, stats: E.stats, accuracy: E.accuracy(), rank: E.rank(), cut, rankNo: all.indexOf(E.score) + 1, player: 'PLAYER ONE' };
  },
  loop() {
    requestAnimationFrame(() => this.loop());
    const ctx = this.ctx, W = this.canvas.width, H = this.canvas.height;
    const L = makeLayout(W, H);
    const now = (performance.now() - this.t0) / 1000;
    if (this.mode === 'title') { this.C.title(L, now); this.drawToast(L); return; }
    if (this.mode === 'play') {
      const t = this.songTime();
      while (this.queue.length) {
        const q = this.queue.shift();
        const ti = t - (performance.now() - q.ts) / 1000;
        this.E.press(q.lane, ti);
      }
      if (this.demo) { while (this.demoIdx < this.demoInputs.length && this.demoInputs[this.demoIdx].t <= t) { const d = this.demoInputs[this.demoIdx++]; this.E.press(d.lane, d.t); } }
      this.E.update(t);
      // sounds for new events
      for (; this.evSeen < this.E.events.length; this.evSeen++) {
        const e = this.E.events[this.evSeen];
        if (e.type === 'hit') { this.play(e.lane === 'one' ? 'hit_one' : 'hit_wave', 0.8); if (e.judge === 'perfect') this.play('perfect', 0.5); }
        else if (e.type === 'miss' || e.type === 'wrong') this.play('miss', 0.8);
        else if (e.type === 'baited') { this.play('bait'); this.play('pat', 0.8); }
        else if (e.type === 'dodge') this.play('dodge', 0.5);
        else if (e.type === 'mask_on') this.play('mask_on', 0.9);
        else if (e.type === 'mask_off') this.play('mask_off', 0.7);
        else if (e.type === 'lie_on') this.play('colors_lie', 0.8);
        else if (e.type === 'milestone') this.play('combo', 0.6);
      }
      const hint = t < 7 ? { text: this.demo ? 'DEMO — watch how it plays' : (L.portrait ? 'TAP LEFT = ONE · TAP RIGHT = WAVE' : '◀ / A = ONE     ▶ / D = WAVE'), t: 3.4 } : null;
      this.R.frame(this.E, t, { hint });
      if (t > this.chart.duration + 1.2) { this.result = this.buildResult(); this.mode = 'results'; this.resT = now; this.play('stamp'); this.startLoopMusic(); }
      this.drawToast(L);
      return;
    }
    if (this.mode === 'results' || this.mode === 'board') {
      const lt = now - this.resT;
      if (this.mode === 'board') this.C.leaderboard(L, this.result, lt, { climb: clamp(lt / 1.2), hideSmirk: true });
      else {
        this.C.bg(L, '#2B1F4A', '#151116', now);
        const cw = L.portrait ? W * 0.92 : W * 0.54;
        this.C.resultCard(L.portrait ? W / 2 : W * 0.37, (L.portrait ? H * 0.33 : H * 0.47) + Math.sin(now * 2.2) * 5 * L.u, cw, this.result, now, { stamp: clamp(lt / 0.5), tally: easeOut(lt / 0.8), shine: now });
      }
      // buttons: right column in landscape, bottom stack in portrait (never over the list or card)
      const labels = [['PLAY AGAIN  (SPACE)', () => this.startRun(false)], [this.mode === 'board' ? 'RESULT  (L)' : 'LEADERBOARD  (L)', () => { this.mode = this.mode === 'board' ? 'results' : 'board'; this.resT = now; this.play('whoosh'); }], ['COPY SHARE TEXT  (S)', () => this.share()]];
      const bw = L.portrait ? W * 0.84 : W * 0.27, bh = L.portrait ? H * 0.052 : H * 0.085;
      this.btns = [];
      labels.forEach(([lab, fn], i) => {
        const x = L.portrait ? W / 2 - bw / 2 : W * 0.695;
        const y = L.portrait ? H * 0.785 + i * (bh + 16 * L.u) : H * 0.30 + i * (bh + 26 * L.u);
        ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, x + 6 * L.u, y + 8 * L.u, bw, bh, bh / 2); ctx.fill();
        ctx.fillStyle = i === 0 ? PAL.bannerYellow : '#FFFFFF'; rr(ctx, x, y, bw, bh, bh / 2); ctx.fill();
        ctx.strokeStyle = PAL.ink; ctx.lineWidth = 6 * L.u; rr(ctx, x, y, bw, bh, bh / 2); ctx.stroke();
        txt(ctx, lab, x + bw / 2, y + bh * 0.63, { size: bh * 0.34, fill: PAL.ink });
        this.btns.push({ x0: x / W, x1: (x + bw) / W, y0: y / H, y1: (y + bh) / H, fn });
      });
      if (!L.portrait) txt(ctx, 'Sample leaderboard · share copies text only · nothing is posted', W * 0.695 + bw / 2, H * 0.30 + 3 * (bh + 26 * L.u) + 30 * L.u, { size: H * 0.018, fill: '#CFC8E6', font: NFONT(700, H * 0.018) });
      this.drawToast(L);
    }
  },
  drawToast(L) {
    if (!this.toast) return;
    const a = (performance.now() - this.toast.t) / 1000; if (a > 2.2) { this.toast = null; return; }
    const ctx = this.ctx; const s = L.portrait ? 0.035 * L.W : 0.03 * L.H;
    ctx.save(); ctx.globalAlpha = clamp((2.2 - a) / 0.3);
    ctx.font = FONT(700, s); const w = ctx.measureText(this.toast.text).width + s * 1.6;
    ctx.fillStyle = PAL.ink; rr(ctx, L.W / 2 - w / 2, L.H * 0.06, w, s * 1.8, s * 0.9); ctx.fill();
    txt(ctx, this.toast.text, L.W / 2, L.H * 0.06 + s * 1.25, { size: s, fill: '#FFFFFF' });
    ctx.restore();
  },
};

/* ---------------------------------------------------------------- capture API (offline, deterministic) */
window.YORI_CAPTURE = {
  async init(w, h) {
    const c = document.getElementById('c'); c.width = w; c.height = h; c.style.width = w + 'px'; c.style.height = h + 'px';
    if (!App.R) await App.boot({ capture: true });
    App.canvas.width = w; App.canvas.height = h;
    return true;
  },
  setupRun(opts) {
    App.E = new Engine(App.chart);
    this.inputs = autoplayInputs(App.chart, opts || {});
    this.k = 0;
    return this.inputs.length;
  },
  advance(t) {
    while (this.k < this.inputs.length && this.inputs[this.k].t <= t) { const d = this.inputs[this.k++]; App.E.press(d.lane, d.t); }
    App.E.update(t);
  },
  renderGame(t, caption) { this.advance(t); App.R.frame(App.E, t, { caption }); return true; },
  result() { return App.buildResult(); },
  renderCard(name, lt, params) {
    const L = makeLayout(App.canvas.width, App.canvas.height);
    const res = params && params.result ? params.result : App.buildResult();
    if (name === 'leaderboard') { const lb = App.C.leaderboard(L, res, lt, Object.assign({ climb: easeInOut((lt - 0.65) / 1.5) }, params || {})); if (params && params.caption) params.caption.pos = L.portrait ? { x: L.W / 2, y: Math.min(L.H * 0.93, lb.bottom + L.H * 0.065) } : { x: L.W * 0.79, y: L.H * 0.36 }; }
    else if (name === 'result') { App.C.bg(L, '#2B1F4A', '#151116', lt); const cw = L.portrait ? L.W * 0.92 : L.W * 0.58; App.C.resultCard(L.W / 2, (L.portrait ? L.H * 0.45 : L.H * 0.5) + Math.sin(lt * 2.2) * 6 * L.u, cw, res, lt, Object.assign({ stamp: clamp((lt - 0.25) / 0.35), tally: easeOut(lt / 0.7), scale: easeOutBack(clamp(lt / 0.35)) * (1 + 0.022 * lt), rot: Math.sin(lt * 1.3) * 0.012, shine: lt }, params || {})); }
    else if (name === 'post') App.C.postMock(L, res, lt);
    else if (name === 'end') App.C.endCard(L, lt);
    else if (name === 'title') App.C.title(L, lt);
    if (params && params.caption) App.R.drawCaption(L, params.caption, params.caption.tNow != null ? params.caption.tNow : lt);
    return true;
  },
  overlay(kind, age) {
    const ctx = App.ctx, W = App.canvas.width, H = App.canvas.height;
    if (kind === 'palm' && age >= 0 && age < 0.22) {
      const im = App.R.img(['palm-105', 'palm-110', 'palm-115'][Math.min(2, Math.floor(age / 0.07))]);
      if (im) { const s = Math.max(W / im.width, H / im.height) * (1.15 - 0.15 * age / 0.22); ctx.save(); ctx.globalAlpha = age < 0.15 ? 1 : 1 - (age - 0.15) / 0.07; ctx.drawImage(im, (W - im.width * s) / 2, (H - im.height * s) / 2, im.width * s, im.height * s); ctx.restore(); }
    }
    if (kind === 'burst' && age >= 0 && age < 0.2) {
      const im = App.R.img(age < 0.1 ? 'iroburst-365' : 'iroburst-375');
      if (im) { const s = Math.max(W / im.width, H / im.height); ctx.save(); ctx.globalAlpha = age < 0.14 ? 1 : 1 - (age - 0.14) / 0.06; ctx.drawImage(im, (W - im.width * s) / 2, (H - im.height * s) / 2, im.width * s, im.height * s); ctx.restore(); }
    }
    return true;
  },
  events() { return App.E.events.map((e) => ({ t: e.t, type: e.type, lane: e.lane || null, judge: e.judge || null, note: e.note ?? null })); },
  summary() { const E = App.E; return { score: E.score, maxCombo: E.maxCombo, stats: E.stats, rank: E.rank(), accuracy: E.accuracy() }; },
};
