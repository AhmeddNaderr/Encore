/* YORI: COLOR CUT — rules engine (pure, deterministic, time-driven).
   Unofficial game concept by Encore Studio. Character art (c) YORI. */
'use strict';

const WIN = { perfect: 0.055, good: 0.11, bait: 0.08, late: 0.14 };
const PTS = { perfect: 300, good: 120, dodge: 150 };

function hash32(a, b = 0, c = 0) {
  let h = (a * 374761393 + b * 668265263 + c * 2246822519) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
function mulberry(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

class Engine {
  constructor(chart) {
    this.chart = chart;
    this.notes = chart.notes.map((n, i) => Object.assign({}, n, { i, state: 0, judge: null, hitT: null, dt: 0 }));
    this.score = 0; this.combo = 0; this.maxCombo = 0; this.meter = 0;
    this.stats = { perfect: 0, good: 0, miss: 0, dodge: 0, baited: 0, wrong: 0 };
    this.events = [];
    this.t = -10;
    this.fever = null; this.lie = false;
    const S = chart.sections;
    const endOf = (k) => (k + 1 < S.length ? S[k + 1].t : chart.duration);
    this.windows = [];
    S.forEach((s, k) => {
      if (s.name === 'drop' || s.name === 'final') this.windows.push({ kind: 'fever', t: s.t, end: endOf(k), done: false });
      if (s.name === 'lie') this.windows.push({ kind: 'lie', t: s.t, end: endOf(k), done: false, off: false });
      this.windows.push({ kind: 'section', name: s.name, t: s.t, done: false });
    });
    this.windows.sort((a, b) => a.t - b.t);
    this.ended = false;
    this.lastColor = 'blue';
  }
  emit(e) { this.events.push(e); return e; }
  mult() { return Math.min(4, 1 + Math.floor(this.combo / 10)) * (this.fever ? 2 : 1); }
  add(kind, t, note) {
    const base = PTS[kind] || 0;
    const m = this.mult();
    this.score += base * m;
    this.combo += 1; this.maxCombo = Math.max(this.maxCombo, this.combo);
    if (!this.fever) this.meter = Math.min(1, this.meter + (kind === 'perfect' ? 0.034 : kind === 'good' ? 0.02 : 0.03));
    if (this.combo % 25 === 0) this.emit({ t, type: 'milestone', combo: this.combo });
  }
  breakCombo(t) {
    if (this.combo >= 10) this.emit({ t, type: 'combo_break', combo: this.combo });
    this.combo = 0;
    if (!this.fever) this.meter = Math.max(0, this.meter - 0.08);
  }
  colorFor(note) {
    // the colour a card shows (lies swap it); stage cuts to the shown colour
    const real = note.type === 'one' ? 'red' : note.type === 'wave' ? 'yellow' : 'blue';
    if (!note.lie) return real;
    if (note.type === 'one') return 'yellow';
    if (note.type === 'wave') return 'red';
    return hash32(note.i, 7) < 0.5 ? 'red' : 'yellow';
  }
  update(t) {
    if (t < this.t) return;
    // scheduled windows (fever / lie / sections) in time order with note resolution
    for (const w of this.windows) {
      if (!w.done && t >= w.t) {
        this.resolveUntil(w.t);
        w.done = true;
        if (w.kind === 'section') this.emit({ t: w.t, type: 'section', name: w.name });
        if (w.kind === 'fever') {
          if (this.meter >= 0.999) { this.fever = { start: w.t, end: w.end }; this.emit({ t: w.t, type: 'mask_on', end: w.end }); }
          else this.emit({ t: w.t, type: 'mask_miss' });
        }
        if (w.kind === 'lie') { this.lie = true; this.emit({ t: w.t, type: 'lie_on', end: w.end }); }
      }
      if (w.kind === 'lie' && w.done && !w.off && t >= w.end) { w.off = true; this.resolveUntil(w.end); this.lie = false; this.emit({ t: w.end, type: 'lie_off' }); }
    }
    if (this.fever && t >= this.fever.end) {
      this.resolveUntil(this.fever.end);
      this.emit({ t: this.fever.end, type: 'mask_off' });
      this.fever = null; this.meter = 0;
    }
    this.resolveUntil(t);
    if (!this.ended && t >= this.chart.duration - 0.2) { this.ended = true; this.emit({ t, type: 'end' }); }
    this.t = t;
  }
  resolveUntil(t) {
    for (const n of this.notes) {
      if (n.state !== 0) continue;
      if (n.t + WIN.late > t) break;
      const te = n.t + WIN.late;
      if (n.type === 'bait') {
        n.state = 3; n.judge = 'dodge'; this.stats.dodge++; this.add('dodge', te, n);
        this.emit({ t: n.t + 0.02, type: 'dodge', note: n.i, color: this.colorFor(n) });
      } else {
        n.state = 2; n.judge = 'miss'; this.stats.miss++; this.breakCombo(te);
        this.emit({ t: te, type: 'miss', note: n.i });
      }
    }
  }
  press(lane, t) {
    this.update(t);
    let best = null, bd = 1e9;
    for (const n of this.notes) {
      if (n.state !== 0) continue;
      if (n.t - WIN.late > t) break;
      const d = Math.abs(t - n.t);
      const win = n.type === 'bait' ? WIN.bait : WIN.good;
      if (d <= win && d < bd) { best = n; bd = d; }
    }
    if (!best) { this.emit({ t, type: 'empty', lane }); return null; }
    const n = best; n.hitT = t; n.dt = t - n.t;
    if (n.type === 'bait') {
      n.state = 4; n.judge = 'baited'; this.stats.baited++; this.breakCombo(t);
      this.emit({ t, type: 'baited', note: n.i, lane });
      return n;
    }
    if (n.type !== lane) {
      n.state = 2; n.judge = 'wrong'; this.stats.wrong++; this.stats.miss++; this.breakCombo(t);
      this.emit({ t, type: 'wrong', note: n.i, lane });
      return n;
    }
    const kind = bd <= WIN.perfect ? 'perfect' : 'good';
    n.state = 1; n.judge = kind; this.stats[kind]++;
    this.add(kind, t, n);
    const color = this.fever ? 'purple' : this.colorFor(n);
    this.emit({ t, type: 'hit', note: n.i, lane, judge: kind, color, combo: this.combo, fever: !!this.fever, dt: n.dt });
    return n;
  }
  accuracy() {
    const s = this.stats;
    const total = this.notes.filter((n) => n.state !== 0).length || 1;
    return (s.perfect + s.dodge + 0.6 * s.good) / total;
  }
  rank() {
    const a = this.accuracy();
    if (a >= 0.95) return { letter: 'S', title: 'MORE THAN COLORS' };
    if (a >= 0.88) return { letter: 'A', title: 'FULL COLOR' };
    if (a >= 0.75) return { letter: 'B', title: 'TWO-TONE' };
    return { letter: 'C', title: 'GRAYSCALE' };
  }
}

/* Autoplay for demo/capture: a skilled human-like player with seeded timing
   spread. It uses the same press() path as keyboard/touch input. */
function autoplayInputs(chart, opts = {}) {
  const rnd = mulberry(opts.seed || 11);
  const gauss = () => { let u = 0, v = 0; while (u === 0) u = rnd(); v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
  const skip = new Set(opts.missNotes || []);
  const takeBait = new Set(opts.baitNotes || []);
  const wrong = new Set(opts.wrongNotes || []);
  const inputs = [];
  chart.notes.forEach((n, i) => {
    if (n.type === 'bait') {
      if (takeBait.has(i)) inputs.push({ t: n.t + 0.012, lane: rnd() < 0.5 ? 'one' : 'wave' });
      return;
    }
    if (skip.has(i)) return;
    let off = (opts.bias || 0.004) + gauss() * (opts.spread || 0.019);
    off = Math.max(-0.085, Math.min(0.085, off));
    const lane = wrong.has(i) ? (n.type === 'one' ? 'wave' : 'one') : n.type;
    inputs.push({ t: n.t + off, lane });
  });
  inputs.sort((a, b) => a.t - b.t);
  return inputs;
}

if (typeof module !== 'undefined') module.exports = { Engine, autoplayInputs, hash32, mulberry, WIN };
