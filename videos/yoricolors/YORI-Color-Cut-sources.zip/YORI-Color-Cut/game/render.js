/* YORI: COLOR CUT — renderer. Every frame is a pure function of
   (engine state, events, time) so live play and offline capture match. */
'use strict';

const PAL = {
  ink: '#151116', white: '#FFFFFF', cream: '#FFF4DC',
  red: '#E04A35', yellow: '#F9C622', blue: '#3567C8', purple: '#7B6BD6',
  stage: {
    blue: ['#2E5590', '#33609E'], red: ['#AC392C', '#BC4431'], yellow: ['#DD8F1C', '#E59F22'],
    purple: ['#4A3F86', '#54489A'], teal: ['#0E2A31', '#123540'], magenta: ['#A61576', '#B81C84'],
  },
  rivalOrange: '#C3703B', cyan: '#3AE1DC', bannerYellow: '#FDDC03', darkred: '#66000B',
  site: ['#FF5FB0', '#FFC14D', '#19D3A8', '#7A6BFF'],
  hair: '#ED9913',
};
const CARD = { red: PAL.red, yellow: PAL.yellow, blue: PAL.blue, purple: PAL.purple };
const FONT = (w, px) => `${w} ${Math.round(px)}px Fredoka, Nunito, system-ui, sans-serif`;
const NFONT = (w, px) => `${w} ${Math.round(px)}px Nunito, Fredoka, system-ui, sans-serif`;

const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const lerp = (a, b, t) => a + (b - a) * t;
const easeOut = (t) => 1 - Math.pow(1 - clamp(t), 3);
const easeIn = (t) => Math.pow(clamp(t), 3);
const easeOutBack = (t) => { t = clamp(t); const c1 = 1.9, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const easeInOut = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };

function hexA(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
function mix(h1, h2, t) {
  const a = parseInt(h1.slice(1), 16), b = parseInt(h2.slice(1), 16);
  const r = Math.round(lerp((a >> 16) & 255, (b >> 16) & 255, t)), g = Math.round(lerp((a >> 8) & 255, (b >> 8) & 255, t)), bl = Math.round(lerp(a & 255, b & 255, t));
  return '#' + ((1 << 24) | (r << 16) | (g << 8) | bl).toString(16).slice(1);
}
function rr(ctx, x, y, w, h, r) {
  r = Math.min(r, w / 2, h / 2);
  ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}
function txt(ctx, s, x, y, o) {
  const size = o.size;
  ctx.save();
  ctx.font = o.font || FONT(700, size);
  ctx.textAlign = o.align || 'center'; ctx.textBaseline = o.base || 'alphabetic';
  if (o.ls && ctx.letterSpacing !== undefined) ctx.letterSpacing = o.ls + 'px';
  ctx.lineJoin = 'round'; ctx.miterLimit = 2;
  if (o.shadow) { ctx.fillStyle = o.shadow; ctx.strokeStyle = o.shadow; ctx.lineWidth = (o.sw || size * 0.16); ctx.strokeText(s, x + (o.sx ?? size * 0.06), y + (o.sy ?? size * 0.07)); ctx.fillText(s, x + (o.sx ?? size * 0.06), y + (o.sy ?? size * 0.07)); }
  if (o.stroke) { ctx.strokeStyle = o.stroke; ctx.lineWidth = o.sw || size * 0.16; ctx.strokeText(s, x, y); }
  ctx.fillStyle = o.fill || '#fff'; ctx.fillText(s, x, y);
  ctx.restore();
}

/* ------------------------------------------------------------------ layout */
function makeLayout(W, H) {
  const portrait = H > W * 1.2;
  if (!portrait) {
    const u = H / 1080;
    return {
      portrait, W, H, u,
      lane: { y: 0.175 * H, h: 0.17 * H, x0: -10 * u, x1: 0.80 * W },
      ring: { x: 0.118 * W, y: 0.175 * H, r: 0.074 * H },
      rival: { x: 0.785 * W, y: 0.028 * H, w: 0.197 * W, h: 0.30 * H, rot: 0.04 },
      spawnX: 0.79 * W,
      yori: { cx: 0.43 * W, bottom: H, scale: H / 1080 },
      score: { x: 0.022 * W, y: 0.952 * H, size: 0.085 * H },
      combo: { x: 0.875 * W, y: 0.56 * H, size: 0.15 * H },
      meter: { x: 0.785 * W, y: 0.705 * H, w: 0.195 * W, h: 0.034 * H },
      buttons: [{ x: 0.838 * W, y: 0.875 * H, r: 0.064 * H, lane: 'one' }, { x: 0.938 * W, y: 0.875 * H, r: 0.064 * H, lane: 'wave' }],
      judge: { x: 0.118 * W, y: 0.37 * H, size: 0.082 * H },
      card: 0.15 * H, progress: { y: 0.0 * H, h: 0.012 * H },
      caption: { y: 0.805 * H, size: 0.072 * H },
      band: { y: 0.5 * H, h: 0.40 * H },
    };
  }
  const u = W / 1080;
  const laneY = 0.215 * H;
  return {
    portrait, W, H, u,
    lane: { y: laneY, h: 0.092 * H, x0: -10 * u, x1: 0.70 * W },
    ring: { x: 0.155 * W, y: laneY, r: 0.074 * W },
    rival: { x: 0.665 * W, y: 0.118 * H, w: 0.315 * W, h: 0.185 * H, rot: 0.04 },
    spawnX: 0.70 * W,
    yori: { cx: 0.5 * W, top: laneY, scale: W / 1080 * 1.0 },
    deck: { y: laneY + 1080 * (W / 1080) - 4 * u },
    score: { x: 0.045 * W, y: 0.085 * H, size: 0.085 * W },
    combo: { x: 0.80 * W, y: 0.072 * H, size: 0.105 * W },
    meter: { x: 0.30 * W, y: 0.0, w: 0.40 * W, h: 0.034 * W },
    buttons: [{ x: 0.255 * W, y: 0.0, r: 0.13 * W, lane: 'one' }, { x: 0.745 * W, y: 0.0, r: 0.13 * W, lane: 'wave' }],
    judge: { x: 0.155 * W, y: 0.32 * H, size: 0.09 * W },
    card: 0.15 * W, progress: { y: 0, h: 0.008 * H },
    caption: { y: 0.60 * H, size: 0.088 * W },
    band: { y: 0.47 * H, h: 0.25 * H },
  };
}

/* ------------------------------------------------------------------ renderer */
class Renderer {
  constructor(ctx, assets, chart) {
    this.ctx = ctx; this.A = assets; this.chart = chart;
    this.noise = this.makeNoise();
    this.spriteMeta = assets.meta;
  }
  _evBefore(ce) {
    const ev = this._E ? this._E.events : [];
    const k = ev.indexOf(ce);
    return k > 0 ? ev.slice(Math.max(0, k - 60), k) : [];
  }
  makeNoise() {
    const c = (typeof OffscreenCanvas !== 'undefined') ? new OffscreenCanvas(256, 256) : document.createElement('canvas');
    c.width = 256; c.height = 256;
    const x = c.getContext('2d'); const id = x.createImageData(256, 256); const r = mulberry(5);
    for (let i = 0; i < id.data.length; i += 4) { const v = 110 + r() * 40; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; }
    x.putImageData(id, 0, 0); return c;
  }
  img(name) { return this.A.img[name]; }

  /* derive visual state from events up to time t */
  vstate(E, t) {
    const ev = E.events;
    let lastHit = null, lastColorEv = null, lastBad = null, lastDodge = null, maskOn = null, maskOff = null, lieOn = null, lieOff = null, lastMilestone = null, lastSection = null;
    let hitsRecent = [];
    for (let k = ev.length - 1; k >= 0; k--) {
      const e = ev[k];
      if (e.t > t) continue;
      const age = t - e.t;
      if (age > 6 && lastHit && lastColorEv && maskOn !== undefined && lastSection) {
        if (age > 20) break;
      }
      if (e.type === 'hit') { if (!lastHit) lastHit = e; if (age < 1.2) hitsRecent.push(e); }
      if ((e.type === 'hit' || e.type === 'dodge' || e.type === 'baited') && !lastColorEv) lastColorEv = e;
      if ((e.type === 'miss' || e.type === 'baited' || e.type === 'wrong') && !lastBad) lastBad = e;
      if (e.type === 'dodge' && !lastDodge) lastDodge = e;
      if (e.type === 'mask_on' && !maskOn) maskOn = e;
      if (e.type === 'mask_off' && !maskOff) maskOff = e;
      if (e.type === 'lie_on' && !lieOn) lieOn = e;
      if (e.type === 'lie_off' && !lieOff) lieOff = e;
      if (e.type === 'milestone' && !lastMilestone) lastMilestone = e;
      if (e.type === 'section' && !lastSection) lastSection = e;
    }
    const fever = maskOn && (!maskOff || maskOff.t < maskOn.t) && t < maskOn.end;
    const lie = lieOn && (!lieOff || lieOff.t < lieOn.t);
    return { lastHit, lastColorEv, lastBad, lastDodge, maskOn, maskOff, lieOn, lieOff, fever, lie, lastMilestone, lastSection, hitsRecent };
  }

  stageColor(V, t) {
    if (V.fever) { const h = V.lastHit && V.lastHit.t >= V.maskOn.t ? V.lastHit : null; return PAL.stage.purple[h ? (h.note % 2) : 0]; }
    let base = 'blue', alt = 0;
    const e = V.lastColorEv;
    if (e) {
      if (e.type === 'baited') base = 'blue';
      else base = e.color === 'purple' ? 'purple' : e.color;
      alt = (e.note || 0) % 2;
    }
    if (V.lie) {
      const fresh = e && e.t >= V.lieOn.t && (t - e.t) < 0.16;
      if (!fresh) base = 'teal';
    }
    const pal = PAL.stage[base] || PAL.stage.blue;
    return pal[alt % pal.length];
  }

  pose(V, t) {
    // returns {name, pop(0..1 age factor), seed}
    const cand = [];
    if (V.lastHit) cand.push(V.lastHit);
    if (V.lastBad) cand.push(V.lastBad);
    if (V.lastDodge) cand.push(V.lastDodge);
    cand.sort((a, b) => b.t - a.t);
    const e = cand[0];
    const idleSmirk = () => { const k = Math.floor(t * 2.6) % 4; return ['smirk-000', 'smirk-005', 'smirk-010', 'smirk-005'][k]; };
    const fever = V.fever;
    if (!e) return { name: fever ? 'peace-160' : idleSmirk(), age: 9, seed: 0 };
    const age = t - e.t;
    if (fever && V.maskOn && e.t >= V.maskOn.t - 0.01) {
      if (e.type === 'hit') return { name: (e.note % 2 ? 'peace-185' : 'peace-160'), age, seed: e.note };
      if (age < 0.5 && (e.type === 'miss' || e.type === 'wrong' || e.type === 'baited')) return { name: 'peace-175', age, seed: e.note || 0 };
      return { name: 'peace-160', age: 9, seed: 0 };
    }
    if (e.type === 'hit') {
      const hold = 0.62;
      if (age > hold) return { name: idleSmirk(), age: 9, seed: 0 };
      if (e.lane === 'one') {
        const seq = age < 0.05 ? 'one-170' : age < 0.14 ? 'one-180' : age < 0.26 ? 'one-190' : 'one-195';
        return { name: seq, age, seed: e.note };
      }
      const k = Math.floor(age * 11) % 4; return { name: ['wave-210', 'wave-215', 'wave-220', 'wave-215'][k], age, seed: e.note };
    }
    if (e.type === 'baited') {
      if (age > 0.75) return { name: idleSmirk(), age: 9, seed: 0 };
      const k = Math.floor(age * 9) % 4; return { name: ['headpat-040', 'headpat-055', 'headpat-070', 'headpat-055'][k], age, seed: e.note };
    }
    if (e.type === 'miss' || e.type === 'wrong') {
      if (age > 0.6) return { name: idleSmirk(), age: 9, seed: 0 };
      return { name: age < 0.15 ? 'pout-115' : age < 0.32 ? 'pout-125' : 'pout-135', age, seed: e.note };
    }
    if (e.type === 'dodge') {
      if (age > 0.55) return { name: idleSmirk(), age: 9, seed: 0 };
      return { name: 'smirk-000', age, seed: e.note };
    }
    return { name: idleSmirk(), age: 9, seed: 0 };
  }

  camera(V, t, L) {
    let zoom = 1, sx = 0, sy = 0, rot = 0;
    for (const h of V.hitsRecent) {
      const a = t - h.t; if (a < 0) continue;
      zoom += 0.022 * Math.exp(-a / 0.09) * (h.judge === 'perfect' ? 1 : 0.6) * (h.fever ? 1.4 : 1);
    }
    if (V.lastBad) {
      const a = t - V.lastBad.t;
      if (a >= 0 && a < 0.4) { const k = Math.exp(-a / 0.09); sx += Math.sin(a * 90) * 16 * L.u * k; sy += Math.cos(a * 77) * 10 * L.u * k; }
    }
    if (V.maskOn) {
      const a = t - V.maskOn.t;
      if (a >= 0 && a < 0.6) { const k = Math.exp(-a / 0.12); sx += Math.sin(a * 70) * 22 * L.u * k; sy += Math.cos(a * 55) * 16 * L.u * k; zoom += 0.06 * k; }
    }
    return { zoom, sx, sy, rot };
  }

  /* ------------------------------------------------------------- main frame */
  frame(E, t, opts = {}) {
    const ctx = this.ctx, W = ctx.canvas.width, H = ctx.canvas.height;
    const L = makeLayout(W, H);
    this._E = E;
    const V = this.vstate(E, t);
    const beat = this.chart.step * 4;
    const bphase = ((t % beat) + beat) % beat / beat;
    ctx.save();
    ctx.clearRect(0, 0, W, H);
    const stage = this.stageColor(V, t);
    const cam = this.camera(V, t, L);
    this.drawStage(L, V, t, stage, bphase);
    // character (camera applied)
    ctx.save();
    ctx.translate(W / 2 + cam.sx, H / 2 + cam.sy); ctx.scale(cam.zoom, cam.zoom); ctx.translate(-W / 2, -H / 2);
    this.drawYori(L, V, t);
    ctx.restore();
    if (L.portrait) this.drawDeck(L, E, V, t);
    this.drawLane(L, E, V, t, bphase);
    this.drawRival(L, E, V, t);
    this.drawCards(L, E, V, t);
    this.drawHitFx(L, E, V, t);
    this.drawRing(L, E, V, t, bphase);
    this.drawJudgements(L, E, V, t);
    this.drawHud(L, E, V, t, opts);
    this.drawBanners(L, E, V, t);
    this.drawCutins(L, E, V, t);
    // colour drain on mistakes
    if (V.lastBad) {
      const a = t - V.lastBad.t;
      if (a >= 0 && a < 0.42) {
        ctx.save(); ctx.globalCompositeOperation = 'saturation'; ctx.globalAlpha = clamp(1 - a / 0.42) * 0.95; ctx.fillStyle = '#808080'; ctx.fillRect(0, 0, W, H); ctx.restore();
      }
    }
    if (opts.caption) this.drawCaption(L, opts.caption, t);
    ctx.restore();
    return { L, V };
  }

  drawStage(L, V, t, color, bphase) {
    const ctx = this.ctx, W = L.W, H = L.H;
    ctx.fillStyle = color; ctx.fillRect(0, 0, W, H);
    const ce = V.lastColorEv;
    if (ce && !V.fever) {
      const a = t - ce.t;
      if (a >= 0 && a < 0.09) {
        const prev = this.stageColor(this.vstate({ events: this._evBefore(ce) }, ce.t - 1e-4), ce.t - 1e-4);
        const k = easeOut(a / 0.09);
        ctx.fillStyle = prev; ctx.beginPath();
        const edge = -0.3 * W + k * 1.6 * W;
        ctx.moveTo(edge, 0); ctx.lineTo(W + 10, 0); ctx.lineTo(W + 10, H); ctx.lineTo(edge - 0.35 * W, H); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 10 * L.u;
        ctx.beginPath(); ctx.moveTo(edge, 0); ctx.lineTo(edge - 0.35 * W, H); ctx.stroke();
      }
    }
    if (V.fever) this.drawSpeedLines(L, t, 'rgba(190,180,255,0.16)');
    if (V.lie) this.drawLieGlow(L, t);
    // soft vignette like the source frames
    const g = ctx.createRadialGradient(W * 0.45, H * 0.45, Math.min(W, H) * 0.25, W * 0.5, H * 0.5, Math.max(W, H) * 0.78);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${V.fever ? 0.5 : 0.32})`);
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // canvas grain
    ctx.save(); ctx.globalAlpha = 0.055; ctx.globalCompositeOperation = 'overlay';
    const pat = ctx.createPattern(this.noise, 'repeat'); ctx.fillStyle = pat; ctx.fillRect(0, 0, W, H); ctx.restore();
    if (V.fever) this.drawEmbers(L, t);
  }
  drawSpeedLines(L, t, col) {
    const ctx = this.ctx, W = L.W, H = L.H;
    const cx = L.portrait ? W * 0.5 : W * 0.43, cy = L.portrait ? H * 0.45 : H * 0.5;
    ctx.save(); ctx.translate(cx, cy);
    const R = Math.hypot(W, H);
    for (let i = 0; i < 70; i++) {
      const a = (i / 70) * Math.PI * 2 + hash32(i, 3) * 0.08;
      const ph = (t * (1.6 + hash32(i, 9)) + hash32(i, 5)) % 1;
      const r0 = R * (0.18 + 0.5 * ph), len = R * (0.1 + 0.25 * hash32(i, 2));
      const w = (2 + 5 * hash32(i, 4)) * L.u;
      ctx.strokeStyle = col; ctx.lineWidth = w; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); ctx.lineTo(Math.cos(a) * (r0 + len), Math.sin(a) * (r0 + len)); ctx.stroke();
    }
    ctx.restore();
  }
  drawEmbers(L, t) {
    const ctx = this.ctx, W = L.W, H = L.H;
    ctx.save();
    for (let i = 0; i < 46; i++) {
      const sp = 0.05 + 0.08 * hash32(i, 1);
      const p = (t * sp + hash32(i, 2)) % 1;
      const x = (hash32(i, 3) * 1.1 - 0.05) * W + Math.sin(t * 1.3 + i) * 18 * L.u;
      const y = H * (1.05 - p * 1.1);
      const r = (1.5 + 3.2 * hash32(i, 4)) * L.u;
      const a = Math.sin(p * Math.PI) * (0.5 + 0.5 * hash32(i, 6));
      ctx.fillStyle = `rgba(255,${140 + Math.floor(60 * hash32(i, 7))},60,${a})`;
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }
  drawLieGlow(L, t) {
    const ctx = this.ctx, W = L.W, H = L.H;
    ctx.save(); ctx.globalAlpha = 0.18 + 0.06 * Math.sin(t * 6);
    const g = ctx.createRadialGradient(W * 0.9, H * 0.15, 0, W * 0.9, H * 0.15, W * 0.6);
    g.addColorStop(0, PAL.cyan); g.addColorStop(1, 'rgba(58,225,220,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H); ctx.restore();
  }

  drawYori(L, V, t) {
    const ctx = this.ctx;
    const P = this.pose(V, t);
    const im = this.img(P.name); const m = this.spriteMeta[P.name];
    if (!im || !m) return;
    const pop = P.age < 0.16 ? 1 + 0.045 * (1 - easeOut(P.age / 0.16)) : 1;
    const jx = P.age < 0.6 ? (hash32(P.seed, 1) - 0.5) * 22 * L.u : 0;
    let s, x, y;
    if (!L.portrait) {
      s = L.yori.scale * pop;
      x = L.yori.cx - (m.frameW / 2) * s + m.x0 * s + jx; y = L.H - m.h * s;
    } else {
      s = L.yori.scale * pop;
      x = L.yori.cx - (m.frameW / 2) * s + m.x0 * s + jx; y = L.yori.top - (s - L.yori.scale) * m.h * 0.5;
    }
    // breathing
    const breathe = 1 + 0.006 * Math.sin(t * 2.4);
    ctx.save();
    ctx.translate(x + m.w * s / 2, y + m.h * s); ctx.scale(breathe, breathe); ctx.translate(-(x + m.w * s / 2), -(y + m.h * s));
    ctx.drawImage(im, x, y, m.w * s, m.h * s);
    ctx.restore();
  }

  drawDeck(L, E, V, t) {
    const ctx = this.ctx, W = L.W, H = L.H, u = L.u;
    const y0 = L.deck.y;
    ctx.save();
    ctx.fillStyle = PAL.ink; rr(ctx, -20, y0, W + 40, H - y0 + 40, 46 * u); ctx.fill();
    ctx.strokeStyle = hexA('#FFFFFF', 0.14); ctx.lineWidth = 3 * u; rr(ctx, 14 * u, y0 + 14 * u, W - 28 * u, H - y0 - 28 * u, 34 * u); ctx.stroke();
    ctx.restore();
    // place buttons + meter inside the deck
    const by = y0 + (H - y0) * 0.5;
    L.buttons[0].y = by; L.buttons[1].y = by;
    L.meter.y = y0 + 38 * u;
  }

  drawLane(L, E, V, t, bphase) {
    const ctx = this.ctx, u = L.u;
    const { y, h, x0, x1 } = L.lane;
    ctx.save();
    ctx.fillStyle = hexA(PAL.ink, L.portrait ? 1 : 0.9);
    rr(ctx, x0, y - h / 2, x1 - x0 + 60 * u, h, h * 0.5); ctx.fill();
    ctx.strokeStyle = hexA('#FFFFFF', 0.85); ctx.lineWidth = 4 * u;
    rr(ctx, x0 + 10 * u, y - h / 2 + 10 * u, x1 - x0 + 40 * u, h - 20 * u, (h - 20 * u) * 0.5); ctx.stroke();
    // beat ticks scrolling toward the ring
    const lead = this.leadTime(V);
    const speed = (L.spawnX - L.ring.x) / lead;
    const beat = this.chart.step * 4;
    ctx.strokeStyle = hexA('#FFFFFF', 0.22); ctx.lineWidth = 3 * u;
    const first = Math.ceil((t - 0.2) / beat);
    for (let k = first; k < first + 16; k++) {
      const bx = L.ring.x + (k * beat - t) * speed;
      if (bx < L.ring.x + L.ring.r || bx > x1) continue;
      const big = k % 4 === 0;
      ctx.beginPath(); ctx.moveTo(bx, y - h * (big ? 0.3 : 0.18)); ctx.lineTo(bx, y + h * (big ? 0.3 : 0.18)); ctx.stroke();
    }
    ctx.restore();
  }
  leadTime(V) { return V.fever ? 1.25 : V.lie ? 1.35 : 1.5; }

  drawRival(L, E, V, t) {
    const ctx = this.ctx, u = L.u;
    const R = L.rival;
    // which frame: cap kid during COLORS LIE, else blue kid; "throw" pose right after a card launches
    const lead = this.leadTime(V);
    let throwAge = 9;
    for (const n of E.notes) { const launch = n.t - lead; if (launch > t) break; if (n.type === 'bait' && t - launch < throwAge) throwAge = t - launch; }
    let name;
    if (V.lie) { name = ['panel-cap-315', 'panel-cap-320', 'panel-cap-325'][Math.floor(t * 6) % 3]; }
    else if (throwAge < 0.34) name = throwAge < 0.17 ? 'panel-bluereach-270' : 'panel-bluereach-275';
    else name = Math.floor(t * 1.5) % 2 ? 'panel-bluesmirk-255' : 'panel-bluesmirk-260';
    const im = this.img(name);
    const bob = Math.sin(t * 3.1) * 4 * u;
    const kick = throwAge < 0.18 ? (1 - throwAge / 0.18) * 10 * u : 0;
    ctx.save();
    ctx.translate(R.x + R.w / 2 - kick, R.y + R.h / 2 + bob); ctx.rotate(R.rot);
    const w = R.w, h = R.h, rad = 22 * u;
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, -w / 2 + 10 * u, -h / 2 + 12 * u, w, h, rad); ctx.fill();
    ctx.save(); rr(ctx, -w / 2, -h / 2, w, h, rad); ctx.clip();
    ctx.fillStyle = V.lie ? PAL.cyan : PAL.rivalOrange; ctx.fillRect(-w / 2, -h / 2, w, h);
    if (im) {
      const s = Math.max(w / im.width, h / im.height);
      ctx.drawImage(im, -im.width * s / 2, -im.height * s / 2 + (V.lie ? 0 : 0.06 * h), im.width * s, im.height * s);
    }
    if (V.lie) { ctx.globalAlpha = 0.25 + 0.2 * Math.sin(t * 12); ctx.fillStyle = '#FF2A2A'; ctx.globalCompositeOperation = 'overlay'; ctx.fillRect(-w / 2, -h / 2, w, h); }
    ctx.restore();
    ctx.strokeStyle = PAL.ink; ctx.lineWidth = 9 * u; rr(ctx, -w / 2, -h / 2, w, h, rad); ctx.stroke();
    ctx.restore();
  }

  cardColor(E, n) { return CARD[E.colorFor(n)]; }

  drawCard(n, x, y, size, color, alpha, rot, E, glitch) {
    const ctx = this.ctx, u = size / 162;
    const st = n.type === 'one' ? 'sticker-one' : n.type === 'wave' ? 'sticker-wave' : 'sticker-bait';
    const im = this.img(st);
    ctx.save(); ctx.globalAlpha = alpha; ctx.translate(x, y); ctx.rotate(rot);
    const s = size, r = 26 * u;
    ctx.fillStyle = 'rgba(0,0,0,0.38)'; rr(ctx, -s / 2 + 7 * u, -s / 2 + 9 * u, s, s, r); ctx.fill();
    ctx.fillStyle = color; rr(ctx, -s / 2, -s / 2, s, s, r); ctx.fill();
    // inner highlight band
    ctx.save(); rr(ctx, -s / 2, -s / 2, s, s, r); ctx.clip();
    ctx.fillStyle = 'rgba(255,255,255,0.18)'; ctx.fillRect(-s / 2, -s / 2, s, s * 0.32);
    if (glitch) { ctx.fillStyle = 'rgba(58,225,220,0.35)'; ctx.fillRect(-s / 2, -s * 0.1 + Math.sin(glitch * 40) * s * 0.2, s, s * 0.08); }
    ctx.restore();
    ctx.strokeStyle = PAL.ink; ctx.lineWidth = 8 * u; rr(ctx, -s / 2, -s / 2, s, s, r); ctx.stroke();
    if (im) {
      const k = (s * 1.08) / Math.max(im.width, im.height);
      const iw = im.width * k, ih = im.height * k;
      ctx.drawImage(im, -iw / 2, -s / 2 - ih * 0.18 + s * 0.06, iw, ih);
    }
    // key badge
    const bx = s * 0.36, by = s * 0.36, br = 24 * u;
    ctx.fillStyle = n.type === 'bait' ? '#FFFFFF' : PAL.ink; ctx.beginPath(); ctx.arc(bx, by, br, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = n.type === 'bait' ? PAL.ink : '#FFFFFF'; ctx.lineWidth = 4 * u; ctx.stroke();
    if (n.type === 'bait') {
      ctx.strokeStyle = '#E2322B'; ctx.lineWidth = 6 * u; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(bx - 10 * u, by - 10 * u); ctx.lineTo(bx + 10 * u, by + 10 * u); ctx.moveTo(bx + 10 * u, by - 10 * u); ctx.lineTo(bx - 10 * u, by + 10 * u); ctx.stroke();
    } else {
      ctx.fillStyle = '#FFFFFF'; ctx.beginPath();
      const d = n.type === 'one' ? -1 : 1;
      ctx.moveTo(bx + d * 11 * u, by); ctx.lineTo(bx - d * 7 * u, by - 11 * u); ctx.lineTo(bx - d * 7 * u, by + 11 * u); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
  }

  drawCards(L, E, V, t) {
    const lead = this.leadTime(V);
    const span = L.spawnX - L.ring.x;
    const size = L.card;
    const list = [];
    for (const n of E.notes) {
      if (n.t - lead > t + 0.05) break;
      const dtn = n.t - t;
      if (n.state === 1) continue;                 // shattered (drawn in fx)
      if (n.state === 4 && t - n.hitT > 0.3) continue;
      if (n.state === 3 && t - (n.t + 0.02) > 0.35) continue;
      if (n.state === 2 && t - n.t > 0.5) continue;
      if (dtn > lead) continue;
      list.push(n);
    }
    for (let k = list.length - 1; k >= 0; k--) {
      const n = list[k];
      const dtn = n.t - t;
      let x = L.ring.x + (dtn / lead) * span;
      let y = L.lane.y + Math.sin((t + n.i) * 5) * 3 * L.u;
      let alpha = clamp((lead - dtn) / 0.18);
      let sc = 1 + 0.12 * clamp(1 - Math.abs(dtn) / 0.25);
      let rot = (n.i % 2 ? 1 : -1) * 0.07;
      if (n.state === 2) { const a = t - n.t; alpha = clamp(1 - a / 0.5); y += a * a * 900 * L.u; rot += a * 3; x = Math.min(x, L.ring.x - a * 120 * L.u); }
      if (n.state === 3) { const a = t - (n.t + 0.02); alpha = clamp(1 - a / 0.35); sc *= 1 - 0.6 * easeIn(a / 0.35); x = L.ring.x - a * 260 * L.u; }
      if (n.state === 4) { const a = t - n.hitT; sc *= 1 + 0.6 * easeOut(a / 0.3); alpha = clamp(1 - a / 0.3); }
      const glitch = n.lie && dtn > 0 ? t : 0;
      const jit = n.lie && dtn > 0.2 ? (hash32(n.i, Math.floor(t * 18)) - 0.5) * 10 * L.u : 0;
      this.drawCard(n, x + jit, y, size * sc, this.cardColor(E, n), alpha, rot, E, glitch);
    }
  }

  drawRing(L, E, V, t, bphase) {
    const ctx = this.ctx, u = L.u, R = L.ring;
    const pulse = 1 + 0.06 * Math.pow(1 - bphase, 4);
    let flashCol = null, flashA = 0;
    for (let k = E.events.length - 1; k >= 0; k--) {
      const e = E.events[k]; if (e.t > t) continue; if (t - e.t > 0.25) break;
      if (e.type === 'hit' || e.type === 'empty' || e.type === 'wrong' || e.type === 'baited') { flashCol = e.type === 'hit' ? CARD[e.color] || '#fff' : e.type === 'empty' ? '#FFFFFF' : '#9a9a9a'; flashA = 1 - (t - e.t) / 0.25; break; }
    }
    ctx.save(); ctx.translate(R.x, R.y); ctx.scale(pulse, pulse);
    ctx.fillStyle = hexA('#FFFFFF', 0.10); ctx.beginPath(); ctx.arc(0, 0, R.r, 0, Math.PI * 2); ctx.fill();
    if (flashCol) { ctx.globalAlpha = flashA; ctx.fillStyle = flashCol; ctx.beginPath(); ctx.arc(0, 0, R.r * 0.92, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1; }
    ctx.lineWidth = 12 * u; ctx.strokeStyle = PAL.ink; ctx.beginPath(); ctx.arc(0, 0, R.r, 0, Math.PI * 2); ctx.stroke();
    ctx.lineWidth = 6 * u; ctx.strokeStyle = '#FFFFFF'; ctx.beginPath(); ctx.arc(0, 0, R.r - 2 * u, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([10 * u, 12 * u]); ctx.lineWidth = 3 * u; ctx.strokeStyle = hexA('#FFFFFF', 0.6);
    ctx.beginPath(); ctx.arc(0, 0, R.r * 0.7, t * 2, t * 2 + Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    ctx.restore();
  }

  drawHitFx(L, E, V, t) {
    const ctx = this.ctx, u = L.u, R = L.ring;
    for (let k = E.events.length - 1; k >= 0; k--) {
      const e = E.events[k]; if (e.t > t) continue; const a = t - e.t; if (a > 1.0) break;
      if (e.type !== 'hit') continue;
      const col = CARD[e.color] || '#fff';
      // shock ring
      if (a < 0.35) {
        ctx.save(); ctx.globalAlpha = 1 - a / 0.35; ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = (14 - 30 * a) * u;
        ctx.beginPath(); ctx.arc(R.x, R.y, R.r * (1 + a * 3.2), 0, Math.PI * 2); ctx.stroke(); ctx.restore();
      }
      // shards of the card
      const n = e.note;
      for (let i = 0; i < 9; i++) {
        const ang = hash32(n, i, 1) * Math.PI * 2, sp = (300 + 420 * hash32(n, i, 2)) * u;
        const life = 0.5;
        if (a > life) continue;
        const x = R.x + Math.cos(ang) * sp * a, y = R.y + Math.sin(ang) * sp * a + 700 * u * a * a;
        const sz = (14 + 18 * hash32(n, i, 3)) * u * (1 - a / life * 0.6);
        ctx.save(); ctx.globalAlpha = clamp(1 - easeIn(a / life)); ctx.translate(x, y); ctx.rotate(a * (8 + 10 * hash32(n, i, 4)) + ang);
        ctx.fillStyle = i % 3 === 0 ? col : i % 3 === 1 ? '#FFFFFF' : PAL.site[(n + i) % 4]; ctx.strokeStyle = PAL.ink; ctx.lineWidth = 4 * u;
        ctx.beginPath(); ctx.moveTo(-sz, -sz * 0.6); ctx.lineTo(sz, -sz * 0.2); ctx.lineTo(-sz * 0.3, sz); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.restore();
      }
      // paint dots
      for (let i = 0; i < 10; i++) {
        if (a > 0.5) break;
        const ang = hash32(n, i, 7) * Math.PI * 2, sp = (200 + 700 * hash32(n, i, 8)) * u;
        const x = R.x + Math.cos(ang) * sp * a, y = R.y + Math.sin(ang) * sp * a;
        ctx.fillStyle = hexA(i % 2 ? col : '#FFFFFF', 1 - a / 0.5);
        ctx.beginPath(); ctx.arc(x, y, (5 + 9 * hash32(n, i, 9)) * u * (1 - a), 0, Math.PI * 2); ctx.fill();
      }
      if (e.judge === 'perfect' && a < 0.45) {
        for (let i = 0; i < 5; i++) {
          const ang = (i / 5) * Math.PI * 2 + n, d = R.r * (1.1 + a * 2.5);
          this.star(R.x + Math.cos(ang) * d, R.y + Math.sin(ang) * d, (16 - 26 * a) * u, '#FFFFFF', 1 - a / 0.45);
        }
      }
    }
  }
  star(x, y, r, col, alpha) {
    if (r <= 0) return;
    const ctx = this.ctx; ctx.save(); ctx.globalAlpha = clamp(alpha); ctx.fillStyle = col; ctx.beginPath();
    for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4, rr2 = i % 2 ? r * 0.28 : r; ctx.lineTo(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
    ctx.closePath(); ctx.fill(); ctx.restore();
  }

  drawJudgements(L, E, V, t) {
    const J = L.judge;
    let e = null;
    for (let k = E.events.length - 1; k >= 0; k--) {
      const x = E.events[k]; if (x.t > t) continue; if (t - x.t > 0.6) break;
      if (['hit', 'miss', 'wrong', 'baited', 'dodge'].includes(x.type)) { e = x; break; }
    }
    if (!e) return;
    const a = t - e.t;
    let label, shadow, size = J.size;
    if (e.type === 'hit') { label = e.judge === 'perfect' ? 'PERFECT' : 'GOOD'; shadow = CARD[e.color] || PAL.red; if (e.judge !== 'perfect') size *= 0.82; }
    else if (e.type === 'miss') { label = 'MISS'; shadow = '#6b6b6b'; }
    else if (e.type === 'wrong') { label = 'WRONG MOVE'; shadow = '#6b6b6b'; size *= 0.8; }
    else if (e.type === 'baited') { label = 'BAITED!'; shadow = PAL.blue; }
    else { label = 'DODGED'; shadow = PAL.blue; size *= 0.8; }
    const s = easeOutBack(a / 0.14) * (1 - 0.15 * easeIn((a - 0.4) / 0.2));
    const alpha = 1 - easeIn((a - 0.42) / 0.18);
    const ctx = this.ctx;
    ctx.save(); ctx.globalAlpha = clamp(alpha);
    ctx.translate(J.x + (L.portrait ? -0.1 * L.W : 0.02 * L.W), J.y - a * 40 * L.u); ctx.rotate(-0.06); ctx.scale(s, s);
    txt(ctx, label, 0, 0, { size, align: L.portrait ? 'left' : 'center', fill: '#FFFFFF', stroke: PAL.ink, sw: size * 0.2, shadow, sx: size * 0.07, sy: size * 0.08 });
    ctx.restore();
  }

  drawHud(L, E, V, t, opts) {
    const ctx = this.ctx, u = L.u, W = L.W, H = L.H;
    // progress
    const p = clamp(t / this.chart.duration);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; ctx.fillRect(0, L.progress.y, W, L.progress.h);
    ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0, L.progress.y, W * p, L.progress.h);
    // score
    let lastScoreT = -9;
    for (let k = E.events.length - 1; k >= 0; k--) { const e = E.events[k]; if (e.t > t) continue; if (e.type === 'hit' || e.type === 'dodge') { lastScoreT = e.t; break; } }
    const sa = t - lastScoreT; const bump = sa < 0.15 ? 1 + 0.08 * (1 - sa / 0.15) : 1;
    const S = L.score;
    ctx.save(); ctx.translate(S.x, S.y); ctx.scale(bump, bump);
    txt(ctx, 'SCORE', 4 * u, -S.size * 0.95, { size: S.size * 0.32, align: 'left', fill: '#FFFFFF', stroke: PAL.ink, sw: S.size * 0.09, font: FONT(700, S.size * 0.32), ls: 3 * u });
    txt(ctx, E.score.toLocaleString('en-US'), 0, 0, { size: S.size, align: 'left', fill: '#FFFFFF', stroke: PAL.ink, sw: S.size * 0.18 });
    ctx.restore();
    // multiplier chip
    const mult = Math.min(4, 1 + Math.floor(E.combo / 10)) * (V.fever ? 2 : 1);
    if (!L.portrait) {
      ctx.save(); ctx.font = FONT(700, S.size); const sw = ctx.measureText(E.score.toLocaleString('en-US')).width; ctx.restore();
      const cx = S.x + sw + 34 * u, cy = S.y - S.size * 0.36;
      this.chip(cx, cy, '×' + mult, V.fever ? PAL.purple : PAL.ink, S.size * 0.42);
    } else {
      this.chip(S.x + 10 * u, S.y + S.size * 0.55, '×' + mult, V.fever ? PAL.purple : PAL.ink, S.size * 0.5, 'left');
    }
    // combo
    if (E.combo >= 3) {
      let lastHitT = V.lastHit ? V.lastHit.t : -9;
      const ca = t - lastHitT; const cb = ca < 0.12 ? 1 + 0.18 * (1 - ca / 0.12) : 1;
      const C = L.combo;
      ctx.save(); ctx.translate(C.x, C.y); ctx.rotate(0.05); ctx.scale(cb, cb);
      txt(ctx, String(E.combo), 0, 0, { size: C.size, fill: '#FFFFFF', stroke: PAL.ink, sw: C.size * 0.16, shadow: V.fever ? PAL.purple : (V.lastHit ? CARD[V.lastHit.color] : PAL.red), sx: C.size * 0.05, sy: C.size * 0.06 });
      txt(ctx, 'COMBO', 0, C.size * 0.38, { size: C.size * 0.26, fill: '#FFFFFF', stroke: PAL.ink, sw: C.size * 0.07, ls: 4 * u });
      ctx.restore();
    }
    // mask meter
    const M = L.meter;
    const full = V.fever ? clamp((V.maskOn.end - t) / (V.maskOn.end - V.maskOn.t)) : E.meter;
    ctx.save();
    const mh = M.h, mw = M.w;
    ctx.fillStyle = hexA(PAL.ink, 0.85); rr(ctx, M.x, M.y, mw, mh, mh / 2); ctx.fill();
    const fillW = Math.max(mh, mw * full);
    const ready = !V.fever && E.meter >= 0.999;
    ctx.fillStyle = V.fever ? PAL.purple : ready ? (Math.floor(t * 8) % 2 ? '#FF4D3D' : '#FFFFFF') : '#E2322B';
    if (full > 0.01) { rr(ctx, M.x + 4 * u, M.y + 4 * u, fillW - 8 * u, mh - 8 * u, (mh - 8 * u) / 2); ctx.fill(); }
    ctx.strokeStyle = PAL.ink; ctx.lineWidth = 5 * u; rr(ctx, M.x, M.y, mw, mh, mh / 2); ctx.stroke();
    const label = V.fever ? 'MASK ON' : ready ? 'MASK READY' : 'MASK';
    txt(ctx, label, M.x + mw / 2, M.y - 12 * u, { size: mh * 0.95, fill: '#FFFFFF', stroke: PAL.ink, sw: mh * 0.28, ls: 3 * u });
    ctx.restore();
    // buttons
    const pressed = { one: -9, wave: -9 };
    for (let k = E.events.length - 1; k >= 0; k--) { const e = E.events[k]; if (e.t > t) continue; if (t - e.t > 0.2) break; if (e.lane && pressed[e.lane] < -1) pressed[e.lane] = e.t; }
    for (const b of L.buttons) {
      const pa = t - pressed[b.lane]; const down = pa >= 0 && pa < 0.12;
      const col = b.lane === 'one' ? PAL.red : PAL.yellow;
      ctx.save(); ctx.translate(b.x, b.y + (down ? 6 * u : 0)); const sc = down ? 0.93 : 1; ctx.scale(sc, sc);
      ctx.fillStyle = 'rgba(0,0,0,0.4)'; ctx.beginPath(); ctx.arc(5 * u, (down ? 2 : 9) * u, b.r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = down ? '#FFFFFF' : col; ctx.beginPath(); ctx.arc(0, 0, b.r, 0, Math.PI * 2); ctx.fill();
      ctx.lineWidth = 8 * u; ctx.strokeStyle = PAL.ink; ctx.stroke();
      const im = this.img(b.lane === 'one' ? 'sticker-one' : 'sticker-wave');
      if (im) { const k2 = b.r * 1.55 / Math.max(im.width, im.height); ctx.drawImage(im, -im.width * k2 / 2, -im.height * k2 / 2 - b.r * 0.08, im.width * k2, im.height * k2); }
      const lab = b.lane === 'one' ? '◀ ONE' : 'WAVE ▶';
      txt(ctx, lab, 0, b.r + b.r * 0.42, { size: b.r * 0.34, fill: '#FFFFFF', stroke: PAL.ink, sw: b.r * 0.1, ls: 2 * u });
      ctx.restore();
    }
    if (opts.hint) {
      const a = clamp(1 - (t - opts.hint.t) / 3.0);
      if (a > 0) txt(ctx, opts.hint.text, W / 2, L.portrait ? H * 0.355 : H * 0.42, { size: (L.portrait ? 0.05 * W : 0.045 * H), fill: '#FFFFFF', stroke: PAL.ink, sw: 9 * u });
    }
  }
  chip(x, y, label, col, size, align = 'left') {
    const ctx = this.ctx;
    ctx.save(); ctx.font = FONT(700, size); const w = ctx.measureText(label).width + size * 0.9, h = size * 1.25;
    const x0 = align === 'left' ? x : x - w / 2;
    ctx.fillStyle = col; rr(ctx, x0, y - h / 2, w, h, h / 2); ctx.fill();
    ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = size * 0.12; rr(ctx, x0, y - h / 2, w, h, h / 2); ctx.stroke();
    ctx.restore();
    txt(ctx, label, x0 + w / 2, y + size * 0.36, { size, fill: '#FFFFFF' });
  }

  drawBanners(L, E, V, t) {
    const ctx = this.ctx, u = L.u, W = L.W, H = L.H;
    // COLORS LIE stamp
    if (V.lieOn) {
      const a = t - V.lieOn.t - 0.6;
      if (a >= 0 && a < 2.2) {
        const s = easeOutBack(a / 0.2), alpha = 1 - easeIn((a - 1.8) / 0.4);
        const size = L.portrait ? 0.13 * W : 0.13 * H;
        const y = L.portrait ? H * 0.42 : H * 0.55;
        ctx.save(); ctx.globalAlpha = clamp(alpha); ctx.translate(W * (L.portrait ? 0.5 : 0.47), y); ctx.rotate(-0.05); ctx.scale(s, s);
        for (const [dx, col] of [[-6, '#3AE1DC'], [6, '#FF3355']]) {
          ctx.save(); ctx.globalAlpha = 0.85 * clamp(alpha);
          txt(ctx, 'COLORS LIE', dx * u * (1 + Math.sin(t * 50)), 0, { size, fill: col }); ctx.restore();
        }
        txt(ctx, 'COLORS LIE', 0, 0, { size, fill: '#FFFFFF', stroke: PAL.ink, sw: size * 0.17 });
        txt(ctx, 'READ THE MOVE', 0, size * 0.62, { size: size * 0.38, fill: PAL.cyan, stroke: PAL.ink, sw: size * 0.09, ls: 6 * u });
        ctx.restore();
      }
    }
    // milestones
    if (V.lastMilestone) {
      const a = t - V.lastMilestone.t;
      if (a >= 0 && a < 1.1) {
        const size = L.portrait ? 0.075 * W : 0.07 * H;
        const x = L.portrait ? W * 0.5 : W * 0.62, y = L.portrait ? H * 0.40 : H * 0.36;
        const s = easeOutBack(a / 0.18); const alpha = 1 - easeIn((a - 0.8) / 0.3);
        ctx.save(); ctx.globalAlpha = clamp(alpha); ctx.translate(x, y); ctx.rotate(0.04); ctx.scale(s, s);
        txt(ctx, `${V.lastMilestone.combo} COMBO!`, 0, 0, { size, fill: PAL.bannerYellow, stroke: PAL.ink, sw: size * 0.2 });
        ctx.restore();
        for (let i = 0; i < 26; i++) {
          const ang = hash32(V.lastMilestone.combo, i) * Math.PI * 2, sp = (300 + 500 * hash32(i, V.lastMilestone.combo)) * u;
          const px = x + Math.cos(ang) * sp * a, py = y + Math.sin(ang) * sp * a + 600 * u * a * a;
          ctx.save(); ctx.globalAlpha = clamp(1 - a / 1.1); ctx.translate(px, py); ctx.rotate(a * 9 + i);
          ctx.fillStyle = PAL.site[i % 4]; ctx.fillRect(-8 * u, -4 * u, 16 * u, 8 * u); ctx.restore();
        }
      }
    }
  }

  drawCutins(L, E, V, t) {
    const ctx = this.ctx, W = L.W, H = L.H, u = L.u;
    const band = (age, dur, frames, fps, label, sub, bg, titleCol) => {
      if (age < 0 || age > dur) return;
      const inT = 0.14, outT = 0.16;
      const k = age < inT ? easeOut(age / inT) : age > dur - outT ? 1 - easeIn((age - (dur - outT)) / outT) : 1;
      const bh = L.band.h, by = L.band.y;
      // flash + dim
      ctx.save(); ctx.fillStyle = `rgba(0,0,0,${0.45 * k})`; ctx.fillRect(0, 0, W, H); ctx.restore();
      if (age < 0.08) { ctx.save(); ctx.globalAlpha = 1 - age / 0.08; ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0, 0, W, H); ctx.restore(); }
      ctx.save();
      ctx.translate(W / 2 + (age < inT ? -(1 - k) * W * 1.35 : age > dur - outT ? (1 - k) * W * 1.35 : 0), by);
      ctx.rotate(-0.07);
      const bw = W * 1.4;
      ctx.fillStyle = PAL.ink; ctx.fillRect(-bw / 2, -bh / 2 - 18 * u, bw, bh + 36 * u);
      ctx.save(); ctx.beginPath(); ctx.rect(-bw / 2, -bh / 2, bw, bh); ctx.clip();
      ctx.fillStyle = bg; ctx.fillRect(-bw / 2, -bh / 2, bw, bh);
      const idx = Math.min(frames.length - 1, Math.floor(age * fps));
      const im = this.img(frames[idx]);
      if (im) {
        const s = Math.max(bw * 0.72 / im.width, bh / im.height) * (1 + 0.04 * age);
        ctx.drawImage(im, -im.width * s / 2 - W * 0.08, -im.height * s / 2, im.width * s, im.height * s);
      }
      ctx.restore();
      ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 6 * u; ctx.strokeRect(-bw / 2, -bh / 2, bw, bh);
      // title
      const ta = age - 0.18;
      if (ta > 0) {
        const ts = easeOutBack(ta / 0.16);
        const size = L.portrait ? 0.15 * W : 0.15 * H;
        ctx.save(); ctx.translate(L.portrait ? 0 : W * 0.24, bh * 0.28); ctx.rotate(0.02); ctx.scale(ts, ts);
        txt(ctx, label, 0, 0, { size, fill: '#FFFFFF', stroke: PAL.ink, sw: size * 0.18, shadow: titleCol, sx: size * 0.06, sy: size * 0.07 });
        if (sub) txt(ctx, sub, 0, size * 0.5, { size: size * 0.3, fill: titleCol, stroke: PAL.ink, sw: size * 0.08, ls: 5 * u });
        ctx.restore();
      }
      ctx.restore();
    };
    if (V.maskOn) {
      const a = t - V.maskOn.t;
      // brand burst flash (official 色より motion-graphic frame) for the first beats
      if (a >= 0 && a < 0.16) {
        const im = this.img(a < 0.08 ? 'iroburst-365' : 'iroburst-375');
        if (im) { ctx.save(); ctx.globalAlpha = 1; const s = Math.max(W / im.width, H / im.height); ctx.drawImage(im, (W - im.width * s) / 2, (H - im.height * s) / 2, im.width * s, im.height * s); ctx.restore(); }
      } else {
        const frames = []; for (let n = 0; n <= 85; n += 5) frames.push('cutin-mask-' + String(n).padStart(3, '0'));
        band(a - 0.16, 1.45, frames, 12, 'MASK ON', '×2 SCORE', '#0D2125', PAL.purple);
      }
    }
    if (V.maskOff && (!V.maskOn || V.maskOff.t >= V.maskOn.t)) {
      const a = t - V.maskOff.t;
      band(a, 0.8, ['cutin-tongue-315', 'cutin-tongue-320', 'cutin-tongue-325', 'cutin-tongue-320'], 8, 'MASK OFF', null, '#A61576', '#FF5FB0');
    }
  }

  drawCaption(L, cap, t) {
    const ctx = this.ctx, u = L.u, W = L.W;
    const a = t - cap.t0, d = cap.t1 - cap.t0;
    if (a < 0 || a > d) return;
    const k = a < 0.16 ? easeOutBack(a / 0.16) : a > d - 0.14 ? 1 - easeIn((a - (d - 0.14)) / 0.14) : 1;
    const size = L.caption.size * (cap.scale || 1);
    const lines = cap.text.split('\n');
    ctx.save(); ctx.font = FONT(700, size);
    const tw = Math.max(...lines.map((s) => ctx.measureText(s).width));
    ctx.restore();
    const ph = size * (1.25 + (lines.length - 1) * 1.05), pw = tw + size * 1.1;
    const cp = cap.pos || { x: W / 2, y: L.caption.y };
    ctx.save(); ctx.translate(cp.x, cp.y); ctx.rotate(-0.025); ctx.scale(k, k);
    ctx.fillStyle = 'rgba(0,0,0,0.35)'; rr(ctx, -pw / 2 + 8 * u, -ph / 2 + 10 * u, pw, ph, ph * 0.3); ctx.fill();
    ctx.fillStyle = cap.bg || PAL.bannerYellow; rr(ctx, -pw / 2, -ph / 2, pw, ph, ph * 0.3); ctx.fill();
    ctx.strokeStyle = PAL.ink; ctx.lineWidth = 9 * u; rr(ctx, -pw / 2, -ph / 2, pw, ph, ph * 0.3); ctx.stroke();
    lines.forEach((s, i) => txt(ctx, s, 0, -ph / 2 + size * 1.0 + i * size * 1.05, { size, fill: '#FFFFFF', stroke: PAL.ink, sw: size * 0.2 }));
    ctx.restore();
  }
}

if (typeof module !== 'undefined') module.exports = { Renderer, makeLayout, PAL };
