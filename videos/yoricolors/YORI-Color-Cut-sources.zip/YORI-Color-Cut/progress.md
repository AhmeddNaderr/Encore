# YORI (@yoricolors) game concept — production log

Brief: Encore Studio game-concept master prompt (from this repository's Clover source package). Input: https://x.com/yoricolors. The user asked for a high-quality game video plus a playable, fun game in YORI's art and style.

## Phases
- **Phase 1, research: DONE.** `research_brief.md`. x.com is blocked here. A web-fetch agent and an FxTwitter call were first refused by the auto-mode safety check; after the user explicitly approved the X fetch, profile and posts came from api.fxtwitter.com and media from pbs/video.twimg.com. With the user's approval, yoricolors.xyz was added to this environment's allowed hosts; only the public page was read (an attempt to probe the site's API paths was refused and dropped).
- **Phase 2, art: DONE.** `art_bible.md`, `art/reference_board.png`, `art/palette-sampled.json`. 53 exact 60 fps frames extracted. A custom outline-unmixing keyer (`tools/keyer.py`) separates the art from the flat backgrounds. Gate A side-by-side: `art/side_by_side.png` (character pixels identical).
- **Phase 3, concepts: DONE.** `concepts.md`. COLOR CUT won with 58/70.
- **Phase 4, prototype: DONE.** `game/` builds to a single offline HTML (8.3 MB). 229-note chart, ONE/WAVE/bait, MASK ON fever, COLORS LIE, results, sample leaderboard, share-text copy, demo mode, portrait and landscape layouts. Live smoke test: 9/9 checks pass (`tools/smoke.cjs`).
- **Phase 5, storyboard: DONE.** `storyboard.md`.
- **Phase 6, AI inserts: NONE**, by design. Only official art is used.
- **Phase 7, edit/export: DONE.** Deterministic capture (`tools/capture.cjs`), re-sequenced original score plus mapped gameplay SFX (`tools/mix_trailer.py`), x264/AAC (`tools/encode_validate.py`).

## Decisions
- Use only official frames. The GTD "finger on mask" frames (3.5–4.9 s) are ambiguous and could read as a rude gesture, so they are excluded. The planned "shh" mechanic became the blue-kid **bait** card.
- Every hit is a colour-cut "shot", copying YORI's own edit style. The tagline "More than colors" became the COLORS LIE rule.
- Bar-aligned edit. The trailer's music is re-rendered from the same composition, so there are no audio splices.
- The palm-slam frames hid a note during play, so they are used only as a trailer transition.
- The sample leaderboard is tuned so a strong run lands at #3, which shows there is competition. It is clearly labelled "SAMPLE DATA · NO REAL ALLOCATION".

## Failures and fixes
- Keyer: yellow-orange background ≈ hair colour (21 RGB apart). Fixed with dominant-colour seeding plus a tight per-frame threshold.
- Encoder letterbox rows: both outer rows are now always repaired.
- Purple frames: the mask was speckled by hue removal, which is now limited to large pockets. A shirt sliver was flooded, so background now grows only through purple hue.
- Mix: the 808 was 18 dB hot. Fixed with a monophonic choke and a gain structure; the master pre-gain stops tanh squashing.
- Card scenes froze (freezedetect flagged 0.85–3.7 s holds). Added a leaderboard climb, push-ins, shimmer, confetti and counters.
- True peak was −0.8 dBTP; the limiter ceiling is now −1.9 dBFS.

## Open
- The founder has not reviewed this. Continuous full-speed playback and listening are not possible with these tools; the review is frame-based and metric-based.
