# yoricolors.xyz — public page notes (read 2026-11-28)

Only the public landing page HTML was read. No API endpoints were called.

- **Title:** "YORI | More Than Colors". **Hero:** "YORI" in gradient type, "MORE THAN COLORS", four colour dots, a "Connect X" button, "Built on Aptos".
- **WL tasks** (after connecting X):
  - follow @yoricolors
  - like and retweet the pinned post
  - quote it with "more than colors @yoricolors"
  - reply and tag 3 friends
  - submit an Aptos wallet (Petra, Martian and Pontem are suggested)
- After submitting, the site generates a shareable **WL status card**: a 1200×630 canvas with a gradient frame (#FF5FB0 → #7A6BFF → #19D3A8), a white rounded card, four dots (#FF5FB0, #FFC14D, #19D3A8, #7A6BFF), the user's PFP circle, "@handle", "Whitelist application", "YORI", "MORE THAN COLORS", and a yellow "APPLICATION STATUS · PENDING" pill. Its share text: "Just applied for the YORI whitelist on @Aptos. MORE THAN COLORS @yoricolors".
- **WL checker:** paste a wallet to see whether it is whitelisted. "The list is updated prior to mint."
- **Type:** Fredoka 500/600/700 and Nunito 600/700 (Google Fonts). **Text colour:** #2B1F4A. **Muted:** #7D7296.

The game's result card copies this visual language (gradient frame, four dots, PFP circle, yellow status pill) as a deliberate nod. The share flow only copies text; nothing is posted.
