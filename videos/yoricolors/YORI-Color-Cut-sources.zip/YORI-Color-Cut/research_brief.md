# YORI (@yoricolors) — research brief

**Identity.** YORI is a new PFP project on Aptos. Its whole public tagline is "More than colors on @Aptos". The banner wordmark pairs **色より** with **yori**. より ("yori") is the Japanese comparison particle ("than"), so 色より reads as "more than color". *(The particle reading is ours. The project's own English tagline matches it.)*

**Art and world (from the two official videos, the PFP and the banner).** A cocky kid with spiky orange hair and dark skin. He has heavy dark eye bags, big white eyes and fangs. He wears a black tee, a black neck gaiter and an olive plate-carrier vest. Each shot sits on one flat, saturated colour (blue, yellow-orange, red, orange, purple, magenta, teal), and the edit hard-cuts from colour to colour. He ties on a black-and-gold oni half-mask with a braided red cord, and his gestures are cheeky: index finger "one", an open-hand wave, a V/peace sign, a head-pat from a bandaged hand, a kissy pout and a tongue-out wink. Colour variants appear: a pale-blue kid with light-blue hair, and a kid in a black cap with glowing red eyes. Both videos end on the 色より burst and the yori wordmark.

**Five core motifs.** (1) Flat colour backgrounds that hard-cut on the beat. (2) "More than colors": the personality matters more than the colour. (3) The oni mask on its red cord, tied on for "mask on" moments. (4) Cheeky hand gestures and expressions as the attitude. (5) Colour variants of the same kid.

**Tone.** Short, confident and playful-cocky ("like, RT, Drop aptos evm"). Lowercase energy. No lore text is published.

**Mint / status.** WL application is live (Nov 25, 2026) and GTD application is live (Nov 27, 2026). Applicants apply at yoricolors.xyz by connecting X and doing follow / like / RT / QT ("more than colors @yoricolors") / tag-3 tasks, then submitting an Aptos wallet. The site has a WL checker and a shareable WL status card: gradient frame, four colour dots, PFP circle, "YORI / MORE THAN COLORS", a yellow "APPLICATION STATUS" pill. Supply, price and mint date: **unknown** (not published).

**Founder / team.** Unknown. The account follows one account. No team is named on X or on the site.

**Community signals.** At research time the account had 1,253 followers and 3 posts (2 with media). WL post: 366 likes, 252 reposts, 157 replies, 12.4k views. GTD post: 262 likes, 176 reposts, 154 replies, 7.0k views. The account was created Nov 5, 2026. Community inside jokes: unknown (too new).

**Competitive check.** No YORI game was found on X or on the site. The site is a WL task app only. Web search returned nothing about the project.

**Things the community likes (inferred only from the official posts and the site design).** The attitude, the mask reveal and the colour cuts. The site's own colour system: pink #FF5FB0, yellow #FFC14D, teal #19D3A8, purple #7A6BFF, with Fredoka and Nunito type.

**Avoid.** Invented lore, factions or names. Mint, allocation or price promises. Calling the concept official. Any gesture that could read as rude: the GTD video's "finger on mask" frames are ambiguous, so they are **not used**. Generic fantasy or 3D restyling.

**Coverage limits.** x.com itself is blocked from this environment. Profile and post data came through the public FxTwitter API (api.fxtwitter.com) with the user's approval, and media came from pbs/video.twimg.com. Only 2 of the 3 posts were retrievable, and replies were not read, so a 100-post audit was impossible (the account has 3 posts). The site's API endpoints were not probed. Only the public page HTML was read.

## Sources opened
- https://x.com/yoricolors (via https://api.fxtwitter.com/2/profile/yoricolors/media and …/statuses)
- https://x.com/yoricolors/status/2125607967425024066 (WL post, video)
- https://x.com/yoricolors/status/2126346282352709741 (GTD post, video)
- https://yoricolors.xyz/ (public page only: tasks, checker, WL card generator, palette, fonts; see `research/site-notes.md`)
- Media URLs and SHA-256 hashes: `art/sources.csv`
