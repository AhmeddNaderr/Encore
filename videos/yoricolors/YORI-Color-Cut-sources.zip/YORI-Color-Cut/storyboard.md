# YORI: COLOR CUT — storyboard

Score: original 128 BPM cue built on a 4-bar Em–C–D–B loop (1 bar = 1.875 s). Every cut lands on a bar line. Each gameplay shot takes the song bar whose chord matches its trailer position (trailer bar *k* ≡ source bar *b* mod 4), so the re-sequenced music stays harmonically continuous.

Every gameplay shot is a deterministic capture of the real engine. One scripted "skilled player" run (seed 11, ±26 ms human timing spread) goes through the same `press()` path as keyboard and touch input. It takes one bait on purpose (note 48) to show the fail state. Run result: 317,580 points, 212 perfect, 7 good, 9 dodged, 1 baited, 180 max combo, rank S. Captions, the sample leaderboard, the post mock-up and the end card are motion graphics drawn by the same renderer.

## Main cut — 42.0 s, 1920×1080, 60 fps
| Time | Trailer bars | Source | On screen | Text | Sound |
|---|---|---|---|---|---|
| 0.00–3.75 | 0–1 | song bars 24–25 (45.0–48.75 s) | **Hook, mid-game.** MASK ON fever: masked YORI (official GTD peace frames) on purple speed lines with embers, ×8, combo 80+, card shatters. No logo, no title. | in-game UI only | drop hook + hit ticks |
| 3.75–7.50 | 2–3 | bars 6–7 (verse A) | Basic loop: ONE/WAVE stickers reach the ring and each hit hard-cuts the stage red or yellow with the matching official pose | **"Read the move. Hit the beat."** (6 words) | verse groove |
| 7.50–11.25 | 4–5 | bars 12–13 (verse B) | The blue kid throws a bait card. The player hits it: **BAITED!**, a grayscale "colour drain", the bandaged-hand head-pat (official). Then recovery. | **"Blue card? Don't take the bait."** | bonk + pat |
| 11.25–15.00 | 6–7 | bars 22–23 (drop start) | 色より burst, then the **MASK ON** cut-in band (the official mask-tie frames at 12 fps), ×2 score, then the fever stage | in-game "MASK ON ×2 SCORE" | impact + taiko |
| 15.00–18.75 | 8–9 | bars 28–29 | Fever escalation, combo past 100 | — | hook |
| 18.75–22.50 | 10–11 | bars 30–31 | **MASK OFF** tongue-wink band (official), then the night stage, then the cap kid takes over the rival panel, then **COLORS LIE / READ THE MOVE** | in-game stamp | glitch sting |
| 22.50–26.25 | 12–13 | bars 32–33 | Lying colours: red cards ask for WAVE, yellow for ONE; a disguised bait gets dodged | — | lie section |
| 26.25–28.13 | 14 | bar 42 (outro) | Final hit and resolve | — | impact + final chord |
| 28.13–31.88 | 15–16 | motion graphics | Palm-slam transition (official GTD frames), then the **sample WL leaderboard**: the player's run climbs into the top 3 | **"Anyone can like a post. / Can you read the move?"** | ticks + rank-up |
| 31.88–35.63 | 17–18 | motion graphics | Result card in the style of YORI's own WL status card (gradient frame, four dots, PFP, rank stamp "S · MORE THAN COLORS", YOUR CUT colour barcode, SAMPLE WL RANK pill) | — | stamp |
| 35.63–37.50 | 19 | motion graphics | The card flies into a generic social **post mock-up** labelled "POST MOCK-UP · NOTHING IS POSTED" | — | whoosh |
| 37.50–42.00 | 20–22 | motion graphics | 色より burst, then the end card: the official yori banner plaque, COLOR CUT, "A GAME CONCEPT BY" the Encore mark, ENCORE STUDIO, "One crew for your whole launch.", encorestudio.xyz · @EncoreStudiohq, Book a free 30-min call, and the unofficial-concept line | — | Em resolution, fade |

## 15 s cut — 1080×1920, 60 fps (works with the sound off)
| Time | Source | On screen | Text |
|---|---|---|---|
| 0.00–1.88 | bar 24 | Fever hook (portrait layout: big face, lane, control deck) | — |
| 1.88–3.75 | bar 5 | Basic ONE/WAVE hits with colour cuts | **"Read the move. / Hit the beat."** |
| 3.75–5.63 | bar 30 | MASK OFF, then COLORS LIE with the cap kid | in-game stamp |
| 5.63–7.50 | bar 35 | Lying colours plus a disguised bait dodged | — |
| 7.50–11.25 | motion graphics | Palm transition, then the sample WL leaderboard | **"Anyone can like a post. / Can you read the move?"** |
| 11.25–13.13 | motion graphics | Result card into the post mock-up | — |
| 13.13–15.00 | motion graphics | End card | — |

## Phase 6 — AI inserts
None. The official art already supplies the cinematic beats (the mask tie, the palm slam, the 色より burst). No generated footage is used anywhere, so there is no risk of identity drift.
