"""Inline all assets into one self-contained HTML file (offline playable)."""
import base64, json, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = os.path.join(ROOT, 'build/assets')
os.makedirs(os.path.join(ROOT, 'dist'), exist_ok=True)
def uri(path, mime):
    return f'data:{mime};base64,' + base64.b64encode(open(path, 'rb').read()).decode()
sprites = json.load(open(os.path.join(A, 'sprites.json')))
misc = json.load(open(os.path.join(A, 'misc.json')))
skip = {'bluesmirk-255', 'bluesmirk-260', 'peace-145'}
images, meta = {}, {}
for k, m in sprites.items():
    if k in skip: continue
    images[k] = uri(os.path.join(A, k + '.webp'), 'image/webp'); meta[k] = m
for k in misc:
    name = k[:-5] if k.endswith('.webp') else k
    if name == 'encore-mark':
        images[name] = uri(os.path.join(A, 'encore-mark.png'), 'image/png')
    else:
        images[name] = uri(os.path.join(A, name + '.webp'), 'image/webp')
fontdir = os.path.join(ROOT, 'tools/node/node_modules/@fontsource')
fonts = [
    {'family': 'Fredoka', 'weight': 600, 'src': uri(f'{fontdir}/fredoka/files/fredoka-latin-600-normal.woff2', 'font/woff2')},
    {'family': 'Fredoka', 'weight': 700, 'src': uri(f'{fontdir}/fredoka/files/fredoka-latin-700-normal.woff2', 'font/woff2')},
    {'family': 'Nunito', 'weight': 700, 'src': uri(f'{fontdir}/nunito/files/nunito-latin-700-normal.woff2', 'font/woff2')},
    {'family': 'Nunito', 'weight': 800, 'src': uri(f'{fontdir}/nunito/files/nunito-latin-800-normal.woff2', 'font/woff2')},
]
au = os.path.join(ROOT, 'build/audio'); mp = os.path.join(ROOT, 'build/audio/mp3'); os.makedirs(mp, exist_ok=True)
def mp3(src, dst, br='160k', mono=False):
    if not os.path.exists(dst) or os.path.getmtime(dst) < os.path.getmtime(src):
        cmd = ['ffmpeg', '-v', 'error', '-y', '-i', src] + (['-ac', '1'] if mono else []) + ['-c:a', 'libmp3lame', '-b:a', br, dst]
        subprocess.run(cmd, check=True)
    return dst
audio = {'song': uri(mp3(f'{au}/song.wav', f'{mp}/song.mp3', '192k'), 'audio/mpeg'),
         'loop': uri(mp3(f'{au}/results-loop.wav', f'{mp}/results-loop.mp3', '160k'), 'audio/mpeg'), 'sfx': {}}
for f in sorted(os.listdir(f'{au}/sfx')):
    k = f[:-4]
    audio['sfx'][k] = uri(mp3(f'{au}/sfx/{f}', f'{mp}/sfx-{k}.mp3', '112k', mono=True), 'audio/mpeg')
chart = json.load(open(os.path.join(ROOT, 'build/chart.json')))
data = 'window.__YORI = ' + json.dumps({'images': images, 'meta': meta, 'fonts': fonts, 'audio': audio, 'chart': chart}, separators=(',', ':')) + ';'
html = open(os.path.join(ROOT, 'game/shell.html')).read()
for tag, f in [('/*__ENGINE__*/', 'engine.js'), ('/*__RENDER__*/', 'render.js'), ('/*__APP__*/', 'app.js')]:
    html = html.replace(tag, open(os.path.join(ROOT, 'game', f)).read())
html = html.replace('/*__DATA__*/', data)
out = os.path.join(ROOT, 'dist/yori-color-cut.html')
open(out, 'w').write(html)
print(out, round(os.path.getsize(out) / 1e6, 2), 'MB;', len(images), 'images')
