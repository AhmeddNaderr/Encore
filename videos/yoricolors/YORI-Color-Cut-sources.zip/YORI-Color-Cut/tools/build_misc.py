import sys, json, numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage as ndi
sys.path.insert(0, 'tools')
from keyer import repair_edges
A = 'build/assets/'
meta = json.load(open(A + 'sprites.json'))
def load(p): return Image.fromarray(repair_edges(np.array(Image.open(p).convert('RGB'))))
def save(im, name, q=88, size=None):
    if size: im = im.resize(size, Image.LANCZOS)
    im.save(A + name, 'WEBP', quality=q, method=6); return im.size
info = {}
# 1) MASK ON cut-in: official mask-tie frames (12 fps, anime timing), cropped to face+hands band
for n in range(0, 90, 5):
    im = load(f'art/src/maskseq/m{n:03d}.png').crop((0, 0, 1956, 760))
    info[f'cutin-mask-{n:03d}'] = save(im, f'cutin-mask-{n:03d}.webp', 84, (1280, 497))
# 2) MASK OFF cut-in: tongue-wink frames (magenta)
for nm in ['tongue-315', 'tongue-320', 'tongue-325']:
    im = load(f'art/src/{nm}.png').crop((0, 0, 1956, 760))
    info['cutin-' + nm] = save(im, f'cutin-{nm}.webp', 84, (1280, 497))
# 3) Palm slam (full frame, purple)
for nm in ['palm-105', 'palm-110', 'palm-115']:
    info[nm] = save(load(f'art/src/{nm}.png'), f'{nm}.webp', 82, (1280, 707))
# 4) Rival panels (original backgrounds kept): blue kid (orange), cap kid (cyan)
for nm, box in [('bluesmirk-255', (260, 0, 1700, 1080)), ('bluesmirk-260', (260, 0, 1700, 1080)),
                ('bluereach-270', (260, 0, 1950, 1080)), ('bluereach-275', (260, 0, 1950, 1080)),
                ('cap-315', (150, 0, 1800, 1080)), ('cap-320', (150, 0, 1800, 1080)), ('cap-325', (150, 0, 1800, 1080))]:
    im = load(f'art/src/{nm}.png').crop(box)
    w = 760; h = round(im.height * w / im.width)
    info['panel-' + nm] = save(im, f'panel-{nm}.webp', 86, (w, h))
# 5) 色より burst + end logo (official motion-graphic frames)
for nm in ['iroburst-365', 'iroburst-375', 'logoend-410']:
    info[nm] = save(load(f'art/src/{nm}.png'), f'{nm}.webp', 86, (1280, 709))
# 6) Banner plaque + keyed logo (white bubble letters, black outline) from the X banner
ban = Image.open('art/raw/x-banner-1500x500.jpg').convert('RGB')
info['banner'] = save(ban, 'banner.webp', 92)
b = np.array(ban).astype(np.float32)
yel = np.median(b[:6].reshape(-1, 3), axis=0)
d = np.linalg.norm(b - yel, axis=2)
alpha = np.clip((d - 30) / 70, 0, 1)
fgw = np.clip((b - (1 - alpha[..., None]) * yel) / np.maximum(alpha[..., None], 1e-3), 0, 255)
rgba = np.dstack([fgw, alpha * 255]).astype(np.uint8)
ys, xs = np.where(alpha > 0.05)
rgba = rgba[ys.min() - 4: ys.max() + 5, xs.min() - 4: xs.max() + 5]
im = Image.fromarray(rgba); im.save(A + 'logo-keyed.webp', 'WEBP', quality=92, method=6, alpha_quality=100)
info['logo-keyed'] = im.size
# 7) PFP avatar
info['avatar'] = save(Image.open('art/raw/x-avatar-400.jpg').convert('RGB'), 'avatar.webp', 92)
# 8) Encore mark (from Encore's own end card in the earlier Clover delivery)
enc = Image.open('/tmp/claude-0/-home-user-Encore/1d29cf34-f047-5d02-b617-b6ee1d4d1d5a/scratchpad/clover-ref/Cloverheads-Same-Roots/art/encore-reference-endcard.png').convert('RGB')
crop = enc.crop((810, 150, 1118, 360))
e = np.array(crop).astype(np.float32)
lum = e.max(2)
al = np.clip(lum / 40.0, 0, 1)  # soft alpha for use on black/dark backgrounds
info['encore-mark'] = crop.size
crop.save(A + 'encore-mark.png')
# 9) Stickers for the move cards (white die-cut border around official art)
def sticker(nm, box, out, size=300, border=14):
    m = meta[nm]
    sp = Image.open(A + f'{nm}.webp').convert('RGBA')
    full = Image.new('RGBA', (m['frameW'], m['h']), (0, 0, 0, 0)); full.alpha_composite(sp, (m['x0'], 0))
    c = full.crop(box)
    s = size / max(c.size); c = c.resize((max(1, round(c.width * s)), max(1, round(c.height * s))), Image.LANCZOS)
    pad = border + 4
    canvas = Image.new('RGBA', (c.width + 2 * pad, c.height + 2 * pad), (0, 0, 0, 0))
    canvas.alpha_composite(c, (pad, pad))
    a = np.array(canvas)[..., 3] > 40
    outer = ndi.binary_dilation(a, iterations=border)
    ink = ndi.binary_dilation(outer, iterations=3) & ~outer
    base = np.zeros(a.shape + (4,), np.uint8)
    base[outer] = (255, 255, 255, 255); base[ink] = (20, 16, 20, 255)
    bim = Image.fromarray(base).filter(ImageFilter.GaussianBlur(0.6))
    bim.alpha_composite(canvas)
    bim.save(A + out, 'WEBP', quality=92, method=6, alpha_quality=100)
    info[out] = bim.size
sticker('one-180', (356, 0, 1500, 1080), 'sticker-one.webp')
sticker('wave-215', (168, 0, 1500, 1080), 'sticker-wave.webp')
sticker('bluesmirk-260', (300, 0, 1500, 1080), 'sticker-bait.webp')
sticker('peace-185', (300, 0, 1700, 1080), 'sticker-peace.webp')
sticker('smirk-005', (242, 0, 1629, 1080), 'sticker-smirk.webp')
json.dump(info, open(A + 'misc.json', 'w'), indent=1)
print(json.dumps(info))
