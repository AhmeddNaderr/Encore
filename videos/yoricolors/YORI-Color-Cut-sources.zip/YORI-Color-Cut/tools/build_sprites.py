"""Build game sprites from the official YORI frames.
Keyed sprites keep the full source frame height (so the frame's top/bottom cut
lines stay consistent) and are trimmed horizontally; offsets are recorded.
"""
import sys, json, numpy as np
from PIL import Image
sys.path.insert(0, 'tools')
from keyer import key, preview

def hsv(img):
    x = img / 255.0
    mx = x.max(2); mn = x.min(2); d = mx - mn + 1e-6
    r, g, b = x[..., 0], x[..., 1], x[..., 2]
    h = np.where(mx == r, ((g - b) / d) % 6, np.where(mx == g, (b - r) / d + 2, (r - g) / d + 4)) * 60
    return h, d / (mx + 1e-6), mx
def purple(img):
    h, s, v = hsv(img); return (h > 225) & (h < 290) & (s > 0.16) & (v > 0.20)

FLAT = dict(thresh=40)
SPRITES = {
  'smirk':   (['smirk-000', 'smirk-005', 'smirk-010'], FLAT),
  'one':     (['one-170', 'one-180', 'one-190', 'one-195'], FLAT),
  'wave':    (['wave-210', 'wave-215', 'wave-220'], FLAT),
  'pout':    (['pout-115', 'pout-125', 'pout-135'], dict(thresh=11, seed_tol=9, sides='lr', pocket_tol=0, grow=3)),
  'headpat': (['headpat-040', 'headpat-055', 'headpat-070'], dict(thresh=40, sides='lr')),
  'blue':    (['bluesmirk-255', 'bluesmirk-260'], FLAT),
  'peace':   (['peace-145', 'peace-160', 'peace-175', 'peace-185'], dict(thresh=10, seed_tol=60, hue_bg=purple, pocket_tol=0, global_hue=True)),
}
meta = {}
for group, (names, kw) in SPRITES.items():
    for nm in names:
        kw2 = dict(kw); glob = kw2.pop('global_hue', False)
        src = np.array(Image.open(f'art/src/{nm}.png').convert('RGB'))
        rgba, B, bgm = key(src, **kw2)
        if glob:  # remove only large enclosed purple pockets (inside the red cord loops); keep mask tints
            from scipy import ndimage as ndi
            a = rgba[..., 3].astype(np.float32)
            pm = purple(src.astype(np.float32)) & (a > 128)
            pm = ndi.binary_opening(pm, iterations=2)
            lab, n = ndi.label(pm)
            if n:
                sizes = ndi.sum(np.ones_like(a), lab, np.arange(1, n + 1))
                keep = np.zeros(n + 1, bool); keep[1:] = sizes > 2500
                pk = keep[lab]
                pk = ndi.binary_dilation(pk, iterations=2) & purple(src.astype(np.float32))
                soft = ndi.gaussian_filter(pk.astype(np.float32), 1.0)
                a = a * (1 - np.clip(soft * 1.6, 0, 1))
            rgba[..., 3] = a.clip(0, 255).astype(np.uint8)
        al = rgba[..., 3]
        xs = np.where(al.max(0) > 8)[0]
        x0, x1 = max(xs.min() - 6, 0), min(xs.max() + 7, al.shape[1])
        crop = Image.fromarray(rgba[:, x0:x1])
        crop.save(f'build/assets/{nm}.webp', 'WEBP', quality=90, method=6, alpha_quality=95)
        Image.fromarray(rgba).save(f'art/keyed/{nm}.png')
        preview(rgba).save(f'art/preview/{nm}.jpg', quality=88)
        meta[nm] = {'group': group, 'x0': int(x0), 'w': int(x1 - x0), 'h': int(al.shape[0]), 'frameW': int(al.shape[1])}
        print(nm, meta[nm], flush=True)
json.dump(meta, open('build/assets/sprites.json', 'w'), indent=1)
