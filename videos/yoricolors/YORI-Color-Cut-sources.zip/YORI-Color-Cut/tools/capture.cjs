// Deterministic trailer capture: renders every frame of a timeline from the
// built game (real engine + autoplay inputs), writes PNG frames + an event log.
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const BAR = 60 / 128 * 4;
(async () => {
  const spec = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const outDir = process.argv[3];
  const only = process.argv[4] ? process.argv[4].split(',').map(Number) : null;
  fs.mkdirSync(outDir, { recursive: true });
  const { w, h, fps } = spec;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + path.resolve('dist/yori-color-cut.html') + '?capture=1');
  await page.waitForFunction(() => window.__ready === true, null, { timeout: 60000 });
  await page.evaluate(([w, h]) => window.YORI_CAPTURE.init(w, h), [w, h]);
  // full simulated run -> final result + complete event log
  const full = await page.evaluate((run) => { const C = window.YORI_CAPTURE; C.setupRun(run); C.advance(App.chart.duration + 2); return { result: C.result(), events: C.events(), summary: C.summary(), inputs: C.inputs.length }; }, spec.run);
  fs.writeFileSync(path.join(outDir, 'run.json'), JSON.stringify(full, null, 1));
  console.log('run', JSON.stringify(full.summary));
  const total = Math.round(spec.duration * fps);
  const shots = spec.shots.map((s, i) => {
    const t0 = s.k * BAR, t1 = i + 1 < spec.shots.length ? spec.shots[i + 1].k * BAR : spec.duration;
    return Object.assign({}, s, { idx: i, t0, t1, f0: Math.ceil(t0 * fps - 1e-6), f1: Math.min(total, Math.ceil(t1 * fps - 1e-6)) });
  });
  fs.writeFileSync(path.join(outDir, 'shots.json'), JSON.stringify(shots, null, 1));
  const started = Date.now(); let n = 0;
  const order = shots.slice().sort((a, b) => (a.type === 'game' ? a.srcBar : 1e3 + a.k) - (b.type === 'game' ? b.srcBar : 1e3 + b.k));
  for (const s of order) {
    if (only && !only.includes(s.idx)) continue;
    if (s.type === 'game') {
      const src0 = s.srcBar * BAR;
      await page.evaluate(([run, t]) => { const C = window.YORI_CAPTURE; C.setupRun(run); C.advance(t); }, [spec.run, src0 - 0.001]);
    }
    for (let f = s.f0; f < s.f1; f++) {
      const tau = f / fps, lt = tau - s.t0;
      let cap = null;
      if (s.caption) cap = { text: s.caption.text, scale: s.caption.scale || 1 };
      if (s.type === 'game') {
        const src = s.srcBar * BAR + lt;
        if (cap) { cap.t0 = s.srcBar * BAR + s.caption.at; cap.t1 = cap.t0 + s.caption.dur; }
        await page.evaluate(([t, c]) => window.YORI_CAPTURE.renderGame(t, c), [src, cap]);
      } else {
        if (cap) { cap.t0 = s.caption.at; cap.t1 = s.caption.at + s.caption.dur; cap.tNow = lt; }
        await page.evaluate(([name, lt, res, c]) => window.YORI_CAPTURE.renderCard(name, lt, { result: res, caption: c }), [s.card, lt, full.result, cap]);
      }
      if (s.overlay) await page.evaluate(([k, a]) => window.YORI_CAPTURE.overlay(k, a), [s.overlay, lt]);
      const buf = await page.screenshot({ clip: { x: 0, y: 0, width: w, height: h }, type: 'png' });
      fs.writeFileSync(path.join(outDir, `f${String(f).padStart(5, '0')}.png`), buf);
      n++;
      if (n % 120 === 0) console.log(`frames ${n}  ${((Date.now() - started) / n).toFixed(0)} ms/frame`);
    }
  }
  console.log('done', n, 'frames in', ((Date.now() - started) / 1000).toFixed(1), 's');
  if (errors.length) console.log('PAGE ERRORS:', errors.slice(0, 8).join('\n'));
  await browser.close();
})();
