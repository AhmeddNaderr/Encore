"""YORI: COLOR CUT - original score, effects and note chart.

Everything is synthesised here from oscillators and seeded noise (no samples,
no third-party loops). 128 BPM, 4-bar Em-C-D-B loop so any bar can be
re-sequenced for trailer edits while the harmony stays continuous.

    python3 tools/compose.py song          -> build/audio/song.wav + build/chart.json
    python3 tools/compose.py sfx           -> build/audio/sfx/*.wav
    python3 tools/compose.py loop          -> build/audio/results-loop.wav
    python3 tools/compose.py arrange FILE  -> render an arrangement JSON (trailers)
"""
import json, sys, os, math, hashlib
import numpy as np
from scipy import signal
from scipy.ndimage import minimum_filter1d, uniform_filter1d

SR = 48000
BPM = 128.0
STEP = 60.0 / BPM / 4.0          # 16th note
BAR = STEP * 16                   # 1.875 s
OUT = 'build/audio'

def mtof(m): return 440.0 * 2 ** ((m - 69) / 12.0)

def rng_for(*key):
    h = hashlib.sha256(repr(key).encode()).digest()
    return np.random.default_rng(int.from_bytes(h[:8], 'little'))

# ---------------------------------------------------------------- filters
def bp(x, lo, hi, order=2):
    sos = signal.butter(order, [lo, hi], btype='band', fs=SR, output='sos'); return signal.sosfilt(sos, x)
def hp(x, f, order=2):
    sos = signal.butter(order, f, btype='high', fs=SR, output='sos'); return signal.sosfilt(sos, x)
def lp(x, f, order=2):
    sos = signal.butter(order, f, btype='low', fs=SR, output='sos'); return signal.sosfilt(sos, x)

def freeverb(x, room=0.84, damp=0.35, width=23):
    combs = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617]
    aps = [556, 441, 341, 225]
    s = SR / 44100.0
    out = []
    for off in (0, width):
        acc = np.zeros_like(x)
        for c in combs:
            D = int((c + off) * s); f = room; d = damp
            a = np.zeros(D + 1); a[0] = 1; a[1] = -d; a[D] -= f * (1 - d)
            acc += signal.lfilter([1, -d], a, x)
        y = acc / len(combs)
        for ap in aps:
            D = int((ap + off) * s); g = 0.5
            b = np.zeros(D + 1); b[0] = -g; b[D] = 1
            a = np.zeros(D + 1); a[0] = 1; a[D] = -g
            y = signal.lfilter(b, a, y)
        out.append(y)
    return np.stack(out, 1)

# ---------------------------------------------------------------- instruments (mono)
def env_ar(n, a, r_tau, hold):
    t = np.arange(n) / SR
    e = np.minimum(t / max(a, 1e-4), 1.0)
    rel = np.where(t > hold, np.exp(-(t - hold) / r_tau), 1.0)
    return e * rel

def kick(vel=1.0, seed=0):
    n = int(0.5 * SR); t = np.arange(n) / SR
    f = 47 + (170 - 47) * np.exp(-t / 0.032)
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.24)
    r = rng_for('kick', seed)
    click = hp(r.standard_normal(n), 2500) * np.exp(-t / 0.0025) * 0.35
    x = np.tanh(1.8 * (body + click)) / np.tanh(1.8)
    return x * vel

def b808(freq, dur, vel=1.0, glide_to=None):
    n = int((dur + 0.3) * SR); t = np.arange(n) / SR
    f = freq * (1 + 0.18 * np.exp(-t / 0.018))
    if glide_to:
        k = np.clip((t - dur * 0.55) / (dur * 0.45 + 1e-3), 0, 1)
        f = f * (glide_to / freq) ** (k * k * (3 - 2 * k))
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) + 0.22 * np.sin(2 * ph) + 0.08 * np.sin(3 * ph)
    e = env_ar(n, 0.004, 0.11, dur)
    return np.tanh(2.4 * x) / np.tanh(2.4) * e * vel

def clap(vel=1.0, seed=0):
    n = int(0.42 * SR); t = np.arange(n) / SR
    r = rng_for('clap', seed)
    nz = bp(r.standard_normal(n), 850, 3200)
    e = np.zeros(n)
    for k, o in enumerate((0.0, 0.010, 0.021, 0.030)):
        tt = np.clip(t - o, 0, None); e += (t >= o) * np.exp(-tt / 0.0045) * (0.8 + 0.1 * k)
    e += (t >= 0.03) * np.exp(-np.clip(t - 0.03, 0, None) / 0.11) * 0.55
    snare_tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.05) * 0.25
    return (nz * e * 0.9 + snare_tone) * vel

def snare(vel=1.0, seed=0):
    n = int(0.25 * SR); t = np.arange(n) / SR
    r = rng_for('snare', seed)
    nz = hp(r.standard_normal(n), 1200) * np.exp(-t / 0.07)
    tone = np.sin(2 * np.pi * (210 + 40 * np.exp(-t / 0.01)) * t) * np.exp(-t / 0.04)
    return (0.75 * nz + 0.45 * tone) * vel

def hat(vel=1.0, open_=False, seed=0):
    n = int((0.32 if open_ else 0.07) * SR); t = np.arange(n) / SR
    r = rng_for('hat', seed % 32, open_)
    nz = hp(r.standard_normal(n), 7200, 3)
    e = np.exp(-t / (0.16 if open_ else 0.022))
    return nz * e * vel * 0.55

def taiko(vel=1.0, seed=0):
    n = int(1.1 * SR); t = np.arange(n) / SR
    f = 60 + 55 * np.exp(-t / 0.045)
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.38)
    r = rng_for('taiko', seed)
    skin = lp(r.standard_normal(n), 1400) * np.exp(-t / 0.05) * 0.6
    return np.tanh(1.4 * (body + skin)) * vel

def crash(vel=1.0, seed=0):
    n = int(2.2 * SR); t = np.arange(n) / SR
    r = rng_for('crash', seed)
    nz = hp(r.standard_normal(n), 3500, 2) * np.exp(-t / 0.7)
    ring = sum(np.sin(2 * np.pi * f * t + p) for f, p in ((5230, 0), (6170, 1), (7410, 2))) * 0.05 * np.exp(-t / 0.5)
    return (nz * 0.5 + ring) * vel

_KS = {}
def koto(midi, dur=1.4, vel=1.0, bright=0.6):
    key = (midi, round(dur, 2), round(bright, 2))
    if key not in _KS:
        freq = mtof(midi)
        D = max(int(round(SR / freq - 0.5)), 2)
        f_ks = SR / (D + 0.5)
        n = int((dur + 0.2) * SR)
        r = rng_for('koto', midi)
        exc = r.standard_normal(D) * np.hanning(D) ** 0.5
        exc = lp(exc, 2500 + 6000 * bright)
        x = np.zeros(n); x[:D] = exc
        g = 0.9965 if midi < 72 else 0.9945
        a = np.zeros(D + 2); a[0] = 1; a[D] = -g * 0.5; a[D + 1] = -g * 0.5
        y = signal.lfilter([1.0], a, x)
        ratio = f_ks / freq  # resample to exact pitch
        idx = np.arange(int(n / ratio)) * ratio
        idx = idx[idx < n - 1]
        y = np.interp(idx, np.arange(n), y)
        t = np.arange(len(y)) / SR
        twang = np.sin(2 * np.pi * freq * 2 * t) * np.exp(-t / 0.03) * 0.25
        y = y / (np.max(np.abs(y)) + 1e-9) + twang
        y = bp(y, 180, 9000, 1)
        fade = np.ones(len(y)); m = int(0.08 * SR); fade[-m:] = np.linspace(1, 0, m)
        _KS[key] = (y * fade).astype(np.float32)
    return _KS[key] * vel

def saw_add(freq, n, maxf=9000, detune=0.0, phase=0.0):
    t = np.arange(n) / SR
    out = np.zeros(n)
    f = freq * 2 ** (detune / 1200)
    k = 1
    while k * f < maxf and k < 60:
        out += np.sin(2 * np.pi * k * f * t + phase * k) / k
        k += 1
    return out

_LEAD = {}
def lead(midi, dur, vel=1.0):
    key = (midi, round(dur, 3))
    if key not in _LEAD: _LEAD[key] = _lead(midi, dur)
    return _LEAD[key] * vel

def _lead(midi, dur, vel=1.0):
    n = int((dur + 0.25) * SR); t = np.arange(n) / SR
    f = mtof(midi)
    x = 0.6 * saw_add(f, n, 7000, -7) + 0.6 * saw_add(f, n, 7000, 7, 1.3) + 0.35 * np.sign(np.sin(2 * np.pi * f / 2 * t))
    e = env_ar(n, 0.006, 0.09, dur)
    # pluck filter envelope via crossfade of bright/dark versions
    dark = lp(x, 900)
    k = np.exp(-t / 0.12)
    y = x * k + dark * (1 - k)
    return y * e * vel * 0.22

def flute(midi, dur, vel=1.0, seed=0):
    n = int((dur + 0.35) * SR); t = np.arange(n) / SR
    f = mtof(midi)
    vib = 1 + 0.006 * np.sin(2 * np.pi * 5.2 * t) * np.clip((t - 0.18) / 0.25, 0, 1)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    tone = np.sin(ph) + 0.18 * np.sin(2 * ph) + 0.06 * np.sin(3 * ph)
    r = rng_for('flute', seed)
    breath = bp(r.standard_normal(n), f * 0.8, min(f * 3.5, 12000)) * 0.35
    e = env_ar(n, 0.05, 0.18, dur)
    chiff = np.exp(-t / 0.03) * 0.6
    return (tone * (1 - 0.2 * chiff) + breath * (0.6 + chiff)) * e * vel * 0.32

_PAD = {}
def pad_chord(notes, dur, vel=1.0, bright=2200):
    key = (tuple(notes), round(dur, 3), int(bright))
    if key in _PAD: return _PAD[key] * vel
    _PAD[key] = _pad_chord(notes, dur, bright)
    return _PAD[key] * vel

def _pad_chord(notes, dur, bright):
    vel = 1.0
    n = int((dur + 0.6) * SR)
    x = np.zeros(n)
    for i, m in enumerate(notes):
        f = mtof(m)
        for d, p in ((-9, 0.1), (0, 1.7), (9, 3.1)):
            x += saw_add(f, n, bright * 1.6, d, p)
    x = lp(x, bright)
    e = env_ar(n, 0.25, 0.35, dur)
    return x * e * vel * 0.05

def riser(dur, vel=1.0, seed=0):
    n = int(dur * SR); t = np.arange(n) / SR
    r = rng_for('riser', seed)
    nz = r.standard_normal(n)
    k = t / dur
    out = np.zeros(n)
    seg = int(0.05 * SR)
    for s0 in range(0, n, seg):
        c = 400 + 9000 * (s0 / n) ** 2
        part = nz[max(s0 - 2048, 0): s0 + seg]
        y = bp(part, c * 0.7, min(c * 1.4, 20000))[-(min(seg, n - s0)):]
        out[s0: s0 + len(y)] = y
    sweep = np.sin(2 * np.pi * np.cumsum(220 * 2 ** (3 * k)) / SR) * 0.15
    return (out * 0.5 + sweep) * (k ** 1.6) * vel

def impact(vel=1.0, seed=0):
    n = int(2.0 * SR); t = np.arange(n) / SR
    boom = np.sin(2 * np.pi * np.cumsum(38 + 50 * np.exp(-t / 0.08)) / SR) * np.exp(-t / 0.7)
    r = rng_for('impact', seed)
    nz = lp(r.standard_normal(n), 2500) * np.exp(-t / 0.15) * 0.5
    return np.tanh(1.5 * (boom + nz)) * vel

def reverse_swell(dur, vel=1.0, seed=0):
    x = crash(1.0, seed)[: int(dur * SR)]
    return x[::-1] * np.linspace(0, 1, len(x)) ** 2 * vel

# ---------------------------------------------------------------- composition
CHORDS = ['Em', 'C', 'D', 'B']
PAD = {'Em': [52, 59, 64, 67], 'C': [48, 55, 64, 67], 'D': [50, 57, 62, 66], 'B': [47, 54, 63, 66]}
ROOT = {'Em': 28, 'C': 36, 'D': 38, 'B': 35}
HOOK = {
    'Em': [(0, 76, 2), (3, 76, 2), (6, 79, 2), (8, 81, 3), (12, 79, 2), (14, 76, 2)],
    'C':  [(2, 79, 2), (4, 76, 2), (6, 74, 2), (8, 76, 6)],
    'D':  [(0, 74, 2), (3, 74, 2), (6, 78, 2), (8, 81, 3), (12, 78, 2), (14, 74, 2)],
    'B':  [(2, 78, 2), (4, 75, 2), (6, 71, 2), (8, 75, 2), (10, 78, 2), (12, 83, 4)],
}
ARP = {
    'Em': [64, 71, 76, 71, 79, 71, 76, 71], 'C': [60, 67, 72, 67, 76, 67, 72, 67],
    'D': [62, 69, 74, 69, 78, 69, 74, 69], 'B': [59, 66, 71, 66, 75, 66, 71, 66],
}

# Note chart patterns (16 steps per bar): O = ONE (left), W = WAVE (right), B = BAIT (do not press)
CHART = {
    'intro':  ['................', '................'],
    'verseA': ['O.......W.......', 'O.......W.......', 'O...W...O...W...', 'O...W...O...W...',
               'O...W...O...W...', 'O...W...O.O.W...', 'O...W...O...W.W.', 'O.O.W...O...W...'],
    'verseB': ['O..O..W.O...W...', 'O...W...B...W...', 'O..O..W.O...W.W.', 'O...W...B...W...',
               'O..O..W.O.O.W...', 'O...B...O...W...', 'O..O..W.O..O..W.', 'O.W.O.W.B...W...'],
    'build':  ['O.W.O.W.O.W.O.W.', 'O.W.O.W.O.W.B.W.', 'O.O.W.W.O.O.W.W.', 'O.W.O.W.O.W.O...'],
    'drop':   ['O..O..W.W...W.O.', '..W.O.O.O...W...', 'O..O..W.W...W.O.', '..W.O.O.O.W.W...',
               'O..O..W.W...B.O.', '..W.O.O.O...W.W.', 'O..O..W.W.O.W.O.', '..W.O.O.O.W.W...'],
    'lie':    ['O..O..W.W...W.O.', '..W.B.O.O...W...', 'O..O..W.W...W.O.', '..W.O.B.O.W.W...',
               'O.O.W.W.O.O.W.W.', 'O..O..W.B...W.O.', 'O..O..W.W.O.W.O.', '..W.O.O.O.W.W...'],
    'final':  ['O.W.O.W.O.W.O.W.', 'O..O..W.W...W.O.', 'O.W.O.W.B.W.O.W.', 'O.W.O.W.O.......'],
    'outro':  ['W...............', '................'],
    'cards':  ['................'] * 4,
    'endcard': ['................'] * 2,
}
SONG = [('intro', 2), ('verseA', 8), ('verseB', 8), ('build', 4), ('drop', 8), ('lie', 8), ('final', 4), ('outro', 2)]

def song_arrangement():
    arr = []
    for name, n in SONG:
        for i in range(n): arr.append((name, i))
    return arr

def bar_events(section, i, chord, ev):
    """Append (time_in_bar, kind, params) for one bar."""
    S = STEP
    def add(step, kind, **p): ev.append((step * S, kind, p))
    nxt = CHORDS[(CHORDS.index(chord) + 1) % 4]
    if section == 'intro':
        for k, m in enumerate(ARP[chord]):
            add(k * 2, 'koto', midi=m, vel=0.35 + 0.05 * (k % 2), dur=1.2, lpf=True)
        if i == 0: add(0, 'taiko', vel=0.9); add(10, 'taiko', vel=0.5)
        if i == 1:
            add(0, 'taiko', vel=0.9); add(6, 'taiko', vel=0.6); add(8, 'taiko', vel=0.8)
            for s in (12, 13, 14, 15): add(s, 'taiko', vel=0.45 + 0.1 * (s - 12))
            add(0, 'riser', dur=BAR, vel=0.6)
        add(0, 'pad', notes=PAD[chord], dur=BAR, vel=0.6, bright=1300)
        return
    if section == 'cards':
        for k, m in enumerate(ARP[chord]):
            add(k * 2, 'koto', midi=m, vel=0.32, dur=1.0)
        add(0, 'kick', vel=0.85); add(8, 'kick', vel=0.7); add(10, 'kick', vel=0.5)
        add(4, 'clap', vel=0.55); add(12, 'clap', vel=0.6)
        for s in range(0, 16, 2): add(s, 'hat', vel=0.35 + 0.15 * (s % 4 == 2))
        add(0, 'bass', midi=ROOT[chord], dur=S * 7, vel=0.75)
        add(10, 'bass', midi=ROOT[chord], dur=S * 5, vel=0.6)
        add(0, 'pad', notes=PAD[chord], dur=BAR, vel=0.7, bright=1800)
        return
    if section == 'endcard':
        if i == 0:
            add(0, 'taiko', vel=0.85); add(0, 'crash', vel=0.5)
            add(0, 'bass', midi=28, dur=BAR * 1.6, vel=0.7)
            add(0, 'pad', notes=PAD['Em'], dur=BAR * 2.2, vel=0.75, bright=1700)
            for k, m in enumerate([64, 71, 76, 79, 83]):
                add(k * 2, 'koto', midi=m, vel=0.5 - 0.05 * k, dur=2.4)
            add(10, 'flute', midi=88, dur=BAR * 0.8, vel=0.35)
        return
    if section == 'outro':
        if i == 0:
            add(0, 'impact', vel=1.0); add(0, 'crash', vel=0.9); add(0, 'taiko', vel=1.0)
            add(0, 'bass', midi=28, dur=BAR * 1.5, vel=0.9)
            add(0, 'koto', midi=76, vel=0.8, dur=2.5); add(0, 'koto', midi=64, vel=0.6, dur=2.5)
            add(0, 'pad', notes=PAD['Em'], dur=BAR * 1.8, vel=0.8, bright=2000)
            add(0, 'flute', midi=83, dur=BAR * 0.9, vel=0.5)
        return
    # ---------------- drums
    if section == 'verseA':
        add(0, 'kick'); add(8, 'kick', vel=0.85)
        if i % 2 == 1: add(10, 'kick', vel=0.6)
        add(4, 'clap', vel=0.8); add(12, 'clap', vel=0.85)
        for s in range(0, 16, 2): add(s, 'hat', vel=0.45 + 0.2 * (s % 4 == 2))
        if i == 7: add(14, 'hat', vel=0.6, open_=True)
    elif section == 'verseB':
        add(0, 'kick'); add(6, 'kick', vel=0.8); add(10, 'kick', vel=0.85)
        add(4, 'clap', vel=0.85); add(12, 'clap', vel=0.9)
        for s in range(16): add(s, 'hat', vel=0.3 + 0.25 * (s % 4 == 2) + 0.1 * (s % 2 == 0))
        if i % 2 == 1:
            for k in range(6): ev.append(((12 + k * 4 / 6) * S, 'hat', {'vel': 0.3 + 0.08 * k}))
    elif section == 'build':
        for s in range(0, 16, 4 if i < 2 else 2): add(s, 'kick', vel=0.8 + 0.05 * i)
        rate = [4, 2, 1, 1][i]
        for s in range(0, 16, rate): add(s, 'snare', vel=0.35 + 0.5 * (i * 16 + s) / 64)
        if i == 3:
            for k in range(8): ev.append(((8 + k) * S, 'snare', {'vel': 0.7 + 0.03 * k}))
        for s in range(0, 16, 2): add(s, 'hat', vel=0.35)
        if i == 0: add(0, 'riser', dur=BAR * 4, vel=0.8)
    elif section in ('drop', 'lie', 'final'):
        add(0, 'kick'); add(7, 'kick', vel=0.8); add(10, 'kick', vel=0.9)
        if section == 'final': add(14, 'kick', vel=0.7)
        add(4, 'clap'); add(12, 'clap')
        add(4, 'snare', vel=0.45); add(12, 'snare', vel=0.5)
        for s in range(16): add(s, 'hat', vel=0.28 + 0.27 * (s % 4 == 2) + 0.12 * (s % 2 == 0))
        if i % 2 == 1:
            for k in range(8): ev.append(((14 + k * 2 / 8) * S, 'hat', {'vel': 0.25 + 0.06 * k}))
        if i % 2 == 0: add(0, 'taiko', vel=0.8)
        if i == 0: add(0, 'crash', vel=0.9); add(0, 'impact', vel=0.8)
        if section == 'lie' and i in (3, 7):
            for s in (12, 13, 14, 15): add(s, 'taiko', vel=0.5 + 0.1 * (s - 12))
    # ---------------- bass
    r = ROOT[chord]
    if section == 'verseA':
        add(0, 'bass', midi=r, dur=S * 7, vel=0.85); add(10, 'bass', midi=r, dur=S * 5, vel=0.7)
    elif section == 'verseB':
        add(0, 'bass', midi=r, dur=S * 2.5, vel=0.85); add(3, 'bass', midi=r, dur=S * 2.5, vel=0.75)
        add(6, 'bass', midi=r, dur=S * 3.5, vel=0.8); add(10, 'bass', midi=r, dur=S * 5, vel=0.75)
    elif section == 'build':
        for s in range(0, 16, 2): add(s, 'bass', midi=r, dur=S * 1.6, vel=0.6 + 0.02 * s)
    elif section in ('drop', 'lie', 'final'):
        add(0, 'bass', midi=r, dur=S * 2.5, vel=0.95); add(3, 'bass', midi=r, dur=S * 2.5, vel=0.85)
        add(6, 'bass', midi=r, dur=S * 1.8, vel=0.85)
        add(8, 'bass', midi=r, dur=S * 3.5, vel=0.9, glide=r + 12 if (i % 4 == 3) else None)
        add(12, 'bass', midi=r, dur=S * 3.5, vel=0.8)
    # ---------------- harmony / melody
    if section == 'verseA':
        add(0, 'pad', notes=PAD[chord], dur=BAR, vel=0.75, bright=1600)
        for k, m in enumerate(ARP[chord]): add(k * 2, 'koto', midi=m, vel=0.42 + 0.08 * (k % 4 == 0), dur=1.1)
    elif section == 'verseB':
        add(0, 'pad', notes=PAD[chord], dur=BAR, vel=0.8, bright=1900)
        for (s, m, l) in HOOK[chord]: add(s, 'koto', midi=m - 12, vel=0.62, dur=1.0)
        if i >= 4:
            for (s, m, l) in HOOK[chord][:3]: add(s, 'flute', midi=m, dur=S * l * 1.1, vel=0.5)
    elif section == 'build':
        add(0, 'pad', notes=PAD[chord], dur=BAR, vel=0.6 + 0.1 * i, bright=1500 + 600 * i)
        for k, m in enumerate(ARP[chord] * 2): add(k, 'koto', midi=m, vel=0.32 + 0.08 * i, dur=0.6)
    elif section in ('drop', 'lie', 'final'):
        add(0, 'pad', notes=PAD[chord], dur=BAR, vel=0.9, bright=2600)
        shift = 12 if section == 'lie' and i % 2 == 1 else 0
        for (s, m, l) in HOOK[chord]:
            add(s, 'koto', midi=m + shift, vel=0.85, dur=1.2)
            add(s, 'lead', midi=m + shift, dur=S * l * 0.9, vel=0.9 if section != 'lie' else 0.75)
            if section == 'final': add(s, 'lead', midi=m + shift - 5 if m - 5 > 60 else m + 7, dur=S * l * 0.9, vel=0.45)
        if section == 'lie':
            add(0, 'glitch', vel=0.5)

MIXG = {'drums': 0.6, 'perc': 0.55, 'bass': 0.30, 'koto': 1.15, 'lead': 1.1, 'pad': 0.45, 'fx': 0.5}
SECTION_VEL = {'verseA': 0.74, 'verseB': 0.86, 'build': 0.9, 'drop': 1.0, 'lie': 0.97, 'final': 1.0, 'cards': 0.78, 'intro': 1.0, 'outro': 1.0}

def render(arrangement, tail=2.5, master_lufs=-14.5, return_stems=False):
    nb = len(arrangement)
    n = int((nb * BAR + tail) * SR)
    stems = {k: np.zeros(n) for k in ('drums', 'bass', 'koto', 'lead', 'pad', 'fx', 'perc')}
    kicks = []
    events = []
    for b, (section, i) in enumerate(arrangement):
        chord = CHORDS[b % 4]
        ev = []
        bar_events(section, i, chord, ev)
        t0 = b * BAR
        for (t, kind, p) in ev:
            events.append((t0 + t, kind, section))
            T = t0 + t
            s0 = int(round(T * SR))
            seed = int(T * 1000)
            if kind == 'kick': x, st = kick(p.get('vel', 1.0), seed), 'drums'; kicks.append(T)
            elif kind == 'clap': x, st = clap(p.get('vel', 1.0), seed), 'drums'
            elif kind == 'snare': x, st = snare(p.get('vel', 1.0), seed), 'drums'
            elif kind == 'hat': x, st = hat(p.get('vel', 1.0), p.get('open_', False), seed), 'perc'
            elif kind == 'taiko': x, st = taiko(p.get('vel', 1.0), seed), 'perc'
            elif kind == 'crash': x, st = crash(p.get('vel', 1.0), seed) * 0.5, 'fx'
            elif kind == 'impact': x, st = impact(p.get('vel', 1.0), seed) * 0.6, 'fx'
            elif kind == 'riser': x, st = riser(p['dur'], p.get('vel', 1.0), seed) * 0.5, 'fx'
            elif kind == 'bass':
                g = p.get('glide'); x = b808(mtof(p['midi']), p['dur'], p.get('vel', 1.0), mtof(g) if g else None); st = 'bass'
            elif kind == 'koto':
                x = koto(p['midi'], p.get('dur', 1.2), p.get('vel', 1.0)); st = 'koto'
                if p.get('lpf'): x = lp(x, 1800)
            elif kind == 'lead': x, st = lead(p['midi'], p['dur'], p.get('vel', 1.0)), 'lead'
            elif kind == 'flute': x, st = flute(p['midi'], p['dur'], p.get('vel', 1.0), seed), 'lead'
            elif kind == 'pad': x, st = pad_chord(p['notes'], p['dur'], p.get('vel', 1.0), p.get('bright', 2000)), 'pad'
            elif kind == 'glitch':
                r = rng_for('glitch', seed); m = int(0.12 * SR)
                blip = np.sign(np.sin(2 * np.pi * 1760 * np.arange(m) / SR)) * np.exp(-np.arange(m) / (0.02 * SR))
                x = np.concatenate([blip * (k % 2) for k in range(3)]) * 0.12 * p.get('vel', 1.0); st = 'fx'
            else: continue
            if st in ('drums', 'bass'): x = x * SECTION_VEL.get(section, 1.0)
            if st == 'bass':  # monophonic 808: choke the previous note with a 6 ms fade
                f = int(0.006 * SR); cut = stems['bass'][s0:s0 + int(2.5 * SR)]
                if len(cut) > f:
                    cut[:f] *= np.linspace(1, 0, f); cut[f:] = 0
            e = min(s0 + len(x), n)
            if e > s0: stems[st][s0:e] += x[: e - s0]
    # sidechain ducking from kicks
    duck = np.ones(n)
    t = np.arange(int(0.35 * SR)) / SR
    curve = 1 - 0.55 * np.exp(-t / 0.11) * np.minimum(t / 0.004, 1)
    for T in kicks:
        s0 = int(T * SR); e = min(s0 + len(curve), n)
        duck[s0:e] = np.minimum(duck[s0:e], curve[: e - s0])
    # stereo mix
    def pan(x, p):
        l = np.cos((p + 1) * np.pi / 4); r = np.sin((p + 1) * np.pi / 4)
        return np.stack([x * l, x * r], 1)
    mix = np.zeros((n, 2))
    G = MIXG
    mix += pan(stems['drums'] * G['drums'], 0.0)
    mix += pan(stems['perc'] * G['perc'], 0.12)
    mix += pan(stems['bass'] * duck ** 0.5 * G['bass'], 0.0)
    kt = stems['koto'] * duck ** 0.4
    mix += pan(kt * G['koto'], -0.22); mix += pan(np.roll(kt, int(0.011 * SR)) * G['koto'] * 0.85, 0.3)
    mix += pan(stems['lead'] * duck ** 0.4 * G['lead'], 0.05)
    padw = stems['pad'] * duck
    mix += np.stack([padw * G['pad'], np.roll(padw, int(0.017 * SR)) * G['pad']], 1)
    mix += pan(stems['fx'] * G['fx'], 0.0)
    # sends
    send = stems['koto'] * 0.35 + stems['lead'] * 0.25 + stems['drums'] * 0.06 + stems['perc'] * 0.12 + stems['fx'] * 0.2
    rev = freeverb(hp(send, 250), room=0.86, damp=0.4)
    mix += rev * 0.32
    # delay on koto (3/16 ping-pong)
    dly = int(STEP * 3 * SR)
    kd = hp(stems['koto'], 400) * 0.18
    dl = np.zeros(n); dr = np.zeros(n)
    dl[dly:] += kd[:-dly]; dr[2 * dly:] += kd[:-2 * dly] * 0.7
    mix += np.stack([dl, dr], 1)
    mix = np.stack([hp(mix[:, 0], 28), hp(mix[:, 1], 28)], 1)
    if return_stems: return mix, stems, duck
    mix = master(mix, master_lufs)
    return mix, events

def lufs(x):
    """ITU-R BS.1770 integrated loudness (K-weighting + gating)."""
    b1, a1 = signal.iirfilter(2, 1681.97, btype='highpass', ftype='butter', fs=SR)  # approximation stage
    sos_shelf = signal.iirfilter(2, 1500, btype='highpass', ftype='butter', fs=SR, output='sos')
    # standard K-weighting coefficients at 48k
    b_pre = [1.53512485958697, -2.69169618940638, 1.19839281085285]; a_pre = [1.0, -1.69065929318241, 0.73248077421585]
    b_rlb = [1.0, -2.0, 1.0]; a_rlb = [1.0, -1.99004745483398, 0.99007225036621]
    y = signal.lfilter(b_rlb, a_rlb, signal.lfilter(b_pre, a_pre, x, axis=0), axis=0)
    blk = int(0.4 * SR); hop = int(0.1 * SR)
    ms = []
    for s in range(0, len(y) - blk, hop):
        ms.append(np.mean(np.sum(y[s:s + blk] ** 2, axis=1)))
    ms = np.array(ms) + 1e-12
    L = -0.691 + 10 * np.log10(ms)
    g = ms[L > -70]
    if not len(g): return -70.0
    rel = -0.691 + 10 * np.log10(g.mean()) - 10
    g2 = ms[(L > -70) & (L > rel)]
    return -0.691 + 10 * np.log10(g2.mean())

def limiter(x, ceiling=0.89, look=0.004, rel=0.08):
    peak = np.max(np.abs(x), axis=1)
    g = np.minimum(1.0, ceiling / np.maximum(peak, 1e-9))
    L = int(look * SR)
    g = minimum_filter1d(g, size=2 * L + 1)
    # release smoothing (one-pole on the inverted gain keeps attack instant)
    a = np.exp(-1 / (rel * SR))
    inv = 1 - g
    sm = signal.lfilter([1 - a], [1, -a], inv)
    g2 = 1 - np.maximum(inv, sm)
    g2 = uniform_filter1d(g2, size=L)
    g2 = np.minimum(g2, g)  # never exceed the instantaneous requirement
    return x * g2[:, None]

def master(mix, target=-14.5):
    mix = mix * 10 ** ((-21.0 - lufs(mix)) / 20)
    mix = np.tanh(mix * 1.35) / 1.35
    for _ in range(3):
        cur = lufs(mix)
        mix = mix * 10 ** ((target - cur) / 20)
        mix = limiter(mix, ceiling=10 ** (-1.9 / 20))
    return mix

def write_wav(path, x, bits=16):
    import wave
    os.makedirs(os.path.dirname(path), exist_ok=True)
    x = np.clip(x, -1, 1)
    if x.ndim == 1: x = x[:, None]
    data = (x * 32767).astype('<i2').tobytes()
    with wave.open(path, 'wb') as w:
        w.setnchannels(x.shape[1]); w.setsampwidth(2); w.setframerate(SR); w.writeframes(data)

def chart_for(arrangement, lie_seed=7):
    notes = []
    r = np.random.default_rng(lie_seed)
    for b, (section, i) in enumerate(arrangement):
        pat = CHART.get(section, ['.' * 16])[i % len(CHART.get(section, ['.' * 16]))]
        for s, ch in enumerate(pat):
            if ch == '.': continue
            t = b * BAR + s * STEP
            typ = {'O': 'one', 'W': 'wave', 'B': 'bait'}[ch]
            lie = bool(section == 'lie' and r.random() < 0.6)
            notes.append({'t': round(t, 6), 'type': typ, 'lie': lie, 'section': section, 'bar': b, 'step': s})
    return notes

def sections_meta(arrangement):
    out = []
    for b, (section, i) in enumerate(arrangement):
        if i == 0: out.append({'name': section, 'bar': b, 't': round(b * BAR, 6)})
    return out

# ---------------------------------------------------------------- SFX
def sfx_all():
    d = os.path.join(OUT, 'sfx'); os.makedirs(d, exist_ok=True)
    def fade(x, ms=6):
        m = int(ms / 1000 * SR); x = x.copy(); x[-m:] *= np.linspace(1, 0, m); return x
    def norm(x, peak=0.8): return x / (np.max(np.abs(x)) + 1e-9) * peak
    def fit(x, n):
        x = np.asarray(x, dtype=np.float64)
        return x[:n] if len(x) >= n else np.concatenate([x, np.zeros(n - len(x))])
    t = lambda dur: np.arange(int(dur * SR)) / SR
    out = {}
    tt = t(0.16)
    out['hit_one'] = norm(np.sin(2 * np.pi * 620 * tt) * np.exp(-tt / 0.03) + 0.5 * np.sin(2 * np.pi * 1240 * tt) * np.exp(-tt / 0.015) + 0.4 * hp(rng_for('h1').standard_normal(len(tt)), 3000) * np.exp(-tt / 0.006), 0.7)
    out['hit_wave'] = norm(np.sin(2 * np.pi * 930 * tt) * np.exp(-tt / 0.028) + 0.5 * np.sin(2 * np.pi * 1860 * tt) * np.exp(-tt / 0.014) + 0.4 * hp(rng_for('h2').standard_normal(len(tt)), 3500) * np.exp(-tt / 0.006), 0.7)
    tt = t(0.5)
    bell = sum(np.sin(2 * np.pi * f * tt + 2.2 * np.sin(2 * np.pi * f * 1.41 * tt) * np.exp(-tt / 0.08)) * a for f, a in ((2637, 1), (3951, 0.5)))
    out['perfect'] = norm(bell * np.exp(-tt / 0.12), 0.45)
    tt = t(0.35)
    out['bait'] = norm(np.sin(2 * np.pi * np.cumsum(620 * np.exp(-tt / 0.08) + 160) / SR) * np.exp(-tt / 0.12) + 0.3 * lp(rng_for('bk').standard_normal(len(tt)), 900) * np.exp(-tt / 0.02), 0.85)
    tt = t(0.5)
    pats = np.zeros(len(tt))
    for o in (0.0, 0.17):
        k = (tt >= o) * np.exp(-np.clip(tt - o, 0, None) / 0.03)
        pats += lp(rng_for('pat', o).standard_normal(len(tt)), 700) * k
    out['pat'] = norm(pats, 0.7)
    tt = t(0.45)
    nz = rng_for('wh').standard_normal(len(tt))
    sw = np.zeros(len(tt)); seg = 1200
    for s0 in range(0, len(tt), seg):
        c = 6000 * (1 - s0 / len(tt)) + 500
        part = nz[max(s0 - 1024, 0): s0 + seg]
        y = bp(part, c * 0.6, min(c * 1.5, 20000))[-min(seg, len(tt) - s0):]
        sw[s0: s0 + len(y)] = y
    out['dodge'] = norm(sw * np.sin(np.pi * tt / tt[-1]) ** 2, 0.5)
    tt = t(0.4)
    out['miss'] = norm(np.sin(2 * np.pi * np.cumsum(240 * np.exp(-tt / 0.2) + 70) / SR) * np.exp(-tt / 0.14) + 0.4 * lp(rng_for('ms').standard_normal(len(tt)), 400) * np.exp(-tt / 0.03), 0.6)
    tt = t(2.2)
    whip = hp(rng_for('whip').standard_normal(len(tt)), 1500) * np.exp(-np.abs(tt - 0.08) / 0.025) * 0.8
    shimmer = sum(np.sin(2 * np.pi * f * tt) for f in (1318, 1661, 1976, 2637)) * np.exp(-np.clip(tt - 0.25, 0, None) / 0.5) * (tt > 0.25) * 0.12
    out['mask_on'] = norm(whip + fit(impact(1.0, 3), len(tt)) * 0.9 + fit(taiko(1.0, 4), len(tt)) * 0.6 + shimmer, 0.95)
    tt = t(1.4)
    rs = reverse_swell(0.6, 1.0, 5)
    pop = np.zeros(len(tt)); pop[: len(rs)] += rs
    s0 = len(rs); k = tt[: len(tt) - s0]
    pop[s0:] += (np.sin(2 * np.pi * 880 * k) + 0.5 * np.sin(2 * np.pi * 1320 * k)) * np.exp(-k / 0.18) * 0.6
    out['mask_off'] = norm(pop, 0.8)
    m = int(0.045 * SR); g = []
    r = rng_for('glitch2')
    for k in range(7):
        f = [1760, 880, 2349, 1175, 3520, 1760, 587][k]
        seg = np.sign(np.sin(2 * np.pi * f * np.arange(m) / SR)) * 0.5 + r.standard_normal(m) * 0.25
        g.append(np.round(seg * 6) / 6 * (0.5 if k % 2 else 1.0))
    out['colors_lie'] = norm(np.concatenate(g), 0.6)
    seqn = []
    for f in (1046.5, 1318.5, 1568.0, 2093.0):
        k = t(0.07); seqn.append(np.sin(2 * np.pi * f * k) * np.exp(-k / 0.05))
    out['combo'] = norm(np.concatenate(seqn), 0.45)
    tt = t(0.06)
    out['click'] = norm(np.sin(2 * np.pi * 1500 * tt) * np.exp(-tt / 0.008), 0.4)
    tt = t(0.5)
    nz = rng_for('uiw').standard_normal(len(tt))
    out['whoosh'] = norm(bp(nz, 500, 4000) * np.sin(np.pi * tt / tt[-1]) ** 3, 0.55)
    tt = t(0.6)
    out['stamp'] = norm(fit(impact(1.0, 9), len(tt)) * 0.8 + fit(clap(1.0, 9), len(tt)) * 0.5, 0.8)
    tt = t(0.08)
    out['tick'] = norm(np.sin(2 * np.pi * 2200 * tt) * np.exp(-tt / 0.012), 0.35)
    tt = t(1.2)
    out['rank_up'] = norm(np.concatenate([np.sin(2 * np.pi * f * t(0.09)) * np.exp(-t(0.09) / 0.07) for f in (784, 988, 1175, 1568, 1976)] + [np.zeros(int(0.3 * SR))]), 0.5)
    for k, x in out.items():
        x = np.asarray(x, dtype=np.float64)
        write_wav(os.path.join(d, k + '.wav'), fade(x))
    print('sfx:', ', '.join(sorted(out)))

if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'song'
    os.makedirs(OUT, exist_ok=True)
    if cmd == 'song':
        arr = song_arrangement()
        mix, events = render(arr, tail=3.0)
        write_wav(os.path.join(OUT, 'song.wav'), mix)
        chart = {'bpm': BPM, 'step': STEP, 'bar': BAR, 'bars': len(arr), 'duration': len(arr) * BAR,
                 'sections': sections_meta(arr), 'notes': chart_for(arr)}
        json.dump(chart, open('build/chart.json', 'w'), indent=0)
        print('song', round(len(mix) / SR, 2), 's; notes', len(chart['notes']), '; LUFS', round(lufs(mix), 2))
    elif cmd == 'loop':
        arr = [('cards', i % 4) for i in range(8)]
        mix, _ = render(arr, tail=0.0)
        n4 = int(4 * BAR * SR)
        loop = mix[n4: 2 * n4]
        write_wav(os.path.join(OUT, 'results-loop.wav'), loop * 0.8)
        print('loop', round(len(loop) / SR, 3))
    elif cmd == 'sfx':
        sfx_all()
    elif cmd == 'arrange':
        spec = json.load(open(sys.argv[2]))
        arr = [tuple(x) for x in spec['bars']]
        mix, events = render(arr, tail=spec.get('tail', 2.0), master_lufs=spec.get('lufs', -14.5))
        dur = spec.get('duration')
        if dur:
            n = int(round(dur * SR)); mix = mix[:n]
            f = int(spec.get('fade', 0.8) * SR); mix[-f:] *= np.linspace(1, 0, f)[:, None] ** 1.5
        write_wav(spec['out'], mix)
        print('arranged', spec['out'], round(len(mix) / SR, 3), 'LUFS', round(lufs(mix), 2))
