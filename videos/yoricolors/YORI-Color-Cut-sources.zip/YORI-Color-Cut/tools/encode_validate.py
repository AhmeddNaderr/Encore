"""Encode captured PNG frames + mix to H.264/AAC MP4 and validate it.
    python3 tools/encode_validate.py build/cap-main out.mp4 1920 1080 2520
"""
import json, subprocess, sys, re, os
cap, out, w, h, nframes = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
crf = os.environ.get('CRF', '17')
cmd = ['ffmpeg', '-v', 'error', '-y', '-framerate', '60', '-i', f'{cap}/f%05d.png', '-i', f'{cap}/mix.wav',
       '-vf', 'scale=out_color_matrix=bt709:out_range=tv,format=yuv420p',
       '-c:v', 'libx264', '-preset', 'slow', '-crf', crf, '-profile:v', 'high', '-level', '4.2', '-g', '120',
       '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-color_range', 'tv',
       '-c:a', 'aac', '-b:a', '256k', '-ar', '48000', '-ac', '2', '-movflags', '+faststart',
       '-frames:v', str(nframes), out]
subprocess.run(cmd, check=True)
pr = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-count_frames', '-show_streams', '-show_format', '-of', 'json', out], capture_output=True, text=True).stdout)
v = [s for s in pr['streams'] if s['codec_type'] == 'video'][0]
a = [s for s in pr['streams'] if s['codec_type'] == 'audio'][0]
dec = subprocess.run(['ffmpeg', '-v', 'error', '-i', out, '-f', 'null', '-'], capture_output=True, text=True)
frz = subprocess.run(['ffmpeg', '-v', 'info', '-i', out, '-vf', 'freezedetect=n=-55dB:d=0.35', '-map', '0:v', '-f', 'null', '-'], capture_output=True, text=True).stderr
freezes = re.findall(r'freeze_start: ([\d.]+).*?freeze_duration: ([\d.]+)', frz, re.S)
ebu = subprocess.run(['ffmpeg', '-v', 'info', '-i', out, '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True).stderr
I = re.findall(r'I:\s+(-?[\d.]+) LUFS', ebu); TP = re.findall(r'Peak:\s+(-?[\d.]+) dBFS', ebu)
with open(out, 'rb') as f: head = f.read(64)
report = {
  'file': out, 'bytes': os.path.getsize(out),
  'video': {'codec': v['codec_name'], 'profile': v.get('profile'), 'w': v['width'], 'h': v['height'], 'fps': v['r_frame_rate'], 'pix_fmt': v['pix_fmt'],
            'frames': int(v.get('nb_read_frames', 0)), 'duration': float(v.get('duration', 0)), 'color': [v.get('color_space'), v.get('color_primaries'), v.get('color_transfer'), v.get('color_range')]},
  'audio': {'codec': a['codec_name'], 'sr': a['sample_rate'], 'ch': a['channels'], 'duration': float(a.get('duration', 0)), 'bitrate': a.get('bit_rate')},
  'container_duration': float(pr['format']['duration']), 'faststart_moov_first': head.find(b'moov') != -1 or b'moov' in open(out, 'rb').read(4096),
  'full_decode_errors': dec.stderr.strip()[:300], 'freezes(>0.35s)': freezes,
  'loudness_I_LUFS': float(I[-1]) if I else None, 'true_peak_dBFS': float(TP[-1]) if TP else None,
  'expect': {'w': w, 'h': h, 'frames': nframes},
}
report['pass'] = (report['video']['w'] == w and report['video']['h'] == h and report['video']['frames'] == nframes and not report['full_decode_errors'])
print(json.dumps(report, indent=1))
json.dump(report, open(out + '.validation.json', 'w'), indent=1)
