# Extract exact source frames (60fps index) from the official YORI videos.
import subprocess, json, sys, os
WL = 'raw/x-wl-video-1950x1080.mp4'
GTD = 'raw/x-gtd-video-1956x1080.mp4'
POSES = {
  WL: {'smirk': [0, 5, 10], 'headpat': [40, 55, 70], 'vest': [95], 'pout': [115, 125, 135],
       'sideeye': [155], 'one': [170, 180, 190, 195], 'wave': [210, 215, 220],
       'bluesmirk': [255, 260, 285], 'bluereach': [270, 275], 'cap': [315, 320, 325],
       'iroburst': [365, 375], 'logoend': [410]},
  GTD: {'maskhold': [0, 5], 'maskraise': [10, 15], 'maskon': [20, 45, 75, 85], 'palm': [105, 110, 115],
        'peace': [145, 160, 175, 185], 'shh': [215, 230, 240], 'shhnose': [255, 260],
        'maskdown': [300], 'tongue': [315, 320, 325]},
}
manifest = []
for video, poses in POSES.items():
    for name, frames in poses.items():
        for n in frames:
            out = f'src/{name}-{n:03d}.png'
            if not os.path.exists(out):
                subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', video, '-vf', f'select=eq(n\\,{n})', '-frames:v', '1', out], check=True)
            manifest.append({'file': out, 'video': os.path.basename(video), 'frame60': n, 'time_s': round(n/60, 3), 'pose': name})
json.dump(manifest, open('src/manifest.json', 'w'), indent=1)
print(len(manifest), 'frames')
