import json, sys, time, urllib.request, urllib.parse
UA = {"User-Agent": "EncoreResearch/1.0"}
def get(url):
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode() or "{}")
handle = sys.argv[1]
results, cursor, pages = [], None, 0
while pages < 30:
    url = f"https://api.fxtwitter.com/2/profile/{handle}/media" + (f"?cursor={urllib.parse.quote(cursor)}" if cursor else "")
    code, data = get(url)
    got = data.get("results", [])
    print("page", pages, code, len(got), file=sys.stderr)
    if not got: break
    new = [g for g in got if g["id"] not in {r["id"] for r in results}]
    results += new
    cursor = (data.get("cursor") or {}).get("bottom")
    pages += 1
    if not cursor or not new: break
    time.sleep(1.0)
json.dump(results, open(f"fx-{handle}-media.json", "w"), indent=1, ensure_ascii=False)
print(len(results), "posts with media", file=sys.stderr)
code, prof = get(f"https://api.fxtwitter.com/2/profile/{handle}")
json.dump(prof, open(f"fx-{handle}-profile.json", "w"), indent=1, ensure_ascii=False)
print("profile", code, file=sys.stderr)
