"""Background keyer for YORI's flat-colour video frames.

YORI art always meets its background through a thick black outline, so the
silhouette edge is unmixed as  P = a*K + (1-a)*B  (K = outline ink, B = local
background from normalised convolution of confirmed background pixels).
Background is grown only from border seeds that match the dominant border
colour, so hair cut by the frame edge is never seeded. Enclosed pockets are
removed only when they are flat and match the local background closely.
"""
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

INK = np.array([18.0, 14.0, 18.0])
N4 = [[0, 1, 0], [1, 1, 1], [0, 1, 0]]

def _smooth_field(img, mask, sigma, scale=4):
    h, w = mask.shape
    small = img[::scale, ::scale]
    m = mask[::scale, ::scale].astype(np.float32)
    num = np.stack([ndi.gaussian_filter(small[..., c] * m, sigma / scale) for c in range(3)], -1)
    den = ndi.gaussian_filter(m, sigma / scale)[..., None]
    glob = img[mask].mean(0) if mask.any() else img.reshape(-1, 3).mean(0)
    field = np.where(den > 1e-4, num / np.maximum(den, 1e-6), glob)
    return np.stack([np.array(Image.fromarray(field[..., c].astype(np.float32)).resize((w, h), Image.BILINEAR)) for c in range(3)], -1)

def border_ref(img, sides='ltr', q=10):
    parts = []
    if 'l' in sides: parts.append(img[:, :4].reshape(-1, 3))
    if 'r' in sides: parts.append(img[:, -4:].reshape(-1, 3))
    if 't' in sides: parts.append(img[:4].reshape(-1, 3))
    if 'b' in sides: parts.append(img[-4:].reshape(-1, 3))
    b = np.concatenate(parts)
    k = (b // q).astype(np.int64)
    code = k[:, 0] * 1_000_000 + k[:, 1] * 1000 + k[:, 2]
    vals, counts = np.unique(code, return_counts=True)
    top = vals[np.argmax(counts)]
    sel = code == top
    return b[sel].mean(0)

def repair_edges(img_u8, dark=12):
    """Replace encoder letterbox lines: the two outermost rows (always) and any near-black columns."""
    im = img_u8.copy()
    h, w = im.shape[:2]
    im[0] = im[2]; im[1] = im[2]
    im[h - 1] = im[h - 3]; im[h - 2] = im[h - 3]
    for j in range(3):
        if im[:, j].mean() < dark: im[:, j] = im[:, 3]
        if im[:, w - 1 - j].mean() < dark: im[:, w - 1 - j] = im[:, w - 4]
    return im

def key(img_u8, thresh=40.0, seed_tol=20.0, sigma=48.0, sides='ltr', min_part=2500,
        pocket_tol=14.0, pocket_std=9.0, pocket_min=250, iters=4, hue_bg=None, grow=0, grow_k=2.5):
    img = repair_edges(img_u8).astype(np.float32)
    h, w, _ = img.shape
    border = np.zeros((h, w), bool)
    if 'l' in sides: border[:, :3] = True
    if 'r' in sides: border[:, -3:] = True
    if 't' in sides: border[:3, :] = True
    if 'b' in sides: border[-3:, :] = True
    ref = border_ref(img, sides)
    seed = border & (np.linalg.norm(img - ref, axis=2) < seed_tol)
    if hue_bg is not None:
        seed |= border & hue_bg(img)
    bgmask = seed.copy()
    for _ in range(iters):
        B = _smooth_field(img, bgmask, sigma)
        d = np.linalg.norm(img - B, axis=2)
        cand = d < thresh
        if hue_bg is not None:
            cand |= hue_bg(img)
        lab, n = ndi.label(cand, structure=N4)
        ids = np.unique(lab[seed & cand]); ids = ids[ids > 0]
        bgmask = np.isin(lab, ids)
    B = _smooth_field(img, bgmask, sigma)
    d = np.linalg.norm(img - B, axis=2)
    # enclosed flat pockets that match the local background (gap between finger and face, etc.)
    if pocket_tol > 0:
        cand = (d < pocket_tol) & ~bgmask
        lab, n = ndi.label(cand, structure=N4)
        if n:
            idx = np.arange(1, n + 1)
            area = ndi.sum(np.ones_like(d), lab, idx)
            sd = np.sqrt(np.maximum(ndi.mean(d * d, lab, idx) - ndi.mean(d, lab, idx) ** 2, 0))
            good = (area >= pocket_min) & (sd < pocket_std)
            keep = np.zeros(n + 1, bool); keep[1:] = good
            pockets = keep[lab]
            pockets = ndi.binary_dilation(pockets, iterations=1) & (d < thresh)
            bgmask |= pockets
    if grow:
        lum = img.mean(2)
        for _ in range(grow):
            ring = ndi.binary_dilation(bgmask, structure=N4) & ~bgmask
            bgmask |= ring & (d < thresh * grow_k) & (lum > 70)
    fg = ~bgmask
    lab, n = ndi.label(fg)
    if n > 1:
        sizes = ndi.sum(np.ones_like(d), lab, index=np.arange(1, n + 1))
        keep = np.zeros(n + 1, bool)
        keep[1:] = sizes >= max(min_part, sizes.max() * 0.004)
        fg = keep[lab]
    band = ndi.binary_dilation(fg, iterations=2) & ~ndi.binary_erosion(fg, iterations=2)
    BK = B - INK
    a_un = np.clip(np.sum((B - img) * BK, axis=2) / np.maximum(np.sum(BK * BK, axis=2), 1.0), 0, 1)
    alpha = np.where(band, a_un, fg.astype(np.float32))
    a3 = np.maximum(alpha, 1e-3)[..., None]
    col = np.where(band[..., None], np.clip((img - (1 - alpha[..., None]) * B) / a3, 0, 255), img)
    out = np.dstack([col, alpha * 255]).round().clip(0, 255).astype(np.uint8)
    return out, B, bgmask

def trim(rgba, pad=4):
    a = rgba[..., 3]
    ys, xs = np.where(a > 8)
    y0, y1 = max(ys.min() - pad, 0), min(ys.max() + pad + 1, rgba.shape[0])
    x0, x1 = max(xs.min() - pad, 0), min(xs.max() + pad + 1, rgba.shape[1])
    return rgba[y0:y1, x0:x1], (int(x0), int(y0), int(x1), int(y1))

def preview(rgba, col=(40, 220, 90), half=True):
    h, w = rgba.shape[:2]
    bg = np.zeros((h, w, 3), np.float32); bg[...] = col
    a = rgba[..., 3:4] / 255.0
    comp = (rgba[..., :3] * a + bg * (1 - a)).astype(np.uint8)
    im = Image.fromarray(comp)
    return im.resize((w // 2, h // 2), Image.LANCZOS) if half else im
