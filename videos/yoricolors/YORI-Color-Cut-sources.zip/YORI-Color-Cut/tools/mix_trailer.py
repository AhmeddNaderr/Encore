"""Trailer audio: re-render the score for the trailer's bar sequence, then place
every gameplay sound from the captured run at its mapped trailer time, plus UI
sounds for the card scenes. Writes <capdir>/mix.wav and <capdir>/sfx-events.json.

    python3 tools/mix_trailer.py trailer/main.json build/cap-main
"""
import json, sys, os, wave
import numpy as np
sys.path.insert(0, os.path.dirname(__file__))
import compose as C

spec = json.load(open(sys.argv[1]))
cap = sys.argv[2]
run = json.load(open(os.path.join(cap, 'run.json')))
shots = json.load(open(os.path.join(cap, 'shots.json')))
BAR = C.BAR
SR = C.SR

def load_wav(p):
    w = wave.open(p); n = w.getnframes(); ch = w.getnchannels()
    x = np.frombuffer(w.readframes(n), '<i2').astype(np.float64) / 32768
    return x.reshape(-1, ch).mean(1)
SFX = {f[:-4]: load_wav(os.path.join('build/audio/sfx', f)) for f in os.listdir('build/audio/sfx')}

arr = [tuple(x) for x in spec['music']]
music, stems, duck = C.render(arr, tail=2.5, return_stems=True)
music = music * 10 ** ((-21.0 - C.lufs(music)) / 20)   # same pre-gain the master uses
n = int(round(spec['duration'] * SR))
if len(music) < n: music = np.concatenate([music, np.zeros((n - len(music), 2))])
music = music[:n].copy()

placed = []
def place(name, t, gain, pan=0.0):
    if name not in SFX or t < 0 or t >= spec['duration']: return
    x = SFX[name] * gain
    s0 = int(round(t * SR)); e = min(n, s0 + len(x))
    l = np.cos((pan + 1) * np.pi / 4) * 1.414; r = np.sin((pan + 1) * np.pi / 4) * 1.414
    music[s0:e, 0] += x[: e - s0] * l * 0.5; music[s0:e, 1] += x[: e - s0] * r * 0.5
    placed.append({'t': round(t, 4), 'sfx': name, 'gain': gain})

for s in shots:
    if s['type'] == 'game':
        src0 = s['srcBar'] * BAR; src1 = src0 + (s['t1'] - s['t0'])
        for e in run['events']:
            if not (src0 <= e['t'] < src1): continue
            tt = s['t0'] + (e['t'] - src0)
            ty = e['type']
            if ty == 'hit':
                place('hit_one' if e['lane'] == 'one' else 'hit_wave', tt, 0.34, -0.15 if e['lane'] == 'one' else 0.15)
                if e['judge'] == 'perfect': place('perfect', tt, 0.2)
            elif ty in ('miss', 'wrong'): place('miss', tt, 0.5)
            elif ty == 'baited': place('bait', tt, 0.7); place('pat', tt + 0.12, 0.55)
            elif ty == 'dodge': place('dodge', tt, 0.35)
            elif ty == 'mask_on': place('mask_on', tt, 0.8)
            elif ty == 'mask_off': place('mask_off', tt, 0.55)
            elif ty == 'lie_on': place('colors_lie', tt + 0.6, 0.55)
            elif ty == 'milestone': place('combo', tt, 0.4)
        if s.get('caption'): place('click', s['t0'] + s['caption']['at'], 0.35)
    else:
        t0 = s['t0']
        if s.get('overlay') == 'palm': place('whoosh', t0, 0.6); place('stamp', t0 + 0.02, 0.45)
        if s.get('overlay') == 'burst': place('mask_on', t0, 0.45)
        if s['card'] == 'leaderboard':
            for i in range(11): place('tick', t0 + 0.05 * i + 0.08, 0.5)
            place('rank_up', t0 + 2.15, 0.6)
            for kk in range(4): place('tick', t0 + 0.9 + kk * 0.32, 0.45)
            if s.get('caption'): place('click', t0 + s['caption']['at'], 0.35)
        elif s['card'] == 'result':
            place('whoosh', t0, 0.5)
            for i in range(12): place('tick', t0 + 0.04 + 0.055 * i, 0.32)
            place('stamp', t0 + 0.3, 0.75)
        elif s['card'] == 'post':
            place('whoosh', t0 + 0.22, 0.55); place('click', t0 + 0.62, 0.4)
mix = C.master(music, -14.5)
f = int(0.85 * SR)
mix[-f:] *= np.linspace(1, 0, f)[:, None] ** 1.6
mix[-64:] = 0
C.write_wav(os.path.join(cap, 'mix.wav'), mix)
json.dump(placed, open(os.path.join(cap, 'sfx-events.json'), 'w'), indent=0)
print('mix', os.path.join(cap, 'mix.wav'), round(len(mix) / SR, 3), 's; LUFS', round(C.lufs(mix), 2), '; peak dBFS', round(20 * np.log10(np.abs(mix).max()), 2), '; sfx', len(placed))
