"""Adjacent-frame motion scan of an MP4: counts identical adjacent frames (at 320x180)
and reports the longest run of near-static frames per section."""
import subprocess, sys, json
import numpy as np
path, w, h = sys.argv[1], 320, 180
if len(sys.argv) > 3: w, h = int(sys.argv[2]), int(sys.argv[3])
p = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', path, '-vf', f'scale={w}:{h}', '-f', 'rawvideo', '-pix_fmt', 'gray', '-'], stdout=subprocess.PIPE)
prev = None; diffs = []
while True:
    b = p.stdout.read(w * h)
    if len(b) < w * h: break
    f = np.frombuffer(b, np.uint8).astype(np.int16)
    if prev is not None: diffs.append(float(np.abs(f - prev).mean()))
    prev = f
d = np.array(diffs)
ident = int((d == 0).sum())
static = d < 0.15
runs, cur, start = [], 0, 0
for i, s in enumerate(static):
    if s:
        if cur == 0: start = i
        cur += 1
    else:
        if cur: runs.append((start, cur)); cur = 0
if cur: runs.append((start, cur))
runs.sort(key=lambda r: -r[1])
out = {'frames': len(d) + 1, 'identical_adjacent_pairs': ident, 'mean_abs_diff': round(float(d.mean()), 3),
       'longest_near_static_runs(frames,start_s)': [(r[1], round(r[0] / 60, 2)) for r in runs[:5]]}
print(json.dumps(out, indent=1))
