// Live-mode smoke test: real keyboard input path, WebAudio clock, demo mode, results screen.
const { chromium } = require('playwright');
const path = require('path');
(async () => {
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const page = await browser.newPage({ viewport: { width: Number(process.env.VW || 1280), height: Number(process.env.VH || 720) } });
  const errs = [];
  page.on('pageerror', (e) => errs.push('pageerror: ' + e));
  page.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  await page.goto('file://' + path.resolve('dist/yori-color-cut.html'));
  await page.waitForFunction(() => window.__ready === true, null, { timeout: 60000 });
  await page.waitForTimeout(600);
  await page.screenshot({ path: 'snaps/live-title-' + (process.env.VW || 1280) + '.png' });
  const checks = [];
  checks.push(['title mode', await page.evaluate(() => App.mode) === 'title']);
  await page.keyboard.press('Space');
  await page.waitForTimeout(2500);
  const st = await page.evaluate(() => ({ mode: App.mode, ac: App.ac && App.ac.state, t: App.songTime() }));
  checks.push(['play mode after Space', st.mode === 'play']);
  checks.push(['audio context running', st.ac === 'running']);
  checks.push(['song clock advancing (>1.5s)', st.t > 1.5]);
  // press keys exactly when the first notes are due, using the page's own clock
  const res = await page.evaluate(async () => {
    const notes = App.chart.notes.slice(0, 6);
    const out = [];
    for (const n of notes) {
      while (App.songTime() < n.t - 0.004) await new Promise((r) => setTimeout(r, 1));
      const code = n.type === 'one' ? 'ArrowLeft' : 'ArrowRight';
      window.dispatchEvent(new KeyboardEvent('keydown', { code, key: code }));
      await new Promise((r) => setTimeout(r, 30));
      out.push(n.type);
    }
    await new Promise((r) => setTimeout(r, 400));
    return { pressed: out, hits: App.E.events.filter((e) => e.type === 'hit').map((e) => e.judge + ':' + e.dt.toFixed(3)), stats: App.E.stats, score: App.E.score };
  });
  checks.push(['6 timed key presses -> 6 hits', res.hits.length === 6]);
  await page.screenshot({ path: 'snaps/live-play.png' });
  // demo mode through to results (fast-forward by shifting the song start)
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  await page.keyboard.press('KeyP');
  await page.waitForTimeout(1500);
  const demo = await page.evaluate(() => ({ mode: App.mode, demo: App.demo }));
  checks.push(['demo mode starts', demo.mode === 'play' && demo.demo === true]);
  await page.evaluate(() => { App.songStart -= 60; });
  await page.waitForTimeout(1200);
  await page.evaluate(() => { App.songStart -= 30; });
  await page.waitForTimeout(2500);
  const fin = await page.evaluate(() => ({ mode: App.mode, result: App.result && { score: App.result.score, rank: App.result.rank, cut: App.result.cut.length } }));
  checks.push(['results screen reached', fin.mode === 'results']);
  await page.screenshot({ path: 'snaps/live-results-' + (process.env.VW || 1280) + '.png' });
  await page.keyboard.press('KeyL'); await page.waitForTimeout(800);
  checks.push(['leaderboard toggles', (await page.evaluate(() => App.mode)) === 'board']);
  await page.screenshot({ path: 'snaps/live-board-' + (process.env.VW || 1280) + '.png' });
  await page.keyboard.press('Space'); await page.waitForTimeout(1000);
  checks.push(['play again restarts with zero score', await page.evaluate(() => App.mode === 'play' && App.E.score === 0)]);
  console.log(JSON.stringify({ st, res, fin }, null, 1));
  for (const [k, ok] of checks) console.log((ok ? 'PASS ' : 'FAIL ') + k);
  console.log('errors:', errs.length ? errs.join('\n') : 'none');
  await browser.close();
})();
