// Render stills from the built game via its deterministic capture API.
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const [w, h] = (process.argv[2] || '1920x1080').split('x').map(Number);
  const times = (process.argv[3] || '5').split(',');
  const prefix = process.argv[4] || 'snap';
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
  const errs = [];
  page.on('pageerror', (e) => errs.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') errs.push(m.text()); });
  await page.goto('file://' + path.resolve('dist/yori-color-cut.html') + '?capture=1');
  await page.waitForFunction(() => window.__ready === true, null, { timeout: 60000 });
  await page.evaluate(([w, h]) => window.YORI_CAPTURE.init(w, h), [w, h]);
  const vb = await page.evaluate(() => { const c = App.chart; const vb = c.notes.map((n, i) => [i, n]).filter(([i, n]) => n.section === 'verseB' && n.type === 'bait'); return vb.map((x) => x[0]); });
  await page.evaluate((bait) => window.YORI_CAPTURE.setupRun({ seed: 11, spread: 0.026, baitNotes: [bait[0]], missNotes: [] }), vb);
  for (const tt of times) {
    let file;
    if (tt.startsWith('card:')) {
      const [, name, lt] = tt.split(':');
      await page.evaluate(([n, lt]) => {
        const C = window.YORI_CAPTURE;
        if (!window.__res) { const keep = App.E; C.setupRun({ seed: 11, spread: 0.026, baitNotes: [48] }); C.advance(App.chart.duration + 2); window.__res = C.result(); App.E = keep; }
        const cap = n === 'leaderboard' ? { text: 'Anyone can like a post.\nCan you read the move?', t0: 1.0, t1: 3.7, scale: 0.72, tNow: Number(lt) } : null;
        return C.renderCard(n, Number(lt), { result: window.__res, caption: cap });
      }, [name, lt]);
      file = `snaps/${prefix}-${name}-${lt}.png`;
    } else {
      await page.evaluate((t) => window.YORI_CAPTURE.renderGame(t), Number(tt));
      file = `snaps/${prefix}-${tt}.png`;
    }
    const buf = await page.locator('#c').screenshot();
    fs.writeFileSync(file, buf);
    console.log('saved', file);
  }
  if (errs.length) console.log('ERRORS:', errs.slice(0, 10).join('\n'));
  await browser.close();
})();
