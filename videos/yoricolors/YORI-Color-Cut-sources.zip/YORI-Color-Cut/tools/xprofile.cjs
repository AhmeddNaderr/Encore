// Load the public X profile the user linked, as a logged-out visitor, and keep
// the JSON responses the page itself requests (profile + visible posts).
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const out = process.argv[2];
const url = process.argv[3] || 'https://x.com/yoricolors';
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 2200 }, locale: 'en-US' });
  const page = await ctx.newPage();
  let n = 0;
  page.on('response', async (res) => {
    const u = res.url();
    if (/graphql|api\.x\.com|api\.twitter\.com/.test(u)) {
      try {
        const body = await res.text();
        const name = (u.split('/graphql/')[1] || 'api').split('?')[0].replace(/[^a-zA-Z0-9_-]/g, '_');
        fs.writeFileSync(path.join(out, `net-${String(n++).padStart(2, '0')}-${name}.json`), body);
        console.log('saved', res.status(), name, body.length);
      } catch (e) {}
    }
  });
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(9000);
  for (let i = 0; i < 6; i++) { await page.mouse.wheel(0, 1800); await page.waitForTimeout(1800); }
  await page.screenshot({ path: path.join(out, 'x-profile.png'), fullPage: false });
  fs.writeFileSync(path.join(out, 'x-profile.html'), await page.content());
  fs.writeFileSync(path.join(out, 'x-profile.txt'), await page.innerText('body').catch(() => ''));
  await browser.close();
})();
