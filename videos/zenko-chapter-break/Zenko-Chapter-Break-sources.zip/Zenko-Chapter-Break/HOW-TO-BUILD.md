# Building ZENKO: CHAPTER BREAK from source

Code and docs only; Zenko's art is not redistributed. `art_sources.csv` lists every file's original URL and SHA-256.

1. Download each file in `art_sources.csv` into `raw/` (Zenko) and `encore/` (Encore) using the listed filenames.
2. `python tools/prep_assets.py .` makes the cutouts, logo alphas and card-back texture in `assets/`.
3. Fonts: `npm i @fontsource/dela-gothic-one` inside `npmfonts/` (OFL). Inter, Inter Display and JetBrains Mono (OFL) must be installed system-wide.
4. The game script lives in `game/chapter.js` (panels, enemies, gestures, camera, timeline). Shared drawing helpers come from the PANEL CUT renderer; `python tools/build2.py .` assembles `game/render2.js`. The prebuilt `render2.js` is included.
5. Render (silent): `PAGE=render2.html node tools/capture.mjs video main out.mp4` and `PAGE=render2.html node tools/capture.mjs video vertical out-15s.mp4` (Playwright + Chromium).
6. `bash tools/validate.sh out.mp4 sheet.png` checks frames, decode, freezes and faststart.
