// AUTO-BUILT by tools/build2.py — shared helpers from render.js + chapter.js
// ZENKO: PANEL CUT — trailer renderer (deterministic, frame-addressable).
// Every character pixel comes from Zenko's official art files.
const Q = new URLSearchParams(location.search);
const LAYOUT = Q.get('layout') || 'main';
const VERT = LAYOUT === 'vertical';
const W = VERT ? 1080 : 1920, H = VERT ? 1920 : 1080;
const FPS = 60;
const cv = document.getElementById('c');
cv.width = W; cv.height = H;
const ctx = cv.getContext('2d');

// ---------------- palette ----------------
const C = {
  ink: '#0b090c', paper: '#f3f0ea', paper2: '#e9e5dc', coral: '#F4575E', card: '#E46762', purple: '#E46EFF',
  haze: '#403748', haze2: '#665A72', navy: '#344771', sakura: '#EF9BCC', gold: '#F2B43C', fur: '#383240',
  encRed: '#E24A51', encGrey: '#a1a0a2', encMono: '#6b6b6d',
};
const FONT = { dela: '"Dela Gothic One"', disp: '"Inter Display"', ui: 'Inter', mono: '"JetBrains Mono"' };

// ---------------- math ----------------
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const inv = (a, b, v) => clamp((v - a) / (b - a));
const eOut = (t) => 1 - Math.pow(1 - clamp(t), 3);
const eIn = (t) => Math.pow(clamp(t), 3);
const eIO = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
const eBack = (t) => { t = clamp(t); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const noise1 = (x) => { const i = Math.floor(x), f = x - i; const u = f * f * (3 - 2 * f); return lerp(hash(i), hash(i + 1), u); };


const IMG = {};
let HT_CANVAS = null;
function loadImg(key, src) {
  return new Promise((res, rej) => { const im = new Image(); im.onload = () => { IMG[key] = im; res(); }; im.onerror = () => rej(new Error(src)); im.src = src; });
}

function sprite(img, rect, maxSide = 900, gray = false) {
  const [x0, y0, x1, y1] = rect; const w = x1 - x0, h = y1 - y0;
  const s = Math.min(1, maxSide / Math.max(w, h));
  const c = document.createElement('canvas'); c.width = Math.round(w * s); c.height = Math.round(h * s);
  const g = c.getContext('2d'); g.imageSmoothingQuality = 'high';
  if (gray) g.filter = 'grayscale(1) contrast(1.05)';
  g.drawImage(img, x0, y0, w, h, 0, 0, c.width, c.height);
  return c;
}

function makeNeroHead() {
  // Nero's official head, softly faded below the jaw so it can float in the rift
  const im = IMG.nero; const sx = 400, sy = 300, sw = 860, sh = 860;
  const c = document.createElement('canvas'); c.width = 520; c.height = 520; const g = c.getContext('2d');
  g.drawImage(im, sx, sy, sw, sh, 0, 0, 520, 520);
  g.globalCompositeOperation = 'destination-in';
  const gr = g.createLinearGradient(0, 330, 0, 470);
  gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 520, 520);
  return c;
}

function makeHalftone() {
  const c = document.createElement('canvas'); c.width = 24; c.height = 24; const g = c.getContext('2d');
  g.fillStyle = '#000'; g.beginPath(); g.arc(6, 6, 2.6, 0, 7); g.arc(18, 18, 2.6, 0, 7); g.fill();
  return c;
}

function makeGrain() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 256; const g = c.getContext('2d');
  const d = g.createImageData(256, 256);
  for (let i = 0; i < d.data.length; i += 4) { const v = hash(i * 0.37) * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 22; }
  g.putImageData(d, 0, 0); return c;
}

function bboxOf(p) { let a = 1e9, b = 1e9, c = -1e9, d = -1e9; for (const [x, y] of p) { a = Math.min(a, x); b = Math.min(b, y); c = Math.max(c, x); d = Math.max(d, y); } return [a, b, c, d]; }

function polyPath(g, p) { g.beginPath(); g.moveTo(p[0][0], p[0][1]); for (let i = 1; i < p.length; i++) g.lineTo(p[i][0], p[i][1]); g.closePath(); }

function cover(g, img, x0, y0, x1, y1, zoom = 1, ox = 0, oy = 0) {
  const w = x1 - x0, h = y1 - y0; const s = Math.max(w / img.width, h / img.height) * zoom;
  const dw = img.width * s, dh = img.height * s;
  g.drawImage(img, x0 + (w - dw) / 2 + ox, y0 + (h - dh) / 2 + oy, dw, dh);
}

function rrect(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }

function text(g, s, x, y, o = {}) {
  g.save();
  g.font = `${o.weight || ''} ${o.size || 32}px ${o.font || FONT.ui}`.trim();
  g.textAlign = o.align || 'left'; g.textBaseline = o.base || 'alphabetic';
  if (o.ls != null) g.letterSpacing = `${o.ls}px`;
  g.globalAlpha *= o.alpha ?? 1;
  if (o.stroke) { g.lineJoin = 'round'; g.lineWidth = o.stroke; g.strokeStyle = o.strokeColor || C.ink; g.strokeText(s, x, y); }
  g.fillStyle = o.color || '#fff'; g.fillText(s, x, y);
  g.restore();
}

function wrap(g, s, maxW, o) {
  const words = s.split(' '); const out = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (measure(g, t, o) > maxW && cur) { out.push(cur); cur = w; } else cur = t; }
  if (cur) out.push(cur); return out;
}

function measure(g, s, o) { g.save(); g.font = `${o.weight || ''} ${o.size}px ${o.font}`.trim(); if (o.ls != null) g.letterSpacing = `${o.ls}px`; const w = g.measureText(s).width; g.restore(); return w; }

function sfx(g, s, x, y, size, age, o = {}) {
  if (age < 0 || age > (o.life || 40)) return;
  const pop = age < 7 ? lerp(1.7, 1, eOut(age / 7)) : 1;
  const fade = 1 - inv((o.life || 40) - 10, o.life || 40, age);
  g.save(); g.translate(x, y); g.rotate(o.rot ?? -0.12); g.scale(pop, pop); g.globalAlpha *= fade;
  g.font = `${size}px ${FONT.dela}`; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.lineJoin = 'round';
  g.lineWidth = size * 0.34; g.strokeStyle = o.outer || '#fff'; g.strokeText(s, 0, 0);
  g.lineWidth = size * 0.16; g.strokeStyle = C.ink; g.strokeText(s, 0, 0);
  g.fillStyle = o.color || C.coral; g.fillText(s, 0, 0);
  g.restore();
}

function speedLines(g, cx, cy, r0, r1, n, seed, alpha = 1, color = C.ink, width = 1) {
  g.save(); g.globalAlpha *= alpha; g.fillStyle = color;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + hash(seed + i) * 0.08;
    const rr = r0 + hash(seed + i * 3.1) * (r1 - r0) * 0.35;
    const w = (0.004 + hash(seed + i * 7.7) * 0.012) * width;
    g.beginPath();
    g.moveTo(cx + Math.cos(a - w) * r1, cy + Math.sin(a - w) * r1);
    g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
    g.lineTo(cx + Math.cos(a + w) * r1, cy + Math.sin(a + w) * r1);
    g.fill();
  }
  g.restore();
}

function star4(g, x, y, r, color = '#fff') {
  g.save(); g.fillStyle = color; g.beginPath();
  g.moveTo(x, y - r); g.quadraticCurveTo(x, y, x + r, y); g.quadraticCurveTo(x, y, x, y + r); g.quadraticCurveTo(x, y, x - r, y); g.quadraticCurveTo(x, y, x, y - r);
  g.fill(); g.restore();
}

function cardShape(g, x, y, w, h) {
  const r = w * 0.07; rrect(g, x, y, w, h, r);
}

function drawCardFront(g, x, y, w, h, o) {
  const frame = o.frame === 'purple' ? C.purple : o.frame === 'gold' ? C.gold : C.card;
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = w * 0.12; g.shadowOffsetY = w * 0.04;
  cardShape(g, x, y, w, h); g.fillStyle = frame; g.fill();
  g.shadowColor = 'transparent';
  // diagonal sheen stripes on the frame (as on Zenko's card)
  g.save(); cardShape(g, x, y, w, h); g.clip();
  g.globalAlpha = 0.16; g.fillStyle = '#fff';
  for (let i = -2; i < 6; i++) { g.beginPath(); const sx = x + i * w * 0.28; g.moveTo(sx, y + h); g.lineTo(sx + w * 0.12, y + h); g.lineTo(sx + w * 0.6, y); g.lineTo(sx + w * 0.48, y); g.fill(); }
  g.restore();
  // black inner window with notched top-left corner
  const m = w * 0.075, n = w * 0.17;
  const ix = x + m, iy = y + m, iw = w - m * 2, ih = h - m * 2;
  g.beginPath(); g.moveTo(ix + n, iy); g.lineTo(ix + iw, iy); g.lineTo(ix + iw, iy + ih); g.lineTo(ix, iy + ih); g.lineTo(ix, iy + n); g.closePath();
  g.fillStyle = '#111'; g.fill();
  // art window
  const a = w * 0.035, ax = ix + a, ay = iy + a, aw = iw - a * 2, ahh = ih * 0.76 - a;
  g.save(); g.beginPath(); g.moveTo(ax + n * 0.8, ay); g.lineTo(ax + aw, ay); g.lineTo(ax + aw, ay + ahh); g.lineTo(ax, ay + ahh); g.lineTo(ax, ay + n * 0.8); g.closePath(); g.clip();
  g.fillStyle = o.artBg || frame; g.fillRect(ax, ay, aw, ahh);
  if (o.art) cover(g, o.art, ax, ay, ax + aw, ay + ahh, o.zoom || 1, o.ox || 0, o.oy || 0);
  if (o.stamp) drawHanko(g, ax + aw * 0.78, ay + ahh * 0.8, aw * 0.2, -0.15, 1);
  if (o.holo != null) { // holo sweep
    const hx = lerp(ax - aw, ax + aw * 2, (o.holo % 1));
    const gr = g.createLinearGradient(hx - aw * 0.4, ay, hx + aw * 0.4, ay + ahh);
    gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.28)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(ax, ay, aw, ahh);
  }
  g.restore();
  // text box
  const ty = ay + ahh + a * 0.9;
  if (o.title) { let fs = Math.round(w * 0.105); g.save(); g.font = `${fs}px ${FONT.dela}`; const tw = g.measureText(o.title).width; g.restore(); if (tw > aw - a * 0.8) fs = Math.floor(fs * (aw - a * 0.8) / tw); text(g, o.title, ax + a * 0.4, ty + h * 0.07, { font: FONT.dela, size: fs, color: '#fff' }); }
  if (o.sub) text(g, o.sub, ax + a * 0.4, ty + h * 0.115, { font: FONT.mono, size: Math.max(9, Math.round(w * 0.042)), color: frame, ls: 1 });
  if (o.lines === true) { g.fillStyle = '#2a2a2a'; for (let i = 0; i < 2; i++) g.fillRect(ax + aw * 0.42, ty + h * (0.045 + i * 0.035), aw * (0.5 - i * 0.12), h * 0.012); }
  g.restore();
}

function drawCardBack(g, x, y, w, h) {
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = w * 0.12; g.shadowOffsetY = w * 0.04;
  cardShape(g, x, y, w, h); g.fillStyle = '#151515'; g.fill(); g.shadowColor = 'transparent';
  g.save(); cardShape(g, x + w * 0.05, y + w * 0.05, w * 0.9, h - w * 0.1); g.clip();
  cover(g, IMG.cardback, x, y, x + w, y + h, 1.05);
  g.restore();
  const lw = w * 0.86, lh = lw * IMG.logoCB.height / IMG.logoCB.width;
  g.translate(x + w / 2, y + h / 2); g.rotate(-0.5);
  g.drawImage(IMG.logoCB, -lw / 2, -lh / 2, lw, lh);
  g.restore();
}

function drawCard(g, cx, cy, w, h, flip, front, rot = 0) {
  // flip: 0 = back, 1 = front, animated via horizontal scale
  const a = flip * Math.PI; const sx = Math.cos(a);
  g.save(); g.translate(cx, cy); g.rotate(rot); g.scale(Math.max(0.02, Math.abs(sx)), 1);
  if (sx > 0) drawCardBack(g, -w / 2, -h / 2, w, h); else drawCardFront(g, -w / 2, -h / 2, w, h, front);
  g.restore();
}

function drawHanko(g, x, y, s, rot, k) {
  g.save(); g.translate(x, y); g.rotate(rot); g.scale(k, k);
  g.fillStyle = '#d6303a'; rrect(g, -s / 2, -s / 2, s, s, s * 0.12); g.fill();
  g.strokeStyle = C.paper; g.lineWidth = s * 0.05; rrect(g, -s * 0.4, -s * 0.4, s * 0.8, s * 0.8, s * 0.06); g.stroke();
  g.font = `${Math.round(s * 0.62)}px ${FONT.dela}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = C.paper;
  g.fillText('封', 0, s * 0.03);
  g.restore();
}

function drawWisp(g, a, vt, emerge) {
  const r = a.r * emerge; if (r < 1) return;
  const id = a.id; const dir = Math.atan2(a.vy, a.vx);
  g.save(); g.translate(a.x, a.y);
  // ink droplet trail
  for (let i = 1; i <= 5; i++) {
    const k = i * 0.055; const jx = (hash(id + i) - 0.5) * 10, jy = (hash(id * 3 + i) - 0.5) * 10;
    g.fillStyle = i % 2 ? C.ink : '#3a1420';
    g.beginPath(); g.arc(-a.vx * k + jx, -a.vy * k + jy, r * (0.32 - i * 0.045), 0, 7); g.fill();
  }
  // flame tongues (Resonance): swept back behind the anomaly like a fireball
  const N = 11, backA = dir + Math.PI;
  for (let pass = 0; pass < 2; pass++) for (let i = 0; i < N; i++) {
    const ang = (i / N) * Math.PI * 2 + Math.sin(vt * 2.1 + id + i) * 0.18 + hash(id + i) * 0.35;
    const back = Math.max(0, -Math.cos(ang - dir));
    const L = r * (0.1 + 0.3 * noise1(vt * 4 + i * 1.7 + id) + 1.6 * Math.pow(back, 1.4) * (0.75 + 0.5 * noise1(vt * 6 + i)));
    if (L < r * 0.18) continue;
    let da = backA - ang; da = Math.atan2(Math.sin(da), Math.cos(da));
    const tipA = ang + da * 0.55;
    const base = r * 0.8, w = 0.3 + 0.16 * back;
    const tip = [Math.cos(tipA) * (base + L), Math.sin(tipA) * (base + L)];
    const c1 = [Math.cos(ang + da * 0.2 - 0.18) * (base + L * 0.55), Math.sin(ang + da * 0.2 - 0.18) * (base + L * 0.55)];
    const c2 = [Math.cos(ang + da * 0.3 + 0.22) * (base + L * 0.4), Math.sin(ang + da * 0.3 + 0.22) * (base + L * 0.4)];
    g.beginPath();
    g.moveTo(Math.cos(ang - w) * base, Math.sin(ang - w) * base);
    g.quadraticCurveTo(c1[0], c1[1], tip[0], tip[1]);
    g.quadraticCurveTo(c2[0], c2[1], Math.cos(ang + w) * base, Math.sin(ang + w) * base);
    g.closePath();
    if (pass === 0) { g.lineWidth = 5; g.strokeStyle = C.ink; g.lineJoin = 'round'; g.stroke(); }
    else { g.fillStyle = i % 3 === 0 ? '#ff8b84' : C.coral; g.fill(); }
  }
  // body blob
  g.beginPath();
  for (let i = 0; i <= 28; i++) {
    const th = (i / 28) * Math.PI * 2;
    const rr = r * (1 + 0.07 * Math.sin(th * 3 + vt * 4 + id) + 0.05 * Math.sin(th * 5 - vt * 3));
    i ? g.lineTo(Math.cos(th) * rr, Math.sin(th) * rr) : g.moveTo(Math.cos(th) * rr, Math.sin(th) * rr);
  }
  g.closePath();
  const gr = g.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r * 1.05);
  gr.addColorStop(0, '#4a2238'); gr.addColorStop(0.6, '#1c0f18'); gr.addColorStop(1, '#0b070a');
  g.fillStyle = gr; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
  // rim highlight
  g.strokeStyle = 'rgba(255,190,190,0.55)'; g.lineWidth = 2.5; g.beginPath(); g.arc(0, 0, r * 0.78, Math.PI * 1.05, Math.PI * 1.45); g.stroke();
  // single slit eye (amber, like Nero's) looking where it moves
  g.rotate(dir);
  const ex = r * 0.28, ew = r * 0.62, eh = r * 0.34;
  g.beginPath(); g.moveTo(ex - ew / 2, 0); g.quadraticCurveTo(ex, -eh, ex + ew / 2, 0); g.quadraticCurveTo(ex, eh * 0.75, ex - ew / 2, 0); g.closePath();
  g.fillStyle = C.gold; g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke();
  g.fillStyle = C.ink; g.beginPath(); g.ellipse(ex + ew * 0.08, 0, r * 0.06, eh * 0.62, 0, 0, 7); g.fill();
  g.fillStyle = '#fff'; g.beginPath(); g.arc(ex - ew * 0.1, -eh * 0.28, r * 0.07, 0, 7); g.fill();
  g.restore();
}

function drawNero(g, a, vt, emerge) {
  const r = a.r * emerge; if (r < 1) return;
  g.save(); g.translate(a.x, a.y);
  // golden aura + violet flames
  const gl = g.createRadialGradient(0, 0, r * 0.4, 0, 0, r * 2.1);
  gl.addColorStop(0, 'rgba(242,180,60,0.55)'); gl.addColorStop(1, 'rgba(242,180,60,0)');
  g.fillStyle = gl; g.beginPath(); g.arc(0, 0, r * 2.1, 0, 7); g.fill();
  const dirN = Math.atan2(a.vy, a.vx), backN = dirN + Math.PI;
  for (let pass = 0; pass < 2; pass++) for (let i = 0; i < 9; i++) {
    const ang = (i / 9) * Math.PI * 2 + Math.sin(vt * 1.6 + i) * 0.2;
    const back = Math.max(0, -Math.cos(ang - dirN));
    const L = r * (0.15 + 0.3 * noise1(vt * 3 + i * 1.3) + 1.3 * Math.pow(back, 1.3));
    let da = backN - ang; da = Math.atan2(Math.sin(da), Math.cos(da)); const tipA = ang + da * 0.5;
    const base = r * 0.85, w = 0.3 + 0.12 * back;
    g.beginPath(); g.moveTo(Math.cos(ang - w) * base, Math.sin(ang - w) * base);
    g.quadraticCurveTo(Math.cos(ang + da * 0.2) * (base + L * 0.6), Math.sin(ang + da * 0.2) * (base + L * 0.6), Math.cos(tipA) * (base + L), Math.sin(tipA) * (base + L));
    g.quadraticCurveTo(Math.cos(ang + da * 0.3 + 0.25) * (base + L * 0.35), Math.sin(ang + da * 0.3 + 0.25) * (base + L * 0.35), Math.cos(ang + w) * base, Math.sin(ang + w) * base);
    g.closePath();
    if (pass === 0) { g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke(); } else { g.fillStyle = i % 2 ? C.gold : C.coral; g.fill(); }
  }
  // soft spirit halo so the head reads clearly
  const halo = g.createRadialGradient(0, 0, r * 0.3, 0, 0, r * 1.25);
  halo.addColorStop(0, 'rgba(255,236,190,0.95)'); halo.addColorStop(0.7, 'rgba(242,180,60,0.85)'); halo.addColorStop(1, 'rgba(242,180,60,0)');
  g.fillStyle = halo; g.beginPath(); g.arc(0, 0, r * 1.25, 0, 7); g.fill();
  // Nero's official head art floating in the flames
  const s = r * 3.0; const bob = Math.sin(vt * 5) * r * 0.05;
  const face = a.vx < 0 ? 1 : -1; // official art faces left; mirror when moving right
  g.scale(face, 1);
  g.drawImage(ART.neroHead, -s * 0.55, -s * 0.52 + bob, s, s);
  g.restore();
}

function halftoneLayer() {
  if (HT_CANVAS) return HT_CANVAS;
  const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d');
  const step = 16;
  g.save(); g.translate(W / 2, H / 2); g.rotate(Math.PI / 4);
  const R = Math.hypot(W, H) / 2 + step;
  for (let y = -R; y < R; y += step) for (let x = -R; x < R; x += step) {
    const sx = W / 2 + (x - y) * Math.SQRT1_2, sy = H / 2 + (x + y) * Math.SQRT1_2;
    const f = clamp(0.15 + 0.85 * (1 - Math.hypot((sx - W * 0.82) / W, (sy - H * 0.9) / H) * 1.25)) * (0.75 + 0.25 * noise1(sx * 0.01 + sy * 0.013));
    const r = 0.6 + 5.2 * f;
    g.fillStyle = `rgba(150,52,60,${0.22 + 0.25 * f})`; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  g.restore();
  HT_CANVAS = c; return c;
}

function drawRedHalftone(g, t, dark = 0.35) {
  const bg = g.createRadialGradient(W * 0.5, H * 0.42, 40, W * 0.5, H * 0.5, Math.max(W, H) * 0.75);
  bg.addColorStop(0, '#5b2026'); bg.addColorStop(0.55, '#3a1216'); bg.addColorStop(1, '#170608');
  g.fillStyle = bg; g.fillRect(0, 0, W, H);
  g.save(); g.globalAlpha = 0.18; g.globalCompositeOperation = 'multiply';
  cover(g, IMG.cardback, 0, 0, W, H, 1.2, Math.sin(t * 0.1) * 30, 0); g.restore();
  g.drawImage(halftoneLayer(), 0, 0);
  // drifting card backs
  const cards = VERT
    ? [[-60, 260, 0.5, 430], [880, 120, -0.35, 380], [-40, 1500, -0.6, 420], [860, 1560, 0.45, 400]]
    : [[60, -40, 0.55, 420], [1640, 40, -0.4, 400], [-20, 760, -0.7, 380], [1700, 820, 0.5, 430]];
  for (const [x, y, r, w] of cards) {
    g.save(); g.globalAlpha = 0.55;
    g.translate(x + Math.sin(t * 0.3 + r) * 14, y + Math.cos(t * 0.25 + r) * 10); g.rotate(r + Math.sin(t * 0.2 + x) * 0.02);
    drawCardBack(g, -w / 2, -w * 0.7, w, w * 1.4);
    g.restore();
  }
  g.fillStyle = `rgba(20,6,8,${dark})`; g.fillRect(0, 0, W, H);
  const vg = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.7);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.6)'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
}

function drawBackdrop(g, t, tint = 0.74) {
  g.fillStyle = '#120e15'; g.fillRect(0, 0, W, H);
  g.save(); g.globalAlpha = 0.9;
  const s = Math.max(W / ART.bannerBg.width, H / ART.bannerBg.height) * 1.08;
  g.drawImage(ART.bannerBg, (W - ART.bannerBg.width * s) / 2 + Math.sin(t * 0.15) * 24, (H - ART.bannerBg.height * s) / 2, ART.bannerBg.width * s, ART.bannerBg.height * s);
  g.restore();
  g.fillStyle = `rgba(18,13,22,${tint})`; g.fillRect(0, 0, W, H);
  // embers
  for (let i = 0; i < 46; i++) {
    const sp = 20 + hash(i) * 50; const x = (hash(i * 3.3) * W + Math.sin(t * 0.7 + i) * 30) % W;
    const y = H - ((t * sp + hash(i * 7.1) * H) % (H + 40)); const r = 1.5 + hash(i * 2.2) * 3;
    g.fillStyle = `rgba(244,87,94,${0.35 + 0.5 * noise1(t * 3 + i)})`; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  const vg = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.7)'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
}

function drawCutIn(g, u, kind) {
  // u: 0..1 over the cut-in's life
  const inT = eOut(inv(0, 0.16, u)), outT = eIn(inv(0.84, 1, u));
  const k = inT * (1 - outT);
  if (k <= 0) return;
  const cfg = {
    shonen: { art: ART.cutShonen, col: C.coral, col2: '#2b0d14', big: 'SPLASH  PAGE', lbl: 'SHONEN · VANGUARD · FINISHER', jp: 'ザンッ' },
    shojo: { art: ART.cutShojo, col: C.sakura, col2: C.navy, big: 'TAG  IN: SHOJO', lbl: 'CATALYST · TAP TO THROW & PARRY', jp: 'シュッ' },
    nero: { art: ART.cutNero, col: C.gold, col2: '#2a1f12', big: 'NEROOOOO.', lbl: 'THE ANOMALY · HOLD & DRAG THROUGH WALLS', jp: 'ドンッ' },
  }[kind];
  g.save();
  g.fillStyle = `rgba(8,5,10,${0.62 * k})`; g.fillRect(0, 0, W, H);
  const bh = VERT ? 560 : 430; const cy = H * (VERT ? 0.46 : 0.5); const sk = VERT ? 120 : 160;
  const slide = (1 - inT) * -W * 1.2 + outT * W * 1.2;
  g.translate(slide, 0);
  // band
  g.beginPath(); g.moveTo(-200, cy - bh / 2 + sk / 2); g.lineTo(W + 200, cy - bh / 2 - sk / 2); g.lineTo(W + 200, cy + bh / 2 - sk / 2); g.lineTo(-200, cy + bh / 2 + sk / 2); g.closePath();
  g.save(); g.clip();
  g.fillStyle = cfg.col2; g.fillRect(-200, 0, W + 400, H);
  const drift = u * 120;
  const aw = W * 1.02, ah = aw * cfg.art.height / cfg.art.width;
  g.drawImage(cfg.art, (W - aw) / 2 - drift + 60, cy - ah / 2, aw, ah);
  speedLines(g, W * 0.3, cy, 200, W * 1.1, 90, 77, 0.35, '#fff', 1.4);
  g.restore();
  // band edges
  g.lineWidth = 14; g.strokeStyle = cfg.col;
  g.beginPath(); g.moveTo(-200, cy - bh / 2 + sk / 2); g.lineTo(W + 200, cy - bh / 2 - sk / 2); g.stroke();
  g.beginPath(); g.moveTo(-200, cy + bh / 2 + sk / 2); g.lineTo(W + 200, cy + bh / 2 - sk / 2); g.stroke();
  g.lineWidth = 5; g.strokeStyle = C.ink;
  g.beginPath(); g.moveTo(-200, cy - bh / 2 + sk / 2 - 10); g.lineTo(W + 200, cy - bh / 2 - sk / 2 - 10); g.stroke();
  g.beginPath(); g.moveTo(-200, cy + bh / 2 + sk / 2 + 10); g.lineTo(W + 200, cy + bh / 2 - sk / 2 + 10); g.stroke();
  // text
  const big = VERT ? 100 : 128;
  g.save(); g.translate(W * (VERT ? 0.5 : 0.62), cy + bh / 2 - (VERT ? 90 : 60)); g.rotate(-0.08);
  g.font = `${big}px ${FONT.dela}`; g.letterSpacing = '3px';
  const fit = Math.min(1, (W * (VERT ? 0.86 : 0.7)) / (g.measureText(cfg.big).width + big * 0.3));
  const tk = lerp(1.25, 1, eOut(inv(0.05, 0.25, u))) * fit;
  g.scale(tk, tk); g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
  g.lineWidth = big * 0.3; g.strokeStyle = '#fff'; g.strokeText(cfg.big, 0, 0);
  g.lineWidth = big * 0.15; g.strokeStyle = C.ink; g.strokeText(cfg.big, 0, 0);
  g.fillStyle = cfg.col; g.fillText(cfg.big, 0, 0);
  g.restore();
  text(g, cfg.lbl, VERT ? 60 : 120, cy - bh / 2 + (VERT ? 120 : 110), { font: FONT.mono, size: VERT ? 26 : 26, color: '#fff', ls: 6, stroke: 8, strokeColor: C.ink });
  g.restore();
}

function invertCanvas(g, amt = 1) {
  g.save(); g.globalCompositeOperation = 'difference'; g.fillStyle = `rgba(255,255,255,${amt})`; g.fillRect(0, 0, W, H); g.restore();
}

function mapTime(keys, t) {
  for (let i = 0; i < keys.length - 1; i++) { const [a, sa] = keys[i], [b, sb] = keys[i + 1]; if (t >= a && t <= b) return lerp(sa, sb, (t - a) / (b - a)); }
  return t < keys[0][0] ? keys[0][1] : keys[keys.length - 1][1];
}

function sfxText(g, s, x, y, size, ls = 0) {
  g.letterSpacing = `${ls}px`;
  g.font = `${size}px ${FONT.dela}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
  g.lineWidth = size * 0.3; g.strokeStyle = '#fff'; g.strokeText(s, x, y);
  g.lineWidth = size * 0.14; g.strokeStyle = C.ink; g.strokeText(s, x, y);
  g.fillStyle = C.coral; g.fillText(s, x, y);
}

function drawMeter(g, x, y, w, h, v, vt) {
  g.save(); rrect(g, x, y, w, h, h / 2); g.fillStyle = '#231c27'; g.fill(); g.lineWidth = 2; g.strokeStyle = '#4a3f52'; g.stroke();
  if (v > 0.001) {
    g.save(); rrect(g, x, y, w * v, h, h / 2); g.clip();
    const gr = g.createLinearGradient(x, 0, x + w, 0); gr.addColorStop(0, '#8e1f3a'); gr.addColorStop(1, C.coral);
    g.fillStyle = gr; g.fillRect(x, y, w, h);
    g.fillStyle = 'rgba(255,255,255,0.35)';
    for (let i = 0; i < 14; i++) { const px = x + ((i * 37 + vt * 120) % (w + 40)) - 20; g.beginPath(); g.moveTo(px, y + h); g.lineTo(px + 8, y); g.lineTo(px + 14, y); g.lineTo(px + 6, y + h); g.fill(); }
    g.restore();
    if (v >= 1) { g.shadowColor = C.coral; g.shadowBlur = 24; rrect(g, x, y, w, h, h / 2); g.strokeStyle = '#ffb3ae'; g.lineWidth = 2; g.stroke(); }
  }
  g.restore();
}

function mascotPath(g, s) {
  // body: semicircle top (r = 88.5) over straight sides, rounded bottom corners
  const r = 88.5 * s, w = 177 * s, h = (313 - 115) * s, cr = 16 * s;
  g.beginPath();
  g.moveTo(-w / 2, 0);
  g.arc(0, 0, r, Math.PI, 0);
  g.lineTo(w / 2, h - r - cr); g.quadraticCurveTo(w / 2, h - r, w / 2 - cr, h - r);
  g.lineTo(-w / 2 + cr, h - r); g.quadraticCurveTo(-w / 2, h - r, -w / 2, h - r - cr);
  g.closePath();
}

function drawMascot(g, cx, cy, size, t, blink) {
  const s = size / 177;
  g.save(); g.translate(cx, cy);
  // echo outline
  g.save(); g.translate(-37 * s, -32 * s); mascotPath(g, s);
  const eg = g.createLinearGradient(-90 * s, -90 * s, 90 * s, 110 * s); eg.addColorStop(0, '#8d8d8d'); eg.addColorStop(1, '#2e2e2e');
  g.lineWidth = 8 * s; g.strokeStyle = eg; g.stroke(); g.restore();
  // chrome body
  mascotPath(g, s);
  const gr = g.createLinearGradient(-88 * s, -88 * s, 89 * s, 110 * s);
  gr.addColorStop(0, '#d2d2d2'); gr.addColorStop(0.2, '#a7a7a7'); gr.addColorStop(0.36, '#6b6b6b'); gr.addColorStop(0.5, '#ececec'); gr.addColorStop(0.68, '#d6d6d6'); gr.addColorStop(1, '#b4b4b4');
  g.fillStyle = gr; g.fill();
  // moving sheen
  g.save(); mascotPath(g, s); g.clip();
  const sx = lerp(-260, 260, (t * 0.35) % 1.4) * s;
  const sh = g.createLinearGradient(sx - 60 * s, -100 * s, sx + 60 * s, 120 * s);
  sh.addColorStop(0, 'rgba(255,255,255,0)'); sh.addColorStop(0.5, 'rgba(255,255,255,0.55)'); sh.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = sh; g.fillRect(-120 * s, -120 * s, 240 * s, 260 * s); g.restore();
  // eyes
  const eh = 52 * s * (1 - 0.9 * blink), ew = 17 * s;
  g.fillStyle = '#1b1b1d';
  for (const ex of [-15.5, 24.5]) { rrect(g, ex * s - ew / 2, -4 * s - eh / 2, ew, eh, ew / 2); g.fill(); }
  g.restore();
}

function sceneTitle(g, t, shot) {
  const u = t - shot.t0, d = shot.t1 - shot.t0;
  drawRedHalftone(g, t, 0.25);
  // diagonal slash wipe in
  const slash = eOut(inv(0, 0.35, u));
  g.save();
  const lw = VERT ? 860 : 1100, lh = lw * IMG.logoL.height / IMG.logoL.width;
  const k = lerp(1.25, 1, eOut(inv(0.1, 0.6, u)));
  g.translate(W / 2, H * (VERT ? 0.38 : 0.36)); g.scale(k, k);
  g.globalAlpha = inv(0.08, 0.3, u);
  g.drawImage(IMG.logoL, -lw / 2, -lh / 2, lw, lh);
  g.restore();
  const ty = H * (VERT ? 0.38 : 0.36) + lh / 2 + (VERT ? 120 : 110);
  g.save(); g.globalAlpha = inv(0.35, 0.6, u);
  sfxText(g, 'CHAPTER  BREAK', W / 2, ty, VERT ? 74 : 104, 4);
  g.restore();
  const ry = ty + (VERT ? 150 : 130);
  text(g, 'SWIPE. TAP. DRAG. BREAK THE PAGE.', W / 2, ry, { font: FONT.disp, weight: 600, size: VERT ? 46 : 52, color: '#fff', align: 'center', alpha: inv(0.7, 1.0, u), ls: 1 });
  text(g, 'A GAME CONCEPT FOR ZENKO', W / 2, ry + (VERT ? 64 : 58), { font: FONT.mono, size: VERT ? 22 : 20, color: '#f2c2bf', align: 'center', alpha: inv(0.9, 1.2, u), ls: 6 });
  // slash line across
  if (u < 0.5) {
    g.save(); g.globalAlpha = 1 - inv(0.25, 0.5, u); g.strokeStyle = '#fff'; g.shadowColor = C.coral; g.shadowBlur = 30; g.lineWidth = 10;
    g.beginPath(); g.moveTo(-100, H * 0.85); g.lineTo(lerp(-100, W + 100, slash), lerp(H * 0.85, H * 0.15, slash)); g.stroke(); g.restore();
  }
  // out: page tear
  if (u > d - 0.18) invertCanvas(g, 1 - inv(d - 0.18, d, u));
}

function sceneLeader(g, t, shot) {
  const d = shot.t1 - shot.t0; const u = (t - shot.t0) * (4.2 / Math.max(2.2, d)) * (d < 3 ? 1.25 : 1);
  drawBackdrop(g, t, 0.82);
  const pw = VERT ? 960 : 1040, ph = VERT ? 1080 : 760, px = (W - pw) / 2, py = VERT ? 260 : 70;
  // panel styled like the card's black window with a coral frame
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 40;
  rrect(g, px, py, pw, ph, 28); g.fillStyle = C.card; g.fill(); g.shadowColor = 'transparent';
  const m = 16, n = 60;
  g.beginPath(); g.moveTo(px + m + n, py + m); g.lineTo(px + pw - m, py + m); g.lineTo(px + pw - m, py + ph - m); g.lineTo(px + m, py + ph - m); g.lineTo(px + m, py + m + n); g.closePath();
  g.fillStyle = '#121014'; g.fill();
  g.restore();
  text(g, 'WL LEADERBOARD', px + 90, py + 92, { font: FONT.dela, size: VERT ? 44 : 46, color: '#fff' });
  text(g, 'SAMPLE · CHAPTER 01', VERT ? px + 92 : px + pw - 56, VERT ? py + 128 : py + 86, { font: FONT.mono, size: 18, color: C.card, align: VERT ? 'left' : 'right', ls: 3 });
  const names = ['holder_01', 'holder_12', 'holder_07', 'holder_33', 'holder_04', 'holder_21', 'holder_09', 'holder_15', 'holder_28', 'holder_02'];
  const base = [9820, 9410, 0, 8870, 8650, 8120, 7990, 7600, 7310, 7020];
  const youScore = Math.round(lerp(6200, 9120, eOut(inv(0.5, 2.2, u))));
  const others = names.map((nm, i) => ({ nm, score: base[i] })).filter((_, i) => i !== 2).sort((a, b) => b.score - a.score);
  // continuous rank for "you": slides up through the rows as the score passes each one
  const p = others.reduce((m, o) => m + clamp((o.score - youScore) / 160 + 0.5), 0);
  const rowH = VERT ? 78 : 56; const y0 = py + (VERT ? 200 : 150);
  const moving = Math.abs(p - Math.round(p)) > 0.02 && u < 2.3;
  const draw = (r, slot, you, rankShown, i) => {
    const ry = y0 + slot * rowH;
    const appear = eOut(inv(0.05 + i * 0.05, 0.35 + i * 0.05, u));
    g.save(); g.globalAlpha = appear; g.translate((1 - appear) * 60 + (you && moving ? 26 : 0), 0);
    if (you) { rrect(g, px + 50, ry - rowH * 0.62, pw - 100, rowH * 0.9, 12); g.fillStyle = 'rgba(228,103,98,0.25)'; g.fill(); g.strokeStyle = C.card; g.lineWidth = 3; g.stroke(); }
    text(g, String(rankShown).padStart(2, '0'), px + 80, ry, { font: FONT.dela, size: VERT ? 36 : 30, color: you ? C.coral : '#8b8291' });
    text(g, you ? `${r.nm}  (you)` : r.nm, px + 170, ry, { font: FONT.mono, size: VERT ? 30 : 26, color: you ? '#fff' : '#d8d2dc' });
    text(g, r.score.toLocaleString('en-US'), px + pw - 80, ry, { font: FONT.dela, size: VERT ? 34 : 28, color: you ? '#fff' : '#d8d2dc', align: 'right' });
    g.restore();
  };
  others.forEach((o, k) => { const slot = k + clamp(k + 1 - p); draw(o, slot, false, Math.round(slot) + 1, k); });
  draw({ nm: 'holder_07', score: youScore }, p, true, Math.round(p) + 1, 2);
  // bots line
  const by = VERT ? py + ph + 150 : py + ph + 110;
  const bu = inv(1.4, 1.8, u);
  text(g, 'Bots can like a post.', W / 2, by, { font: FONT.disp, weight: 600, size: VERT ? 54 : 56, color: '#fff', align: 'center', alpha: bu });
  text(g, 'They can’t clear a chapter.', W / 2, by + (VERT ? 72 : 70), { font: FONT.disp, weight: 600, size: VERT ? 54 : 56, color: C.coral, align: 'center', alpha: inv(1.8, 2.2, u) });
  if (VERT) text(g, 'Concept feature · sample handles · no allocation implied', W / 2, by + 140, { font: FONT.mono, size: 20, color: '#8b8291', align: 'center', alpha: bu });
  else text(g, 'Concept feature · sample handles · no allocation implied', W / 2, H - 22, { font: FONT.mono, size: 16, color: '#8b8291', align: 'center', alpha: bu, ls: 1 });
}

function sceneZenko(g, t, shot) {
  const u = t - shot.t0, d = shot.t1 - shot.t0;
  drawRedHalftone(g, t, 0.3);
  const lw = VERT ? 840 : 980, lh = lw * IMG.logoL.height / IMG.logoL.width;
  const k = lerp(1.15, 1, eOut(inv(0, 0.5, u)));
  g.save(); g.translate(W / 2, H * 0.4); g.scale(k, k); g.globalAlpha = inv(0, 0.2, u);
  g.drawImage(IMG.logoL, -lw / 2, -lh / 2, lw, lh); g.restore();
  g.save(); g.globalAlpha = inv(0.25, 0.5, u); sfxText(g, 'CHAPTER  BREAK', W / 2, H * 0.4 + lh / 2 + 90, VERT ? 70 : 96, 4); g.restore();
  text(g, 'A game concept for Zenko · built from your own art', W / 2, H * 0.4 + lh / 2 + (VERT ? 215 : 215), { font: FONT.disp, weight: 500, size: VERT ? 36 : 38, color: '#fff', align: 'center', alpha: inv(0.5, 0.8, u) });
  if (u > d - 0.3) { g.fillStyle = `rgba(0,0,0,${inv(d - 0.3, d, u)})`; g.fillRect(0, 0, W, H); }
}

function sceneEncore(g, t, shot) {
  const u = t - shot.t0, d = shot.t1 - shot.t0;
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const rg = g.createRadialGradient(W / 2, H * 0.36, 10, W / 2, H * 0.36, Math.max(W, H) * 0.6);
  rg.addColorStop(0, 'rgba(70,24,28,0.55)'); rg.addColorStop(0.5, 'rgba(20,10,12,0.35)'); rg.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = rg; g.fillRect(0, 0, W, H);
  // mascot + wordmark lockup
  const mk = eOut(inv(0, 0.6, u));
  const blinkT = (u - 1.6) / 0.16; const blink = blinkT > 0 && blinkT < 1 ? Math.sin(blinkT * Math.PI) : 0;
  const msz = VERT ? 210 : 170;
  const lockY = VERT ? 560 : 250;
  const wordH = VERT ? 120 : 104, wordW = wordH * IMG.encWord.width / IMG.encWord.height;
  const gap = VERT ? 0 : 60;
  const totalW = VERT ? wordW : msz + gap + wordW;
  const mx = VERT ? W / 2 : (W - totalW) / 2 + msz / 2 + 18, my = VERT ? lockY - 140 : lockY - 20;
  g.save(); g.globalAlpha = mk; g.translate(0, (1 - mk) * 30);
  drawMascot(g, mx, my, msz, t, blink);
  const wx = VERT ? (W - wordW) / 2 : mx + msz / 2 + gap, wy = VERT ? lockY + 120 : lockY - wordH / 2 + 10;
  g.drawImage(IMG.encWord, wx, wy, wordW, wordH);
  text(g, 'STUDIO', wx + wordW + 18, wy + wordH * 0.86, { font: FONT.mono, size: VERT ? 22 : 20, color: '#9a9a9e', ls: 5 });
  g.restore();
  // slogan
  const sy = VERT ? 1010 : 560;
  const su = inv(0.5, 0.9, u);
  g.save(); g.globalAlpha = su;
  g.font = `600 ${VERT ? 66 : 76}px ${FONT.disp}`; g.textBaseline = 'alphabetic';
  const a1 = 'Every launch deserves ', a2 = 'an encore.';
  if (VERT) {
    text(g, 'Every launch deserves', W / 2, sy, { font: FONT.disp, weight: 600, size: 66, color: '#e9e8ea', align: 'center' });
    text(g, a2, W / 2, sy + 84, { font: FONT.disp, weight: 600, size: 66, color: C.encRed, align: 'center' });
  } else {
    const w1 = g.measureText(a1).width, w2 = g.measureText(a2).width; const x0 = (W - w1 - w2) / 2;
    text(g, a1, x0, sy, { font: FONT.disp, weight: 600, size: 76, color: '#e9e8ea' });
    text(g, a2, x0 + w1, sy, { font: FONT.disp, weight: 600, size: 76, color: C.encRed });
  }
  g.restore();
  const ly = VERT ? 1190 : 650;
  text(g, 'ZENKO: CHAPTER BREAK · A GAME CONCEPT BY ENCORE STUDIO', W / 2, ly, { font: FONT.mono, size: VERT ? 20 : 20, color: C.encMono, align: 'center', ls: VERT ? 3 : 5, alpha: inv(0.8, 1.1, u) });
  text(g, VERT ? 'Book a free 30-min call' : 'Book a free 30-min call · encorestudio.xyz · @EncoreStudiohq', W / 2, ly + (VERT ? 90 : 84), { font: FONT.disp, weight: 500, size: VERT ? 40 : 38, color: '#f2f2f3', align: 'center', alpha: inv(1.0, 1.3, u) });
  if (VERT) text(g, 'encorestudio.xyz · @EncoreStudiohq', W / 2, ly + 146, { font: FONT.disp, weight: 500, size: 38, color: '#f2f2f3', align: 'center', alpha: inv(1.0, 1.3, u) });
  // divider + disclaimer
  const dy = VERT ? 1480 : 800;
  g.save(); g.globalAlpha = inv(1.2, 1.5, u); g.fillStyle = '#26262a'; g.fillRect(VERT ? 120 : 440, dy, VERT ? 840 : 1040, 2); g.restore();
  text(g, 'Unofficial concept by Encore Studio. Not affiliated with or endorsed by Zenko.', W / 2, dy + (VERT ? 60 : 52), { font: FONT.ui, size: VERT ? 22 : 24, color: '#8d8d92', align: 'center', alpha: inv(1.2, 1.5, u) });
  text(g, 'Zenko characters, manga, logo and art © Zenko.', W / 2, dy + (VERT ? 96 : 90), { font: FONT.ui, size: VERT ? 22 : 24, color: '#8d8d92', align: 'center', alpha: inv(1.2, 1.5, u) });
  // concept tag
  g.save(); g.globalAlpha = inv(1.2, 1.5, u);
  const tw = VERT ? 330 : 340, th = 46, tx = W - tw - (VERT ? 40 : 56), ty = H - th - (VERT ? 60 : 44);
  rrect(g, tx, ty, tw, th, 8); g.strokeStyle = '#3a3a40'; g.lineWidth = 2; g.stroke();
  g.fillStyle = C.encRed; g.fillRect(tx + 18, ty + th / 2 - 4, 8, 8);
  text(g, 'CONCEPT · UNOFFICIAL', tx + 40, ty + th / 2 + 7, { font: FONT.mono, size: 19, color: '#d7d7da', ls: 3 });
  g.restore();
  if (u > d - 0.6) { g.fillStyle = `rgba(0,0,0,${inv(d - 0.6, d, u)})`; g.fillRect(0, 0, W, H); }
}

// ===================== ZENKO: CHAPTER BREAK =====================
// The rift is rewriting Zenko's vertical-scroll manga. Fight through the chapter panel by panel:
// swipe (Shonen), tap / parry (Shojo), hold & drag (Nero), tag swap, drag cards, choose the plot
// fork, pinch for a Splash Page finisher. Cleared panels restore into Zenko's real art.
const ART = {};
const WIN = VERT ? { x: 46, y: 350, w: 988, h: 1300, s: 1.3 } : { x: 580, y: 40, w: 760, h: 1000, s: 1.0 };
const T_END = 27.6;

// ---------------- chapter world (page units, 760 wide) ----------------
const PANELS = [
  { id: 'P1', kind: 'story', poly: [[24, 24], [736, 24], [736, 300], [24, 336]], art: ['manga', [40, 0, 1180, 640], true] },
  { id: 'P2', kind: 'fight', poly: [[24, 350], [736, 314], [736, 770], [24, 730]], art: ['katanaF', [520, 520, 1480, 1420]], restoreT: 5.45 },
  { id: 'P3', kind: 'fight', poly: [[24, 744], [736, 784], [736, 1230], [24, 1250]], art: ['scytheF', [560, 440, 1560, 1440]], restoreT: 9.8 },
  { id: 'P4', kind: 'lock', poly: [[24, 1264], [736, 1244], [736, 1420], [24, 1420]], shatterT: 11.66, art: ['neroF', [560, 760, 1700, 1300]] },
  { id: 'P5a', kind: 'fork', poly: [[24, 1434], [370, 1434], [340, 1880], [24, 1880]], art: ['manga', [840, 700, 1500, 1230], true], label: 'ALLEY', reward: '+1 CARD', pct: 39 },
  { id: 'P5b', kind: 'fork', poly: [[384, 1434], [736, 1434], [736, 1880], [354, 1880]], art: ['banner', [2360, 160, 3000, 1000]], label: 'ROOFTOP', reward: '+RESONANCE', pct: 61, restoreT: 14.7, chosen: true },
  { id: 'P6', kind: 'fight', poly: [[24, 1894], [736, 1894], [736, 2360], [24, 2400]], art: ['shojoF', [380, 420, 1500, 1420]], restoreT: 18.2 },
  { id: 'P7', kind: 'boss', poly: [[24, 2414], [736, 2374], [736, 3180], [24, 3180]], art: ['banner', [1420, 20, 2080, 600]], restoreT: 26.3 },
];
const PM = Object.fromEntries(PANELS.map((p) => [p.id, p]));
const CHOOSE_T = 14.3;
const INSETS = [
  { panel: 'P2', poly: [[24, 350], [290, 337], [250, 730], [24, 730]], hero: 'shonen', t0: 0, t1: 99 },
  { panel: 'P3', poly: [[490, 771], [736, 784], [736, 1230], [540, 1236]], hero: 'shojo', t0: 0, t1: 99 },
  { panel: 'P7', poly: [[40, 2992], [262, 3002], [262, 3164], [40, 3164]], hero: 'active', t0: 19.4, t1: 26.3 },
];
const EYES = [
  { id: 'I1', poly: [[64, 2452], [300, 2440], [300, 2622], [64, 2632]], c: [182, 2537], hitT: 22.02 },
  { id: 'I2', poly: [[470, 2960], [704, 2950], [704, 3144], [470, 3154]], c: [587, 3052], hitT: 22.32 },
];
const HERO_TL = [[0, 'shonen'], [6.2, 'shojo'], [10.9, 'nero'], [15.9, 'shonen'], [21.1, 'shojo'], [22.6, 'nero'], [23.85, 'shonen']];
const heroAt = (s) => { let h = 'shonen'; for (const [t, x] of HERO_TL) if (s >= t) h = x; return h; };
const heroSwapT = (s) => { let tt = -9; for (const [t] of HERO_TL) if (s >= t && t > 0) tt = t; return tt; };
const HUD_TAPS = [[6.2, 'shojo'], [10.9, 'nero'], [15.9, 'shonen'], [21.1, 'shojo'], [22.6, 'nero']];

// enemies with scripted hits (skilled run)
const ENEMIES = [];
const E = (o) => ENEMIES.push({ ph: ENEMIES.length * 1.7 + 0.4, hits: [], ...o });
E({ id: 1, kind: 'wisp', r: 30, x: 520, y: 545, spawn: 1.86, from: [260, 292], hits: [{ t: 2.87, dmg: 212, kill: 1, src: 'claw' }] });
E({ id: 2, kind: 'wisp', r: 30, x: 632, y: 650, spawn: 1.95, from: [430, 284], hits: [{ t: 3.42, dmg: 198, kill: 1, src: 'claw' }] });
E({ id: 3, kind: 'wisp', r: 28, x: 432, y: 622, spawn: 2.04, from: [580, 276], hits: [{ t: 3.45, dmg: 96, src: 'claw' }, { t: 3.92, dmg: 184, kill: 1, src: 'claw' }] });
E({ id: 4, kind: 'brute', r: 54, x: 575, y: 560, spawn: 4.15, from: [575, 600], rift: [575, 600, 3.9], hits: [{ t: 4.72, dmg: 240, src: 'claw' }, { t: 5.07, dmg: 312, kill: 1, src: 'claw', big: 1 }] });
E({ id: 5, kind: 'wisp', r: 28, x: 180, y: 890, spawn: 6.0, from: [260, 1000], hits: [{ t: 8.18, dmg: 180, kill: 1, src: 'kunai' }] });
E({ id: 6, kind: 'wisp', r: 28, x: 352, y: 1082, spawn: 6.1, from: [260, 1000], hits: [{ t: 8.48, dmg: 176, kill: 1, src: 'kunai' }] });
E({ id: 7, kind: 'wisp', r: 28, x: 160, y: 1140, spawn: 6.2, from: [260, 1000], hits: [{ t: 8.78, dmg: 182, kill: 1, src: 'kunai' }] });
E({ id: 8, kind: 'brute', r: 52, x: 322, y: 962, spawn: 6.45, from: [260, 1000], rift: [260, 1000, 5.85], tele: { t0: 7.0, t1: 7.62, at: [332, 858] }, stun: [7.62, 9.05],
  hits: [{ t: 7.62, dmg: 0, parry: 1 }, { t: 9.18, dmg: 262, src: 'kunai' }, { t: 9.48, dmg: 318, kill: 1, src: 'kunai', big: 1 }] });
for (let i = 0; i < 5; i++) E({ id: 10 + i, kind: 'wisp', r: 28, orbit: { c: [380, 2140], R: 165, a0: i * 1.2566 }, spawn: 15.5 + i * 0.07, from: [380, 2140], rift: i === 0 ? [380, 2140, 15.35] : null,
  hits: [{ t: 17.42 + i * 0.035, dmg: 420 + i * 17, kill: 1, src: 'card' }] });

const SWIPES = [
  { t: 2.8, d: 0.14, a: [390, 440], b: [690, 700] },
  { t: 3.35, d: 0.14, a: [712, 598], b: [378, 690] },
  { t: 3.85, d: 0.13, a: [360, 560], b: [540, 680] },
  { t: 4.65, d: 0.14, a: [720, 420], b: [430, 700] },
  { t: 5.0, d: 0.14, a: [430, 430], b: [720, 700] },
  { t: 20.3, d: 0.15, a: [190, 2640], b: [600, 2960] },
  { t: 20.7, d: 0.15, a: [600, 2620], b: [175, 2960] },
];
const TAPS = [
  { t: 7.6, at: [332, 858], parry: 1 },
  { t: 8.06, at: [180, 890], kunai: 5, from: [600, 1010] }, { t: 8.36, at: [352, 1082], kunai: 6, from: [600, 1010] }, { t: 8.66, at: [160, 1140], kunai: 7, from: [600, 1010] },
  { t: 9.06, at: [322, 962], kunai: 8, from: [600, 1010] }, { t: 9.36, at: [322, 962], kunai: 8, from: [600, 1010] },
  { t: CHOOSE_T, at: [560, 1660], choose: 1 },
  { t: 21.5, at: [600, 2540], parry: 1 },
  { t: 21.9, at: [182, 2537], kunai: 'I1', from: [160, 3070] }, { t: 22.2, at: [587, 3052], kunai: 'I2', from: [160, 3070] },
];
const DRAGS = [
  { t: 11.12, d: 0.9, nero: 1, appear: 10.96, path: [[380, 1172], [392, 1262], [430, 1345], [500, 1470], [560, 1585]] },
  { t: 16.55, d: 0.7, card: 1 },
  { t: 22.8, d: 0.56, nero: 1, appear: 22.62, path: [[150, 3072], [262, 2950], [382, 2800], [560, 2602], [660, 2520]], strike: 23.18 },
];
const PINCH = { t: 24.1, d: 0.6, at: [380, 2790] };
const SPLASH = [24.75, 26.3];
const BOSS = { x: 380, y: 2790, rise: [19.0, 19.9], die: 24.8, tele: { t0: 21.0, t1: 21.5, at: [600, 2540] },
  hits: [{ t: 20.36, dmg: 0.1 }, { t: 20.76, dmg: 0.1 }, { t: 21.52, dmg: 0, parry: 1 }, { t: 22.02, dmg: 0.14, eye: 'I1' }, { t: 22.32, dmg: 0.14, eye: 'I2' }, { t: 23.18, dmg: 0.44, nero: 1 }] };
const PROMPTS = [
  { t0: 2.2, t1: 2.95, at: [560, 400], text: 'SWIPE!' },
  { t0: 6.95, t1: 7.62, at: [585, 735], text: 'TAP IT!' },
  { t0: 10.98, t1: 11.55, at: [590, 1135], text: 'HOLD & DRAG!' },
  { t0: 16.1, t1: 16.62, at: [380, 1990], text: 'DRAG A CARD!' },
  { t0: 23.8, t1: 24.2, at: [380, 2520], text: 'PINCH FOR SPLASH PAGE!' },
];
const CAM = [
  [0, 380, 480, 1.0], [1.6, 380, 480, 1.0], [2.3, 380, 560, 1.12], [5.6, 380, 560, 1.12], [6.3, 380, 1000, 1.12], [10.0, 380, 1000, 1.12],
  [10.7, 380, 1290, 1.0], [11.2, 380, 1290, 1.0], [12.2, 380, 1480, 1.0], [13.0, 380, 1660, 1.0], [14.4, 380, 1660, 1.0], [14.9, 545, 1660, 1.28],
  [15.15, 545, 1700, 1.28], [15.8, 380, 2150, 1.1], [18.6, 380, 2150, 1.1], [19.5, 380, 2686, 0.98], [99, 380, 2686, 0.98],
];
const RESULT = { time: '0:26.4', combo: 24, parry: '2/2', route: 'ROOFTOP', cards: '+3', rank: 'S' };

// all hit events, chronological (for combo / score / resonance / numbers)
const HITS = [];
for (const e of ENEMIES) for (const h of e.hits) HITS.push({ ...h, e });
for (const h of BOSS.hits) HITS.push({ ...h, boss: 1 });
HITS.push({ t: 24.8, dmg: 0.08, boss: 1, splash: 1 });
HITS.sort((a, b) => a.t - b.t);
const comboAt = (s) => HITS.filter((h) => h.t <= s).length;
const scoreAt = (s) => HITS.filter((h) => h.t <= s).reduce((m, h) => m + (h.boss ? h.dmg * 12000 : h.dmg * 10) + (h.parry ? 1500 : 0), 0);
const resAt = (s) => (s >= 23.3 && s < 24.8 ? 1 : s >= 24.8 ? Math.max(0, 1 - (s - 24.8) * 2) : clamp(comboAt(s) / 23));
const bossHP = (s) => 1 - BOSS.hits.filter((h) => h.t <= s).reduce((m, h) => m + h.dmg, 0) - (s >= 24.8 ? 0.08 : 0);

// ---------------- init ----------------
async function init() {
  const R = '..';
  await Promise.all([
    loadImg('banner', `${R}/raw/x-HX5dbiwaoAAvHvH.png`), loadImg('manga', `${R}/raw/article-HX5f-NMaAAAOjhL.png`),
    loadImg('neroF', `${R}/raw/x-HXf342bbgAACWJr.png`), loadImg('shojoF', `${R}/raw/x-HXVarTyasAEhHsN.png`),
    loadImg('katanaF', `${R}/raw/x-HXae84Ta4AALN3w.png`), loadImg('scytheF', `${R}/raw/x-HXklmjraIAAWuqX.png`),
    loadImg('nero', `${R}/assets/nero.png`), loadImg('shojo', `${R}/assets/shojo.png`),
    loadImg('logoL', `${R}/assets/zenko-logo-light.png`), loadImg('logoCB', `${R}/assets/zenko-logo-cardback.png`),
    loadImg('cardback', `${R}/assets/cardback-texture.png`), loadImg('encWord', `${R}/assets/encore-wordmark.png`),
  ]);
  ART.clean = {}; ART.corrupt = {};
  for (const p of PANELS) if (p.art) {
    const [im, r, gray] = p.art; ART.clean[p.id] = sprite(IMG[im], r, 900, !!gray); ART.corrupt[p.id] = corrupt(ART.clean[p.id], p.id.length * 7 + p.poly[0][1]);
  }
  ART.bannerBg = sprite(IMG.banner, [0, 0, 1250, 1000], 1400);
  ART.kunai = sprite(IMG.shojo, [105, 450, 300, 1020], 400);
  ART.neroHead = makeNeroHead();
  ART.heroShonen = sprite(IMG.banner, [1380, 0, 2280, 1000], 700);
  ART.heroShojo = sprite(IMG.shojoF, [300, 300, 1700, 1900], 700);
  ART.heroNero = sprite(IMG.neroF, [450, 350, 1850, 1950], 700);
  ART.cutShonen = sprite(IMG.banner, [1380, 120, 2200, 520], 1400);
  ART.cutShojo = sprite(IMG.shojoF, [480, 640, 1450, 1180], 1400);
  ART.cutNero = sprite(IMG.neroF, [560, 760, 1700, 1300], 1400);
  ART.splash = sprite(IMG.banner, [1180, 0, 2600, 1000], 2000);
  ART.cardClaw = sprite(IMG.banner, [440, 260, 1260, 1000], 600);
  ART.cardKunai = sprite(IMG.shojoF, [140, 560, 640, 1480], 600);
  ART.cardSplash = sprite(IMG.banner, [1420, 20, 2080, 600], 600);
  ART.halftone = makeHalftone(); ART.grain = makeGrain();
  ART.shards = makeShards();
  await document.fonts.load(`40px ${FONT.dela}`, 'ザシュッバキッドンッゴシュッパリンポン SPLASH PAGE CHAPTER BREAK 0123456789%×!');
  await document.fonts.load(`600 40px ${FONT.disp}`, 'Aa'); await document.fonts.load(`500 40px ${FONT.disp}`, 'Aa');
  await document.fonts.load(`40px ${FONT.mono}`, 'Aa'); await document.fonts.load(`700 40px ${FONT.ui}`, 'Aa'); await document.fonts.load(`40px ${FONT.ui}`, 'Aa');
  window.TOTAL_FRAMES = Math.round(TIMELINE.dur * FPS);
  window.ready = true;
}
function corrupt(sp, seed) {
  // the rift's rewrite: inverted, red-shifted, sliced and redacted
  const c = document.createElement('canvas'); c.width = sp.width; c.height = sp.height; const g = c.getContext('2d');
  g.filter = 'grayscale(1) invert(1) contrast(1.25) brightness(1.0)'; g.drawImage(sp, 0, 0); g.filter = 'none';
  g.globalCompositeOperation = 'multiply'; g.fillStyle = '#f2737a'; g.fillRect(0, 0, c.width, c.height);
  g.globalCompositeOperation = 'screen'; g.globalAlpha = 0.28; g.filter = 'grayscale(1) brightness(0.8)'; g.drawImage(sp, 9, 0); g.filter = 'none'; g.globalAlpha = 1;
  g.globalCompositeOperation = 'source-over';
  for (let i = 0; i < 16; i++) { const y = hash(seed + i) * c.height, hh = 4 + hash(seed + i * 3) * 34, dx = (hash(seed + i * 7) - 0.5) * 70; g.drawImage(c, 0, y, c.width, hh, dx, y, c.width, hh); }
  g.fillStyle = '#060406';
  for (let i = 0; i < 4; i++) { const w = c.width * (0.25 + 0.4 * hash(seed + i * 11)), x = hash(seed + i * 13) * (c.width - w), y = hash(seed + i * 17) * c.height; g.fillRect(x, y, w, 12 + hash(seed + i) * 20); }
  return c;
}
function makeShards() {
  const sh = []; const cols = 9, rows = 2; const x0 = 24, x1 = 736, y0 = 1250, y1 = 1420;
  const P = (i, j) => [lerp(x0, x1, i / cols) + (i % cols ? (hash(i * 7 + j) - 0.5) * 40 : 0), lerp(y0, y1, j / rows) + (j % rows ? (hash(i * 3 + j * 5) - 0.5) * 30 : 0)];
  for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
    const q = [P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)];
    sh.push([q[0], q[1], q[2]], [q[0], q[2], q[3]]);
  }
  return sh;
}

// ---------------- camera ----------------
function view(s) {
  let k = 0; while (k < CAM.length - 2 && s > CAM[k + 1][0]) k++;
  const [t0, x0, y0, z0] = CAM[k], [t1, x1, y1, z1] = CAM[k + 1];
  const u = eIO(inv(t0, t1, s));
  const z = lerp(z0, z1, u); let cx = lerp(x0, x1, u); const cy = lerp(y0, y1, u);
  const half = 380 / z; cx = clamp(cx, half, 760 - half);
  const [sx, sy] = shake2(s);
  return { cx: cx + sx, cy: cy + sy, z };
}
function shake2(s) {
  let amp = 0;
  for (const h of HITS) { const dt = s - h.t; if (dt < 0 || dt > 0.5) continue; amp += (h.splash ? 0 : h.nero ? 16 : h.kill && h.e?.kind === 'brute' ? 12 : h.parry ? 9 : h.boss ? 10 : 5) * Math.exp(-dt / 0.08); }
  const sh = PM.P4.shatterT; if (s > sh && s < sh + 0.5) amp += 12 * Math.exp(-(s - sh) / 0.1);
  return [(noise1(s * 40) - 0.5) * 2 * amp, (noise1(s * 40 + 9) - 0.5) * 2 * amp];
}
function w2s(x, y, V) { return [WIN.x + WIN.w / 2 + (x - V.cx) * V.z * WIN.s, WIN.y + WIN.h / 2 + (y - V.cy) * V.z * WIN.s]; }

// ---------------- world drawing ----------------
function drawWorld(g, s, vt) {
  g.fillStyle = C.paper; g.fillRect(-200, -200, 1160, 3600);
  for (const p of PANELS) drawPanel2(g, p, s, vt);
  drawRifts(g, s, vt);
  drawPollChip(g, s);
  drawBoss(g, s, vt);
  for (const ey of EYES) drawEyeInset(g, ey, s, vt);
  for (const ins of INSETS) drawHeroInset(g, ins, s, vt);
  for (const e of ENEMIES) drawEnemy(g, e, s, vt);
  drawTelegraphs(g, s, vt);
  drawKunai(g, s, vt);
  for (const sw of SWIPES) drawClaws(g, sw, s);
  drawHitFX(g, s, vt);
  drawCardBurst(g, s, vt);
  for (const d of DRAGS) if (d.nero) drawNeroDrag(g, d, s, vt);
  drawShards(g, s);
  for (const p of PROMPTS) drawPrompt(g, p, s);
  g.save(); g.globalCompositeOperation = 'multiply'; g.globalAlpha = 0.45; g.fillStyle = g.createPattern(ART.grain, 'repeat'); g.fillRect(0, 0, 760, 3200); g.restore();
}
function drawPanel2(g, p, s, vt) {
  const [x0, y0, x1, y1] = bboxOf(p.poly);
  g.save(); polyPath(g, p.poly); g.clip();
  g.fillStyle = '#f5f2ec'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  if (p.kind === 'lock') {
    drawLock(g, p, s, vt, x0, y0, x1, y1);
  } else {
    const clean = ART.clean[p.id], cor = ART.corrupt[p.id];
    let rp = p.kind === 'story' ? 1 : p.restoreT != null ? eOut(inv(p.restoreT, p.restoreT + 0.6, s)) : 0;
    const unread = p.kind === 'fork' && !p.chosen && s >= CHOOSE_T;
    if (unread) rp = 1;
    if (rp < 1) {
      cover(g, cor, x0, y0, x1, y1, 1.05 + 0.015 * Math.sin(vt * 3 + y0));
      // live glitch
      const k = Math.floor(vt * 18);
      for (let i = 0; i < 5; i++) {
        const yy = y0 + hash(k * 13 + i + y0) * (y1 - y0), hh = 2 + hash(k * 7 + i) * 9;
        g.fillStyle = i % 2 ? 'rgba(244,87,94,0.45)' : 'rgba(255,255,255,0.18)'; g.fillRect(x0, yy, x1 - x0, hh);
      }
      g.fillStyle = 'rgba(10,4,8,0.08)'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
    }
    if (rp > 0) {
      g.save();
      if (rp < 1) { const yy = lerp(y0 - 40, y1 + 40, rp); g.beginPath(); g.rect(x0, y0, x1 - x0, yy - y0); g.clip(); }
      cover(g, clean, x0, y0, x1, y1, p.kind === 'story' ? 1.0 : 1.08 - 0.06 * eOut(inv(p.restoreT ?? 0, (p.restoreT ?? 0) + 3, s)));
      if (unread) { g.fillStyle = 'rgba(20,16,22,0.62)'; g.fillRect(x0, y0, x1 - x0, y1 - y0); }
      g.restore();
      if (rp < 1) { // halftone edge of the restoring ink
        const yy = lerp(y0 - 40, y1 + 40, rp);
        g.save(); g.globalAlpha = 0.6; g.fillStyle = g.createPattern(ART.halftone, 'repeat'); g.fillRect(x0, yy - 30, x1 - x0, 60); g.restore();
        g.fillStyle = 'rgba(255,255,255,0.8)'; g.fillRect(x0, yy - 3, x1 - x0, 6);
      }
    }
    if (p.kind === 'story') drawNarration(g, s);
    if (p.kind === 'fork') drawForkUI(g, p, s, vt, x0, y0, x1, y1);
    if (p.restoreT != null && s > p.restoreT + 0.35) drawRestored(g, p, s, x0, y0, x1, y1);
  }
  g.restore();
  // border (P4 shatters away)
  if (p.kind === 'lock' && s >= p.shatterT && s < p.shatterT + 0.35) return;
  g.save(); polyPath(g, p.poly); g.lineJoin = 'miter'; g.lineWidth = 6; g.strokeStyle = C.ink; g.stroke();
  if (p.chosen && s >= CHOOSE_T && s < CHOOSE_T + 1.2) { g.lineWidth = 8; g.strokeStyle = `rgba(244,87,94,${1 - inv(CHOOSE_T, CHOOSE_T + 1.2, s)})`; g.stroke(); }
  g.restore();
}
function drawNarration(g, s) {
  const box = (x, y, w, h, str, o, a) => {
    if (a <= 0) return; g.save(); g.globalAlpha = a; g.translate(0, (1 - a) * 10);
    g.fillStyle = '#fff'; g.fillRect(x, y, w, h); g.lineWidth = 4; g.strokeStyle = C.ink; g.strokeRect(x, y, w, h);
    text(g, str, x + 16, y + h / 2 + o.size * 0.36, o); g.restore();
  };
  box(44, 44, 330, 50, 'KUROKAWA · 02:14 AM', { font: FONT.mono, size: 20, color: C.ink, ls: 2 }, inv(0.05, 0.3, s));
  box(330, 150, 386, 56, 'The rift is rewriting the manga.', { font: FONT.disp, weight: 600, size: 22, color: C.ink }, inv(0.5, 0.8, s));
}
function drawRestored(g, p, s, x0, y0, x1, y1) {
  const a = inv(p.restoreT + 0.35, p.restoreT + 0.5, s); const k = lerp(2, 1, eOut(a));
  g.save(); g.globalAlpha = a; g.translate(x1 - 120, y0 + 64 + (p.id === 'P7' ? 40 : 0)); g.rotate(-0.12); g.scale(k, k);
  rrect(g, -86, -24, 172, 48, 6); g.lineWidth = 5; g.strokeStyle = '#d6303a'; g.stroke();
  text(g, 'RESTORED', 0, 10, { font: FONT.dela, size: 24, color: '#d6303a', align: 'center', ls: 2 });
  g.restore();
}
function drawLock(g, p, s, vt, x0, y0, x1, y1) {
  if (s < p.shatterT) {
    g.fillStyle = '#140a0f'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
    g.save(); g.globalAlpha = 0.5;
    for (let i = -10; i < 30; i++) { g.fillStyle = i % 2 ? C.coral : '#000'; g.beginPath(); const xx = x0 + i * 40 + (vt * 30) % 80; g.moveTo(xx, y1); g.lineTo(xx + 40, y1); g.lineTo(xx + 140, y0); g.lineTo(xx + 100, y0); g.fill(); }
    g.restore();
    g.fillStyle = '#060406'; g.fillRect(x0, (y0 + y1) / 2 - 34, x1 - x0, 68);
    text(g, 'LOCKED BY THE RIFT', 380, (y0 + y1) / 2 + 9, { font: FONT.dela, size: 30, color: '#fff', align: 'center', ls: 3 });
    // chains
    g.save(); g.strokeStyle = '#8a7d84'; g.lineWidth = 6;
    for (let i = 0; i < 14; i++) { g.beginPath(); g.ellipse(60 + i * 50, y0 + 26, 22, 10, 0, 0, 7); g.stroke(); g.beginPath(); g.ellipse(60 + i * 50 + 25, y1 - 22, 22, 10, 0, 0, 7); g.stroke(); }
    g.restore();
  } else {
    // opened: Nero's eye panel inks in where he broke through
    g.fillStyle = '#f5f2ec'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
    const rp = eOut(inv(p.shatterT + 0.08, p.shatterT + 0.55, s));
    g.save(); g.beginPath(); g.rect(x0, y0, (x1 - x0) * rp, y1 - y0); g.clip(); cover(g, ART.clean.P4, x0, y0, x1, y1, 1.15 - 0.08 * rp); g.restore();
    const a = 1 - inv(p.shatterT, p.shatterT + 1.5, s);
    const gl = g.createRadialGradient(430, 1340, 10, 430, 1340, 300); gl.addColorStop(0, `rgba(242,180,60,${0.6 * a + 0.1})`); gl.addColorStop(1, 'rgba(242,180,60,0)');
    g.fillStyle = gl; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  }
}
function drawShards(g, s) {
  const t0 = PM.P4.shatterT; const age = s - t0; if (age < 0 || age > 0.9) return;
  const k = 1 - age / 0.9;
  ART.shards.forEach((tri, i) => {
    const cx = (tri[0][0] + tri[1][0] + tri[2][0]) / 3, cy = (tri[0][1] + tri[1][1] + tri[2][1]) / 3;
    const dx = cx - 430, dy = cy - 1340, L = Math.hypot(dx, dy) || 1;
    const sp = 260 + 380 * hash(i * 3.7);
    const ox = (dx / L) * sp * age, oy = (dy / L) * sp * age + 900 * age * age;
    const rot = (hash(i * 9.1) - 0.5) * 8 * age;
    g.save(); g.translate(cx + ox, cy + oy); g.rotate(rot); g.globalAlpha = k;
    g.beginPath(); tri.forEach(([x, y], j) => (j ? g.lineTo(x - cx, y - cy) : g.moveTo(x - cx, y - cy))); g.closePath();
    g.fillStyle = i % 3 ? '#140a0f' : C.coral; g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke();
    g.restore();
  });
  sfx(g, 'パリンッ', 470, 1250, 84, age * 60, { life: 46, rot: -0.1, color: C.gold });
}
function drawForkUI(g, p, s, vt, x0, y0, x1, y1) {
  const a = inv(12.9, 13.2, s); if (a <= 0) return;
  const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
  const chosen = s >= CHOOSE_T;
  if (chosen && !p.chosen) {
    const ua = inv(CHOOSE_T, CHOOSE_T + 0.3, s);
    text(g, p.label, cx, cy - 8, { font: FONT.dela, size: 40, color: '#bdb6c4', align: 'center', alpha: ua });
    text(g, 'UNREAD', cx, cy + 34, { font: FONT.mono, size: 22, color: '#bdb6c4', align: 'center', ls: 4, alpha: ua });
    return;
  }
  g.save(); g.globalAlpha = a * (p.chosen ? 1 - inv(CHOOSE_T + 0.3, CHOOSE_T + 0.7, s) : 1);
  text(g, p.label, cx, cy - 34, { font: FONT.dela, size: 46, color: '#fff', align: 'center', stroke: 12, strokeColor: C.ink });
  text(g, p.reward, cx, cy + 6, { font: FONT.mono, size: 20, color: '#fff', align: 'center', ls: 2, stroke: 6, strokeColor: C.ink });
  const fill = eOut(inv(13.1, 13.9, s)) * p.pct / 100;
  const bw = 230, bx = cx - bw / 2, by = cy + 30;
  rrect(g, bx, by, bw, 26, 13); g.fillStyle = 'rgba(0,0,0,0.6)'; g.fill(); g.lineWidth = 3; g.strokeStyle = '#fff'; g.stroke();
  g.save(); rrect(g, bx, by, bw * fill, 26, 13); g.clip(); g.fillStyle = p.chosen ? C.coral : '#bdb6c4'; g.fillRect(bx, by, bw, 26); g.restore();
  text(g, `${Math.round(fill * 100)}%`, cx, by + 62, { font: FONT.dela, size: 30, color: '#fff', align: 'center', stroke: 9, strokeColor: C.ink });
  g.restore();
}
function drawPollChip(g, s) {
  const a = inv(12.9, 13.2, s) * (1 - inv(CHOOSE_T, CHOOSE_T + 0.25, s)); if (a <= 0) return;
  g.save(); g.globalAlpha = a; rrect(g, 210, 1448, 340, 44, 22); g.fillStyle = C.ink; g.fill(); g.lineWidth = 3; g.strokeStyle = '#fff'; g.stroke();
  text(g, 'HOLDER POLL · PLOT FORK', 380, 1477, { font: FONT.mono, size: 18, color: '#fff', align: 'center', ls: 2 }); g.restore();
}
function drawRifts(g, s, vt) {
  // P1 tear that spills the first anomalies
  const t0 = 1.15; const u = eOut(inv(t0, t0 + 0.5, s));
  const close = 1 - inv(5.4, 5.9, s);
  if (u > 0 && close > 0) {
    g.save(); g.globalAlpha = close;
    const pts = []; for (let i = 0; i <= 16; i++) { const t = i / 16; pts.push([lerp(120, 660, t), lerp(296, 262, t) + (i % 2 ? -12 : 12) * Math.sin(t * Math.PI)]); }
    const n = Math.max(2, Math.round(pts.length * u));
    g.shadowColor = C.coral; g.shadowBlur = 30 * (0.7 + 0.3 * Math.sin(vt * 8));
    g.lineCap = 'round'; g.lineJoin = 'round';
    g.strokeStyle = '#12060c'; g.lineWidth = 20; g.beginPath(); pts.slice(0, n).forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.stroke();
    g.shadowBlur = 0; g.strokeStyle = C.coral; g.lineWidth = 5; g.stroke();
    // red drips
    for (let i = 0; i < 7; i++) { const x = 160 + i * 74, L = 30 + 50 * hash(i) * u; g.strokeStyle = 'rgba(214,48,58,0.8)'; g.lineWidth = 5; g.beginPath(); g.moveTo(x, 280 - i * 3); g.lineTo(x, 280 - i * 3 + L); g.stroke(); }
    g.restore();
    if (s < 3.2) sfx(g, 'ゴゴゴ', 620, 200, 48, (s - t0) * 60, { life: 80, rot: 0.15, color: C.ink, outer: C.paper });
  }
  for (const e of ENEMIES) {
    if (!e.rift) continue; const [x, y, ts] = e.rift; const a = eBack(inv(ts, ts + 0.3, s)) * (1 - inv(e.spawn + 0.8, e.spawn + 1.3, s));
    if (a <= 0.01) continue;
    g.save(); g.translate(x, y); g.rotate(-0.4); g.scale(a, a);
    g.shadowColor = C.coral; g.shadowBlur = 30; g.beginPath(); g.ellipse(0, 0, 70, 16, 0, 0, 7); g.fillStyle = '#12060c'; g.fill(); g.shadowBlur = 0;
    g.lineWidth = 5; g.strokeStyle = C.coral; g.stroke(); g.restore();
  }
}
function enemyPos(e, s) {
  let x, y;
  if (e.orbit) { const a = e.orbit.a0 + s * 0.9; x = e.orbit.c[0] + Math.cos(a) * e.orbit.R; y = e.orbit.c[1] + Math.sin(a) * e.orbit.R * 0.62; }
  else {
    const st = e.stun && s >= e.stun[0] && s < e.stun[1] ? e.stun[0] : s;
    x = e.x + Math.sin(st * 1.4 + e.ph) * 14; y = e.y + Math.cos(st * 1.1 + e.ph * 1.7) * 10;
  }
  const t = s - e.spawn;
  if (e.from && t < 0.45) { const u = eOut(t / 0.45); x = lerp(e.from[0], x, u); y = lerp(e.from[1], y, u); }
  for (const h of e.hits) {
    const dt = s - h.t; if (dt < 0 || dt > 0.6 || h.parry) continue;
    const dir = e.x > 380 ? 1 : -1; const kb = (h.big ? 34 : 20) * Math.exp(-dt / 0.09);
    x += dir * kb; y -= kb * 0.4;
  }
  return [x, y];
}
function enemyDeath(e) { const k = e.hits.find((h) => h.kill); return k ? k.t : 99; }
function drawEnemy(g, e, s, vt) {
  if (s < e.spawn) return;
  const dT = enemyDeath(e); if (s >= dT) return;
  const [x, y] = enemyPos(e, s), [x2, y2] = enemyPos(e, s + 0.03);
  const a = { id: e.id, x, y, vx: (x2 - x) / 0.03, vy: (y2 - y) / 0.03 + 70, r: e.r };
  const em = eBack(inv(e.spawn, e.spawn + 0.3, s));
  drawWisp(g, a, vt, em);
  if (e.kind === 'brute') { // horns + second eye
    g.save(); g.translate(x, y); g.scale(em, em); g.fillStyle = '#2b1d22'; g.strokeStyle = C.ink; g.lineWidth = 4;
    for (const sx of [-1, 1]) { g.beginPath(); g.moveTo(sx * e.r * 0.35, -e.r * 0.8); g.lineTo(sx * e.r * 0.85, -e.r * 1.55); g.lineTo(sx * e.r * 0.7, -e.r * 0.6); g.closePath(); g.fill(); g.stroke(); }
    g.fillStyle = '#fff'; g.beginPath(); for (let i = 0; i <= 8; i++) { const xx = -e.r * 0.45 + i * e.r * 0.1125; g.lineTo(xx, e.r * 0.42 + (i % 2 ? 10 : 0)); } g.lineTo(e.r * 0.45, e.r * 0.3); g.lineTo(-e.r * 0.45, e.r * 0.3); g.closePath(); g.fill(); g.stroke();
    g.restore();
  }
  // hit flash
  for (const h of e.hits) { const dt = s - h.t; if (dt >= 0 && dt < 0.07 && !h.parry) { g.fillStyle = 'rgba(255,255,255,0.85)'; g.beginPath(); g.arc(x, y, e.r * 1.05, 0, 7); g.fill(); } }
  // stunned stars
  if (e.stun && s >= e.stun[0] && s < e.stun[1]) for (let i = 0; i < 3; i++) { const an = vt * 5 + i * 2.1; star4(g, x + Math.cos(an) * e.r * 1.1, y - e.r * 1.3 + Math.sin(an) * 10, 10, C.gold); }
}
function drawTelegraphs(g, s, vt) {
  const list = ENEMIES.filter((e) => e.tele).map((e) => e.tele).concat([BOSS.tele]);
  for (const T of list) {
    const pre = inv(T.t0, T.t0 + 0.12, s); if (pre <= 0) continue;
    const [x, y] = T.at;
    if (s < T.t1) {
      const ringR = lerp(110, 46, inv(T.t0, T.t1, s));
      g.save(); g.translate(x, y); g.scale(eBack(pre), eBack(pre));
      g.beginPath(); for (let i = 0; i < 18; i++) { const an = (i / 18) * Math.PI * 2, rr = i % 2 ? 44 : 58; g.lineTo(Math.cos(an) * rr, Math.sin(an) * rr * 0.85); } g.closePath();
      g.fillStyle = '#d6303a'; g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
      text(g, '!', 0, 22, { font: FONT.dela, size: 60, color: '#fff', align: 'center' });
      g.restore();
      g.save(); g.lineWidth = 5; g.strokeStyle = `rgba(255,255,255,${0.9})`; g.setLineDash([12, 8]); g.beginPath(); g.arc(x, y, ringR, 0, 7); g.stroke(); g.restore();
      g.save(); g.lineWidth = 3; g.strokeStyle = C.ink; g.beginPath(); g.arc(x, y, 46, 0, 7); g.stroke(); g.restore();
    } else {
      const age = s - T.t1; if (age > 0.7) continue;
      const R = lerp(30, 150, eOut(age / 0.35));
      g.save(); g.globalAlpha = 1 - inv(0.25, 0.7, age);
      const gr = g.createRadialGradient(x - R * 0.3, y - R * 0.3, R * 0.1, x, y, R);
      gr.addColorStop(0, 'rgba(255,220,236,0.85)'); gr.addColorStop(0.7, 'rgba(239,155,204,0.6)'); gr.addColorStop(1, 'rgba(214,96,150,0.7)');
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, R, 0, 7); g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
      g.restore();
      sfx(g, 'ポンッ', x - 40, y - 90, 58, age * 60, { life: 40, rot: -0.15, color: C.sakura });
      text(g, 'PERFECT PARRY', x, y + 120, { font: FONT.dela, size: 32, color: '#fff', align: 'center', stroke: 10, strokeColor: C.ink, alpha: 1 - inv(0.5, 0.7, age) });
    }
  }
}
function drawKunai(g, s, vt) {
  for (const tp of TAPS) {
    if (!tp.kunai) continue; const fl = 0.12; const age = s - tp.t; if (age < 0) continue;
    const [fx, fy] = tp.from; const [tx, ty] = tp.at;
    let alive;
    if (typeof tp.kunai === 'number') { const e = ENEMIES.find((q) => q.id === tp.kunai); alive = s < enemyDeath(e) + 0.02; }
    else alive = s < SPLASH[0];
    if (!alive && age > fl) continue;
    const u = clamp(age / fl);
    let x = lerp(fx, tx, u), y = lerp(fy, ty, u) - Math.sin(u * Math.PI) * 40;
    let ang = Math.atan2(ty - fy, tx - fx);
    if (u >= 1 && typeof tp.kunai === 'number') { const e = ENEMIES.find((q) => q.id === tp.kunai); const [ex, ey] = enemyPos(e, s); x = ex + (fx > tx ? 14 : -14); y = ey - 6; }
    const kh = 86, kw = kh * ART.kunai.width / ART.kunai.height;
    g.save(); g.translate(x, y); g.rotate(ang - Math.PI / 2 + Math.PI); g.drawImage(ART.kunai, -kw / 2, -kh * 0.2, kw, kh); g.restore();
    if (u < 1) { g.save(); g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = 3; g.beginPath(); g.moveTo(lerp(fx, tx, Math.max(0, u - 0.4)), lerp(fy, ty, Math.max(0, u - 0.4))); g.lineTo(x, y); g.stroke(); g.restore(); }
  }
}
function clawPath(sw, u0, u1, off) {
  const [ax, ay] = sw.a, [bx, by] = sw.b; const dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy); const nx = -dy / L, ny = dx / L;
  const pts = [];
  for (let i = 0; i <= 20; i++) { const u = lerp(u0, u1, i / 20); const bend = Math.sin(u * Math.PI) * 26; pts.push([ax + dx * u + nx * (off + bend), ay + dy * u + ny * (off + bend), u]); }
  return { pts, nx, ny };
}
function taper(g, pts, nx, ny, wmax) {
  g.beginPath();
  pts.forEach(([x, y, u], i) => { const w = wmax * Math.pow(Math.sin(Math.PI * clamp((u - pts[0][2]) / Math.max(1e-3, pts[pts.length - 1][2] - pts[0][2]))), 0.7); i ? g.lineTo(x + nx * w, y + ny * w) : g.moveTo(x + nx * w, y + ny * w); });
  for (let i = pts.length - 1; i >= 0; i--) { const [x, y, u] = pts[i]; const w = wmax * Math.pow(Math.sin(Math.PI * clamp((u - pts[0][2]) / Math.max(1e-3, pts[pts.length - 1][2] - pts[0][2]))), 0.7); g.lineTo(x - nx * w, y - ny * w); }
  g.closePath();
}
function drawClaws(g, sw, s, scale = 1) {
  const p = eOut(inv(sw.t, sw.t + sw.d, s)); const fade = 1 - inv(sw.t + sw.d + 0.05, sw.t + sw.d + 0.42, s);
  if (p <= 0 || fade <= 0) return;
  g.save(); g.globalAlpha = fade;
  for (const off of [-28, 0, 28]) {
    const { pts, nx, ny } = clawPath(sw, 0, p, off * scale);
    if (pts.length < 2) continue;
    g.lineJoin = 'round';
    taper(g, pts, nx, ny, 15 * scale); g.lineWidth = 7 * scale; g.strokeStyle = C.ink; g.stroke(); g.fillStyle = C.coral; g.fill();
    taper(g, pts, nx, ny, 6 * scale); g.fillStyle = '#fff'; g.fill();
  }
  g.restore();
}
function drawCardBurst(g, s, vt) {
  const t0 = 17.25; const age = s - t0; if (age < 0 || age > 0.9) return;
  const big = [{ t: t0, d: 0.16, a: [60, 1960], b: [700, 2330] }, { t: t0 + 0.06, d: 0.16, a: [700, 1950], b: [60, 2340] }, { t: t0 + 0.12, d: 0.16, a: [40, 2150], b: [720, 2140] }];
  if (age < 0.25) { const R = lerp(20, 520, eOut(age / 0.25)); g.save(); g.globalAlpha = 1 - age / 0.25; const gr = g.createRadialGradient(380, 2150, 10, 380, 2150, R); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(244,87,94,0)'); g.fillStyle = gr; g.beginPath(); g.arc(380, 2150, R, 0, 7); g.fill(); g.restore(); }
  for (const sw of big) drawClaws(g, sw, s, 2.4);
  speedLines(g, 380, 2150, 80, 700, 80, 33, 0.5 * (1 - age / 0.9), C.ink, 1.2);
  sfx(g, 'ザンッ', 520, 2010, 110, age * 60, { life: 50, rot: -0.12, color: C.coral });
  text(g, 'RESONANCE CLAW', 380, 2300, { font: FONT.dela, size: 42, color: '#fff', align: 'center', stroke: 12, strokeColor: C.ink, alpha: 1 - inv(0.6, 0.9, age) });
}
function neroPathPos(d, u) {
  const P = d.path; const segs = P.length - 1; const f = clamp(u) * segs; const i = Math.min(segs - 1, Math.floor(f)); const t = f - i;
  return [lerp(P[i][0], P[i + 1][0], t), lerp(P[i][1], P[i + 1][1], t)];
}
function drawNeroDrag(g, d, s, vt) {
  if (s < d.appear || s > d.t + d.d + 0.45) return;
  const u = eIO(inv(d.t, d.t + d.d, s));
  const [x, y] = neroPathPos(d, u); const [x2, y2] = neroPathPos(d, u + 0.02);
  // golden trail
  g.save(); g.lineCap = 'round';
  for (let k = 0; k < 14; k++) { const uu = u - k * 0.025; if (uu < 0) break; const [tx, ty] = neroPathPos(d, uu); g.fillStyle = `rgba(242,180,60,${0.55 * (1 - k / 14)})`; g.beginPath(); g.arc(tx, ty, 40 * (1 - k / 16), 0, 7); g.fill(); }
  g.restore();
  const appear = eBack(inv(d.appear, d.appear + 0.2, s)); const out = 1 - inv(d.t + d.d + 0.15, d.t + d.d + 0.45, s);
  drawNero(g, { id: 99, x, y, vx: (x2 - x) * 40 + 1, vy: (y2 - y) * 40, r: 46 * appear * out }, vt, 1);
  if (s < d.appear + 0.3) sfx(g, 'ドンッ', x + 60, y - 60, 52, (s - d.appear) * 60, { life: 24, color: C.gold });
  if (d.strike) { const age = s - d.strike; if (age >= 0 && age < 0.8) { sfx(g, 'ドンッ!!', 470, 2700, 104, age * 60, { life: 48, color: C.gold }); speedLines(g, 380, 2790, 90, 700, 90, 51, 0.5 * (1 - age / 0.8), C.ink, 1.2); } }
}
function drawHitFX(g, s, vt) {
  for (const h of HITS) {
    const age = s - h.t; if (age < 0 || age > 0.9) continue;
    let x, y;
    if (h.e) [x, y] = enemyPos(h.e, Math.min(s, enemyDeath(h.e) - 0.001));
    else if (h.eye) [x, y] = EYES.find((q) => q.id === h.eye).c;
    else if (h.splash) continue;
    else [x, y] = [BOSS.x + (h.nero ? 0 : (hash(h.t * 9) - 0.5) * 160), BOSS.y - 60];
    if (h.dmg > 0) {
      const val = h.boss ? Math.round(h.dmg * 12000) : h.dmg;
      text(g, `${val}`, x + 20, y - 40 - age * 70, { font: FONT.dela, size: h.boss ? 46 : 34, color: h.boss ? C.gold : '#fff', align: 'center', stroke: 9, strokeColor: C.ink, alpha: 1 - inv(0.55, 0.9, age) });
    }
    if (h.kill && h.e) {
      // ink burst
      for (let i = 0; i < 14; i++) { const an = hash(h.t * 31 + i) * 7, sp = (60 + 160 * hash(i * 2 + h.t)) * eOut(age / 0.5); g.fillStyle = i % 4 === 0 ? C.coral : C.ink; g.globalAlpha = 1 - inv(0.3, 0.6, age); g.beginPath(); g.arc(x + Math.cos(an) * sp, y + Math.sin(an) * sp, (5 + 9 * hash(i + h.t)) * (1 - age), 0, 7); g.fill(); g.globalAlpha = 1; }
      if (h.src === 'claw') sfx(g, 'ザシュッ', x + 10, y - 70, h.big ? 80 : 60, age * 60, { life: 36, rot: -0.15, color: C.coral });
      if (h.src === 'kunai') sfx(g, 'シュッ', x - 10, y - 66, h.big ? 72 : 52, age * 60, { life: 34, rot: -0.12, color: C.sakura });
    }
  }
  // combo pop near the action
  const c = comboAt(s); const last = HITS.filter((h) => h.t <= s).pop();
  if (last && c >= 3 && s - last.t < 0.7 && !last.splash) {
    const [x, y] = last.e ? enemyPos(last.e, Math.min(s, enemyDeath(last.e) - 0.001)) : [BOSS.x, BOSS.y - 220];
    const age = s - last.t; const k = age < 0.1 ? lerp(1.5, 1, age / 0.1) : 1;
    g.save(); g.translate(clamp(x - 150, 120, 640), y + 110); g.rotate(-0.08); g.scale(k, k); g.globalAlpha = 1 - inv(0.5, 0.7, age);
    sfxText(g, `${c} HIT`, 0, 0, 40, 2); g.restore();
  }
}
function drawPrompt(g, p, s) {
  const a = inv(p.t0, p.t0 + 0.12, s) * (1 - inv(p.t1 - 0.05, p.t1 + 0.1, s)); if (a <= 0) return;
  const [x, y] = p.at;
  g.save(); g.translate(x, y); g.scale(eBack(inv(p.t0, p.t0 + 0.2, s)), eBack(inv(p.t0, p.t0 + 0.2, s))); g.globalAlpha = a;
  g.font = `30px ${FONT.dela}`; const w = g.measureText(p.text).width + 54; const h = 64;
  g.beginPath(); g.ellipse(0, 0, w / 2 + 10, h / 2 + 8, 0, 0, 7); g.moveTo(-20, h / 2); g.lineTo(-44, h / 2 + 36); g.lineTo(6, h / 2 + 4); g.closePath();
  g.fillStyle = '#fff'; g.fill(); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
  text(g, p.text, 0, 11, { font: FONT.dela, size: 30, color: C.ink, align: 'center' });
  g.restore();
}
function heroArt2(h) { return h === 'shojo' ? ART.heroShojo : h === 'nero' ? ART.heroNero : ART.heroShonen; }
function heroActT(h, s) {
  let t = -9;
  if (h === 'shonen') for (const sw of SWIPES) if (sw.t <= s) t = sw.t;
  if (h === 'shojo') for (const tp of TAPS) if (tp.t <= s && (tp.kunai || tp.parry)) t = tp.t;
  if (h === 'nero') for (const d of DRAGS) if (d.nero && d.t <= s) t = d.t;
  return t;
}
function drawHeroInset(g, ins, s, vt) {
  if (s < ins.t0 || s > ins.t1) return;
  const h = ins.hero === 'active' ? heroAt(s) : ins.hero;
  const [x0, y0, x1, y1] = bboxOf(ins.poly);
  const act = s - heroActT(h, s); const pulse = act >= 0 && act < 0.3 ? 1 - act / 0.3 : 0;
  const sw = ins.hero === 'active' ? s - heroSwapT(s) : 9; const flip = sw < 0.25 ? Math.abs(Math.cos((sw / 0.25) * Math.PI)) : 1;
  const intro = eOut(inv(ins.t0, ins.t0 + 0.4, s));
  g.save();
  polyPath(g, ins.poly); g.lineWidth = 16; g.strokeStyle = '#fff'; g.stroke();
  g.save(); polyPath(g, ins.poly); g.clip();
  g.fillStyle = h === 'shojo' ? C.navy : h === 'nero' ? C.coral : '#2a2030'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  const cx = (x0 + x1) / 2; g.translate(cx, 0); g.scale(flip, 1); g.translate(-cx, 0);
  cover(g, heroArt2(h), x0, y0, x1, y1, (1.0 + 0.08 * pulse) * lerp(1.2, 1, intro), -10 * pulse, 0);
  if (pulse > 0) { speedLines(g, cx, (y0 + y1) / 2, 30, 500, 50, 11, 0.6 * pulse, '#fff', 1); g.fillStyle = `rgba(255,255,255,${0.35 * pulse})`; g.fillRect(x0, y0, x1 - x0, y1 - y0); }
  g.restore();
  polyPath(g, ins.poly); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
  g.restore();
}
function drawBoss(g, s, vt) {
  if (s < BOSS.rise[0] - 0.4 || s >= BOSS.die) return;
  const u = eOut(inv(BOSS.rise[0], BOSS.rise[1], s));
  const R = 200 * lerp(0.55, 1, u) * (1 + 0.02 * Math.sin(vt * 2.2));
  const x = BOSS.x, y = BOSS.y + (1 - u) * 300;
  g.save(); polyPath(g, PM.P7.poly); g.clip();
  // tendrils reaching into the insets and borders
  const tips = [[182, 2537], [587, 3052], [60, 2800], [720, 2700], [380, 2420], [690, 3150], [110, 3100]];
  tips.forEach(([tx, ty], i) => {
    const w = Math.sin(vt * 2 + i) * 40;
    g.beginPath(); g.moveTo(x, y); g.bezierCurveTo(x + (tx - x) * 0.3 + w, y + (ty - y) * 0.1 - w, x + (tx - x) * 0.7 - w, y + (ty - y) * 0.8 + w, lerp(x, tx, u), lerp(y, ty, u));
    g.lineCap = 'round'; g.lineWidth = 30; g.strokeStyle = C.ink; g.stroke(); g.lineWidth = 12; g.strokeStyle = '#5a1624'; g.stroke(); g.lineWidth = 4; g.strokeStyle = C.coral; g.stroke();
  });
  // flame crown
  for (let pass = 0; pass < 2; pass++) for (let i = 0; i < 13; i++) {
    const an = -Math.PI / 2 + (i - 6) * 0.22 + Math.sin(vt * 2 + i) * 0.05; const L = R * (0.45 + 0.4 * noise1(vt * 3 + i));
    const b0 = [x + Math.cos(an - 0.1) * R * 0.9, y + Math.sin(an - 0.1) * R * 0.9], b1 = [x + Math.cos(an + 0.1) * R * 0.9, y + Math.sin(an + 0.1) * R * 0.9];
    const tip = [x + Math.cos(an) * (R + L), y + Math.sin(an) * (R + L) - 20];
    g.beginPath(); g.moveTo(...b0); g.quadraticCurveTo(x + Math.cos(an - 0.15) * (R + L * 0.6), y + Math.sin(an - 0.15) * (R + L * 0.6), ...tip); g.quadraticCurveTo(x + Math.cos(an + 0.15) * (R + L * 0.4), y + Math.sin(an + 0.15) * (R + L * 0.4), ...b1); g.closePath();
    if (pass === 0) { g.lineWidth = 8; g.strokeStyle = C.ink; g.stroke(); } else { g.fillStyle = i % 3 ? C.coral : '#ff9a8f'; g.fill(); }
  }
  // body
  g.beginPath(); for (let i = 0; i <= 40; i++) { const th = (i / 40) * Math.PI * 2; const rr = R * (1 + 0.06 * Math.sin(th * 4 + vt * 3) + 0.04 * Math.sin(th * 7 - vt * 2)); i ? g.lineTo(x + Math.cos(th) * rr, y + Math.sin(th) * rr) : g.moveTo(x + Math.cos(th) * rr, y + Math.sin(th) * rr); }
  g.closePath(); const gr = g.createRadialGradient(x - R * 0.3, y - R * 0.4, R * 0.1, x, y, R); gr.addColorStop(0, '#4a2238'); gr.addColorStop(0.6, '#1c0f18'); gr.addColorStop(1, '#0b070a');
  g.fillStyle = gr; g.fill(); g.lineWidth = 8; g.strokeStyle = C.ink; g.stroke();
  g.strokeStyle = 'rgba(255,190,190,0.5)'; g.lineWidth = 5; g.beginPath(); g.arc(x, y, R * 0.82, Math.PI * 1.05, Math.PI * 1.4); g.stroke();
  // eyes (look toward the active hero inset)
  const look = Math.atan2(3080 - y, 150 - x);
  const eyes = [[0, -20, 58], [-92, -70, 32], [96, -82, 36], [-120, 40, 24], [128, 30, 26]];
  eyes.forEach(([ex, ey, er], i) => {
    const blink = (Math.sin(vt * 1.3 + i * 2) > 0.985) ? 0.15 : 1;
    g.save(); g.translate(x + ex * R / 200, y + ey * R / 200); const rr = er * R / 200;
    g.beginPath(); g.moveTo(-rr, 0); g.quadraticCurveTo(0, -rr * 0.75 * blink, rr, 0); g.quadraticCurveTo(0, rr * 0.6 * blink, -rr, 0); g.closePath();
    g.fillStyle = C.gold; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
    g.fillStyle = C.ink; g.beginPath(); g.ellipse(Math.cos(look) * rr * 0.25, Math.sin(look) * rr * 0.1, rr * 0.12, rr * 0.5 * blink, 0, 0, 7); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(-rr * 0.25, -rr * 0.2 * blink, rr * 0.12, 0, 7); g.fill();
    g.restore();
  });
  // jagged mouth
  g.save(); g.translate(x, y + R * 0.45); g.beginPath(); g.moveTo(-R * 0.45, 0); for (let i = 0; i <= 12; i++) g.lineTo(-R * 0.45 + i * R * 0.075, i % 2 ? R * 0.14 : 0); g.lineTo(R * 0.45, 0); g.quadraticCurveTo(0, R * 0.32, -R * 0.45, 0); g.closePath();
  g.fillStyle = '#5a1624'; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
  g.fillStyle = '#fff'; for (let i = 0; i < 12; i++) { const xx = -R * 0.45 + i * R * 0.075; g.beginPath(); g.moveTo(xx, 0); g.lineTo(xx + R * 0.0375, R * 0.1); g.lineTo(xx + R * 0.075, 0); g.fill(); }
  g.restore();
  // orbiting redaction bars
  for (let i = 0; i < 4; i++) { const an = vt * 0.7 + i * 1.57; g.save(); g.translate(x + Math.cos(an) * R * 1.35, y + Math.sin(an) * R * 0.95); g.rotate(an * 0.3); g.fillStyle = '#060406'; g.fillRect(-70, -13, 140, 26); g.strokeStyle = '#fff'; g.lineWidth = 2; g.strokeRect(-70, -13, 140, 26); g.restore(); }
  // hit flash
  for (const h of BOSS.hits) { const dt = s - h.t; if (dt >= 0 && dt < 0.08 && !h.parry) { g.fillStyle = h.nero ? 'rgba(242,180,60,0.7)' : 'rgba(255,255,255,0.6)'; g.beginPath(); g.arc(x, y, R * 1.05, 0, 7); g.fill(); } }
  g.restore();
  if (s < BOSS.rise[1] + 0.8 && s > BOSS.rise[0]) sfx(g, 'ゴゴゴゴ', 600, 2470, 54, (s - BOSS.rise[0]) * 60, { life: 100, rot: 0.12, color: C.ink, outer: C.paper });
}
function drawEyeInset(g, ey, s, vt) {
  if (s < 19.5 || s >= BOSS.die) return;
  const a = eBack(inv(19.5, 19.8, s));
  const [x0, y0, x1, y1] = bboxOf(ey.poly); const [cx, cy] = ey.c;
  g.save(); g.translate(cx, cy); g.scale(a, a); g.translate(-cx, -cy);
  polyPath(g, ey.poly); g.lineWidth = 16; g.strokeStyle = '#fff'; g.stroke();
  g.save(); polyPath(g, ey.poly); g.clip();
  g.fillStyle = '#12070c'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
  for (let i = 0; i < 8; i++) { g.strokeStyle = 'rgba(214,48,58,0.6)'; g.lineWidth = 3; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + Math.cos(i) * 200, cy + Math.sin(i * 1.3) * 120); g.stroke(); }
  const hit = s >= ey.hitT;
  const rr = 82;
  g.save(); g.translate(cx, cy);
  const open = hit ? 0.12 : 1 - (Math.sin(vt * 1.7 + cx) > 0.98 ? 0.8 : 0);
  g.beginPath(); g.moveTo(-rr, 0); g.quadraticCurveTo(0, -rr * 0.8 * open, rr, 0); g.quadraticCurveTo(0, rr * 0.65 * open, -rr, 0); g.closePath();
  g.fillStyle = C.gold; g.fill(); g.lineWidth = 6; g.strokeStyle = C.ink; g.stroke();
  if (!hit) { g.fillStyle = C.ink; g.beginPath(); g.ellipse(Math.sin(vt * 2) * 10, 0, 10, rr * 0.5, 0, 0, 7); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(-22, -16, 9, 0, 7); g.fill(); }
  else { g.strokeStyle = C.coral; g.lineWidth = 7; g.beginPath(); g.moveTo(-60, -40); g.lineTo(60, 40); g.moveTo(60, -40); g.lineTo(-60, 40); g.stroke(); }
  g.restore();
  if (hit && s - ey.hitT < 0.6) sfx(g, 'バキッ', cx, cy - 60, 56, (s - ey.hitT) * 60, { life: 36, color: '#fff', outer: C.coral });
  g.restore();
  polyPath(g, ey.poly); g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke();
  g.restore();
}

// ---------------- HUD ----------------
const HAND = [
  { title: 'RESONANCE CLAW', sub: 'SHONEN · AOE', art: 'cardClaw' },
  { title: 'KUNAI RAIN', sub: 'SHOJO · MULTI', art: 'cardKunai' },
  { title: 'NERO PHASE', sub: 'NERO · PIERCE', art: 'heroNero', frame: 'purple' },
];
function castSlot(i) {
  if (!VERT) return { x: 96 + 64, y: 268 + i * 196 + 88, w: 128, h: 176 };
  return { x: 70 + i * 108 + 48, y: 1790, w: 96, h: 134 };
}
function handSlot(i) {
  if (!VERT) return { x: 1514 + i * 128, y: 880, w: 116, h: 162, rot: (i - 1) * 0.07 };
  return { x: 712 + i * 112, y: 1790, w: 98, h: 136, rot: (i - 1) * 0.06 };
}
const HEROES = ['shonen', 'shojo', 'nero'];
const HERO_INFO = { shonen: ['SHONEN', 'VANGUARD', 'SWIPE'], shojo: ['SHOJO', 'CATALYST', 'TAP'], nero: ['NERO', 'ANOMALY', 'DRAG'] };
function drawHUD2(g, s, vt, alpha) {
  if (alpha <= 0) return;
  g.save(); g.globalAlpha = alpha;
  const active = heroAt(s);
  if (!VERT) {
    const lw = 260, lh = lw * IMG.logoL.height / IMG.logoL.width;
    g.drawImage(IMG.logoL, 96, 46, lw, lh);
    text(g, 'CHAPTER BREAK', 100, 46 + lh + 40, { font: FONT.dela, size: 32, color: C.coral, ls: 2 });
    text(g, 'KUROKAWA · CHAPTER 01', 102, 46 + lh + 70, { font: FONT.mono, size: 15, color: '#bdb6c4', ls: 3 });
  } else {
    const lw = 220, lh = lw * IMG.logoL.height / IMG.logoL.width;
    g.drawImage(IMG.logoL, 50, 64, lw, lh);
    text(g, 'CHAPTER BREAK', 54, 64 + lh + 40, { font: FONT.dela, size: 30, color: C.coral, ls: 2 });
  }
  // team (cast) cards
  HEROES.forEach((h, i) => {
    const sl = castSlot(i); const on = h === active; const sw = s - heroSwapT(s);
    const k = on ? 1 + 0.06 * eOut(clamp(sw / 0.2)) : 0.94;
    g.save(); g.translate(sl.x, sl.y); g.scale(k, k);
    if (on) { g.shadowColor = C.coral; g.shadowBlur = 30; }
    g.globalAlpha *= on ? 1 : 0.55;
    drawCardFront(g, -sl.w / 2, -sl.h / 2, sl.w, sl.h, { art: heroArt2(h), title: VERT ? null : null, frame: h === 'nero' ? 'purple' : 'coral' });
    g.restore();
    if (!VERT) {
      const lx = 244, ly = sl.y - sl.h / 2;
      text(g, HERO_INFO[h][0], lx, ly + 42, { font: FONT.dela, size: 26, color: on ? '#fff' : '#8b8291' });
      text(g, HERO_INFO[h][1], lx, ly + 68, { font: FONT.mono, size: 14, color: '#bdb6c4', ls: 2 });
      rrect(g, lx, ly + 84, 96, 28, 14); g.fillStyle = on ? C.coral : '#2a2230'; g.fill();
      text(g, HERO_INFO[h][2], lx + 48, ly + 104, { font: FONT.mono, size: 15, color: '#fff', align: 'center', ls: 2 });
      drawMeter(g, lx, ly + 128, 200, 12, 1, vt);
      if (on) text(g, 'ACTIVE', lx + 108, ly + 104, { font: FONT.mono, size: 13, color: C.coral, ls: 2 });
    } else {
      text(g, HERO_INFO[h][2], sl.x, sl.y + sl.h / 2 + 26, { font: FONT.mono, size: 16, color: on ? C.coral : '#8b8291', align: 'center', ls: 2 });
    }
  });
  // hand
  HAND.forEach((c, i) => {
    let card = c; const sl = handSlot(i);
    if (i === 0) {
      if (s >= DRAGS[1].t && s < 18.3) return; // in flight or used
      if (s >= 18.3) { card = { title: 'SPLASH PAGE', sub: 'FINISHER', art: 'cardSplash', frame: 'gold' }; }
    }
    const slideIn = i === 0 && s >= 18.3 ? eOut(inv(18.3, 18.7, s)) : 1;
    g.save(); g.translate(sl.x, sl.y + (1 - slideIn) * 220); g.rotate(sl.rot);
    drawCardFront(g, -sl.w / 2, -sl.h / 2, sl.w, sl.h, { art: ART[card.art], title: VERT ? null : null, frame: card.frame, holo: vt * 0.3 + i * 0.2 });
    g.restore();
    if (!VERT) text(g, card.title, sl.x, sl.y + sl.h / 2 + 26, { font: FONT.mono, size: 12, color: '#d9d2df', align: 'center', ls: 0.5 });
  });
  if (!VERT) {
    text(g, 'TEAM · TAP TO TAG', 98, 256, { font: FONT.mono, size: 14, color: '#8b8291', ls: 2 });
    text(g, 'HAND · DRAG TO CAST', 1452, 776, { font: FONT.mono, size: 14, color: '#8b8291', ls: 2 });
    // minimap of the chapter (webtoon scrollbar)
    text(g, 'CHAPTER 01', 1452, 64, { font: FONT.mono, size: 15, color: '#bdb6c4', ls: 3 });
    drawMinimap(g, s, 1452, 80, 0.094);
    const X = 1560;
    text(g, 'COMBO', X, 96, { font: FONT.mono, size: 15, color: '#bdb6c4', ls: 3 });
    const c = comboAt(s); const lh2 = HITS.filter((h) => h.t <= s).pop(); const pk = lh2 && s - lh2.t < 0.12 ? lerp(1.25, 1, (s - lh2.t) / 0.12) : 1;
    g.save(); g.translate(X, 186); g.scale(pk, pk); text(g, String(c).padStart(2, '0'), 0, 0, { font: FONT.dela, size: 90, color: C.paper }); g.restore();
    text(g, 'SCORE', X, 236, { font: FONT.mono, size: 15, color: '#bdb6c4', ls: 3 });
    text(g, Math.round(scoreAt(s)).toLocaleString('en-US'), X, 280, { font: FONT.dela, size: 36, color: C.paper });
    text(g, 'RESONANCE', X, 326, { font: FONT.mono, size: 15, color: '#bdb6c4', ls: 3 });
    drawMeter(g, X, 340, 270, 18, resAt(s), vt);
    if (resAt(s) >= 1) text(g, 'MAX', X + 270, 326, { font: FONT.dela, size: 18, color: C.coral, align: 'right', alpha: 0.6 + 0.4 * Math.sin(vt * 10) });
    drawLegend(g, s);
  } else {
    text(g, 'COMBO', 1026, 92, { font: FONT.mono, size: 18, color: '#bdb6c4', ls: 3, align: 'right' });
    text(g, String(comboAt(s)).padStart(2, '0'), 1030, 186, { font: FONT.dela, size: 92, color: C.paper, align: 'right' });
    text(g, Math.round(scoreAt(s)).toLocaleString('en-US'), 1026, 236, { font: FONT.dela, size: 32, color: C.paper, align: 'right' });
    text(g, 'RESONANCE', 54, 288, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
    drawMeter(g, 54, 300, 520, 18, resAt(s), vt);
    text(g, 'TEAM', 70, 1696, { font: FONT.mono, size: 15, color: '#8b8291', ls: 3 });
    text(g, 'HAND', 664, 1696, { font: FONT.mono, size: 15, color: '#8b8291', ls: 3 });
  }
  g.restore();
}
function drawMinimap(g, s, X, Y, k) {
  g.save(); g.translate(X, Y); g.scale(k, k);
  g.fillStyle = '#e9e5dc'; g.fillRect(0, 0, 760, 3194);
  for (const p of PANELS) {
    const [x0, y0, x1, y1] = bboxOf(p.poly);
    g.save(); polyPath(g, p.poly); g.clip();
    const rp = p.kind === 'story' ? 1 : p.restoreT != null && s > p.restoreT ? 1 : 0;
    if (p.kind === 'lock') { g.fillStyle = s >= p.shatterT ? '#f5f2ec' : '#140a0f'; g.fillRect(x0, y0, x1 - x0, y1 - y0); }
    else if (rp) cover(g, ART.clean[p.id], x0, y0, x1, y1, 1);
    else { g.fillStyle = p.kind === 'fork' && s >= CHOOSE_T ? '#5a5560' : '#4a1a20'; g.fillRect(x0, y0, x1 - x0, y1 - y0); }
    g.restore();
    polyPath(g, p.poly); g.lineWidth = 14; g.strokeStyle = C.ink; g.stroke();
  }
  const V = view(s); const hh = 500 / V.z;
  g.lineWidth = 26; g.strokeStyle = C.coral; g.strokeRect(10, V.cy - hh, 740, hh * 2);
  g.restore();
}
function curGesture(s) {
  for (const sw of SWIPES) if (s >= sw.t - 0.1 && s <= sw.t + sw.d + 0.2) return 'swipe';
  for (const tp of TAPS) if (s >= tp.t - 0.15 && s <= tp.t + 0.2) return 'tap';
  for (const [t] of HUD_TAPS) if (s >= t - 0.15 && s <= t + 0.2) return 'tap';
  for (const d of DRAGS) if (s >= d.t - 0.1 && s <= d.t + d.d + 0.15) return 'drag';
  if (s >= PINCH.t - 0.1 && s <= PINCH.t + PINCH.d + 0.2) return 'pinch';
  return null;
}
function drawLegend(g, s) {
  const cur = curGesture(s);
  const items = [['swipe', 'SWIPE'], ['tap', 'TAP'], ['drag', 'DRAG'], ['pinch', 'PINCH']];
  text(g, 'CONTROLS', 98, 922, { font: FONT.mono, size: 14, color: '#8b8291', ls: 2 });
  items.forEach(([k, lbl], i) => {
    const x = 128 + i * 92, y = 976; const on = cur === k;
    g.save(); g.translate(x, y); g.scale(on ? 1.15 : 1, on ? 1.15 : 1);
    g.beginPath(); g.arc(0, 0, 30, 0, 7); g.fillStyle = on ? C.coral : '#231c27'; g.fill(); g.lineWidth = 2; g.strokeStyle = on ? '#fff' : '#4a3f52'; g.stroke();
    g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.lineWidth = 3; g.lineCap = 'round';
    if (k === 'swipe') { g.beginPath(); g.moveTo(-14, 10); g.quadraticCurveTo(0, -14, 14, -8); g.stroke(); g.beginPath(); g.moveTo(14, -8); g.lineTo(5, -12); g.moveTo(14, -8); g.lineTo(10, 1); g.stroke(); }
    if (k === 'tap') { g.beginPath(); g.arc(0, 0, 6, 0, 7); g.fill(); g.beginPath(); g.arc(0, 0, 14, 0, 7); g.stroke(); }
    if (k === 'drag') { g.setLineDash([4, 4]); g.beginPath(); g.moveTo(-14, 12); g.lineTo(10, -10); g.stroke(); g.setLineDash([]); g.beginPath(); g.arc(10, -10, 5, 0, 7); g.fill(); }
    if (k === 'pinch') { g.beginPath(); g.moveTo(-4, 4); g.lineTo(-14, 14); g.moveTo(4, -4); g.lineTo(14, -14); g.stroke(); g.beginPath(); g.moveTo(-14, 14); g.lineTo(-14, 6); g.moveTo(-14, 14); g.lineTo(-6, 14); g.moveTo(14, -14); g.lineTo(14, -6); g.moveTo(14, -14); g.lineTo(6, -14); g.stroke(); }
    g.restore();
    text(g, lbl, x, y + 52, { font: FONT.mono, size: 13, color: on ? '#fff' : '#8b8291', align: 'center', ls: 1 });
  });
}

// ---------------- touch cursor (the player's finger) ----------------
function finger(g, x, y, press, alpha, ripple) {
  if (alpha <= 0) return;
  g.save(); g.globalAlpha = alpha;
  if (ripple > 0 && ripple < 1) { g.strokeStyle = `rgba(255,255,255,${1 - ripple})`; g.lineWidth = 4; g.beginPath(); g.arc(x, y, 26 + ripple * 50, 0, 7); g.stroke(); }
  g.shadowColor = 'rgba(0,0,0,0.5)'; g.shadowBlur = 16;
  g.fillStyle = 'rgba(255,255,255,0.88)'; g.beginPath(); g.arc(x, y, 22 * (1 - 0.18 * press), 0, 7); g.fill();
  g.shadowBlur = 0; g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke();
  g.strokeStyle = 'rgba(255,255,255,0.9)'; g.lineWidth = 2.5; g.beginPath(); g.arc(x, y, 32 - 6 * press, 0, 7); g.stroke();
  g.restore();
}
function drawFingers(g, s, V) {
  const fadeIn = (t) => inv(t - 0.2, t - 0.06, s), fadeOut = (t) => 1 - inv(t + 0.06, t + 0.22, s);
  for (const sw of SWIPES) {
    if (s < sw.t - 0.2 || s > sw.t + sw.d + 0.22) continue;
    const u = eOut(inv(sw.t, sw.t + sw.d, s));
    const wx = lerp(sw.a[0], sw.b[0], u), wy = lerp(sw.a[1], sw.b[1], u);
    const [x, y] = w2s(wx, wy, V);
    if (u > 0 && u < 1) { const [ax, ay] = w2s(lerp(sw.a[0], sw.b[0], Math.max(0, u - 0.5)), lerp(sw.a[1], sw.b[1], Math.max(0, u - 0.5)), V); g.save(); g.strokeStyle = 'rgba(255,255,255,0.7)'; g.lineCap = 'round'; g.lineWidth = 12; g.beginPath(); g.moveTo(ax, ay); g.lineTo(x, y); g.stroke(); g.restore(); }
    finger(g, x, y, u > 0 && u < 1 ? 1 : 0, Math.min(fadeIn(sw.t), fadeOut(sw.t + sw.d)), 0);
  }
  for (const tp of TAPS) {
    if (s < tp.t - 0.25 || s > tp.t + 0.3) continue;
    const [x, y] = w2s(tp.at[0], tp.at[1], V);
    finger(g, x, y, Math.max(0, 1 - Math.abs(s - tp.t) / 0.07), Math.min(fadeIn(tp.t), fadeOut(tp.t)), inv(tp.t, tp.t + 0.3, s));
  }
  for (const [t, h] of HUD_TAPS) {
    if (s < t - 0.25 || s > t + 0.3) continue;
    const sl = castSlot(HEROES.indexOf(h));
    finger(g, sl.x, sl.y, Math.max(0, 1 - Math.abs(s - t) / 0.07), Math.min(fadeIn(t), fadeOut(t)), inv(t, t + 0.3, s));
  }
  for (const d of DRAGS) {
    if (s < d.t - 0.25 || s > d.t + d.d + 0.25) continue;
    const u = eIO(inv(d.t, d.t + d.d, s));
    let x, y;
    if (d.nero) { const [wx, wy] = neroPathPos(d, u); [x, y] = w2s(wx, wy, V); }
    else { const sl = handSlot(0); const [tx, ty] = w2s(380, 2150, V); x = lerp(sl.x, tx, u); y = lerp(sl.y, ty, u); }
    if (d.card && s >= d.t && s < d.t + d.d + 0.08) { // the card follows the finger
      const k = lerp(1, 1.5, u); g.save(); g.translate(x, y - 20); g.rotate(lerp(0, -0.12, u)); const sl = handSlot(0);
      drawCardFront(g, -sl.w * k / 2, -sl.h * k / 2, sl.w * k, sl.h * k, { art: ART.cardClaw, holo: s * 0.6 }); g.restore();
    }
    if (u > 0 && u < 1) { g.save(); g.setLineDash([10, 10]); g.strokeStyle = 'rgba(255,255,255,0.75)'; g.lineWidth = 4; g.beginPath(); for (let k2 = 0; k2 <= 10; k2++) { const uu = u * k2 / 10; let px, py; if (d.nero) { const [wx, wy] = neroPathPos(d, uu); [px, py] = w2s(wx, wy, V); } else { const sl = handSlot(0); const [tx, ty] = w2s(380, 2150, V); px = lerp(sl.x, tx, uu); py = lerp(sl.y, ty, uu); } k2 ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke(); g.restore(); }
    finger(g, x, y, u > 0 && u < 1 ? 1 : 0, Math.min(fadeIn(d.t), fadeOut(d.t + d.d)), 0);
  }
  if (s >= PINCH.t - 0.25 && s <= PINCH.t + PINCH.d + 0.2) {
    const u = eIO(inv(PINCH.t, PINCH.t + PINCH.d, s)); const [cx, cy] = w2s(PINCH.at[0], PINCH.at[1], V);
    const off = lerp(30, 190, u) * WIN.s; const al = Math.min(fadeIn(PINCH.t), fadeOut(PINCH.t + PINCH.d));
    for (const sg of [-1, 1]) {
      finger(g, cx + sg * off * 0.7, cy + sg * off * 0.7, u > 0 && u < 1 ? 1 : 0, al, 0);
      g.save(); g.globalAlpha = al * 0.8; g.strokeStyle = '#fff'; g.lineWidth = 5; g.beginPath(); g.moveTo(cx + sg * off * 0.3, cy + sg * off * 0.3); g.lineTo(cx + sg * off * 0.6, cy + sg * off * 0.6); g.stroke(); g.restore();
    }
  }
}

// ---------------- screen-space overlays ----------------
function drawBossBar(g, s) {
  if (s < 19.4 || s >= SPLASH[0]) return;
  const a = inv(19.4, 19.8, s); const hp = clamp(bossHP(s));
  const x = WIN.x + 40, w = WIN.w - 80, y = WIN.y + 34;
  g.save(); g.globalAlpha = a;
  text(g, 'THE REDACTOR', x, y + 4, { font: FONT.dela, size: VERT ? 34 : 28, color: '#fff', stroke: 9, strokeColor: C.ink });
  text(g, 'BOSS · RIFT ANOMALY', x + w, y + 2, { font: FONT.mono, size: VERT ? 18 : 14, color: '#fff', align: 'right', ls: 2, stroke: 6, strokeColor: C.ink });
  rrect(g, x, y + 16, w, 22, 6); g.fillStyle = 'rgba(10,6,10,0.85)'; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
  g.save(); rrect(g, x + 3, y + 19, (w - 6) * hp, 16, 4); g.clip(); const gr = g.createLinearGradient(x, 0, x + w, 0); gr.addColorStop(0, '#8e1f3a'); gr.addColorStop(1, C.coral); g.fillStyle = gr; g.fillRect(x, y + 16, w, 22); g.restore();
  g.restore();
}
function drawSplash(g, s, vt) {
  const [t0, t1] = SPLASH; if (s < t0 || s > t1) return;
  const age = s - t0; const V = view(s);
  const [px0, py0] = w2s(24, 2374, V), [px1, py1] = w2s(736, 3180, V);
  const ex = eOut(inv(0, 0.16, age));
  const rx0 = lerp(px0, 0, ex), ry0 = lerp(py0, 0, ex), rx1 = lerp(px1, W, ex), ry1 = lerp(py1, H, ex);
  g.save(); g.beginPath(); g.rect(rx0, ry0, rx1 - rx0, ry1 - ry0); g.clip();
  g.fillStyle = '#120a0e'; g.fillRect(0, 0, W, H);
  const z = 1.18 - 0.1 * eOut(inv(0, 1.5, age));
  cover(g, ART.splash, rx0, ry0, rx1, ry1, z, VERT ? 140 : 0, VERT ? 0 : 20);
  speedLines(g, (rx0 + rx1) / 2, (ry0 + ry1) / 2, Math.min(W, H) * 0.25, Math.max(W, H), 120, 71, 0.55, C.ink, 1.3);
  speedLines(g, (rx0 + rx1) / 2, (ry0 + ry1) / 2, Math.min(W, H) * 0.3, Math.max(W, H), 60, 72, 0.4, '#fff', 1);
  // boss ink shattering outward
  for (let i = 0; i < 40; i++) { const an = hash(i * 3.3) * 7, sp = (200 + 900 * hash(i * 1.7)) * eOut(age / 1.2); g.fillStyle = i % 5 === 0 ? C.coral : C.ink; g.globalAlpha = 1 - inv(0.8, 1.5, age); g.beginPath(); g.arc(W / 2 + Math.cos(an) * sp, H / 2 + Math.sin(an) * sp * 0.7, (10 + 26 * hash(i)) * (1 - age * 0.4), 0, 7); g.fill(); }
  g.globalAlpha = 1;
  // manga frame
  g.lineWidth = 18; g.strokeStyle = C.ink; g.strokeRect(rx0 + 9, ry0 + 9, rx1 - rx0 - 18, ry1 - ry0 - 18);
  g.lineWidth = 6; g.strokeStyle = '#fff'; g.strokeRect(rx0 + 24, ry0 + 24, rx1 - rx0 - 48, ry1 - ry0 - 48);
  g.restore();
  if (ex >= 1) {
    sfx(g, 'ドンッ!!', W * (VERT ? 0.62 : 0.72), H * (VERT ? 0.2 : 0.24), VERT ? 150 : 170, (age - 0.16) * 60, { life: 200, rot: -0.1, color: C.coral });
    g.save(); g.globalAlpha = inv(0.25, 0.4, age); sfxText(g, 'SPLASH  PAGE', W / 2, H * (VERT ? 0.82 : 0.84), VERT ? 92 : 120, 4); g.restore();
    text(g, 'FINISHER · SHONEN', W / 2, H * (VERT ? 0.82 : 0.84) + (VERT ? 80 : 92), { font: FONT.mono, size: VERT ? 26 : 24, color: '#fff', align: 'center', ls: 6, stroke: 8, strokeColor: C.ink, alpha: inv(0.35, 0.5, age) });
  }
  if (age < 0.05) invertCanvas(g);
  if (age > t1 - t0 - 0.2) { g.fillStyle = `rgba(255,255,255,${inv(t1 - t0 - 0.2, t1 - t0, age)})`; g.fillRect(0, 0, W, H); }
}
function drawCleared(g, s) {
  const t0 = 26.42; const age = s - t0; if (age < 0) return;
  const cx = WIN.x + WIN.w / 2, cy = WIN.y + WIN.h * 0.42;
  const k = lerp(2.2, 1, eOut(inv(0, 0.18, age)));
  g.save(); g.translate(cx, cy); g.rotate(-0.1); g.scale(k, k); g.globalAlpha = inv(0, 0.1, age);
  const w = VERT ? 860 : 700, h = VERT ? 140 : 112;
  rrect(g, -w / 2, -h / 2, w, h, 10); g.fillStyle = 'rgba(255,255,255,0.92)'; g.fill(); g.lineWidth = 10; g.strokeStyle = '#d6303a'; g.stroke();
  text(g, 'CHAPTER CLEARED', 0, h * 0.17, { font: FONT.dela, size: VERT ? 58 : 46, color: '#d6303a', align: 'center', ls: 1 });
  g.restore();
  const a2 = inv(0.25, 0.4, age); const k2 = lerp(2, 1, eOut(inv(0.25, 0.4, age)));
  g.save(); g.translate(cx + (VERT ? 300 : 230), cy + (VERT ? 190 : 150)); g.rotate(0.15); g.scale(k2, k2); g.globalAlpha = a2;
  g.beginPath(); g.arc(0, 0, VERT ? 90 : 72, 0, 7); g.fillStyle = '#d6303a'; g.fill(); g.lineWidth = 6; g.strokeStyle = '#fff'; g.stroke();
  text(g, 'S', 0, VERT ? 36 : 30, { font: FONT.dela, size: VERT ? 104 : 84, color: '#fff', align: 'center' });
  text(g, 'RANK', 0, VERT ? -50 : -40, { font: FONT.mono, size: VERT ? 18 : 14, color: '#fff', align: 'center', ls: 3 });
  g.restore();
}

// ---------------- game scene ----------------
function sceneGame2(g, t, shot) {
  const s = mapTime(shot.keys, t); const vt = t;
  drawBackdrop(g, t);
  const V = view(s);
  // window (page) frame
  g.save(); g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 50; g.shadowOffsetY = 18; g.fillStyle = C.paper; g.fillRect(WIN.x, WIN.y, WIN.w, WIN.h); g.restore();
  g.save(); g.beginPath(); g.rect(WIN.x, WIN.y, WIN.w, WIN.h); g.clip();
  g.translate(WIN.x + WIN.w / 2, WIN.y + WIN.h / 2); g.scale(V.z * WIN.s, V.z * WIN.s); g.translate(-V.cx, -V.cy);
  drawWorld(g, s, vt);
  g.restore();
  drawBossBar(g, s);
  drawCleared(g, s);
  drawHUD2(g, s, vt, shot.hudIn ? inv(shot.hudIn[0], shot.hudIn[1], t) : 1);
  drawFingers(g, s, V);
  // impact frames on big moments
  for (const h of HITS) { const dt = s - h.t; if (dt >= 0 && dt < 0.035 && (h.parry || h.nero || (h.kill && h.e?.kind === 'brute'))) invertCanvas(g); }
  drawSplash(g, s, vt);
}

// ---------------- results / share scenes ----------------
function drawChapterStrip(g, x, y, w, h, scroll, vt) {
  const k = w / 760; const worldH = 3194 * k;
  g.save(); g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 40; g.fillStyle = C.paper; g.fillRect(x, y, w, h); g.restore();
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  g.translate(x, y - scroll * Math.max(0, worldH - h)); g.scale(k, k);
  drawWorld(g, T_END, vt);
  g.restore();
}
function sceneResults(g, t, shot) {
  const u = t - shot.t0, d = shot.t1 - shot.t0;
  drawRedHalftone(g, t, 0.42);
  const scroll = eIO(inv(0.2, d - 0.2, u));
  if (!VERT) drawChapterStrip(g, 150, 40, 430, 1000, scroll, t);
  else drawChapterStrip(g, 250, 70, 580, 1000, scroll, t);
  const tx = VERT ? 90 : 700, ty = VERT ? 1200 : 170;
  text(g, 'CHAPTER 01', tx, ty, { font: FONT.mono, size: VERT ? 24 : 22, color: '#f2c2bf', ls: 5, alpha: inv(0.1, 0.4, u) });
  text(g, 'CLEARED.', tx - 4, ty + (VERT ? 100 : 110), { font: FONT.dela, size: VERT ? 100 : 118, color: '#fff', alpha: inv(0.2, 0.5, u) });
  text(g, 'Every panel you clear restores Zenko’s canon.', tx, ty + (VERT ? 160 : 170), { font: FONT.disp, weight: 500, size: VERT ? 32 : 34, color: '#fff', alpha: inv(0.4, 0.7, u) });
  const stats = [['TIME', RESULT.time], ['MAX COMBO', String(RESULT.combo)], ['PERFECT PARRY', RESULT.parry], ['ROUTE', RESULT.route], ['CARDS', RESULT.cards]];
  stats.forEach(([l, v], i) => {
    const a = eOut(inv(0.5 + i * 0.12, 0.8 + i * 0.12, u)); const col = i % 3, row = Math.floor(i / 3);
    const sx = tx + col * (row ? (VERT ? 440 : 470) : (VERT ? 310 : 330)), sy = ty + (VERT ? 250 : 270) + row * (VERT ? 120 : 130);
    g.save(); g.globalAlpha = a; g.translate((1 - a) * 30, 0);
    text(g, l, sx, sy, { font: FONT.mono, size: VERT ? 18 : 17, color: '#d9c2c4', ls: 3 });
    text(g, v, sx, sy + (VERT ? 56 : 58), { font: FONT.dela, size: VERT ? 46 : 50, color: '#fff' });
    g.restore();
  });
  // rank stamp
  const ra = inv(1.2, 1.4, u); const rk = lerp(2.2, 1, eOut(inv(1.2, 1.4, u)));
  g.save(); g.translate(VERT ? 900 : 1680, VERT ? 1290 : 230); g.rotate(0.14); g.scale(rk, rk); g.globalAlpha = ra;
  g.beginPath(); g.arc(0, 0, 100, 0, 7); g.fillStyle = '#d6303a'; g.fill(); g.lineWidth = 8; g.strokeStyle = '#fff'; g.stroke();
  text(g, 'RANK', 0, -54, { font: FONT.mono, size: 18, color: '#fff', align: 'center', ls: 4 }); text(g, 'S', 0, 46, { font: FONT.dela, size: 120, color: '#fff', align: 'center' });
  g.restore();
  // cards earned
  const cards = [{ art: ART.cardSplash, title: 'SPLASH PAGE', frame: 'gold' }, { art: ART.heroNero, title: 'NERO PHASE', frame: 'purple' }, { art: ART.cardClaw, title: 'RESONANCE CLAW' }];
  const fx = VERT ? W / 2 : 1240, fy = VERT ? 1760 : 870;
  cards.forEach((c, i) => {
    const st = 1.0 + i * 0.12; const k = eBack(inv(st, st + 0.4, u)); if (k <= 0) return;
    const cw = VERT ? 150 : 170, ch = cw * 1.4; const ang = (i - 1) * 0.13 * k;
    drawCard(g, fx + (i - 1) * (VERT ? 170 : 190), fy + (1 - k) * 260 + Math.abs(i - 1) * 14, cw, ch, clamp((u - st) / 0.4), { art: c.art, title: c.title, frame: c.frame, holo: t * 0.4 + i * 0.2 }, ang);
  });
  if (!VERT) text(g, 'CARDS EARNED', 1050, 712, { font: FONT.mono, size: 16, color: '#d9c2c4', ls: 3, alpha: inv(1.0, 1.3, u) });
}
function sceneShare2(g, t, shot) {
  const u = t - shot.t0;
  drawBackdrop(g, t, 0.85);
  const pw = VERT ? 960 : 1000, ph = VERT ? 1060 : 900, px = (W - pw) / 2, py = VERT ? 380 : 80;
  const pu = eOut(inv(0, 0.35, u));
  g.save(); g.globalAlpha = pu; g.translate(0, (1 - pu) * 40);
  rrect(g, px, py, pw, ph, 26); g.fillStyle = '#0f0f12'; g.fill(); g.strokeStyle = '#2c2c33'; g.lineWidth = 2; g.stroke();
  g.fillStyle = C.card; g.beginPath(); g.arc(px + 70, py + 72, 34, 0, 7); g.fill();
  text(g, 'h', px + 70, py + 84, { font: FONT.dela, size: 32, color: '#111', align: 'center' });
  text(g, 'holder_07', px + 122, py + 66, { font: FONT.ui, weight: 700, size: 26, color: '#fff' });
  text(g, '@holder_07 · now', px + 122, py + 98, { font: FONT.ui, size: 22, color: '#7d7d86' });
  ['Cleared Chapter 01 of Kurokawa. Rank S in 0:26.4,', 'max combo 24, took the ROOFTOP fork.', 'Your move. #ZENKO #ChapterBreak'].forEach((l, i) => text(g, l, px + 50, py + 168 + i * 40, { font: FONT.ui, size: VERT ? 28 : 28, color: '#f1f1f4' }));
  g.restore();
  const ca = eOut(inv(0.25, 0.85, u));
  const cw = VERT ? 860 : 780, ch = VERT ? 560 : 500;
  const cx = px + 50 + cw / 2, cy = py + 300 + ch / 2;
  g.save(); g.translate(lerp(W + cw, cx, ca), lerp(cy + 200, cy, ca)); g.rotate(lerp(0.4, 0, ca));
  rrect(g, -cw / 2, -ch / 2, cw, ch, 22); g.fillStyle = C.card; g.fill();
  const m = 14; g.beginPath(); g.moveTo(-cw / 2 + m + 40, -ch / 2 + m); g.lineTo(cw / 2 - m, -ch / 2 + m); g.lineTo(cw / 2 - m, ch / 2 - m); g.lineTo(-cw / 2 + m, ch / 2 - m); g.lineTo(-cw / 2 + m, -ch / 2 + m + 40); g.closePath(); g.fillStyle = '#121014'; g.fill();
  // chapter thumbnail (the boss half of the chapter)
  const tw = 250, th = ch - 68;
  g.save(); g.beginPath(); g.rect(-cw / 2 + 34, -ch / 2 + 34, tw, th); g.clip(); g.fillStyle = C.paper; g.fillRect(-cw / 2 + 34, -ch / 2 + 34, tw, th);
  const k = tw / 760; g.translate(-cw / 2 + 34, -ch / 2 + 34 - 1420 * k); g.scale(k, k); drawWorld(g, T_END, 0); g.restore();
  const tx = -cw / 2 + 34 + tw + 44;
  text(g, 'CHAPTER BREAK', tx, -ch / 2 + 74, { font: FONT.dela, size: 30, color: C.coral });
  text(g, 'RANK S', tx, -ch / 2 + 160, { font: FONT.dela, size: 72, color: '#fff' });
  text(g, '0:26.4 · COMBO 24', tx, -ch / 2 + 214, { font: FONT.dela, size: 30, color: '#fff' });
  text(g, 'ROOFTOP ROUTE', tx, -ch / 2 + 258, { font: FONT.dela, size: 24, color: C.gold });
  text(g, '+3 CARDS · SPLASH PAGE', tx, -ch / 2 + 296, { font: FONT.dela, size: 22, color: C.purple });
  const bw = 220, bh = 54, byy = ch / 2 - 40 - bh; const press = inv(1.2, 1.35, u) * (1 - inv(1.35, 1.55, u));
  g.save(); g.translate(tx + bw / 2, byy + bh / 2); g.scale(1 - press * 0.08, 1 - press * 0.08); rrect(g, -bw / 2, -bh / 2, bw, bh, bh / 2); g.fillStyle = '#fff'; g.fill();
  text(g, 'Share on X', 0, 8, { font: FONT.ui, weight: 700, size: 22, color: '#111', align: 'center' }); g.restore();
  g.restore();
  const er = inv(1.6, 2.0, u); g.save(); g.globalAlpha = er; const ey = py + ph - 42;
  ['Reply 61', 'Repost 240', 'Like 1.4K', 'Views 21K'].forEach((s2, i) => text(g, s2, px + 50 + i * ((pw - 100) / 4), ey, { font: FONT.ui, size: 22, color: '#7d7d86' })); g.restore();
  text(g, 'X POST MOCK-UP · SAMPLE NUMBERS', W / 2, VERT ? py + ph + 70 : H - 26, { font: FONT.mono, size: 16, color: '#6f6878', align: 'center', ls: 3, alpha: pu });
}

// ---------------- captions ----------------
function caption2(g, t, c) {
  const u = inv(c.t0, c.t0 + 0.25, t) * (1 - inv(c.t1 - 0.25, c.t1, t)); if (u <= 0) return;
  g.save(); g.globalAlpha = u;
  if (VERT) {
    g.translate(0, (1 - eOut(u)) * 20);
    text(g, c.big, W / 2, 1586, { font: FONT.dela, size: 50, color: '#fff', align: 'center', stroke: 12, strokeColor: C.ink });
    if (c.small) text(g, c.small, W / 2, 1630, { font: FONT.mono, size: 23, color: '#efe8f2', align: 'center', ls: 1, stroke: 7, strokeColor: C.ink });
  } else {
    g.translate((1 - eOut(u)) * 30, 0);
    const x = 1452, maxW = 390;
    const lines = wrap(g, c.big, maxW, { font: FONT.dela, size: 38 });
    const y0 = 470 + 40;
    g.fillStyle = C.coral; g.fillRect(x - 22, y0 - 38, 7, (lines.length - 1) * 46 + (c.small ? 82 : 48));
    lines.forEach((ln, i) => text(g, ln, x, y0 + i * 46, { font: FONT.dela, size: 38, color: '#fff' }));
    if (c.small) text(g, c.small, x + 2, y0 + (lines.length - 1) * 46 + 36, { font: FONT.mono, size: 16, color: '#d9d2df', ls: 0.5 });
  }
  g.restore();
}

// ---------------- timeline ----------------
const MAIN = {
  dur: 47.0,
  shots: [
    { type: 'game', t0: 0, t1: 3.0, keys: [[0, 23.6], [0.5, 24.1], [1.15, 24.75], [3.0, 26.05]] },
    { type: 'title', t0: 3.0, t1: 5.0 },
    { type: 'game', t0: 5.0, t1: 10.2, keys: [[5.0, 0.25], [10.2, 5.55]] },
    { type: 'game', t0: 10.2, t1: 10.9, keys: [[10.2, 5.55], [10.9, 6.15]] },
    { type: 'game', t0: 10.9, t1: 11.6, keys: [[10.9, 6.15], [11.6, 6.27]], cutin: 'shojo' },
    { type: 'game', t0: 11.6, t1: 15.2, keys: [[11.6, 6.27], [12.6, 7.3], [13.5, 7.7], [15.2, 9.95]] },
    { type: 'game', t0: 15.2, t1: 15.9, keys: [[15.2, 9.95], [15.9, 10.8]] },
    { type: 'game', t0: 15.9, t1: 16.6, keys: [[15.9, 10.8], [16.6, 10.92]], cutin: 'nero' },
    { type: 'game', t0: 16.6, t1: 18.0, keys: [[16.6, 10.92], [18.0, 12.35]] },
    { type: 'game', t0: 18.0, t1: 19.9, keys: [[18.0, 12.35], [19.9, 14.95]] },
    { type: 'game', t0: 19.9, t1: 23.4, keys: [[19.9, 14.95], [23.4, 18.45]] },
    { type: 'game', t0: 23.4, t1: 24.6, keys: [[23.4, 18.45], [24.6, 20.2]] },
    { type: 'game', t0: 24.6, t1: 27.6, keys: [[24.6, 20.2], [27.6, 23.55]] },
    { type: 'game', t0: 27.6, t1: 30.4, keys: [[27.6, 23.55], [28.1, 24.1], [28.6, 24.75], [29.0, 25.4], [29.4, 26.35], [30.4, 27.45]] },
    { type: 'results', t0: 30.4, t1: 34.0 },
    { type: 'leader', t0: 34.0, t1: 37.2 },
    { type: 'share', t0: 37.2, t1: 40.2 },
    { type: 'zenko', t0: 40.2, t1: 42.0 },
    { type: 'encore', t0: 42.0, t1: 47.0 },
  ],
  captions: [
    { t0: 5.3, t1: 6.6, big: 'THE MANGA IS UNDER ATTACK.', small: 'Anomalies are rewriting Kurokawa.' },
    { t0: 6.7, t1: 8.7, big: 'SWIPE TO SLASH.', small: 'Shonen claws carve through ink.' },
    { t0: 8.8, t1: 10.2, big: 'CLEAR IT, RESTORE IT.', small: 'Cleared panels ink back into the story.' },
    { t0: 11.7, t1: 13.4, big: 'TAP TO PARRY.', small: 'Pop the attack with a bubble.' },
    { t0: 13.5, t1: 15.2, big: 'TAP TO THROW.', small: 'Kunai hit whatever you touch.' },
    { t0: 16.7, t1: 18.0, big: 'DRAG NERO THROUGH WALLS.', small: 'The anomaly phases through panels.' },
    { t0: 18.1, t1: 19.85, big: 'PICK THE PLOT FORK.', small: 'Holder polls shape the route.' },
    { t0: 20.0, t1: 23.3, big: 'DRAG A CARD TO CAST.', small: 'Your card hand is your moveset.' },
    { t0: 23.5, t1: 27.5, big: 'TAG. COMBO. BREAK THE BOSS.', small: 'Swap heroes mid-fight.' },
  ],
};
const VERTICAL = {
  dur: 15.0,
  shots: [
    { type: 'game', t0: 0, t1: 2.2, keys: [[0, 24.0], [0.65, 24.75], [2.2, 25.95]] },
    { type: 'game', t0: 2.2, t1: 4.0, keys: [[2.2, 2.7], [4.0, 4.4]] },
    { type: 'game', t0: 4.0, t1: 5.6, keys: [[4.0, 7.25], [4.7, 7.68], [5.6, 8.85]] },
    { type: 'game', t0: 5.6, t1: 7.0, keys: [[5.6, 11.05], [7.0, 12.25]] },
    { type: 'game', t0: 7.0, t1: 8.5, keys: [[7.0, 16.45], [8.5, 17.95]] },
    { type: 'game', t0: 8.5, t1: 9.5, keys: [[8.5, 22.65], [9.5, 23.45]] },
    { type: 'game', t0: 9.5, t1: 10.3, keys: [[9.5, 26.35], [10.3, 27.4]] },
    { type: 'results', t0: 10.3, t1: 12.2 },
    { type: 'encore', t0: 12.2, t1: 15.0 },
  ],
  captions: [
    { t0: 2.25, t1: 3.95, big: 'SWIPE TO SLASH.', small: 'Shonen claws carve through ink.' },
    { t0: 4.05, t1: 5.55, big: 'TAP TO PARRY & THROW.', small: 'Shojo pops attacks, kunai fly.' },
    { t0: 5.65, t1: 6.95, big: 'DRAG NERO THROUGH WALLS.', small: 'The anomaly phases through panels.' },
    { t0: 7.05, t1: 8.45, big: 'DRAG A CARD TO CAST.', small: 'Your card hand is your moveset.' },
    { t0: 8.55, t1: 9.45, big: 'BREAK THE BOSS.', small: 'Pinch for a Splash Page finisher.' },
  ],
};
const TIMELINE = VERT ? VERTICAL : MAIN;

function renderAt(t) {
  const shot = TIMELINE.shots.find((s) => t >= s.t0 && t < s.t1) || TIMELINE.shots[TIMELINE.shots.length - 1];
  ctx.save();
  const PUSH = { title: 0.035, results: 0.02, leader: 0.035, share: 0.035, zenko: 0.04, encore: 0.03 }[shot.type];
  if (PUSH) { const k = 1 + PUSH * eIO(inv(shot.t0, shot.t1, t)); ctx.translate(W / 2, H / 2); ctx.scale(k, k); ctx.translate(-W / 2, -H / 2); }
  if (shot.type === 'game') {
    sceneGame2(ctx, t, shot);
    if (shot.cutin) drawCutIn(ctx, inv(shot.t0, shot.t1, t), shot.cutin);
    const s = mapTime(shot.keys, t);
    if (!shot.cutin && !(s >= SPLASH[0] && s <= SPLASH[1])) for (const c of TIMELINE.captions) caption2(ctx, t, c);
  } else if (shot.type === 'title') sceneTitle(ctx, t, shot);
  else if (shot.type === 'results') sceneResults(ctx, t, shot);
  else if (shot.type === 'leader') sceneLeader(ctx, t, shot);
  else if (shot.type === 'share') sceneShare2(ctx, t, shot);
  else if (shot.type === 'zenko') sceneZenko(ctx, t, shot);
  else if (shot.type === 'encore') sceneEncore(ctx, t, shot);
  ctx.restore();
  for (const s of TIMELINE.shots) {
    if (s.type === 'game' && (s.cutin || TIMELINE.shots[TIMELINE.shots.indexOf(s) - 1]?.type === 'game')) continue;
    const d = t - s.t0; if (d >= 0 && d < 0.1 && s.t0 > 0 && s.type !== 'encore' && s.type !== 'zenko') { ctx.fillStyle = `rgba(255,255,255,${0.5 * (1 - d / 0.1)})`; ctx.fillRect(0, 0, W, H); }
  }
}
window.renderFrame = (n) => { renderAt(n / FPS); };
window.frameData = (n, type = 'image/png', q) => { renderAt(n / FPS); return cv.toDataURL(type, q); };
window.cues = () => [];
init().catch((e) => { window.initError = String(e && e.stack || e); console.error(e); });
