"""Assemble game/render2.js: shared helpers extracted from render.js + chapter.js (CHAPTER BREAK)."""
import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1])
src = (ROOT / 'game/render.js').read_text()


def extract_fn(name):
    m = re.search(r'^function %s\(' % re.escape(name), src, re.M)
    if not m:
        raise SystemExit('missing ' + name)
    i = m.end() - 1
    depth = 0
    while True:  # parameter list
        c = src[i]
        if c == '(':
            depth += 1
        elif c == ')':
            depth -= 1
            if depth == 0:
                break
        i += 1
    j = src.index('{', i)
    depth = 0
    k = j
    while True:
        c = src[k]
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                break
        k += 1
    return src[m.start():k + 1]


head = src[:src.index('// ---------------- assets ----------------')]
fns = ['loadImg', 'sprite', 'makeNeroHead', 'makeHalftone', 'makeGrain', 'bboxOf', 'polyPath', 'cover', 'rrect', 'text', 'wrap', 'measure',
       'sfx', 'speedLines', 'star4', 'cardShape', 'drawCardFront', 'drawCardBack', 'drawCard', 'drawHanko', 'drawWisp', 'drawNero',
       'halftoneLayer', 'drawRedHalftone', 'drawBackdrop', 'drawCutIn', 'invertCanvas', 'mapTime', 'sfxText', 'drawMeter',
       'mascotPath', 'drawMascot', 'sceneTitle', 'sceneLeader', 'sceneZenko', 'sceneEncore']
body = '\n\n'.join(extract_fn(f) for f in fns)

patches = [
    ("const frame = o.frame === 'purple' ? C.purple : C.card;",
     "const frame = o.frame === 'purple' ? C.purple : o.frame === 'gold' ? C.gold : C.card;"),
    ("shonen: { art: ART.cutShonen, col: C.coral, col2: '#2b0d14', big: 'RESONANCE  BURST', lbl: 'SHONEN · VANGUARD', jp: 'ザンッ' },",
     "shonen: { art: ART.cutShonen, col: C.coral, col2: '#2b0d14', big: 'SPLASH  PAGE', lbl: 'SHONEN · VANGUARD · FINISHER', jp: 'ザンッ' },"),
    ("shojo: { art: ART.cutShojo, col: C.sakura, col2: C.navy, big: 'KUNAI  PIN', lbl: 'SHOJO · CATALYST', jp: 'シュッ' },",
     "shojo: { art: ART.cutShojo, col: C.sakura, col2: C.navy, big: 'TAG  IN: SHOJO', lbl: 'CATALYST · TAP TO THROW & PARRY', jp: 'シュッ' },"),
    ("nero: { art: ART.cutNero, col: C.gold, col2: '#2a1f12', big: 'NEROOOOO.', lbl: 'NERO · THE ANOMALY · LEGENDARY', jp: 'ドンッ' },",
     "nero: { art: ART.cutNero, col: C.gold, col2: '#2a1f12', big: 'NEROOOOO.', lbl: 'THE ANOMALY · HOLD & DRAG THROUGH WALLS', jp: 'ドンッ' },"),
    ("sfxText(g, 'PANEL  CUT', W / 2, ty, VERT ? 120 : 130, 4);", "sfxText(g, 'CHAPTER  BREAK', W / 2, ty, VERT ? 74 : 104, 4);"),
    ("'CUT THE PAGE. TRAP THE ANOMALY.'", "'SWIPE. TAP. DRAG. BREAK THE PAGE.'"),
    ("'SAMPLE · CH.01 PAGE 07'", "'SAMPLE · CHAPTER 01'"),
    ("'They can’t draw the line.'", "'They can’t clear a chapter.'"),
    ("sfxText(g, 'PANEL  CUT', W / 2, H * 0.4 + lh / 2 + 90, VERT ? 100 : 110, 4);",
     "sfxText(g, 'CHAPTER  BREAK', W / 2, H * 0.4 + lh / 2 + 90, VERT ? 70 : 96, 4);"),
    ("'ZENKO: PANEL CUT · A GAME CONCEPT BY ENCORE STUDIO'", "'ZENKO: CHAPTER BREAK · A GAME CONCEPT BY ENCORE STUDIO'"),
    ("if (o.title) text(g, o.title, ax + a * 0.4, ty + h * 0.07, { font: FONT.dela, size: Math.round(w * 0.105), color: '#fff' });",
     "if (o.title) { let fs = Math.round(w * 0.105); g.save(); g.font = `${fs}px ${FONT.dela}`; const tw = g.measureText(o.title).width; g.restore(); if (tw > aw - a * 0.8) fs = Math.floor(fs * (aw - a * 0.8) / tw); text(g, o.title, ax + a * 0.4, ty + h * 0.07, { font: FONT.dela, size: fs, color: '#fff' }); }"),
]
for a, b in patches:
    if a not in body:
        raise SystemExit('patch target missing: ' + a[:70])
    body = body.replace(a, b)

out = '// AUTO-BUILT by tools/build2.py — shared helpers from render.js + chapter.js\n' + head + \
    '\nconst IMG = {};\nlet HT_CANVAS = null;\n' + body + '\n\n' + (ROOT / 'game/chapter.js').read_text()
(ROOT / 'game/render2.js').write_text(out)
print('render2.js', len(out), 'chars')
