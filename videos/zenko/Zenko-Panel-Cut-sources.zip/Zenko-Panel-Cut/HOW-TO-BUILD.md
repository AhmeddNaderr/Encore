# Building ZENKO: PANEL CUT from source

This package holds the code and docs only. Zenko's art files are **not** redistributed here; `art_sources.csv` lists every file's original URL and SHA-256.

1. Download each file in `art_sources.csv` into `raw/` (Zenko) and `encore/` (Encore), using the filenames given.
2. `python tools/prep_assets.py .` makes the background-removed cutouts, logo alphas and card-back texture in `assets/`.
   The card-back and red-halftone textures are crops of `raw/article-HX5gSxsaAAEPKNY.png`; see `prep` notes in the code.
3. Fonts: `npm i @fontsource/dela-gothic-one` inside `npmfonts/` (OFL). Inter, Inter Display and JetBrains Mono (all OFL) must be installed system-wide.
4. `node game/plan.mjs game/take.json` plans the skilled run (deterministic; seed 11).
5. Render: `node tools/capture.mjs video main out.mp4` and `node tools/capture.mjs video vertical out-15s.mp4` (needs Playwright + Chromium).
6. Audio: `node tools/capture.mjs cues main audio/cues-main.json`, then `python tools/compose.py audio/cues-main.json main raw-main.wav`. Master with ffmpeg `loudnorm` (I=-15, TP=-1.5) and mux.

Every sound is synthesized in `compose.py` from oscillators and seeded noise, with no samples or third-party music.
