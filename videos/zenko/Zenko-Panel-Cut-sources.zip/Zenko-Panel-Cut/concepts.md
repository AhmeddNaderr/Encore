# Zenko — concepts

The test for every idea: swap in another collection's art and the game should stop making sense. It has to use manga panels, cards and the Kurokawa rift.

## Brainstorm (15)
1. Panel Cut: slash the manga page into panels to trap rift anomalies; each trapped one becomes a card. **WINNER**
2. Resonance Scroll: rhythm taps down a vertical-scroll chapter.
3. Gutter Runner: Nero runs along panel gutters. (runner, rejected)
4. Ink Duel: draw each hero's signature stroke to land a move.
5. Card Rift: drag cards over rift cracks to seal them.
6. Plot Fork: holders vote, then play whichever branch wins.
7. Screentone Stealth: hide in halftone shadows.
8. Speedline Dodge: dodge in the direction of manga speed lines.
9. Bubble Pop: Shojo bubble-gum physics puzzle.
10. Kunai Pinball.
11. Panel Tetris: fit panels into a page. (tetris clone, rejected)
12. SFX Smash: tap katakana sound effects at the beat.
13. Nero Hunt: find the 200 Nero hidden in crowd panels.
14. Classic Never Fades: a yin-yang balance game.
15. Trick or Scythe: a Halloween reaper mini-game.

## Top 5 cards
| # | Name | One-sentence rule | Why it's Zenko |
|---|---|---|---|
| 1 | **ZENKO: PANEL CUT** | You cut panel gutters across a manga page to trap the anomalies leaking from the Kurokawa rift. A trapped anomaly seals into a TCG card. | Uses all three pillars at once: the page (manga), the cards (TCG), and the broken boundary between city and spirit realm (lore). Shonen, Shojo and Nero each change how you cut. |
| 2 | Ink Duel | Trace a hero's weapon stroke (katana arc, kunai line, claw rake) cleanly to land the panel. | Art-first, but closer to a generic gesture fighter. |
| 3 | Plot Fork | A reading-plus-skill game where your score votes on the chapter's turning point. | Strong for the community, weak on 5-second clarity. |
| 4 | SFX Smash | Rhythm game played on katakana sound effects. | Manga flavour, but it's a rhythm reskin. |
| 5 | Nero Hunt | Spot the anomaly in crowded city panels. | Cute, but nothing much happens in a trailer. |

## Scores (1–10)
| Concept | Lore | Original | Clarity | Replay | Share | Trailer | Build | Total |
|---|---|---|---|---|---|---|---|---|
| **Panel Cut** | 10 | 9 | 9 | 9 | 9 | 10 | 8 | **64** |
| Ink Duel | 8 | 7 | 8 | 7 | 6 | 9 | 7 | 52 |
| Plot Fork | 9 | 8 | 5 | 6 | 7 | 5 | 6 | 46 |
| SFX Smash | 7 | 5 | 8 | 8 | 6 | 8 | 8 | 50 |
| Nero Hunt | 8 | 6 | 9 | 6 | 7 | 5 | 9 | 50 |

## Winner: ZENKO: PANEL CUT
- **Rule (title card):** "Cut the page. Trap the anomaly."
- **Loop:** The rift opens on a blank page and anomalies spill out. You swipe to cut a gutter; the line grows from your finger to both panel edges. If an anomaly touches it before it finishes, the line breaks and you lose a life. An empty panel inks into story art. A small panel with exactly one anomaly seals: hanko stamp 封 ("seal"), and the anomaly flips out as a card.
- **Heroes:** Shonen (vanguard): Resonance Burst, many claw cuts at once. Shojo (catalyst): kunai pin freezes anomalies for a safe cut. Nero (anomaly): the rare golden-eyed pull. Sealing Nero gives the legendary card.
- **Score:** % of the page inked, cards sealed, and a combo for chained seals.
- **Share moment:** The page you cut is your own manga page. Every run produces a different layout, filled with Zenko art, plus the hand of cards you sealed.
- **Bots line:** "Bots can like a post. They can't draw the line."
