// Plans a skilled run: each scripted intent is resolved by searching nearby timings/angles/
// positions in a cloned simulation for the requested outcome. Writes take.json with
// per-frame snapshots and the event log.
import fs from 'node:fs';
import { Sim, FPS, area, centroid, distSeg, LINE_HALF, PAGE } from './sim.js';

const OUT = process.argv[2] || 'take.json';
const sim = new Sim(11);
const snaps = [sim.snapshot()];
const actions = [];
const adv = (n) => { for (let i = 0; i < n; i++) { sim.step(); snaps.push(sim.snapshot()); } };
const idle = () => { while (sim.s.cuts.some((c) => c.state === 'grow')) adv(1); };
const F = (sec) => Math.round(sec * FPS);
const SLANTS = [-12, -8, -4, 4, 8, 12, 78, 82, 86, 94, 98, 102];
const lin = (a, n) => (n <= 1 ? [0] : Array.from({ length: n }, (_, i) => -a + (2 * a * i) / (n - 1)));

function evaluate(base, wait, x, y, ang, opt) {
  const t = base.clone();
  for (let i = 0; i < wait; i++) t.step();
  const e0 = t.s.events.length;
  const c = t.startCut(x, y, ang, opt);
  if (!c) return null;
  let minClear = 1e9;
  for (let i = 0; i < 150 && c.state === 'grow'; i++) {
    const ax = c.x + c.d[0] * c.a, ay = c.y + c.d[1] * c.a, bx = c.x + c.d[0] * c.b, by = c.y + c.d[1] * c.b;
    for (const an of t.s.an) if (an.alive && an.panel === c.panel) minClear = Math.min(minClear, distSeg(an.x, an.y, ax, ay, bx, by) - an.r - LINE_HALF);
    t.step();
  }
  const evs = t.s.events.slice(e0);
  const openFrac = t.s.panels.filter((q) => q.state === 'open').reduce((m, q) => m + Math.abs(area(q.poly)), 0) / t.s.innerArea;
  return { wait, x, y, ang, minClear, evs, openFrac, seals: evs.filter((e) => e.type === 'seal'), inks: evs.filter((e) => e.type === 'ink'),
    brk: evs.find((e) => e.type === 'break'), state: c.state };
}

function planCut(I) {
  idle();
  adv(F(I.gap ?? 0.4));
  const hero = I.hero ?? sim.s.hero;
  const opt = { speed: I.speed ?? (hero === 'shojo' ? 1700 : 1500), hero, immune: !!I.immune, burst: !!I.burst };
  let best = null;
  const waits = [];
  for (let w = 0; w <= F(I.maxWait ?? 0.9); w += (I.waitStep ?? 3)) waits.push(w);
  const grid = [];
  if (I.cands) for (const c of I.cands) grid.push([c.x - I.x, c.y - I.y, c.ang - I.ang]);
  else for (const dx of lin(I.dx ?? 30, I.dx === 0 ? 1 : 5)) for (const dy of lin(I.dy ?? 30, I.dy === 0 ? 1 : 5))
    for (const da of lin(I.dang ?? 5, I.dang === 0 ? 1 : 5)) grid.push([dx, dy, da]);
  for (const w of waits) for (const [dx, dy, da] of grid) {
      const r = evaluate(sim, w, I.x + dx, I.y + dy, I.ang + da, opt);
      if (!r) continue;
      let ok = false, score = w * 0.6 + (Math.abs(dx) + Math.abs(dy)) * 0.08 + Math.abs(da) * 0.3;
      if (I.expect === 'break') {
        ok = !!r.brk && r.brk.prog > 0.45 && r.brk.prog < 0.9;
        if (ok) score += Math.abs(r.brk.prog - 0.72) * 40;
      } else {
        ok = !r.brk && r.state === 'done';
        if (I.expect === 'seal') ok = ok && r.seals.length >= (I.minSeals ?? 1) && (!I.kind || r.seals.some((s) => s.kind === I.kind))
          && (I.maxSeals == null || r.seals.length <= I.maxSeals);
        if (I.expect === 'ink') ok = ok && r.inks.length >= 1;
        if (ok && I.drama) score += 60 / (1 + Math.max(0, r.minClear)) - (r.minClear < 3 ? 40 : 0);
        if (ok && I.preferInk) score -= r.inks.length * 6;
        if (ok) score -= r.seals.length * 10;
        if (ok) score -= r.openFrac * (I.keepOpen ?? 120);
      }
      if (ok && (!best || score < best.score)) best = { ...r, score };
    }
  if (!best) throw new Error(`no candidate for intent ${I.name}`);
  adv(best.wait);
  const c = sim.startCut(best.x, best.y, best.ang, opt);
  actions.push({ f: sim.s.f, type: 'cut', name: I.name, x: best.x, y: best.y, ang: best.ang, hero, minClear: +best.minClear.toFixed(1) });
  console.log(`open=${best.openFrac.toFixed(2)} `, `${I.name.padEnd(10)} f=${sim.s.f} t=${(sim.s.f / FPS).toFixed(2)} wait=${best.wait} ang=${best.ang.toFixed(1)} seals=${best.seals.length} inks=${best.inks.length} brk=${!!best.brk} clear=${best.minClear.toFixed(1)}`);
  idle();
  return c;
}

function largestOpen() {
  return sim.s.panels.filter((p) => p.state === 'open').sort((a, b) => Math.abs(area(b.poly)) - Math.abs(area(a.poly)))[0];
}

// ---------------- the run ----------------
adv(F(0.45));
sim.openRift(380, 560, 1); actions.push({ f: sim.s.f, type: 'rift' });
adv(F(0.35)); sim.spawn('wisp', -55, 250);
adv(F(0.25)); sim.spawn('wisp', 160, 250);
adv(F(0.25)); sim.spawn('wisp', 70, 250);

planCut({ name: 'c1-top', gap: 0.55, x: 380, y: 250, ang: -8, dy: 70, dang: 6, expect: 'ink' });
planCut({ name: 'c2-bottom', gap: 0.35, x: 380, y: 780, ang: 7, dy: 70, dang: 6, expect: 'ink' });
sealTarget('c3-seal', 'any', 0.35, { maxSeals: 1, maxWait: 1.0, waitStep: 6 });
sealTarget('c4-break', 'any', 0.35, { expect: 'break', maxWait: 0.8, waitStep: 6 });
sealTarget('c5-seal', 'any', 0.45, { maxSeals: 1, drama: true, maxWait: 1.2, waitStep: 6 });

// rift level 2
{
  idle(); adv(F(0.4));
  const p = largestOpen(); const [cx, cy] = centroid(p.poly);
  sim.openRift(cx, cy, 2); actions.push({ f: sim.s.f, type: 'rift2' });
  adv(F(0.3)); sim.spawn('wisp', -120, 300);
  adv(F(0.2)); sim.spawn('wisp', 30, 300);
  adv(F(0.2)); sim.spawn('wisp', 150, 300);
}
// Shojo swap + kunai pin
adv(F(0.6)); sim.setHero('shojo'); actions.push({ f: sim.s.f, type: 'hero', hero: 'shojo' });
adv(F(0.5));
{
  const p = largestOpen();
  const ins = sim.s.an.filter((a) => a.alive && a.panel === p.id);
  const ids = ins.slice(0, 2).map((a) => a.id);
  sim.pin(ids, 2.6); actions.push({ f: sim.s.f, type: 'pin', ids });
  console.log('pin', ids, 'panel', p.id, 'n in panel', ins.length);
}
// candidate cut lines at offsets around one anomaly, at manga-like slants
function around(an, angs, offs) {
  const out = [];
  for (const ang of angs) for (const o of offs) for (const sgn of [1, -1]) {
    const nx = -Math.sin((ang * Math.PI) / 180), ny = Math.cos((ang * Math.PI) / 180);
    out.push({ x: an.x + nx * o * sgn, y: an.y + ny * o * sgn, ang });
  }
  return out;
}
function sealTarget(name, id, gap, extra = {}) {
  idle(); adv(F(gap));
  const targets = id === 'any' ? sim.s.an.filter((a) => a.alive) : sim.s.an.filter((a) => a.id === id && a.alive);
  if (!targets.length) { console.log(name, 'target gone'); return; }
  const cands = [];
  for (const an of targets) { const offs = []; for (let o = an.r + 16; o <= an.r + 260; o += 12) offs.push(o); cands.push(...around(an, SLANTS, offs)); }
  return planCut({ name, gap: 0, x: 0, y: 0, ang: 0, cands, expect: 'seal', maxWait: extra.maxWait ?? 0.2, waitStep: extra.waitStep, ...extra });
}
// cuts around pinned anomalies (search wide)
function sealAround(name, gap) {
  const p = largestOpen();
  const [cx, cy] = centroid(p.poly);
  const b = p.poly.reduce((m, [x, y]) => [Math.min(m[0], x), Math.min(m[1], y), Math.max(m[2], x), Math.max(m[3], y)], [1e9, 1e9, -1e9, -1e9]);
  const wide = b[2] - b[0] > b[3] - b[1];
  return planCut({ name, gap, x: cx, y: cy, ang: wide ? 92 : 4, dx: (b[2] - b[0]) * 0.35, dy: (b[3] - b[1]) * 0.35, dang: 10, expect: 'seal', maxWait: 0.6 });
}
const PINNED = actions.find((a) => a.type === 'pin').ids;
sealTarget('c6-shojo', PINNED[0], 0.15, { maxSeals: 1 });
sealTarget('c7-shojo', PINNED[1], 0.1, { maxSeals: 1 });

// Nero
{
  idle(); adv(F(0.6));
  const p = largestOpen(); const [cx, cy] = centroid(p.poly);
  sim.openRift(cx, cy, 3); actions.push({ f: sim.s.f, type: 'rift3' });
  adv(F(0.5)); sim.spawn('nero', -35, 210);
  actions.push({ f: sim.s.f, type: 'nero' });
  adv(F(0.35)); sim.spawn('wisp', 140, 280);
}
{
  const nero = sim.s.an.find((a) => a.kind === 'nero');
  { const p = sim.s.panels.find((q) => q.id === nero.panel); console.log('nero panel frac', (Math.abs(area(p.poly)) / sim.s.innerArea).toFixed(3), 'mates', sim.s.an.filter((a) => a.alive && a.panel === p.id).length, 'open panels', sim.s.panels.filter(q=>q.state==='open').map(q=>[q.id,(Math.abs(area(q.poly))/sim.s.innerArea).toFixed(3), sim.s.an.filter(a=>a.alive&&a.panel===q.id).length])); }
  sealTarget('c8-nero', nero.id, 0.9, { kind: 'nero', drama: true, maxSeals: 1, maxWait: 2.0 });
}

// Resonance burst (Shonen): immune fast cuts that isolate everything left
idle(); adv(F(0.5)); sim.setHero('shonen'); actions.push({ f: sim.s.f, type: 'hero', hero: 'shonen' });
adv(F(0.9)); actions.push({ f: sim.s.f, type: 'burst' }); sim.ev('burst');
let guard = 0;
while (sim.s.an.some((a) => a.alive) && guard++ < 12) {
  const live = sim.s.an.filter((a) => a.alive);
  const a0 = live[0];
  const p = sim.s.panels.find((q) => q.id === a0.panel);
  const mates = live.filter((a) => a.panel === p.id);
  let best = null;
  const [cx, cy] = centroid(p.poly);
  for (let da = 0; da < 180; da += 6) for (let off = -120; off <= 120; off += 10) {
    const ang = da;
    const nx = -Math.sin((ang * Math.PI) / 180), ny = Math.cos((ang * Math.PI) / 180);
    const px = (mates.length > 1 ? (mates[0].x + mates[1].x) / 2 : a0.x) + nx * (mates.length > 1 ? off * 0.3 : off);
    const py = (mates.length > 1 ? (mates[0].y + mates[1].y) / 2 : a0.y) + ny * (mates.length > 1 ? off * 0.3 : off);
    const r = evaluate(sim, 0, px, py, ang, { speed: 5200, immune: true, burst: true, hero: 'shonen' });
    if (!r || r.state !== 'done') continue;
    const tooClose = mates.some((m) => distSeg(m.x, m.y, px - 2000 * Math.cos(ang * Math.PI / 180), py - 2000 * Math.sin(ang * Math.PI / 180), px + 2000 * Math.cos(ang * Math.PI / 180), py + 2000 * Math.sin(ang * Math.PI / 180)) < m.r + 14);
    const slant = Math.min(Math.abs(ang - 0), Math.abs(ang - 90), Math.abs(ang - 180)) ;
    const score = (r.seals.length === 1 ? -100 : r.seals.length > 1 ? 40 : 200) - r.inks.length * 10 + (tooClose ? 500 : 0) + Math.abs(slant - 9) * 1.5;
    if (!best || score < best.score) best = { score, px, py, ang };
  }
  sim.startCut(best.px, best.py, best.ang, { speed: 5200, immune: true, burst: true, hero: 'shonen' });
  actions.push({ f: sim.s.f, type: 'cut', name: 'burst', x: best.px, y: best.py, ang: best.ang, hero: 'shonen' });
  console.log('burst cut', sim.s.f, best.ang, 'alive', sim.s.an.filter((a) => a.alive).length);
  adv(F(0.1));
  idle();
  recut();
}
recut(); recut();
function recut() {
  // slash the largest inked panel into two manga panels
  recut.n ??= 0;
  const p = sim.s.panels.filter((q) => q.state === 'inked').sort((a, b) => Math.abs(area(b.poly)) - Math.abs(area(a.poly)))[0];
  if (!p || Math.abs(area(p.poly)) / sim.s.innerArea < 0.05) return;
  const b = p.poly.reduce((m, [x, y]) => [Math.min(m[0], x), Math.min(m[1], y), Math.max(m[2], x), Math.max(m[3], y)], [1e9, 1e9, -1e9, -1e9]);
  const [cx, cy] = centroid(p.poly);
  const wide = b[2] - b[0] > (b[3] - b[1]) * 1.1;
  const ang = wide ? (recut.n++ % 2 ? 76 : 100) : (recut.n++ % 2 ? -9 : 9);
  const px = wide ? b[0] + (b[2] - b[0]) * (recut.n % 2 ? 0.42 : 0.58) : cx;
  sim.startCut(px, cy, ang, { speed: 5200, immune: true, burst: true, recut: true, hero: 'shonen' });
  actions.push({ f: sim.s.f, type: 'cut', name: 'recut', x: px, y: cy, ang, hero: 'shonen' });
  console.log('recut', sim.s.f, 'panel frac', (Math.abs(area(p.poly)) / sim.s.innerArea).toFixed(3), 'ang', ang);
  adv(F(0.1)); idle();
}
recut.n = 0;
adv(F(2.5));

const s = sim.s;
console.log('frames', snaps.length, 'sec', (snaps.length / FPS).toFixed(2), 'inked', sim.inkedFrac().toFixed(3), 'cards', s.cards.length, 'lives', s.lives, 'done', s.done, 'panels', s.panels.length);
fs.writeFileSync(OUT, JSON.stringify({ fps: FPS, page: PAGE, actions, events: s.events, cards: s.cards, snaps }));
