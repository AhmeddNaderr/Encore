// ZENKO: PANEL CUT — trailer renderer (deterministic, frame-addressable).
// Every character pixel comes from Zenko's official art files.
const Q = new URLSearchParams(location.search);
const LAYOUT = Q.get('layout') || 'main';
const VERT = LAYOUT === 'vertical';
const W = VERT ? 1080 : 1920, H = VERT ? 1920 : 1080;
const FPS = 60;
const cv = document.getElementById('c');
cv.width = W; cv.height = H;
const ctx = cv.getContext('2d');

// ---------------- palette ----------------
const C = {
  ink: '#0b090c', paper: '#f3f0ea', paper2: '#e9e5dc', coral: '#F4575E', card: '#E46762', purple: '#E46EFF',
  haze: '#403748', haze2: '#665A72', navy: '#344771', sakura: '#EF9BCC', gold: '#F2B43C', fur: '#383240',
  encRed: '#E24A51', encGrey: '#a1a0a2', encMono: '#6b6b6d',
};
const FONT = { dela: '"Dela Gothic One"', disp: '"Inter Display"', ui: 'Inter', mono: '"JetBrains Mono"' };

// ---------------- math ----------------
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const inv = (a, b, v) => clamp((v - a) / (b - a));
const eOut = (t) => 1 - Math.pow(1 - clamp(t), 3);
const eIn = (t) => Math.pow(clamp(t), 3);
const eIO = (t) => { t = clamp(t); return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; };
const eBack = (t) => { t = clamp(t); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
const noise1 = (x) => { const i = Math.floor(x), f = x - i; const u = f * f * (3 - 2 * f); return lerp(hash(i), hash(i + 1), u); };

// ---------------- assets ----------------
const IMG = {};
function loadImg(key, src) {
  return new Promise((res, rej) => { const im = new Image(); im.onload = () => { IMG[key] = im; res(); }; im.onerror = () => rej(new Error(src)); im.src = src; });
}
let TAKE, SN, EV, CUTS = {}, CARDS;
const ART = {}; // crop sprites
function sprite(img, rect, maxSide = 900, gray = false) {
  const [x0, y0, x1, y1] = rect; const w = x1 - x0, h = y1 - y0;
  const s = Math.min(1, maxSide / Math.max(w, h));
  const c = document.createElement('canvas'); c.width = Math.round(w * s); c.height = Math.round(h * s);
  const g = c.getContext('2d'); g.imageSmoothingQuality = 'high';
  if (gray) g.filter = 'grayscale(1) contrast(1.05)';
  g.drawImage(img, x0, y0, w, h, 0, 0, c.width, c.height);
  return c;
}
// art crops (source pixel rects in the official files)
const CROPS = {
  manga: [ // official Zenko manga page, greyscale
    [40, 0, 1180, 640], [250, 640, 1180, 1720], [840, 700, 1500, 1230], [0, 1290, 470, 1620], [560, 1640, 1500, 2224],
    [880, 1080, 1500, 1720], [1080, 0, 1500, 520], [0, 1660, 640, 2224], [380, 820, 980, 1340],
  ],
  shonen: [['banner', [1420, 20, 2080, 600]], ['banner', [2360, 160, 3000, 1000]], ['banner', [440, 260, 1260, 1000]], ['banner', [1650, 180, 2700, 1000]]],
  shojo: [['shojoF', [380, 420, 1500, 1420]], ['shojoF', [140, 560, 640, 1480]], ['shojoF', [900, 950, 2000, 2000]]],
  nero: [['neroF', [520, 400, 1720, 1460]]],
  recut: [['katanaF', [520, 520, 1480, 1420]], ['scytheF', [560, 440, 1560, 1440]], ['katanaF', [0, 1150, 900, 2000]], ['scytheF', [1200, 0, 2000, 1000]],
    ['banner', [1420, 20, 2080, 600]], ['shojoF', [380, 420, 1500, 1420]], ['neroF', [520, 400, 1720, 1460]], ['katanaF', [1100, 600, 2000, 1500]]],
};
const PANEL_ART = new Map();

async function init() {
  const R = '..';
  await Promise.all([
    loadImg('banner', `${R}/raw/x-HX5dbiwaoAAvHvH.png`), loadImg('manga', `${R}/raw/article-HX5f-NMaAAAOjhL.png`),
    loadImg('neroF', `${R}/raw/x-HXf342bbgAACWJr.png`), loadImg('shojoF', `${R}/raw/x-HXVarTyasAEhHsN.png`),
    loadImg('katanaF', `${R}/raw/x-HXae84Ta4AALN3w.png`), loadImg('scytheF', `${R}/raw/x-HXklmjraIAAWuqX.png`),
    loadImg('nero', `${R}/assets/nero.png`), loadImg('shojo', `${R}/assets/shojo.png`), loadImg('katana', `${R}/assets/katana.png`), loadImg('scythe', `${R}/assets/scythe.png`),
    loadImg('logoL', `${R}/assets/zenko-logo-light.png`), loadImg('logoI', `${R}/assets/zenko-logo-ink.png`), loadImg('logoCB', `${R}/assets/zenko-logo-cardback.png`),
    loadImg('cardback', `${R}/assets/cardback-texture.png`), loadImg('redht', `${R}/assets/redhalftone-texture.png`),
    loadImg('encWord', `${R}/assets/encore-wordmark.png`), loadImg('encStudio', `${R}/assets/encore-studio.png`),
  ]);
  TAKE = await (await fetch('./take.json')).json();
  SN = TAKE.snaps; EV = TAKE.events; CARDS = TAKE.cards;
  for (const e of EV) if (e.type === 'cut') CUTS[e.id] = e;
  // pre-scaled sprites
  ART.manga = CROPS.manga.map((r) => sprite(IMG.manga, r, 760, true));
  for (const k of ['shonen', 'shojo', 'nero', 'recut']) ART[k] = CROPS[k].map(([im, r]) => sprite(IMG[im], r, 820));
  ART.bannerBg = sprite(IMG.banner, [0, 0, 1250, 1000], 1400);
  ART.kunai = sprite(IMG.shojo, [105, 450, 300, 1020], 400); // kunai from the Shojo cutout (1500px space)
  ART.neroHead = makeNeroHead();
  ART.heroShonen = sprite(IMG.banner, [1380, 0, 2280, 1000], 700);
  ART.heroShojo = sprite(IMG.shojoF, [300, 300, 1700, 1900], 700);
  ART.heroNero = sprite(IMG.neroF, [450, 350, 1850, 1950], 700);
  ART.cutShonen = sprite(IMG.banner, [1380, 120, 2200, 520], 1400);
  ART.cutShojo = sprite(IMG.shojoF, [480, 640, 1450, 1180], 1400);
  ART.cutNero = sprite(IMG.neroF, [560, 760, 1700, 1300], 1400);
  ART.halftone = makeHalftone();
  ART.grain = makeGrain();
  assignPanelArt();
  await document.fonts.load(`40px ${FONT.dela}`, 'ザシュッバキッ封ドンゴシュッ PANEL CUT 0123456789%×');
  await document.fonts.load(`40px ${FONT.disp}`, 'Aa'); await document.fonts.load(`600 40px ${FONT.disp}`, 'Aa');
  await document.fonts.load(`40px ${FONT.mono}`, 'Aa'); await document.fonts.load(`40px ${FONT.ui}`, 'Aa');
  window.TOTAL_FRAMES = Math.round(TIMELINE.dur * FPS);
  window.ready = true;
}

function makeNeroHead() {
  // Nero's official head, softly faded below the jaw so it can float in the rift
  const im = IMG.nero; const sx = 400, sy = 300, sw = 860, sh = 860;
  const c = document.createElement('canvas'); c.width = 520; c.height = 520; const g = c.getContext('2d');
  g.drawImage(im, sx, sy, sw, sh, 0, 0, 520, 520);
  g.globalCompositeOperation = 'destination-in';
  const gr = g.createLinearGradient(0, 330, 0, 470);
  gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 520, 520);
  return c;
}
function makeHalftone() {
  const c = document.createElement('canvas'); c.width = 24; c.height = 24; const g = c.getContext('2d');
  g.fillStyle = '#000'; g.beginPath(); g.arc(6, 6, 2.6, 0, 7); g.arc(18, 18, 2.6, 0, 7); g.fill();
  return c;
}
function makeGrain() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 256; const g = c.getContext('2d');
  const d = g.createImageData(256, 256);
  for (let i = 0; i < d.data.length; i += 4) { const v = hash(i * 0.37) * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 22; }
  g.putImageData(d, 0, 0); return c;
}

// assign art to panels in order of appearance (stable for random access)
function bboxOf(p) { let a = 1e9, b = 1e9, c = -1e9, d = -1e9; for (const [x, y] of p) { a = Math.min(a, x); b = Math.min(b, y); c = Math.max(c, x); d = Math.max(d, y); } return [a, b, c, d]; }
function assignPanelArt() {
  const used = { manga: [], shonen: [], shojo: [], nero: [], recut: [] };
  for (const s of SN) for (const p of s.panels) {
    if (PANEL_ART.has(p.id) || p.state === 'open') continue;
    let pool;
    if (p.state === 'sealed') pool = p.sealKind === 'nero' ? 'nero' : p.hero === 'shojo' ? 'shojo' : 'shonen';
    else pool = p.recut ? 'recut' : 'manga';
    const [x0, y0, x1, y1] = bboxOf(p.poly); const asp = (x1 - x0) / (y1 - y0);
    let best = 0, bs = 1e9;
    ART[pool].forEach((sp, i) => {
      const a2 = sp.width / sp.height;
      const sc = Math.abs(Math.log(a2 / asp)) + used[pool].filter((u) => u === i).length * 0.9;
      if (sc < bs) { bs = sc; best = i; }
    });
    used[pool].push(best);
    PANEL_ART.set(p.id, { pool, i: best });
  }
}

// ---------------- snapshots (interpolated for slow motion) ----------------
function snapAt(sf) {
  sf = clamp(sf, 0, SN.length - 1);
  const i = Math.floor(sf), fr = sf - i;
  const A = SN[i], B = SN[Math.min(SN.length - 1, i + 1)];
  if (fr < 1e-6 || A === B) return A;
  const an = A.an.map((a) => { const b = B.an.find((q) => q.id === a.id); return b ? { ...a, x: lerp(a.x, b.x, fr), y: lerp(a.y, b.y, fr) } : a; });
  const cuts = A.cuts.map((c) => { const d = B.cuts.find((q) => q.id === c.id); return d && d.state === c.state ? { ...c, a: lerp(c.a, d.a, fr), b: lerp(c.b, d.b, fr) } : c; });
  return { ...A, an, cuts };
}
const evIn = (type, f0, f1) => EV.filter((e) => e.type === type && e.f > f0 && e.f <= f1);
const lastEv = (type, sf, pred = () => true) => { let r = null; for (const e of EV) { if (e.f > sf) break; if (e.type === type && pred(e)) r = e; } return r; };

let INKMAX = null;
function inkMax(sf) {
  if (!INKMAX) { INKMAX = []; let m = 0; for (const s of SN) { m = Math.max(m, s.inked); INKMAX.push(m); } }
  return INKMAX[clamp(Math.floor(sf), 0, SN.length - 1)];
}
// ---------------- drawing primitives ----------------
function polyPath(g, p) { g.beginPath(); g.moveTo(p[0][0], p[0][1]); for (let i = 1; i < p.length; i++) g.lineTo(p[i][0], p[i][1]); g.closePath(); }
function cover(g, img, x0, y0, x1, y1, zoom = 1, ox = 0, oy = 0) {
  const w = x1 - x0, h = y1 - y0; const s = Math.max(w / img.width, h / img.height) * zoom;
  const dw = img.width * s, dh = img.height * s;
  g.drawImage(img, x0 + (w - dw) / 2 + ox, y0 + (h - dh) / 2 + oy, dw, dh);
}
function rrect(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }
function text(g, s, x, y, o = {}) {
  g.save();
  g.font = `${o.weight || ''} ${o.size || 32}px ${o.font || FONT.ui}`.trim();
  g.textAlign = o.align || 'left'; g.textBaseline = o.base || 'alphabetic';
  if (o.ls != null) g.letterSpacing = `${o.ls}px`;
  g.globalAlpha *= o.alpha ?? 1;
  if (o.stroke) { g.lineJoin = 'round'; g.lineWidth = o.stroke; g.strokeStyle = o.strokeColor || C.ink; g.strokeText(s, x, y); }
  g.fillStyle = o.color || '#fff'; g.fillText(s, x, y);
  g.restore();
}
function wrap(g, s, maxW, o) {
  const words = s.split(' '); const out = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (measure(g, t, o) > maxW && cur) { out.push(cur); cur = w; } else cur = t; }
  if (cur) out.push(cur); return out;
}
function measure(g, s, o) { g.save(); g.font = `${o.weight || ''} ${o.size}px ${o.font}`.trim(); if (o.ls != null) g.letterSpacing = `${o.ls}px`; const w = g.measureText(s).width; g.restore(); return w; }
// manga onomatopoeia
function sfx(g, s, x, y, size, age, o = {}) {
  if (age < 0 || age > (o.life || 40)) return;
  const pop = age < 7 ? lerp(1.7, 1, eOut(age / 7)) : 1;
  const fade = 1 - inv((o.life || 40) - 10, o.life || 40, age);
  g.save(); g.translate(x, y); g.rotate(o.rot ?? -0.12); g.scale(pop, pop); g.globalAlpha *= fade;
  g.font = `${size}px ${FONT.dela}`; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.lineJoin = 'round';
  g.lineWidth = size * 0.34; g.strokeStyle = o.outer || '#fff'; g.strokeText(s, 0, 0);
  g.lineWidth = size * 0.16; g.strokeStyle = C.ink; g.strokeText(s, 0, 0);
  g.fillStyle = o.color || C.coral; g.fillText(s, 0, 0);
  g.restore();
}
function speedLines(g, cx, cy, r0, r1, n, seed, alpha = 1, color = C.ink, width = 1) {
  g.save(); g.globalAlpha *= alpha; g.fillStyle = color;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + hash(seed + i) * 0.08;
    const rr = r0 + hash(seed + i * 3.1) * (r1 - r0) * 0.35;
    const w = (0.004 + hash(seed + i * 7.7) * 0.012) * width;
    g.beginPath();
    g.moveTo(cx + Math.cos(a - w) * r1, cy + Math.sin(a - w) * r1);
    g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
    g.lineTo(cx + Math.cos(a + w) * r1, cy + Math.sin(a + w) * r1);
    g.fill();
  }
  g.restore();
}
function star4(g, x, y, r, color = '#fff') {
  g.save(); g.fillStyle = color; g.beginPath();
  g.moveTo(x, y - r); g.quadraticCurveTo(x, y, x + r, y); g.quadraticCurveTo(x, y, x, y + r); g.quadraticCurveTo(x, y, x - r, y); g.quadraticCurveTo(x, y, x, y - r);
  g.fill(); g.restore();
}

// ---------------- official-style TCG card ----------------
function cardShape(g, x, y, w, h) {
  const r = w * 0.07; rrect(g, x, y, w, h, r);
}
function drawCardFront(g, x, y, w, h, o) {
  const frame = o.frame === 'purple' ? C.purple : C.card;
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = w * 0.12; g.shadowOffsetY = w * 0.04;
  cardShape(g, x, y, w, h); g.fillStyle = frame; g.fill();
  g.shadowColor = 'transparent';
  // diagonal sheen stripes on the frame (as on Zenko's card)
  g.save(); cardShape(g, x, y, w, h); g.clip();
  g.globalAlpha = 0.16; g.fillStyle = '#fff';
  for (let i = -2; i < 6; i++) { g.beginPath(); const sx = x + i * w * 0.28; g.moveTo(sx, y + h); g.lineTo(sx + w * 0.12, y + h); g.lineTo(sx + w * 0.6, y); g.lineTo(sx + w * 0.48, y); g.fill(); }
  g.restore();
  // black inner window with notched top-left corner
  const m = w * 0.075, n = w * 0.17;
  const ix = x + m, iy = y + m, iw = w - m * 2, ih = h - m * 2;
  g.beginPath(); g.moveTo(ix + n, iy); g.lineTo(ix + iw, iy); g.lineTo(ix + iw, iy + ih); g.lineTo(ix, iy + ih); g.lineTo(ix, iy + n); g.closePath();
  g.fillStyle = '#111'; g.fill();
  // art window
  const a = w * 0.035, ax = ix + a, ay = iy + a, aw = iw - a * 2, ahh = ih * 0.76 - a;
  g.save(); g.beginPath(); g.moveTo(ax + n * 0.8, ay); g.lineTo(ax + aw, ay); g.lineTo(ax + aw, ay + ahh); g.lineTo(ax, ay + ahh); g.lineTo(ax, ay + n * 0.8); g.closePath(); g.clip();
  g.fillStyle = o.artBg || frame; g.fillRect(ax, ay, aw, ahh);
  if (o.art) cover(g, o.art, ax, ay, ax + aw, ay + ahh, o.zoom || 1, o.ox || 0, o.oy || 0);
  if (o.stamp) drawHanko(g, ax + aw * 0.78, ay + ahh * 0.8, aw * 0.2, -0.15, 1);
  if (o.holo != null) { // holo sweep
    const hx = lerp(ax - aw, ax + aw * 2, (o.holo % 1));
    const gr = g.createLinearGradient(hx - aw * 0.4, ay, hx + aw * 0.4, ay + ahh);
    gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.28)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(ax, ay, aw, ahh);
  }
  g.restore();
  // text box
  const ty = ay + ahh + a * 0.9;
  if (o.title) text(g, o.title, ax + a * 0.4, ty + h * 0.07, { font: FONT.dela, size: Math.round(w * 0.105), color: '#fff' });
  if (o.sub) text(g, o.sub, ax + a * 0.4, ty + h * 0.115, { font: FONT.mono, size: Math.max(9, Math.round(w * 0.042)), color: frame, ls: 1 });
  if (o.lines === true) { g.fillStyle = '#2a2a2a'; for (let i = 0; i < 2; i++) g.fillRect(ax + aw * 0.42, ty + h * (0.045 + i * 0.035), aw * (0.5 - i * 0.12), h * 0.012); }
  g.restore();
}
function drawCardBack(g, x, y, w, h) {
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.45)'; g.shadowBlur = w * 0.12; g.shadowOffsetY = w * 0.04;
  cardShape(g, x, y, w, h); g.fillStyle = '#151515'; g.fill(); g.shadowColor = 'transparent';
  g.save(); cardShape(g, x + w * 0.05, y + w * 0.05, w * 0.9, h - w * 0.1); g.clip();
  cover(g, IMG.cardback, x, y, x + w, y + h, 1.05);
  g.restore();
  const lw = w * 0.86, lh = lw * IMG.logoCB.height / IMG.logoCB.width;
  g.translate(x + w / 2, y + h / 2); g.rotate(-0.5);
  g.drawImage(IMG.logoCB, -lw / 2, -lh / 2, lw, lh);
  g.restore();
}
function drawCard(g, cx, cy, w, h, flip, front, rot = 0) {
  // flip: 0 = back, 1 = front, animated via horizontal scale
  const a = flip * Math.PI; const sx = Math.cos(a);
  g.save(); g.translate(cx, cy); g.rotate(rot); g.scale(Math.max(0.02, Math.abs(sx)), 1);
  if (sx > 0) drawCardBack(g, -w / 2, -h / 2, w, h); else drawCardFront(g, -w / 2, -h / 2, w, h, front);
  g.restore();
}
function drawHanko(g, x, y, s, rot, k) {
  g.save(); g.translate(x, y); g.rotate(rot); g.scale(k, k);
  g.fillStyle = '#d6303a'; rrect(g, -s / 2, -s / 2, s, s, s * 0.12); g.fill();
  g.strokeStyle = C.paper; g.lineWidth = s * 0.05; rrect(g, -s * 0.4, -s * 0.4, s * 0.8, s * 0.8, s * 0.06); g.stroke();
  g.font = `${Math.round(s * 0.62)}px ${FONT.dela}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = C.paper;
  g.fillText('封', 0, s * 0.03);
  g.restore();
}

// ---------------- anomaly ----------------
function drawWisp(g, a, vt, emerge) {
  const r = a.r * emerge; if (r < 1) return;
  const id = a.id; const dir = Math.atan2(a.vy, a.vx);
  g.save(); g.translate(a.x, a.y);
  // ink droplet trail
  for (let i = 1; i <= 5; i++) {
    const k = i * 0.055; const jx = (hash(id + i) - 0.5) * 10, jy = (hash(id * 3 + i) - 0.5) * 10;
    g.fillStyle = i % 2 ? C.ink : '#3a1420';
    g.beginPath(); g.arc(-a.vx * k + jx, -a.vy * k + jy, r * (0.32 - i * 0.045), 0, 7); g.fill();
  }
  // flame tongues (Resonance): swept back behind the anomaly like a fireball
  const N = 11, backA = dir + Math.PI;
  for (let pass = 0; pass < 2; pass++) for (let i = 0; i < N; i++) {
    const ang = (i / N) * Math.PI * 2 + Math.sin(vt * 2.1 + id + i) * 0.18 + hash(id + i) * 0.35;
    const back = Math.max(0, -Math.cos(ang - dir));
    const L = r * (0.1 + 0.3 * noise1(vt * 4 + i * 1.7 + id) + 1.6 * Math.pow(back, 1.4) * (0.75 + 0.5 * noise1(vt * 6 + i)));
    if (L < r * 0.18) continue;
    let da = backA - ang; da = Math.atan2(Math.sin(da), Math.cos(da));
    const tipA = ang + da * 0.55;
    const base = r * 0.8, w = 0.3 + 0.16 * back;
    const tip = [Math.cos(tipA) * (base + L), Math.sin(tipA) * (base + L)];
    const c1 = [Math.cos(ang + da * 0.2 - 0.18) * (base + L * 0.55), Math.sin(ang + da * 0.2 - 0.18) * (base + L * 0.55)];
    const c2 = [Math.cos(ang + da * 0.3 + 0.22) * (base + L * 0.4), Math.sin(ang + da * 0.3 + 0.22) * (base + L * 0.4)];
    g.beginPath();
    g.moveTo(Math.cos(ang - w) * base, Math.sin(ang - w) * base);
    g.quadraticCurveTo(c1[0], c1[1], tip[0], tip[1]);
    g.quadraticCurveTo(c2[0], c2[1], Math.cos(ang + w) * base, Math.sin(ang + w) * base);
    g.closePath();
    if (pass === 0) { g.lineWidth = 5; g.strokeStyle = C.ink; g.lineJoin = 'round'; g.stroke(); }
    else { g.fillStyle = i % 3 === 0 ? '#ff8b84' : C.coral; g.fill(); }
  }
  // body blob
  g.beginPath();
  for (let i = 0; i <= 28; i++) {
    const th = (i / 28) * Math.PI * 2;
    const rr = r * (1 + 0.07 * Math.sin(th * 3 + vt * 4 + id) + 0.05 * Math.sin(th * 5 - vt * 3));
    i ? g.lineTo(Math.cos(th) * rr, Math.sin(th) * rr) : g.moveTo(Math.cos(th) * rr, Math.sin(th) * rr);
  }
  g.closePath();
  const gr = g.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r * 1.05);
  gr.addColorStop(0, '#4a2238'); gr.addColorStop(0.6, '#1c0f18'); gr.addColorStop(1, '#0b070a');
  g.fillStyle = gr; g.fill(); g.lineWidth = 4; g.strokeStyle = C.ink; g.stroke();
  // rim highlight
  g.strokeStyle = 'rgba(255,190,190,0.55)'; g.lineWidth = 2.5; g.beginPath(); g.arc(0, 0, r * 0.78, Math.PI * 1.05, Math.PI * 1.45); g.stroke();
  // single slit eye (amber, like Nero's) looking where it moves
  g.rotate(dir);
  const ex = r * 0.28, ew = r * 0.62, eh = r * 0.34;
  g.beginPath(); g.moveTo(ex - ew / 2, 0); g.quadraticCurveTo(ex, -eh, ex + ew / 2, 0); g.quadraticCurveTo(ex, eh * 0.75, ex - ew / 2, 0); g.closePath();
  g.fillStyle = C.gold; g.fill(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke();
  g.fillStyle = C.ink; g.beginPath(); g.ellipse(ex + ew * 0.08, 0, r * 0.06, eh * 0.62, 0, 0, 7); g.fill();
  g.fillStyle = '#fff'; g.beginPath(); g.arc(ex - ew * 0.1, -eh * 0.28, r * 0.07, 0, 7); g.fill();
  g.restore();
}
function drawNero(g, a, vt, emerge) {
  const r = a.r * emerge; if (r < 1) return;
  g.save(); g.translate(a.x, a.y);
  // golden aura + violet flames
  const gl = g.createRadialGradient(0, 0, r * 0.4, 0, 0, r * 2.1);
  gl.addColorStop(0, 'rgba(242,180,60,0.55)'); gl.addColorStop(1, 'rgba(242,180,60,0)');
  g.fillStyle = gl; g.beginPath(); g.arc(0, 0, r * 2.1, 0, 7); g.fill();
  const dirN = Math.atan2(a.vy, a.vx), backN = dirN + Math.PI;
  for (let pass = 0; pass < 2; pass++) for (let i = 0; i < 9; i++) {
    const ang = (i / 9) * Math.PI * 2 + Math.sin(vt * 1.6 + i) * 0.2;
    const back = Math.max(0, -Math.cos(ang - dirN));
    const L = r * (0.15 + 0.3 * noise1(vt * 3 + i * 1.3) + 1.3 * Math.pow(back, 1.3));
    let da = backN - ang; da = Math.atan2(Math.sin(da), Math.cos(da)); const tipA = ang + da * 0.5;
    const base = r * 0.85, w = 0.3 + 0.12 * back;
    g.beginPath(); g.moveTo(Math.cos(ang - w) * base, Math.sin(ang - w) * base);
    g.quadraticCurveTo(Math.cos(ang + da * 0.2) * (base + L * 0.6), Math.sin(ang + da * 0.2) * (base + L * 0.6), Math.cos(tipA) * (base + L), Math.sin(tipA) * (base + L));
    g.quadraticCurveTo(Math.cos(ang + da * 0.3 + 0.25) * (base + L * 0.35), Math.sin(ang + da * 0.3 + 0.25) * (base + L * 0.35), Math.cos(ang + w) * base, Math.sin(ang + w) * base);
    g.closePath();
    if (pass === 0) { g.lineWidth = 5; g.strokeStyle = C.ink; g.stroke(); } else { g.fillStyle = i % 2 ? C.gold : C.coral; g.fill(); }
  }
  // soft spirit halo so the head reads clearly
  const halo = g.createRadialGradient(0, 0, r * 0.3, 0, 0, r * 1.25);
  halo.addColorStop(0, 'rgba(255,236,190,0.95)'); halo.addColorStop(0.7, 'rgba(242,180,60,0.85)'); halo.addColorStop(1, 'rgba(242,180,60,0)');
  g.fillStyle = halo; g.beginPath(); g.arc(0, 0, r * 1.25, 0, 7); g.fill();
  // Nero's official head art floating in the flames
  const s = r * 3.0; const bob = Math.sin(vt * 5) * r * 0.05;
  const face = a.vx < 0 ? 1 : -1; // official art faces left; mirror when moving right
  g.scale(face, 1);
  g.drawImage(ART.neroHead, -s * 0.55, -s * 0.52 + bob, s, s);
  g.restore();
}
function drawPinned(g, a, sf, vt) {
  const age = sf - a.pinF; if (a.pinF < 0) return;
  const left = a.frozenUntil - sf; if (left < -12) return;
  const k = eBack(age / 10) * clamp(left / 12 + 1, 0, 1);
  g.save(); g.translate(a.x, a.y);
  // bubble-gum bubble (Shojo's signature)
  const R = a.r * 1.45 * k;
  const gr = g.createRadialGradient(-R * 0.3, -R * 0.35, R * 0.1, 0, 0, R);
  gr.addColorStop(0, 'rgba(255,220,236,0.55)'); gr.addColorStop(0.7, 'rgba(239,155,204,0.35)'); gr.addColorStop(1, 'rgba(214,96,150,0.55)');
  g.fillStyle = gr; g.beginPath(); g.arc(0, 0, R, 0, 7); g.fill();
  g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke();
  g.fillStyle = 'rgba(255,255,255,0.85)'; g.beginPath(); g.ellipse(-R * 0.4, -R * 0.45, R * 0.16, R * 0.08, -0.7, 0, 7); g.fill();
  // official kunai, stuck in at an angle
  const kh = a.r * 2.3, kw = kh * ART.kunai.width / ART.kunai.height;
  g.rotate(0.7 + (a.id % 2) * 0.5); g.translate(0, -a.r * 0.95 - lerp(60, 0, eOut(age / 6)));
  g.drawImage(ART.kunai, -kw / 2, -kh * 0.75, kw, kh);
  g.restore();
}

// ---------------- the page (game layer) ----------------
function drawPage(g, sf, vt, o = {}) {
  const S = snapAt(sf);
  const { W: PW, H: PH } = TAKE.page;
  // paper
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 50; g.shadowOffsetY = 18;
  g.fillStyle = C.paper; g.fillRect(0, 0, PW, PH); g.restore();
  // panels
  for (const p of S.panels) drawPanel(g, p, S, sf, vt);
  // rift
  drawRift(g, S, sf, vt);
  // cuts
  for (const c of S.cuts) drawCut(g, c, sf, vt);
  // swipe pre-roll for upcoming cuts
  for (const e of EV) if (e.type === 'cut' && sf > e.f - 9 && sf <= e.f + 2) drawSwipe(g, e, sf);
  // anomalies
  for (const a of S.an) {
    if (!a.alive) continue;
    const em = eBack(inv(a.born, a.born + 20, sf));
    if (a.kind === 'nero') drawNero(g, a, vt, em); else drawWisp(g, a, vt, em);
    if (a.pinF >= 0) drawPinned(g, a, sf, vt);
  }
  // seal / break FX
  drawPageFX(g, S, sf, vt);
  g.fillStyle = 'rgba(0,0,0,0)';
  g.save(); g.globalCompositeOperation = 'multiply'; g.globalAlpha = 0.5; g.fillStyle = g.createPattern(ART.grain, 'repeat'); g.fillRect(0, 0, PW, PH); g.restore();
  return S;
}
function cutLine(id) { return CUTS[id]; }
function drawPanel(g, p, S, sf, vt) {
  const born = sf - p.born;
  g.save(); polyPath(g, p.poly); g.clip();
  const [x0, y0, x1, y1] = bboxOf(p.poly);
  if (p.state === 'open') {
    g.fillStyle = '#f7f5f0'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
    // the spirit realm bleeding through the open panel
    g.save(); g.globalAlpha = 0.09; g.globalCompositeOperation = 'multiply';
    g.translate(380, 500); g.rotate(vt * 0.03); g.drawImage(IMG.cardback, -560, -440, 1120, 880); g.restore();
    g.globalAlpha = 0.07; g.fillStyle = g.createPattern(ART.halftone, 'repeat'); g.fillRect(x0, y0, x1 - x0, y1 - y0); g.globalAlpha = 1;
  } else {
    const art = PANEL_ART.get(p.id); const sp = ART[art.pool][art.i];
    const age = sf - p.fillF;
    const cl = cutLine(p.cutId);
    // wipe direction: from the cut line into the panel
    let nx = 0, ny = 1, lx = (x0 + x1) / 2, ly = y0;
    if (cl) { const a = (cl.ang * Math.PI) / 180; nx = -Math.sin(a); ny = Math.cos(a); const [cx, cy] = [(x0 + x1) / 2, (y0 + y1) / 2]; if ((cx - cl.x) * nx + (cy - cl.y) * ny < 0) { nx = -nx; ny = -ny; } lx = cl.x; ly = cl.y; }
    const span = Math.hypot(x1 - x0, y1 - y0);
    if (p.state === 'inked') {
      const pr = eOut(age / 26);
      g.fillStyle = '#f7f5f0'; g.fillRect(x0, y0, x1 - x0, y1 - y0);
      g.save();
      // reveal mask: half-plane advancing from the cut
      const d = pr * span * 1.1;
      g.beginPath();
      const px = lx + nx * d, py = ly + ny * d, tx = -ny * 3000, ty = nx * 3000;
      g.moveTo(lx - nx * 50 + tx, ly - ny * 50 + ty); g.lineTo(px + tx, py + ty); g.lineTo(px - tx, py - ty); g.lineTo(lx - nx * 50 - tx, ly - ny * 50 - ty); g.closePath(); g.clip();
      const z = 1.08 - 0.06 * eOut(age / 120);
      cover(g, sp, x0, y0, x1, y1, z);
      g.restore();
      // halftone front edge
      if (pr < 1) {
        g.save(); g.globalAlpha = 0.55 * (1 - pr);
        const px = lx + nx * d, py = ly + ny * d;
        g.translate(px, py); g.rotate(Math.atan2(ny, nx));
        g.fillStyle = g.createPattern(ART.halftone, 'repeat'); g.fillRect(-40, -3000, 80, 6000);
        g.restore();
      }
    } else if (p.state === 'sealed') {
      const z = 1.12 - 0.08 * eOut(age / 50);
      cover(g, sp, x0, y0, x1, y1, z);
      g.fillStyle = 'rgba(0,0,0,0.0)';
      if (age < 30) { // flash + speed lines
        const [sx, sy] = p.sealAt || [(x0 + x1) / 2, (y0 + y1) / 2];
        g.fillStyle = `rgba(255,255,255,${0.95 * (1 - eOut(age / 10))})`; g.fillRect(x0, y0, x1 - x0, y1 - y0);
        speedLines(g, sx, sy, 30, span, 70, p.id, 0.8 * (1 - age / 30));
      }
      const [sx, sy] = p.sealAt || [(x0 + x1) / 2, (y0 + y1) / 2];
      const st = inv(3, 13, age);
      if (st > 0) {
        const s = Math.min(110, Math.min(x1 - x0, y1 - y0) * 0.5);
        const hx = clamp(sx, x0 + s * 0.7, x1 - s * 0.7), hy = clamp(sy, y0 + s * 0.7, y1 - s * 0.7);
        drawHanko(g, hx, hy, s, -0.18 + (p.id % 3) * 0.08, lerp(2.4, 1, eOut(st)));
      }
    }
  }
  g.restore();
  // border
  g.save(); polyPath(g, p.poly); g.lineJoin = 'miter'; g.lineWidth = 6; g.strokeStyle = C.ink; g.stroke();
  if (born < 14 && born >= 0) { g.lineWidth = 6; g.strokeStyle = `rgba(244,87,94,${1 - born / 14})`; g.stroke(); }
  g.restore();
}
function drawRift(g, S, sf, vt) {
  const R = S.rift; if (!R) return;
  const open = S.panels.find((p) => p.state === 'open' && insidePoly(p.poly, R.x, R.y));
  const age = sf - R.f;
  const lastSplit = open ? 1 : 1 - inv(0, 12, sf - (lastEv('split', sf)?.f ?? sf));
  const k = eBack(inv(0, 24, age)) * lastSplit; if (k <= 0.01) return;
  g.save(); g.translate(R.x, R.y); g.rotate(-0.5 + R.level * 0.9);
  const len = 120 * k * (R.level >= 2 ? 1.25 : 1), wid = 26 * k;
  const pts = [];
  for (let i = 0; i <= 12; i++) { const t = i / 12; const w = Math.sin(t * Math.PI) * wid * (0.6 + 0.4 * hash(R.level * 13 + i)); pts.push([lerp(-len, len, t), w]); }
  const top = pts.map(([x, w], i) => [x, -w - (i % 2 ? 6 : 0) * k]), bot = pts.map(([x, w], i) => [x, w + (i % 2 ? 0 : 6) * k]).reverse();
  const glow = 0.6 + 0.4 * Math.sin(vt * 6);
  g.shadowColor = C.coral; g.shadowBlur = 40 * glow;
  g.beginPath(); [...top, ...bot].forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath();
  g.fillStyle = '#12060c'; g.fill(); g.shadowBlur = 0;
  g.lineWidth = 7; g.strokeStyle = C.coral; g.stroke(); g.lineWidth = 3; g.strokeStyle = C.ink; g.stroke();
  // inner glow streak
  g.strokeStyle = `rgba(255,170,160,${0.8 * glow})`; g.lineWidth = 2; g.beginPath(); g.moveTo(-len * 0.7, 0); g.lineTo(len * 0.7, 0); g.stroke();
  g.restore();
  if (age < 70 && age >= 0) {
    const lbl = R.level === 1 ? 'RIFT OPEN' : R.level === 2 ? 'RIFT LV.2' : 'RIFT LV.3';
    sfx(g, R.level === 1 ? 'ゴゴゴ' : 'ゴゴゴゴ', R.x + 130, R.y - 90, 46, age, { life: 60, rot: 0.15, color: C.ink, outer: C.paper });
    text(g, lbl, R.x, R.y + 92, { font: FONT.mono, size: 22, align: 'center', color: '#fff', ls: 4, alpha: inv(0, 6, age) * (1 - inv(55, 70, age)), stroke: 7, strokeColor: C.coral });
  }
}
function insidePoly(poly, x, y) {
  for (let i = 0; i < poly.length; i++) { const a = poly[i], b = poly[(i + 1) % poly.length]; if ((b[0] - a[0]) * (y - a[1]) - (b[1] - a[1]) * (x - a[0]) < 0) return false; }
  return true;
}
function heroColor(h) { return h === 'shojo' ? C.sakura : C.coral; }
function drawCut(g, c, sf, vt) {
  const col = heroColor(c.hero);
  const A = [c.x + c.d[0] * c.a, c.y + c.d[1] * c.a], B = [c.x + c.d[0] * c.b, c.y + c.d[1] * c.b];
  if (c.state === 'grow') {
    g.save(); g.lineCap = 'round';
    g.shadowColor = col; g.shadowBlur = 28;
    g.strokeStyle = col; g.globalAlpha = 0.55; g.lineWidth = c.burst ? 22 : 16; g.beginPath(); g.moveTo(...A); g.lineTo(...B); g.stroke();
    g.globalAlpha = 1; g.shadowBlur = 0;
    // flame licks along the line
    const L = Math.hypot(B[0] - A[0], B[1] - A[1]); const n = Math.floor(L / 26);
    const nx = -c.d[1], ny = c.d[0];
    g.fillStyle = c.hero === 'shojo' ? '#ffd2ea' : '#ff8b84';
    for (let i = 0; i < n; i++) {
      const t = (i + 0.5) / n; const px = lerp(A[0], B[0], t), py = lerp(A[1], B[1], t);
      const s = (i % 2 ? 1 : -1) * (8 + 10 * noise1(vt * 8 + i));
      g.beginPath(); g.moveTo(px - c.d[0] * 9, py - c.d[1] * 9); g.lineTo(px + nx * s, py + ny * s); g.lineTo(px + c.d[0] * 9, py + c.d[1] * 9); g.fill();
    }
    g.strokeStyle = C.ink; g.lineWidth = 7; g.beginPath(); g.moveTo(...A); g.lineTo(...B); g.stroke();
    g.strokeStyle = '#fff'; g.lineWidth = 3.5; g.beginPath(); g.moveTo(...A); g.lineTo(...B); g.stroke();
    for (const P of [A, B]) { const gl = g.createRadialGradient(P[0], P[1], 0, P[0], P[1], 34); gl.addColorStop(0, 'rgba(255,255,255,0.95)'); gl.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gl; g.beginPath(); g.arc(P[0], P[1], 34, 0, 7); g.fill(); star4(g, P[0], P[1], 20 + 6 * Math.sin(vt * 30)); }
    const age = sf - c.f0;
    if (age < 14) { g.strokeStyle = `rgba(255,255,255,${1 - age / 14})`; g.lineWidth = 4; g.beginPath(); g.arc(c.x, c.y, 10 + age * 5, 0, 7); g.stroke(); }
    g.restore();
  } else if (c.state === 'done') {
    const age = sf - c.fEnd; if (age > 16) return;
    const k = 1 - age / 16;
    const P0 = [c.x + c.d[0] * c.t0, c.y + c.d[1] * c.t0], P1 = [c.x + c.d[0] * c.t1, c.y + c.d[1] * c.t1];
    g.save(); g.lineCap = 'round'; g.shadowColor = col; g.shadowBlur = 30 * k;
    g.strokeStyle = `rgba(255,255,255,${k})`; g.lineWidth = 14 * k + 1; g.beginPath(); g.moveTo(...P0); g.lineTo(...P1); g.stroke();
    g.restore();
    // ink splats where the cut meets the borders
    for (const [P, s] of [[P0, 1], [P1, 2]]) for (let i = 0; i < 6; i++) {
      const ang = hash(c.id * 9 + i + s) * Math.PI * 2, dd = (8 + 30 * hash(c.id + i * 5 + s)) * eOut(age / 8);
      g.fillStyle = C.ink; g.globalAlpha = k; g.beginPath(); g.arc(P[0] + Math.cos(ang) * dd, P[1] + Math.sin(ang) * dd, 3 + 4 * hash(i + s + c.id), 0, 7); g.fill(); g.globalAlpha = 1;
    }
  } else if (c.state === 'broken') {
    const age = sf - c.fEnd; if (age > 34) return;
    const k = 1 - age / 34;
    // shards fly off the broken line
    const n = 12;
    for (let i = 0; i < n; i++) {
      const t0 = i / n, t1 = (i + 0.8) / n;
      const p0 = [lerp(A[0], B[0], t0), lerp(A[1], B[1], t0)], p1 = [lerp(A[0], B[0], t1), lerp(A[1], B[1], t1)];
      const mx = (p0[0] + p1[0]) / 2, my = (p0[1] + p1[1]) / 2;
      const away = [mx - c.hit.x, my - c.hit.y]; const al = Math.hypot(...away) || 1;
      const sp = (80 + 120 * hash(c.id + i)) * eOut(age / 20) * (1.4 - Math.min(1, al / 300));
      const ox = (away[0] / al) * sp, oy = (away[1] / al) * sp + age * age * 0.08;
      const rot = (hash(i + c.id * 2) - 0.5) * age * 0.2;
      g.save(); g.translate(mx + ox, my + oy); g.rotate(rot); g.globalAlpha = k;
      g.strokeStyle = C.ink; g.lineWidth = 7; g.beginPath(); g.moveTo(p0[0] - mx, p0[1] - my); g.lineTo(p1[0] - mx, p1[1] - my); g.stroke();
      g.strokeStyle = heroColor(c.hero); g.lineWidth = 3; g.stroke();
      g.restore();
    }
    // crack burst at the hit
    g.save(); g.translate(c.hit.x, c.hit.y); g.globalAlpha = k; g.strokeStyle = C.coral; g.lineWidth = 5;
    for (let i = 0; i < 7; i++) { const a = (i / 7) * Math.PI * 2 + 0.3; const L = 40 + 50 * hash(i + c.id); g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(a) * L * 0.5 + 8, Math.sin(a) * L * 0.5 - 6); g.lineTo(Math.cos(a) * L, Math.sin(a) * L); g.stroke(); }
    g.restore();
    sfx(g, 'バキッ', c.hit.x + 20, c.hit.y - 70, 78, age, { life: 34, rot: 0.1, color: '#fff', outer: C.coral });
  }
}
function drawSwipe(g, e, sf) {
  const t = inv(e.f - 9, e.f, sf); const a = (e.ang * Math.PI) / 180; const d = [Math.cos(a), Math.sin(a)];
  const head = lerp(-150, 150, eOut(t)), tail = lerp(-150, 150, eIn(t)) - 40;
  const fade = 1 - inv(e.f, e.f + 2, sf);
  g.save(); g.lineCap = 'round'; g.globalAlpha = 0.85 * fade;
  const gr = g.createLinearGradient(e.x + d[0] * tail, e.y + d[1] * tail, e.x + d[0] * head, e.y + d[1] * head);
  gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(1, 'rgba(255,255,255,0.95)');
  g.strokeStyle = 'rgba(11,9,12,0.35)'; g.lineWidth = 16; g.beginPath(); g.moveTo(e.x + d[0] * tail, e.y + d[1] * tail); g.lineTo(e.x + d[0] * head, e.y + d[1] * head); g.stroke();
  g.strokeStyle = gr; g.lineWidth = 9; g.stroke();
  g.fillStyle = '#fff'; g.beginPath(); g.arc(e.x + d[0] * head, e.y + d[1] * head, 11, 0, 7); g.fill();
  g.strokeStyle = C.ink; g.lineWidth = 3; g.stroke();
  g.restore();
}
function drawPageFX(g, S, sf, vt) {
  for (const e of EV) {
    if (e.f > sf) break;
    const age = sf - e.f;
    if (e.type === 'seal' && age < 46) {
      if (e.kind === 'nero') sfx(g, 'ドンッ', e.x + 30, e.y - 110, 96, age, { life: 46, color: C.gold });
      else sfx(g, e.combo >= 2 ? 'ザシュッ' : 'ザシュッ', e.x + 10, e.y - 80, e.combo >= 3 ? 80 : 70, age, { life: 40, rot: -0.14 + (e.card % 3) * 0.1, color: e.hero === 'shojo' ? C.sakura : C.coral });
      // ink burst ring
      if (age < 18) { g.save(); g.strokeStyle = `rgba(11,9,12,${1 - age / 18})`; g.lineWidth = 10 * (1 - age / 18); g.beginPath(); g.arc(e.x, e.y, 20 + age * 9, 0, 7); g.stroke(); g.restore(); }
    }
    if (e.type === 'pin' && age < 36) {
      for (const id of e.ids) { const a = S.an.find((q) => q.id === id); if (a) sfx(g, 'シュッ', a.x - 40, a.y - 70, 50, age, { life: 30, rot: -0.2, color: C.sakura }); }
    }
  }
}

// ---------------- backgrounds ----------------
function drawBackdrop(g, t, tint = 0.74) {
  g.fillStyle = '#120e15'; g.fillRect(0, 0, W, H);
  g.save(); g.globalAlpha = 0.9;
  const s = Math.max(W / ART.bannerBg.width, H / ART.bannerBg.height) * 1.08;
  g.drawImage(ART.bannerBg, (W - ART.bannerBg.width * s) / 2 + Math.sin(t * 0.15) * 24, (H - ART.bannerBg.height * s) / 2, ART.bannerBg.width * s, ART.bannerBg.height * s);
  g.restore();
  g.fillStyle = `rgba(18,13,22,${tint})`; g.fillRect(0, 0, W, H);
  // embers
  for (let i = 0; i < 46; i++) {
    const sp = 20 + hash(i) * 50; const x = (hash(i * 3.3) * W + Math.sin(t * 0.7 + i) * 30) % W;
    const y = H - ((t * sp + hash(i * 7.1) * H) % (H + 40)); const r = 1.5 + hash(i * 2.2) * 3;
    g.fillStyle = `rgba(244,87,94,${0.35 + 0.5 * noise1(t * 3 + i)})`; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  const vg = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.max(W, H) * 0.75);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.7)'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
}
// dark-red halftone stage with scattered Zenko card backs (after Zenko's own TCG promo art)
let HT_CANVAS = null;
function halftoneLayer() {
  if (HT_CANVAS) return HT_CANVAS;
  const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d');
  const step = 16;
  g.save(); g.translate(W / 2, H / 2); g.rotate(Math.PI / 4);
  const R = Math.hypot(W, H) / 2 + step;
  for (let y = -R; y < R; y += step) for (let x = -R; x < R; x += step) {
    const sx = W / 2 + (x - y) * Math.SQRT1_2, sy = H / 2 + (x + y) * Math.SQRT1_2;
    const f = clamp(0.15 + 0.85 * (1 - Math.hypot((sx - W * 0.82) / W, (sy - H * 0.9) / H) * 1.25)) * (0.75 + 0.25 * noise1(sx * 0.01 + sy * 0.013));
    const r = 0.6 + 5.2 * f;
    g.fillStyle = `rgba(150,52,60,${0.22 + 0.25 * f})`; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
  }
  g.restore();
  HT_CANVAS = c; return c;
}
function drawRedHalftone(g, t, dark = 0.35) {
  const bg = g.createRadialGradient(W * 0.5, H * 0.42, 40, W * 0.5, H * 0.5, Math.max(W, H) * 0.75);
  bg.addColorStop(0, '#5b2026'); bg.addColorStop(0.55, '#3a1216'); bg.addColorStop(1, '#170608');
  g.fillStyle = bg; g.fillRect(0, 0, W, H);
  g.save(); g.globalAlpha = 0.18; g.globalCompositeOperation = 'multiply';
  cover(g, IMG.cardback, 0, 0, W, H, 1.2, Math.sin(t * 0.1) * 30, 0); g.restore();
  g.drawImage(halftoneLayer(), 0, 0);
  // drifting card backs
  const cards = VERT
    ? [[-60, 260, 0.5, 430], [880, 120, -0.35, 380], [-40, 1500, -0.6, 420], [860, 1560, 0.45, 400]]
    : [[60, -40, 0.55, 420], [1640, 40, -0.4, 400], [-20, 760, -0.7, 380], [1700, 820, 0.5, 430]];
  for (const [x, y, r, w] of cards) {
    g.save(); g.globalAlpha = 0.55;
    g.translate(x + Math.sin(t * 0.3 + r) * 14, y + Math.cos(t * 0.25 + r) * 10); g.rotate(r + Math.sin(t * 0.2 + x) * 0.02);
    drawCardBack(g, -w / 2, -w * 0.7, w, w * 1.4);
    g.restore();
  }
  g.fillStyle = `rgba(20,6,8,${dark})`; g.fillRect(0, 0, W, H);
  const vg = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.7);
  vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.6)'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
}

// ---------------- layouts ----------------
const LAY = VERT
  ? { page: { x: 76, y: 350, s: 1.22 } }
  : { page: { x: 580, y: 40, s: 1.0 } };
let CUR_L = null;
function pageToScreen(x, y, L = CUR_L || LAY.page) { return [L.x + x * L.s, L.y + y * L.s]; }

// ---------------- HUD ----------------
function heroArt(h) { return h === 'shojo' ? ART.heroShojo : ART.heroShonen; }
function heroInfo(h) {
  return h === 'shojo' ? { title: 'SHOJO', sub: 'CATALYST · KUNAI PIN', frame: 'coral' } : { title: 'SHONEN', sub: 'VANGUARD · RESONANCE', frame: 'coral' };
}
function drawHUD(g, S, sf, vt, alpha = 1) {
  if (alpha <= 0) return;
  g.save(); g.globalAlpha = alpha;
  const lastHero = lastEv('hero', sf);
  const flip = lastHero ? inv(lastHero.f, lastHero.f + 18, sf) : 1;
  const prevHero = lastHero ? (lastHero.hero === 'shojo' ? 'shonen' : 'shojo') : 'shonen';
  const shownHero = flip < 0.5 && lastHero ? prevHero : S.hero;
  const flipScale = Math.abs(Math.cos(flip * Math.PI));
  if (!VERT) {
    // brand
    const lw = 300, lh = lw * IMG.logoL.height / IMG.logoL.width;
    g.drawImage(IMG.logoL, 96, 54, lw, lh);
    text(g, 'PANEL CUT', 100, 54 + lh + 46, { font: FONT.dela, size: 40, color: C.coral, ls: 2 });
    text(g, 'KUROKAWA · CH.01 · PAGE 07', 102, 54 + lh + 80, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
    // hero card
    const cw = 300, ch = 420, cx = 96 + cw / 2, cy = 300 + ch / 2;
    g.save(); g.translate(cx, cy); g.scale(Math.max(0.02, flipScale), 1);
    const hi = heroInfo(shownHero);
    drawCardFront(g, -cw / 2, -ch / 2, cw, ch, { art: heroArt(shownHero), title: hi.title, sub: hi.sub, holo: vt * 0.25, zoom: 1.0, oy: shownHero === 'shojo' ? 20 : 30 });
    g.restore();
    // lives
    text(g, 'LIVES', 100, 780, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
    const brk = lastEv('break', sf);
    for (let i = 0; i < 3; i++) {
      const lost = i >= S.lives; const justLost = brk && lost && i === brk.lives && sf - brk.f < 24;
      drawDrop(g, 112 + i * 52, 822, 18, lost, justLost ? (sf - brk.f) / 24 : 1);
    }
    // resonance
    text(g, 'RESONANCE', 100, 890, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
    drawMeter(g, 100, 904, 300, 20, S.res / 100, vt);
    if (S.res >= 100) text(g, 'MAX', 400, 890, { font: FONT.dela, size: 20, color: C.coral, align: 'right', alpha: 0.6 + 0.4 * Math.sin(vt * 10) });
    // right column: score
    const X = 1450;
    text(g, 'INKED', X, 92, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
    const pct = Math.round(inkMax(sf) * 100);
    text(g, `${pct}%`, X - 4, 196, { font: FONT.dela, size: 104, color: C.paper });
    text(g, 'CARDS SEALED', X, 262, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
    text(g, String(S.cards).padStart(2, '0'), X - 2, 330, { font: FONT.dela, size: 60, color: C.paper });
    // combo
    const lastSeal = lastEv('seal', sf);
    if (lastSeal && lastSeal.combo >= 2 && sf - lastSeal.f < 90) {
      const age = sf - lastSeal.f; const k = age < 8 ? lerp(1.6, 1, eOut(age / 8)) : 1;
      g.save(); g.translate(X + 245, 312); g.rotate(-0.1); g.scale(k, k); g.globalAlpha *= 1 - inv(70, 90, age);
      sfxText(g, `COMBO ×${lastSeal.combo}`, 0, 0, 36);
      g.restore();
    }
    // rack
    drawRack(g, S, sf, vt);
  } else {
    // vertical HUD: top band
    const lw = 250, lh = lw * IMG.logoL.height / IMG.logoL.width;
    g.drawImage(IMG.logoL, 60, 70, lw, lh);
    text(g, 'PANEL CUT', 64, 70 + lh + 44, { font: FONT.dela, size: 36, color: C.coral, ls: 2 });
    text(g, 'INKED', 1020, 92, { font: FONT.mono, size: 18, color: '#bdb6c4', ls: 3, align: 'right' });
    text(g, `${Math.round(inkMax(sf) * 100)}%`, 1024, 196, { font: FONT.dela, size: 100, color: C.paper, align: 'right' });
    text(g, `CARDS ${String(S.cards).padStart(2, '0')}`, 1020, 250, { font: FONT.dela, size: 34, color: C.paper, align: 'right' });
    const brk = lastEv('break', sf);
    for (let i = 0; i < 3; i++) { const lost = i >= S.lives; const jl = brk && lost && i === brk.lives && sf - brk.f < 24; drawDrop(g, 78 + i * 50, 300, 16, lost, jl ? (sf - brk.f) / 24 : 1); }
    drawMeter(g, 250, 290, 340, 18, S.res / 100, vt);
    // bottom band: hero card + rack
    const cw = 140, ch = 196, cx = 60 + cw / 2, cy = 1700 + ch / 2;
    g.save(); g.translate(cx, cy); g.scale(Math.max(0.02, flipScale), 1);
    const hi = heroInfo(shownHero);
    drawCardFront(g, -cw / 2, -ch / 2, cw, ch, { art: heroArt(shownHero), title: hi.title, sub: hi.sub.split(' · ')[0], holo: vt * 0.25, lines: false });
    g.restore();
    const lastSeal = lastEv('seal', sf);
    if (lastSeal && lastSeal.combo >= 2 && sf - lastSeal.f < 90) {
      const age = sf - lastSeal.f; const k = age < 8 ? lerp(1.6, 1, eOut(age / 8)) : 1;
      g.save(); g.translate(880, 330); g.rotate(-0.1); g.scale(k, k); g.globalAlpha *= 1 - inv(70, 90, age); sfxText(g, `COMBO ×${lastSeal.combo}`, 0, 0, 40); g.restore();
    }
    drawRack(g, S, sf, vt);
  }
  g.restore();
}
function sfxText(g, s, x, y, size, ls = 0) {
  g.letterSpacing = `${ls}px`;
  g.font = `${size}px ${FONT.dela}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
  g.lineWidth = size * 0.3; g.strokeStyle = '#fff'; g.strokeText(s, x, y);
  g.lineWidth = size * 0.14; g.strokeStyle = C.ink; g.strokeText(s, x, y);
  g.fillStyle = C.coral; g.fillText(s, x, y);
}
function drawDrop(g, x, y, r, lost, k) {
  g.save(); g.translate(x, y);
  const sc = lost && k < 1 ? 1 + 0.4 * Math.sin(k * Math.PI) : 1; g.scale(sc, sc);
  g.beginPath(); g.moveTo(0, -r * 1.5); g.bezierCurveTo(r * 0.9, -r * 0.4, r, r * 0.2, r, r * 0.35); g.arc(0, r * 0.35, r, 0, Math.PI); g.bezierCurveTo(-r, r * 0.2, -r * 0.9, -r * 0.4, 0, -r * 1.5); g.closePath();
  if (!lost || k < 0.5) { g.fillStyle = C.coral; g.fill(); }
  g.lineWidth = 3; g.strokeStyle = lost ? '#6d6274' : C.ink; g.stroke();
  if (lost) { g.strokeStyle = '#6d6274'; g.lineWidth = 3; g.beginPath(); g.moveTo(-r * 0.3, -r * 0.8); g.lineTo(r * 0.15, -r * 0.1); g.lineTo(-r * 0.2, r * 0.3); g.lineTo(r * 0.2, r * 0.9); g.stroke(); }
  g.restore();
}
function drawMeter(g, x, y, w, h, v, vt) {
  g.save(); rrect(g, x, y, w, h, h / 2); g.fillStyle = '#231c27'; g.fill(); g.lineWidth = 2; g.strokeStyle = '#4a3f52'; g.stroke();
  if (v > 0.001) {
    g.save(); rrect(g, x, y, w * v, h, h / 2); g.clip();
    const gr = g.createLinearGradient(x, 0, x + w, 0); gr.addColorStop(0, '#8e1f3a'); gr.addColorStop(1, C.coral);
    g.fillStyle = gr; g.fillRect(x, y, w, h);
    g.fillStyle = 'rgba(255,255,255,0.35)';
    for (let i = 0; i < 14; i++) { const px = x + ((i * 37 + vt * 120) % (w + 40)) - 20; g.beginPath(); g.moveTo(px, y + h); g.lineTo(px + 8, y); g.lineTo(px + 14, y); g.lineTo(px + 6, y + h); g.fill(); }
    g.restore();
    if (v >= 1) { g.shadowColor = C.coral; g.shadowBlur = 24; rrect(g, x, y, w, h, h / 2); g.strokeStyle = '#ffb3ae'; g.lineWidth = 2; g.stroke(); }
  }
  g.restore();
}
function rackSlot(n) {
  if (!VERT) { const i = n - 1; const cw = 88, ch = 124; return { x: 1450 + (i % 4) * (cw + 12) + cw / 2, y: 430 + Math.floor(i / 4) * (ch + 16) + ch / 2, w: cw, h: ch }; }
  const i = n - 1; const cw = 82, ch = 115; return { x: 232 + i * (cw + 10) + cw / 2, y: 1798, w: cw, h: ch };
}
function cardFront(card, full = false) {
  const p = SN[SN.length - 1].panels.find((q) => q.id === card.panel) || null;
  const art = PANEL_ART.get(card.panel);
  const sp = art ? ART[art.pool][art.i] : ART.manga[0];
  if (card.kind === 'nero') return { frame: 'purple', art: ART.heroNero, title: 'NERO', sub: full ? 'LEGENDARY · ANOMALY' : null, zoom: 1.0 };
  return { art: sp, title: `#${String(card.n).padStart(2, '0')}`, sub: full ? 'SEALED ANOMALY' : null, stamp: true };
}
function drawRack(g, S, sf, vt) {
  for (const card of CARDS) {
    if (sf < card.f) continue;
    const age = sf - card.f; const dur = 40;
    const slot = rackSlot(card.n);
    const [sx, sy] = pageToScreen(card.x, card.y);
    const t = eIO(age / dur);
    const x = lerp(sx, slot.x, t), y = lerp(sy, slot.y, t) - Math.sin(t * Math.PI) * 160;
    const sc = lerp(1.3, 1, t);
    const flip = clamp(age / dur * 1.3);
    drawCard(g, x, y, slot.w * sc, slot.h * sc, flip, { ...cardFront(card), holo: card.kind === 'nero' ? vt * 0.5 : null }, lerp(-0.5, 0, t));
    if (age >= dur && age < dur + 14) { g.save(); g.globalAlpha = 1 - (age - dur) / 14; g.strokeStyle = card.kind === 'nero' ? C.purple : '#fff'; g.lineWidth = 4; rrect(g, slot.x - slot.w / 2 - 4, slot.y - slot.h / 2 - 4, slot.w + 8, slot.h + 8, 10); g.stroke(); g.restore(); }
  }
}

// ---------------- cut-in (anime super move banner) ----------------
function drawCutIn(g, u, kind) {
  // u: 0..1 over the cut-in's life
  const inT = eOut(inv(0, 0.16, u)), outT = eIn(inv(0.84, 1, u));
  const k = inT * (1 - outT);
  if (k <= 0) return;
  const cfg = {
    shonen: { art: ART.cutShonen, col: C.coral, col2: '#2b0d14', big: 'RESONANCE  BURST', lbl: 'SHONEN · VANGUARD', jp: 'ザンッ' },
    shojo: { art: ART.cutShojo, col: C.sakura, col2: C.navy, big: 'KUNAI  PIN', lbl: 'SHOJO · CATALYST', jp: 'シュッ' },
    nero: { art: ART.cutNero, col: C.gold, col2: '#2a1f12', big: 'NEROOOOO.', lbl: 'NERO · THE ANOMALY · LEGENDARY', jp: 'ドンッ' },
  }[kind];
  g.save();
  g.fillStyle = `rgba(8,5,10,${0.62 * k})`; g.fillRect(0, 0, W, H);
  const bh = VERT ? 560 : 430; const cy = H * (VERT ? 0.46 : 0.5); const sk = VERT ? 120 : 160;
  const slide = (1 - inT) * -W * 1.2 + outT * W * 1.2;
  g.translate(slide, 0);
  // band
  g.beginPath(); g.moveTo(-200, cy - bh / 2 + sk / 2); g.lineTo(W + 200, cy - bh / 2 - sk / 2); g.lineTo(W + 200, cy + bh / 2 - sk / 2); g.lineTo(-200, cy + bh / 2 + sk / 2); g.closePath();
  g.save(); g.clip();
  g.fillStyle = cfg.col2; g.fillRect(-200, 0, W + 400, H);
  const drift = u * 120;
  const aw = W * 1.02, ah = aw * cfg.art.height / cfg.art.width;
  g.drawImage(cfg.art, (W - aw) / 2 - drift + 60, cy - ah / 2, aw, ah);
  speedLines(g, W * 0.3, cy, 200, W * 1.1, 90, 77, 0.35, '#fff', 1.4);
  g.restore();
  // band edges
  g.lineWidth = 14; g.strokeStyle = cfg.col;
  g.beginPath(); g.moveTo(-200, cy - bh / 2 + sk / 2); g.lineTo(W + 200, cy - bh / 2 - sk / 2); g.stroke();
  g.beginPath(); g.moveTo(-200, cy + bh / 2 + sk / 2); g.lineTo(W + 200, cy + bh / 2 - sk / 2); g.stroke();
  g.lineWidth = 5; g.strokeStyle = C.ink;
  g.beginPath(); g.moveTo(-200, cy - bh / 2 + sk / 2 - 10); g.lineTo(W + 200, cy - bh / 2 - sk / 2 - 10); g.stroke();
  g.beginPath(); g.moveTo(-200, cy + bh / 2 + sk / 2 + 10); g.lineTo(W + 200, cy + bh / 2 - sk / 2 + 10); g.stroke();
  // text
  const big = VERT ? 100 : 128;
  g.save(); g.translate(W * (VERT ? 0.5 : 0.62), cy + bh / 2 - (VERT ? 90 : 60)); g.rotate(-0.08);
  g.font = `${big}px ${FONT.dela}`; g.letterSpacing = '3px';
  const fit = Math.min(1, (W * (VERT ? 0.86 : 0.7)) / (g.measureText(cfg.big).width + big * 0.3));
  const tk = lerp(1.25, 1, eOut(inv(0.05, 0.25, u))) * fit;
  g.scale(tk, tk); g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
  g.lineWidth = big * 0.3; g.strokeStyle = '#fff'; g.strokeText(cfg.big, 0, 0);
  g.lineWidth = big * 0.15; g.strokeStyle = C.ink; g.strokeText(cfg.big, 0, 0);
  g.fillStyle = cfg.col; g.fillText(cfg.big, 0, 0);
  g.restore();
  text(g, cfg.lbl, VERT ? 60 : 120, cy - bh / 2 + (VERT ? 120 : 110), { font: FONT.mono, size: VERT ? 26 : 26, color: '#fff', ls: 6, stroke: 8, strokeColor: C.ink });
  g.restore();
}

// ---------------- impact frame (manga inversion) ----------------
function invertCanvas(g, amt = 1) {
  g.save(); g.globalCompositeOperation = 'difference'; g.fillStyle = `rgba(255,255,255,${amt})`; g.fillRect(0, 0, W, H); g.restore();
}

// ---------------- scenes ----------------
// Game-time maps: [outputSec, sourceSec] keyframes; linear between.
function mapTime(keys, t) {
  for (let i = 0; i < keys.length - 1; i++) { const [a, sa] = keys[i], [b, sb] = keys[i + 1]; if (t >= a && t <= b) return lerp(sa, sb, (t - a) / (b - a)); }
  return t < keys[0][0] ? keys[0][1] : keys[keys.length - 1][1];
}
function shakeAt(sf) {
  let amp = 0;
  for (const e of EV) {
    if (e.f > sf) break; const age = sf - e.f; if (age > 30) continue;
    const s = e.type === 'seal' ? (e.kind === 'nero' ? 22 : 13) : e.type === 'break' ? 18 : e.type === 'split' ? 4 : e.type === 'burst' ? 26 : 0;
    amp += s * Math.exp(-age / 6);
  }
  return [(noise1(sf * 0.9) - 0.5) * 2 * amp, (noise1(sf * 0.9 + 50) - 0.5) * 2 * amp];
}
function impactAt(sf) {
  for (const e of EV) {
    if (e.f > sf) break; const age = sf - e.f;
    if (e.type === 'seal' && age >= 0 && age < 3 && (e.kind === 'nero' || !(EV.find((q) => q.type === 'burst' && q.f <= e.f)))) return true;
    if (e.type === 'break' && age >= 0 && age < 2) return true;
    if (e.type === 'burst' && age >= 0 && age < 3) return true;
  }
  return false;
}
function sceneGame(g, t, shot) {
  const sf = mapTime(shot.keys, t) * FPS;
  const vt = t;
  drawBackdrop(g, t);
  const [shx, shy] = shakeAt(sf);
  const L = shot.cam ? camPage(shot.cam, t) : LAY.page;
  CUR_L = L;
  g.save(); g.translate(L.x + shx, L.y + shy); g.scale(L.s, L.s);
  const S = drawPage(g, sf, vt);
  g.restore();
  const hudA = shot.hudIn ? inv(shot.hudIn[0], shot.hudIn[1], t) : (shot.hud ?? 1);
  drawHUD(g, S, sf, vt, hudA);
  CUR_L = null;
  if (impactAt(sf)) invertCanvas(g);
  return { sf, S };
}
function camPage(cam, t) { const b = cam.b || LAY.page; const u = eIO(inv(cam.t0, cam.t1, t)); return { x: lerp(cam.a.x, b.x, u), y: lerp(cam.a.y, b.y, u), s: lerp(cam.a.s, b.s, u) }; }

function caption(g, t, c) {
  const u = inv(c.t0, c.t0 + 0.25, t) * (1 - inv(c.t1 - 0.25, c.t1, t));
  if (u <= 0) return;
  g.save(); g.globalAlpha = u;
  if (VERT) {
    g.translate(0, (1 - eOut(u)) * 20);
    text(g, c.big, W / 2, 1632, { font: FONT.dela, size: 52, color: '#fff', align: 'center', stroke: 12, strokeColor: C.ink });
    if (c.small) text(g, c.small, W / 2, 1674, { font: FONT.mono, size: 24, color: '#efe8f2', align: 'center', ls: 1, stroke: 7, strokeColor: C.ink });
  } else {
    // right column, under the card rack
    g.translate((1 - eOut(u)) * 30, 0);
    const x = 1450, maxW = 400;
    const lines = wrap(g, c.big, maxW, { font: FONT.dela, size: 40 });
    const y0 = 1000 - (lines.length - 1) * 48 - (c.small ? 40 : 0);
    g.fillStyle = C.coral; g.fillRect(x - 22, y0 - 40, 7, (lines.length - 1) * 48 + (c.small ? 84 : 50));
    lines.forEach((ln, i) => text(g, ln, x, y0 + i * 48, { font: FONT.dela, size: 40, color: '#fff' }));
    if (c.small) text(g, c.small, x + 2, y0 + (lines.length - 1) * 48 + 38, { font: FONT.mono, size: 17, color: '#d9d2df', ls: 0.5 });
  }
  g.restore();
}

function sceneTitle(g, t, shot) {
  const u = t - shot.t0, d = shot.t1 - shot.t0;
  drawRedHalftone(g, t, 0.25);
  // diagonal slash wipe in
  const slash = eOut(inv(0, 0.35, u));
  g.save();
  const lw = VERT ? 860 : 1100, lh = lw * IMG.logoL.height / IMG.logoL.width;
  const k = lerp(1.25, 1, eOut(inv(0.1, 0.6, u)));
  g.translate(W / 2, H * (VERT ? 0.38 : 0.36)); g.scale(k, k);
  g.globalAlpha = inv(0.08, 0.3, u);
  g.drawImage(IMG.logoL, -lw / 2, -lh / 2, lw, lh);
  g.restore();
  const ty = H * (VERT ? 0.38 : 0.36) + lh / 2 + (VERT ? 120 : 110);
  g.save(); g.globalAlpha = inv(0.35, 0.6, u);
  sfxText(g, 'PANEL  CUT', W / 2, ty, VERT ? 120 : 130, 4);
  g.restore();
  const ry = ty + (VERT ? 150 : 130);
  text(g, 'CUT THE PAGE. TRAP THE ANOMALY.', W / 2, ry, { font: FONT.disp, weight: 600, size: VERT ? 46 : 52, color: '#fff', align: 'center', alpha: inv(0.7, 1.0, u), ls: 1 });
  text(g, 'A GAME CONCEPT FOR ZENKO', W / 2, ry + (VERT ? 64 : 58), { font: FONT.mono, size: VERT ? 22 : 20, color: '#f2c2bf', align: 'center', alpha: inv(0.9, 1.2, u), ls: 6 });
  // slash line across
  if (u < 0.5) {
    g.save(); g.globalAlpha = 1 - inv(0.25, 0.5, u); g.strokeStyle = '#fff'; g.shadowColor = C.coral; g.shadowBlur = 30; g.lineWidth = 10;
    g.beginPath(); g.moveTo(-100, H * 0.85); g.lineTo(lerp(-100, W + 100, slash), lerp(H * 0.85, H * 0.15, slash)); g.stroke(); g.restore();
  }
  // out: page tear
  if (u > d - 0.18) invertCanvas(g, 1 - inv(d - 0.18, d, u));
}

function drawFinalPage(g, cx, cy, s, sf, vt) {
  const { W: PW, H: PH } = TAKE.page;
  g.save(); g.translate(cx - (PW * s) / 2, cy - (PH * s) / 2); g.scale(s, s);
  drawPage(g, sf, vt);
  g.restore();
}
function scenePage(g, t, shot) {
  const u = t - shot.t0;
  const sfEnd = SN.length - 1;
  drawRedHalftone(g, t, 0.45);
  // page moves from game position to centre-left, then cards fan out
  const a = { x: LAY.page.x + 380 * LAY.page.s, y: LAY.page.y + 500 * LAY.page.s, s: LAY.page.s };
  const b = VERT ? { x: W / 2, y: 770, s: 0.94 } : { x: 640, y: 545, s: 0.98 };
  const m = eIO(inv(0, 0.8, u));
  const x = lerp(a.x, b.x, m), y = lerp(a.y, b.y, m), s = lerp(a.s, b.s, m);
  drawFinalPage(g, x, y, s, sfEnd, t);
  // label
  const tx = VERT ? W / 2 : 1120, al = VERT ? 'center' : 'left';
  const ty0 = VERT ? 1345 : 250;
  text(g, 'YOUR PAGE.', tx, ty0, { font: FONT.dela, size: VERT ? 70 : 76, color: '#fff', align: al, alpha: inv(0.5, 0.8, u) });
  const fin = SN[sfEnd];
  text(g, `CH.01 · P.07 · ${Math.round(inkMax(1e9) * 100)}% INKED · ${fin.cards} CARDS`, tx + (VERT ? 0 : 4), ty0 + (VERT ? 54 : 52), { font: FONT.mono, size: VERT ? 24 : 22, color: '#f2c2bf', align: al, ls: 3, alpha: inv(0.7, 1.0, u) });
  text(g, 'Every run cuts a different manga page.', tx + (VERT ? 0 : 2), ty0 + (VERT ? 104 : 102), { font: FONT.disp, weight: 500, size: VERT ? 34 : 34, color: '#fff', align: al, alpha: inv(0.9, 1.2, u) });
  // card fan
  const n = CARDS.length;
  const fx = VERT ? W / 2 : 1440, fy = VERT ? 1815 : 760;
  const order = [...CARDS.keys()].sort((a, b) => (CARDS[a].kind === 'nero') - (CARDS[b].kind === 'nero'));
  for (const i of order) {
    const card = CARDS[i];
    const st = 1.0 + i * 0.09; const k = eBack(inv(st, st + 0.45, u));
    if (k <= 0) continue;
    const spread = (i - (n - 1) / 2);
    const ang = spread * (VERT ? 0.09 : 0.11) * k;
    const R = VERT ? 900 : 1100;
    const cw = VERT ? 138 : 170, ch = cw * 1.4;
    const px = fx + Math.sin(ang) * R * 0.55, py = fy - Math.cos(ang) * R * 0.08 + (1 - k) * 300 + Math.abs(spread) * 6;
    const big = card.kind === 'nero' ? 1.18 : 1;
    drawCard(g, px, py - (card.kind === 'nero' ? 30 : 0), cw * big, ch * big, clamp((u - st) / 0.5), { ...cardFront(card, true), holo: t * 0.4 + i * 0.13 }, ang);
  }
}

function sceneLeader(g, t, shot) {
  const d = shot.t1 - shot.t0; const u = (t - shot.t0) * (4.2 / Math.max(2.2, d)) * (d < 3 ? 1.25 : 1);
  drawBackdrop(g, t, 0.82);
  const pw = VERT ? 960 : 1040, ph = VERT ? 1080 : 760, px = (W - pw) / 2, py = VERT ? 260 : 70;
  // panel styled like the card's black window with a coral frame
  g.save();
  g.shadowColor = 'rgba(0,0,0,0.6)'; g.shadowBlur = 40;
  rrect(g, px, py, pw, ph, 28); g.fillStyle = C.card; g.fill(); g.shadowColor = 'transparent';
  const m = 16, n = 60;
  g.beginPath(); g.moveTo(px + m + n, py + m); g.lineTo(px + pw - m, py + m); g.lineTo(px + pw - m, py + ph - m); g.lineTo(px + m, py + ph - m); g.lineTo(px + m, py + m + n); g.closePath();
  g.fillStyle = '#121014'; g.fill();
  g.restore();
  text(g, 'WL LEADERBOARD', px + 90, py + 92, { font: FONT.dela, size: VERT ? 44 : 46, color: '#fff' });
  text(g, 'SAMPLE · CH.01 PAGE 07', VERT ? px + 92 : px + pw - 56, VERT ? py + 128 : py + 86, { font: FONT.mono, size: 18, color: C.card, align: VERT ? 'left' : 'right', ls: 3 });
  const names = ['holder_01', 'holder_12', 'holder_07', 'holder_33', 'holder_04', 'holder_21', 'holder_09', 'holder_15', 'holder_28', 'holder_02'];
  const base = [9820, 9410, 0, 8870, 8650, 8120, 7990, 7600, 7310, 7020];
  const youScore = Math.round(lerp(6200, 9120, eOut(inv(0.5, 2.2, u))));
  const others = names.map((nm, i) => ({ nm, score: base[i] })).filter((_, i) => i !== 2).sort((a, b) => b.score - a.score);
  // continuous rank for "you": slides up through the rows as the score passes each one
  const p = others.reduce((m, o) => m + clamp((o.score - youScore) / 160 + 0.5), 0);
  const rowH = VERT ? 78 : 56; const y0 = py + (VERT ? 200 : 150);
  const moving = Math.abs(p - Math.round(p)) > 0.02 && u < 2.3;
  const draw = (r, slot, you, rankShown, i) => {
    const ry = y0 + slot * rowH;
    const appear = eOut(inv(0.05 + i * 0.05, 0.35 + i * 0.05, u));
    g.save(); g.globalAlpha = appear; g.translate((1 - appear) * 60 + (you && moving ? 26 : 0), 0);
    if (you) { rrect(g, px + 50, ry - rowH * 0.62, pw - 100, rowH * 0.9, 12); g.fillStyle = 'rgba(228,103,98,0.25)'; g.fill(); g.strokeStyle = C.card; g.lineWidth = 3; g.stroke(); }
    text(g, String(rankShown).padStart(2, '0'), px + 80, ry, { font: FONT.dela, size: VERT ? 36 : 30, color: you ? C.coral : '#8b8291' });
    text(g, you ? `${r.nm}  (you)` : r.nm, px + 170, ry, { font: FONT.mono, size: VERT ? 30 : 26, color: you ? '#fff' : '#d8d2dc' });
    text(g, r.score.toLocaleString('en-US'), px + pw - 80, ry, { font: FONT.dela, size: VERT ? 34 : 28, color: you ? '#fff' : '#d8d2dc', align: 'right' });
    g.restore();
  };
  others.forEach((o, k) => { const slot = k + clamp(k + 1 - p); draw(o, slot, false, Math.round(slot) + 1, k); });
  draw({ nm: 'holder_07', score: youScore }, p, true, Math.round(p) + 1, 2);
  // bots line
  const by = VERT ? py + ph + 150 : py + ph + 110;
  const bu = inv(1.4, 1.8, u);
  text(g, 'Bots can like a post.', W / 2, by, { font: FONT.disp, weight: 600, size: VERT ? 54 : 56, color: '#fff', align: 'center', alpha: bu });
  text(g, 'They can’t draw the line.', W / 2, by + (VERT ? 72 : 70), { font: FONT.disp, weight: 600, size: VERT ? 54 : 56, color: C.coral, align: 'center', alpha: inv(1.8, 2.2, u) });
  if (VERT) text(g, 'Concept feature · sample handles · no allocation implied', W / 2, by + 140, { font: FONT.mono, size: 20, color: '#8b8291', align: 'center', alpha: bu });
  else text(g, 'Concept feature · sample handles · no allocation implied', W / 2, H - 22, { font: FONT.mono, size: 16, color: '#8b8291', align: 'center', alpha: bu, ls: 1 });
}

function drawMiniPage(g, x, y, w) {
  const { W: PW, H: PH } = TAKE.page; const s = w / PW;
  g.save(); g.translate(x, y); g.scale(s, s); drawPage(g, SN.length - 1, 0); g.restore();
}
function sceneShare(g, t, shot) {
  const u = t - shot.t0;
  drawBackdrop(g, t, 0.85);
  const fin = SN[SN.length - 1];
  // X post mock-up (generic UI, dark)
  const pw = VERT ? 960 : 1000, ph = VERT ? 1060 : 900, px = (W - pw) / 2, py = VERT ? 380 : 80;
  const pu = eOut(inv(0, 0.35, u));
  g.save(); g.globalAlpha = pu; g.translate(0, (1 - pu) * 40);
  rrect(g, px, py, pw, ph, 26); g.fillStyle = '#0f0f12'; g.fill(); g.strokeStyle = '#2c2c33'; g.lineWidth = 2; g.stroke();
  g.fillStyle = C.card; g.beginPath(); g.arc(px + 70, py + 72, 34, 0, 7); g.fill();
  text(g, 'h', px + 70, py + 84, { font: FONT.dela, size: 32, color: '#111', align: 'center' });
  text(g, 'holder_07', px + 122, py + 66, { font: FONT.ui, weight: 700, size: 26, color: '#fff' });
  text(g, '@holder_07 · now', px + 122, py + 98, { font: FONT.ui, size: 22, color: '#7d7d86' });
  const lines = [`Cut page 07 of Kurokawa. ${Math.round(inkMax(1e9) * 100)}% inked,`, `${fin.cards} anomalies sealed. Pulled NERO.`, 'Beat my page. #ZENKO #PanelCut'];
  lines.forEach((l, i) => text(g, l, px + 50, py + 168 + i * 40, { font: FONT.ui, size: VERT ? 29 : 28, color: '#f1f1f4' }));
  g.restore();
  // result card flies in
  const ca = eOut(inv(0.25, 0.85, u));
  const cw = VERT ? 860 : 780, ch = VERT ? 560 : 500;
  const cx = px + 50 + cw / 2, cy = py + 300 + ch / 2;
  const fx = lerp(W + cw, cx, ca), fy = lerp(cy + 200, cy, ca), rot = lerp(0.4, 0, ca);
  g.save(); g.translate(fx, fy); g.rotate(rot);
  rrect(g, -cw / 2, -ch / 2, cw, ch, 22); g.fillStyle = C.card; g.fill();
  const m = 14; g.beginPath(); g.moveTo(-cw / 2 + m + 40, -ch / 2 + m); g.lineTo(cw / 2 - m, -ch / 2 + m); g.lineTo(cw / 2 - m, ch / 2 - m); g.lineTo(-cw / 2 + m, ch / 2 - m); g.lineTo(-cw / 2 + m, -ch / 2 + m + 40); g.closePath(); g.fillStyle = '#121014'; g.fill();
  const mpw = (ch - 68) * 0.76; drawMiniPage(g, -cw / 2 + 34, -ch / 2 + 34, mpw);
  const tx = -cw / 2 + 34 + mpw + 44;
  text(g, 'PANEL CUT', tx, -ch / 2 + 74, { font: FONT.dela, size: 30, color: C.coral });
  text(g, `${Math.round(inkMax(1e9) * 100)}%`, tx, -ch / 2 + 168, { font: FONT.dela, size: 78, color: '#fff' });
  text(g, 'INKED', tx + 4, -ch / 2 + 200, { font: FONT.mono, size: 16, color: '#bdb6c4', ls: 3 });
  text(g, `${fin.cards} CARDS`, tx, -ch / 2 + 262, { font: FONT.dela, size: 34, color: '#fff' });
  text(g, 'NERO PULLED', tx, -ch / 2 + 302, { font: FONT.dela, size: 24, color: C.purple });
  text(g, 'RANK #3', tx, -ch / 2 + 344, { font: FONT.dela, size: 24, color: C.gold });
  // share button
  const bw = 220, bh = 54, bx = tx, byy = ch / 2 - 40 - bh;
  const press = inv(1.2, 1.35, u) * (1 - inv(1.35, 1.55, u));
  g.save(); g.translate(bx + bw / 2, byy + bh / 2); g.scale(1 - press * 0.08, 1 - press * 0.08);
  rrect(g, -bw / 2, -bh / 2, bw, bh, bh / 2); g.fillStyle = '#fff'; g.fill();
  text(g, 'Share on X', 0, 8, { font: FONT.ui, weight: 700, size: 22, color: '#111', align: 'center' });
  g.restore();
  g.restore();
  // engagement row appears
  const er = inv(1.6, 2.0, u);
  g.save(); g.globalAlpha = er;
  const ey = py + ph - 42;
  ['Reply 48', 'Repost 213', 'Like 1.2K', 'Views 18K'].forEach((s, i) => text(g, s, px + 50 + i * ((pw - 100) / 4), ey, { font: FONT.ui, size: 22, color: '#7d7d86' }));
  g.restore();
  text(g, 'X POST MOCK-UP · SAMPLE NUMBERS', W / 2, VERT ? py + ph + 70 : H - 26, { font: FONT.mono, size: 16, color: '#6f6878', align: 'center', ls: 3, alpha: pu });
}

function sceneZenko(g, t, shot) {
  const u = t - shot.t0, d = shot.t1 - shot.t0;
  drawRedHalftone(g, t, 0.3);
  const lw = VERT ? 840 : 980, lh = lw * IMG.logoL.height / IMG.logoL.width;
  const k = lerp(1.15, 1, eOut(inv(0, 0.5, u)));
  g.save(); g.translate(W / 2, H * 0.4); g.scale(k, k); g.globalAlpha = inv(0, 0.2, u);
  g.drawImage(IMG.logoL, -lw / 2, -lh / 2, lw, lh); g.restore();
  g.save(); g.globalAlpha = inv(0.25, 0.5, u); sfxText(g, 'PANEL  CUT', W / 2, H * 0.4 + lh / 2 + 90, VERT ? 100 : 110, 4); g.restore();
  text(g, 'A game concept for Zenko · built from your own art', W / 2, H * 0.4 + lh / 2 + (VERT ? 215 : 215), { font: FONT.disp, weight: 500, size: VERT ? 36 : 38, color: '#fff', align: 'center', alpha: inv(0.5, 0.8, u) });
  if (u > d - 0.3) { g.fillStyle = `rgba(0,0,0,${inv(d - 0.3, d, u)})`; g.fillRect(0, 0, W, H); }
}

// Encore mascot, redrawn as a vector from the official avatar geometry
function mascotPath(g, s) {
  // body: semicircle top (r = 88.5) over straight sides, rounded bottom corners
  const r = 88.5 * s, w = 177 * s, h = (313 - 115) * s, cr = 16 * s;
  g.beginPath();
  g.moveTo(-w / 2, 0);
  g.arc(0, 0, r, Math.PI, 0);
  g.lineTo(w / 2, h - r - cr); g.quadraticCurveTo(w / 2, h - r, w / 2 - cr, h - r);
  g.lineTo(-w / 2 + cr, h - r); g.quadraticCurveTo(-w / 2, h - r, -w / 2, h - r - cr);
  g.closePath();
}
function drawMascot(g, cx, cy, size, t, blink) {
  const s = size / 177;
  g.save(); g.translate(cx, cy);
  // echo outline
  g.save(); g.translate(-37 * s, -32 * s); mascotPath(g, s);
  const eg = g.createLinearGradient(-90 * s, -90 * s, 90 * s, 110 * s); eg.addColorStop(0, '#8d8d8d'); eg.addColorStop(1, '#2e2e2e');
  g.lineWidth = 8 * s; g.strokeStyle = eg; g.stroke(); g.restore();
  // chrome body
  mascotPath(g, s);
  const gr = g.createLinearGradient(-88 * s, -88 * s, 89 * s, 110 * s);
  gr.addColorStop(0, '#d2d2d2'); gr.addColorStop(0.2, '#a7a7a7'); gr.addColorStop(0.36, '#6b6b6b'); gr.addColorStop(0.5, '#ececec'); gr.addColorStop(0.68, '#d6d6d6'); gr.addColorStop(1, '#b4b4b4');
  g.fillStyle = gr; g.fill();
  // moving sheen
  g.save(); mascotPath(g, s); g.clip();
  const sx = lerp(-260, 260, (t * 0.35) % 1.4) * s;
  const sh = g.createLinearGradient(sx - 60 * s, -100 * s, sx + 60 * s, 120 * s);
  sh.addColorStop(0, 'rgba(255,255,255,0)'); sh.addColorStop(0.5, 'rgba(255,255,255,0.55)'); sh.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = sh; g.fillRect(-120 * s, -120 * s, 240 * s, 260 * s); g.restore();
  // eyes
  const eh = 52 * s * (1 - 0.9 * blink), ew = 17 * s;
  g.fillStyle = '#1b1b1d';
  for (const ex of [-15.5, 24.5]) { rrect(g, ex * s - ew / 2, -4 * s - eh / 2, ew, eh, ew / 2); g.fill(); }
  g.restore();
}
function sceneEncore(g, t, shot) {
  const u = t - shot.t0, d = shot.t1 - shot.t0;
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const rg = g.createRadialGradient(W / 2, H * 0.36, 10, W / 2, H * 0.36, Math.max(W, H) * 0.6);
  rg.addColorStop(0, 'rgba(70,24,28,0.55)'); rg.addColorStop(0.5, 'rgba(20,10,12,0.35)'); rg.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = rg; g.fillRect(0, 0, W, H);
  // mascot + wordmark lockup
  const mk = eOut(inv(0, 0.6, u));
  const blinkT = (u - 1.6) / 0.16; const blink = blinkT > 0 && blinkT < 1 ? Math.sin(blinkT * Math.PI) : 0;
  const msz = VERT ? 210 : 170;
  const lockY = VERT ? 560 : 250;
  const wordH = VERT ? 120 : 104, wordW = wordH * IMG.encWord.width / IMG.encWord.height;
  const gap = VERT ? 0 : 60;
  const totalW = VERT ? wordW : msz + gap + wordW;
  const mx = VERT ? W / 2 : (W - totalW) / 2 + msz / 2 + 18, my = VERT ? lockY - 140 : lockY - 20;
  g.save(); g.globalAlpha = mk; g.translate(0, (1 - mk) * 30);
  drawMascot(g, mx, my, msz, t, blink);
  const wx = VERT ? (W - wordW) / 2 : mx + msz / 2 + gap, wy = VERT ? lockY + 120 : lockY - wordH / 2 + 10;
  g.drawImage(IMG.encWord, wx, wy, wordW, wordH);
  text(g, 'STUDIO', wx + wordW + 18, wy + wordH * 0.86, { font: FONT.mono, size: VERT ? 22 : 20, color: '#9a9a9e', ls: 5 });
  g.restore();
  // slogan
  const sy = VERT ? 1010 : 560;
  const su = inv(0.5, 0.9, u);
  g.save(); g.globalAlpha = su;
  g.font = `600 ${VERT ? 66 : 76}px ${FONT.disp}`; g.textBaseline = 'alphabetic';
  const a1 = 'Every launch deserves ', a2 = 'an encore.';
  if (VERT) {
    text(g, 'Every launch deserves', W / 2, sy, { font: FONT.disp, weight: 600, size: 66, color: '#e9e8ea', align: 'center' });
    text(g, a2, W / 2, sy + 84, { font: FONT.disp, weight: 600, size: 66, color: C.encRed, align: 'center' });
  } else {
    const w1 = g.measureText(a1).width, w2 = g.measureText(a2).width; const x0 = (W - w1 - w2) / 2;
    text(g, a1, x0, sy, { font: FONT.disp, weight: 600, size: 76, color: '#e9e8ea' });
    text(g, a2, x0 + w1, sy, { font: FONT.disp, weight: 600, size: 76, color: C.encRed });
  }
  g.restore();
  const ly = VERT ? 1190 : 650;
  text(g, 'ZENKO: PANEL CUT · A GAME CONCEPT BY ENCORE STUDIO', W / 2, ly, { font: FONT.mono, size: VERT ? 20 : 20, color: C.encMono, align: 'center', ls: VERT ? 3 : 5, alpha: inv(0.8, 1.1, u) });
  text(g, VERT ? 'Book a free 30-min call' : 'Book a free 30-min call · encorestudio.xyz · @EncoreStudiohq', W / 2, ly + (VERT ? 90 : 84), { font: FONT.disp, weight: 500, size: VERT ? 40 : 38, color: '#f2f2f3', align: 'center', alpha: inv(1.0, 1.3, u) });
  if (VERT) text(g, 'encorestudio.xyz · @EncoreStudiohq', W / 2, ly + 146, { font: FONT.disp, weight: 500, size: 38, color: '#f2f2f3', align: 'center', alpha: inv(1.0, 1.3, u) });
  // divider + disclaimer
  const dy = VERT ? 1480 : 800;
  g.save(); g.globalAlpha = inv(1.2, 1.5, u); g.fillStyle = '#26262a'; g.fillRect(VERT ? 120 : 440, dy, VERT ? 840 : 1040, 2); g.restore();
  text(g, 'Unofficial concept by Encore Studio. Not affiliated with or endorsed by Zenko.', W / 2, dy + (VERT ? 60 : 52), { font: FONT.ui, size: VERT ? 22 : 24, color: '#8d8d92', align: 'center', alpha: inv(1.2, 1.5, u) });
  text(g, 'Zenko characters, manga, logo and art © Zenko.', W / 2, dy + (VERT ? 96 : 90), { font: FONT.ui, size: VERT ? 22 : 24, color: '#8d8d92', align: 'center', alpha: inv(1.2, 1.5, u) });
  // concept tag
  g.save(); g.globalAlpha = inv(1.2, 1.5, u);
  const tw = VERT ? 330 : 340, th = 46, tx = W - tw - (VERT ? 40 : 56), ty = H - th - (VERT ? 60 : 44);
  rrect(g, tx, ty, tw, th, 8); g.strokeStyle = '#3a3a40'; g.lineWidth = 2; g.stroke();
  g.fillStyle = C.encRed; g.fillRect(tx + 18, ty + th / 2 - 4, 8, 8);
  text(g, 'CONCEPT · UNOFFICIAL', tx + 40, ty + th / 2 + 7, { font: FONT.mono, size: 19, color: '#d7d7da', ls: 3 });
  g.restore();
  if (u > d - 0.6) { g.fillStyle = `rgba(0,0,0,${inv(d - 0.6, d, u)})`; g.fillRect(0, 0, W, H); }
}

// ---------------- timeline ----------------
const MAIN = {
  dur: 44.0,
  shots: [
    { type: 'game', t0: 0, t1: 3.0, keys: [[0, 5.2], [0.55, 5.55], [1.7, 5.80], [3.0, 6.42]], cam: { a: { x: 380, y: 12, s: 1.38 }, t0: 1.95, t1: 2.75 }, hudIn: [2.15, 2.8] },
    { type: 'title', t0: 3.0, t1: 5.2 },
    { type: 'game', t0: 5.2, t1: 12.45, keys: [[5.2, 0.15], [12.45, 7.40]] },
    { type: 'game', t0: 12.45, t1: 13.55, keys: [[12.45, 7.40], [13.55, 7.56]], cutin: 'shojo' },
    { type: 'game', t0: 13.55, t1: 15.94, keys: [[13.55, 7.56], [15.94, 9.95]] },
    { type: 'game', t0: 15.94, t1: 17.0, keys: [[15.94, 9.95], [17.0, 10.10]], cutin: 'nero' },
    { type: 'game', t0: 17.0, t1: 17.9, keys: [[17.0, 10.10], [17.9, 11.0]] },
    { type: 'game', t0: 17.9, t1: 19.6, keys: [[17.9, 12.30], [18.55, 12.95], [19.15, 13.13], [19.6, 13.6]] },
    { type: 'game', t0: 19.6, t1: 20.35, keys: [[19.6, 13.6], [20.35, 14.35]] },
    { type: 'game', t0: 20.35, t1: 21.45, keys: [[20.35, 14.35], [21.45, 14.50]], cutin: 'shonen' },
    { type: 'game', t0: 21.45, t1: 23.7, keys: [[21.45, 14.50], [22.9, 15.30], [23.7, 16.2]] },
    { type: 'page', t0: 23.7, t1: 27.9 },
    { type: 'leader', t0: 27.9, t1: 32.1 },
    { type: 'share', t0: 32.1, t1: 35.9 },
    { type: 'zenko', t0: 35.9, t1: 38.3 },
    { type: 'encore', t0: 38.3, t1: 44.0 },
  ],
  captions: [
    { t0: 6.3, t1: 8.3, big: 'CUT A PANEL.', small: 'Swipe to draw a gutter.' },
    { t0: 8.5, t1: 9.55, big: 'TRAP ONE.', small: 'One anomaly in a small panel.' },
    { t0: 9.6, t1: 10.7, big: 'DON’T GET TOUCHED.', small: 'Hit the line and it breaks.' },
    { t0: 10.75, t1: 12.4, big: 'EVERY SEAL IS A CARD.', small: 'Sealed anomalies join your hand.' },
    { t0: 13.7, t1: 15.8, big: 'PIN. CUT. COMBO.', small: 'Shojo kunai freeze the rift.' },
    { t0: 17.05, t1: 19.5, big: 'PULL THE RARE ONE.', small: 'Nero is the anomaly everyone wants.' },
    { t0: 21.5, t1: 23.6, big: 'SLASH THE WHOLE PAGE.', small: 'Full Resonance unleashes the Shonen.' },
  ],
};
const VERTICAL = {
  dur: 15.0,
  shots: [
    { type: 'game', t0: 0, t1: 2.2, keys: [[0, 5.2], [0.6, 5.55], [1.35, 5.80], [2.2, 6.3]] },
    { type: 'game', t0: 2.2, t1: 3.3, keys: [[2.2, 7.90], [3.3, 8.85]] },
    { type: 'game', t0: 3.3, t1: 4.1, keys: [[3.3, 9.95], [4.1, 10.08]], cutin: 'nero' },
    { type: 'game', t0: 4.1, t1: 5.5, keys: [[4.1, 12.55], [4.75, 12.98], [5.15, 13.13], [5.5, 13.5]] },
    { type: 'game', t0: 5.5, t1: 6.3, keys: [[5.5, 14.36], [6.3, 14.50]], cutin: 'shonen' },
    { type: 'game', t0: 6.3, t1: 8.1, keys: [[6.3, 14.50], [7.5, 15.25], [8.1, 15.9]] },
    { type: 'page', t0: 8.1, t1: 10.3 },
    { type: 'leader', t0: 10.3, t1: 12.0 },
    { type: 'encore', t0: 12.0, t1: 15.0 },
  ],
  captions: [
    { t0: 0.2, t1: 2.1, big: 'CUT THE PAGE.', small: 'Trap one anomaly per panel.' },
    { t0: 2.25, t1: 3.25, big: 'EVERY SEAL IS A CARD.', small: 'Shojo kunai pin the rift.' },
    { t0: 4.15, t1: 5.45, big: 'PULL NERO.', small: 'The legendary anomaly.' },
    { t0: 6.35, t1: 8.0, big: 'RESONANCE BURST.', small: 'Slash the whole page.' },
  ],
};
const TIMELINE = VERT ? VERTICAL : MAIN;

function renderAt(t) {
  const shot = TIMELINE.shots.find((s) => t >= s.t0 && t < s.t1) || TIMELINE.shots[TIMELINE.shots.length - 1];
  ctx.save();
  // slow camera push on motion-graphics holds so no frame is ever static
  const PUSH = { title: 0.035, page: 0.02, leader: 0.035, share: 0.035, zenko: 0.04, encore: 0.03 }[shot.type];
  if (PUSH) { const k = 1 + PUSH * eIO(inv(shot.t0, shot.t1, t)); ctx.translate(W / 2, H / 2); ctx.scale(k, k); ctx.translate(-W / 2, -H / 2); }
  if (shot.type === 'game') {
    const { sf } = sceneGame(ctx, t, shot);
    if (shot.cutin) drawCutIn(ctx, inv(shot.t0, shot.t1, t), shot.cutin);
  } else if (shot.type === 'title') sceneTitle(ctx, t, shot);
  else if (shot.type === 'page') scenePage(ctx, t, shot);
  else if (shot.type === 'leader') sceneLeader(ctx, t, shot);
  else if (shot.type === 'share') sceneShare(ctx, t, shot);
  else if (shot.type === 'zenko') sceneZenko(ctx, t, shot);
  else if (shot.type === 'encore') sceneEncore(ctx, t, shot);
  for (const c of TIMELINE.captions) if (shot.type === 'game' && !shot.cutin) caption(ctx, t, c);
  // hook: the first frames of the game cut in from a hard flash
  ctx.restore();
  // shot-boundary flashes
  for (const s of TIMELINE.shots) {
    if (s.type === 'game' && s.cutin) continue;
    const d = t - s.t0; if (d >= 0 && d < 0.1 && s.t0 > 0 && s.type !== 'encore' && s.type !== 'zenko') { ctx.fillStyle = `rgba(255,255,255,${0.5 * (1 - d / 0.1)})`; ctx.fillRect(0, 0, W, H); }
  }
}
window.renderFrame = (n) => { renderAt(n / FPS); };
window.frameData = (n, type = 'image/png', q) => { renderAt(n / FPS); return cv.toDataURL(type, q); };
// audio cue export: events mapped to output time
window.cues = () => {
  const out = [];
  const N = Math.round(TIMELINE.dur * FPS);
  let prev = null;
  for (let n = 0; n < N; n++) {
    const t = n / FPS;
    const shot = TIMELINE.shots.find((s) => t >= s.t0 && t < s.t1);
    if (!shot) continue;
    if (shot.type === 'game') {
      const sf = mapTime(shot.keys, t) * FPS;
      const psf = prev && prev.shot === shot ? prev.sf : sf - 0.0001;
      if (sf > psf) for (const e of EV) if (e.f > psf && e.f <= sf) out.push({ t, type: e.type, kind: e.kind, hero: e.hero, combo: e.combo, burst: e.burst, recut: e.recut, level: e.level });
      prev = { shot, sf };
    } else prev = null;
    if (n === Math.round(shot.t0 * FPS)) out.push({ t, type: 'shot', shot: shot.type, cutin: shot.cutin || null });
  }
  return out;
};
init().catch((e) => { window.initError = String(e && e.stack || e); console.error(e); });
