// ZENKO: PANEL CUT — deterministic game simulation.
// Page units: W x H. Panels are convex CCW polygons separated by gutters.
export const PAGE = { W: 760, H: 1000, M: 24, G: 12 };
export const FPS = 60;
export const DT = 1 / FPS;
export const SEAL_AREA = 0.2; // fraction of inner page area
export const LINE_HALF = 4;

export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- geometry ----------
export function area(p) {
  let s = 0;
  for (let i = 0; i < p.length; i++) {
    const a = p[i], b = p[(i + 1) % p.length];
    s += a[0] * b[1] - b[0] * a[1];
  }
  return s / 2;
}
export function centroid(p) {
  let cx = 0, cy = 0, s = 0;
  for (let i = 0; i < p.length; i++) {
    const a = p[i], b = p[(i + 1) % p.length];
    const c = a[0] * b[1] - b[0] * a[1];
    s += c; cx += (a[0] + b[0]) * c; cy += (a[1] + b[1]) * c;
  }
  return [cx / (3 * s), cy / (3 * s)];
}
export function bbox(p) {
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const [x, y] of p) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
  return [x0, y0, x1, y1];
}
// keep points with dot(v-P, n) >= off
export function clipHalf(poly, P, n, off) {
  const out = [];
  const f = (v) => (v[0] - P[0]) * n[0] + (v[1] - P[1]) * n[1] - off;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const fa = f(a), fb = f(b);
    if (fa >= 0) out.push(a);
    if ((fa >= 0) !== (fb >= 0)) {
      const t = fa / (fa - fb);
      out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]);
    }
  }
  return out;
}
export function inside(poly, x, y, pad = 0) {
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const ex = b[0] - a[0], ey = b[1] - a[1];
    const L = Math.hypot(ex, ey);
    // CCW in y-down screen coords => interior is where cross <= 0 ... normalise via area sign
    const c = (ex * (y - a[1]) - ey * (x - a[0])) / L;
    if (c < pad) return false;
  }
  return true;
}
// chord of a line through P with unit direction d: returns [tmin, tmax]
export function chord(poly, P, d) {
  let tmin = -1e9, tmax = 1e9;
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const ex = b[0] - a[0], ey = b[1] - a[1];
    const L = Math.hypot(ex, ey);
    const nx = -ey / L, ny = ex / L; // inward normal for our orientation
    const num = (P[0] - a[0]) * nx + (P[1] - a[1]) * ny; // distance inside
    const den = d[0] * nx + d[1] * ny;
    if (Math.abs(den) < 1e-9) { if (num < 0) return null; continue; }
    const t = -num / den;
    if (den < 0) tmax = Math.min(tmax, t); else tmin = Math.max(tmin, t);
  }
  return tmin < tmax ? [tmin, tmax] : null;
}
export function distSeg(px, py, ax, ay, bx, by) {
  const vx = bx - ax, vy = by - ay;
  const L2 = vx * vx + vy * vy;
  let t = L2 > 0 ? ((px - ax) * vx + (py - ay) * vy) / L2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + vx * t), py - (ay + vy * t));
}
function edgesInward(poly) {
  const e = [];
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i], b = poly[(i + 1) % poly.length];
    const ex = b[0] - a[0], ey = b[1] - a[1];
    const L = Math.hypot(ex, ey);
    e.push({ a, nx: -ey / L, ny: ex / L });
  }
  return e;
}

// ---------- simulation ----------
export class Sim {
  constructor(seed = 7, init) {
    if (init) { this.s = init; return; }
    const { W, H, M } = PAGE;
    // orientation: points ordered so that edgesInward() normals point inside
    const page = [[M, M], [W - M, M], [W - M, H - M], [M, H - M]];
    this.s = {
      f: 0, seed, nextId: 1,
      innerArea: Math.abs(area(page)),
      panels: [{ id: 0, poly: page, state: 'open', born: 0, depth: 0 }],
      an: [], cuts: [], cards: [], events: [],
      lives: 3, combo: 0, lastSealF: -999, res: 0, hero: 'shonen',
      rift: null, done: false,
    };
  }
  clone() { return new Sim(0, structuredClone(this.s)); }
  get t() { return this.s.f / FPS; }
  ev(type, data = {}) { this.s.events.push({ f: this.s.f, type, ...data }); }
  panelAt(x, y) { return this.s.panels.find((p) => p.state === 'open' && inside(p.poly, x, y)); }
  inkedFrac() {
    let a = 0;
    for (const p of this.s.panels) if (p.state !== 'open') a += Math.abs(area(p.poly));
    return a / this.s.innerArea;
  }

  openRift(x, y, level = 1) {
    const p = this.panelAt(x, y);
    if (!p) throw new Error(`rift outside open panel at ${x},${y}`);
    this.s.rift = { x, y, level, f: this.s.f, panel: p.id };
    this.ev('rift', { x, y, level });
  }
  spawn(kind, angleDeg, speed, r) {
    const R = this.s.rift;
    const id = this.s.nextId++;
    const a = (angleDeg * Math.PI) / 180;
    const rad = r ?? (kind === 'nero' ? 44 : 25);
    const p = this.panelAt(R.x, R.y);
    if (!p) throw new Error('spawn: rift panel closed');
    this.s.an.push({ id, kind, x: R.x, y: R.y, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed, r: rad,
      alive: true, born: this.s.f, frozenUntil: -1, pinF: -1, panel: p.id });
    this.ev('spawn', { id, kind });
    return id;
  }
  setHero(h) { this.s.hero = h; this.ev('hero', { hero: h }); }
  pin(ids, dur = 2.2) {
    for (const id of ids) {
      const a = this.s.an.find((q) => q.id === id);
      a.frozenUntil = this.s.f + Math.round(dur * FPS);
      a.pinF = this.s.f;
    }
    this.ev('pin', { ids });
  }
  startCut(x, y, angDeg, opt = {}) {
    const p = opt.recut ? this.s.panels.find((q) => q.state === 'inked' && inside(q.poly, x, y)) : this.panelAt(x, y);
    if (!p) return null;
    const a = (angDeg * Math.PI) / 180;
    const d = [Math.cos(a), Math.sin(a)];
    const ch = chord(p.poly, [x, y], d);
    if (!ch) return null;
    const cut = { id: this.s.nextId++, panel: p.id, x, y, d, ang: angDeg, t0: ch[0], t1: ch[1], a: 0, b: 0,
      speed: opt.speed ?? 1500, immune: !!opt.immune, hero: opt.hero ?? this.s.hero, f0: this.s.f, state: 'grow', burst: !!opt.burst, recut: !!opt.recut };
    this.s.cuts.push(cut);
    this.ev('cut', { id: cut.id, x, y, ang: angDeg, hero: cut.hero, burst: cut.burst, t0: ch[0], t1: ch[1] });
    return cut;
  }

  step() {
    const s = this.s;
    s.f++;
    // anomalies
    for (const a of s.an) {
      if (!a.alive) continue;
      if (a.frozenUntil > s.f) continue;
      a.x += a.vx * DT; a.y += a.vy * DT;
      const p = s.panels.find((q) => q.id === a.panel);
      for (const e of edgesInward(p.poly)) {
        const dist = (a.x - e.a[0]) * e.nx + (a.y - e.a[1]) * e.ny;
        if (dist < a.r) {
          const vn = a.vx * e.nx + a.vy * e.ny;
          if (vn < 0) { a.vx -= 2 * vn * e.nx; a.vy -= 2 * vn * e.ny; }
          a.x += (a.r - dist) * e.nx; a.y += (a.r - dist) * e.ny;
        }
      }
    }
    // anomaly-anomaly (equal mass elastic)
    const alive = s.an.filter((a) => a.alive);
    for (let i = 0; i < alive.length; i++) for (let j = i + 1; j < alive.length; j++) {
      const A = alive[i], B = alive[j];
      if (A.panel !== B.panel) continue;
      const dx = B.x - A.x, dy = B.y - A.y, D = Math.hypot(dx, dy), m = A.r + B.r;
      if (D < m && D > 1e-6) {
        const nx = dx / D, ny = dy / D;
        const fa = A.frozenUntil > s.f, fb = B.frozenUntil > s.f;
        const va = A.vx * nx + A.vy * ny, vb = B.vx * nx + B.vy * ny;
        if (va - vb > 0) {
          if (!fa && !fb) { A.vx += (vb - va) * nx; A.vy += (vb - va) * ny; B.vx += (va - vb) * nx; B.vy += (va - vb) * ny; }
          else if (fa && !fb) { B.vx -= 2 * vb * nx; B.vy -= 2 * vb * ny; }
          else if (fb && !fa) { A.vx -= 2 * va * nx; A.vy -= 2 * va * ny; }
        }
        const push = (m - D) / 2;
        if (!fa) { A.x -= nx * push; A.y -= ny * push; }
        if (!fb) { B.x += nx * push; B.y += ny * push; }
      }
    }
    // cuts
    for (const c of s.cuts) {
      if (c.state !== 'grow') continue;
      const step = c.speed * DT;
      c.a = Math.max(c.t0, c.a - step);
      c.b = Math.min(c.t1, c.b + step);
      if (!c.immune) {
        const ax = c.x + c.d[0] * c.a, ay = c.y + c.d[1] * c.a;
        const bx = c.x + c.d[0] * c.b, by = c.y + c.d[1] * c.b;
        for (const an of s.an) {
          if (!an.alive || an.panel !== c.panel) continue;
          if (distSeg(an.x, an.y, ax, ay, bx, by) < an.r + LINE_HALF) {
            c.state = 'broken'; c.fEnd = s.f; c.hit = { x: an.x, y: an.y, id: an.id };
            // bounce anomaly away from the line
            const nx = -c.d[1], ny = c.d[0];
            const side = Math.sign((an.x - c.x) * nx + (an.y - c.y) * ny) || 1;
            const vn = an.vx * nx + an.vy * ny;
            if (vn * side < 0) { an.vx -= 2 * vn * nx; an.vy -= 2 * vn * ny; }
            s.lives = Math.max(0, s.lives - 1);
            s.combo = 0;
            const prog = (c.b - c.a) / (c.t1 - c.t0);
            this.ev('break', { id: c.id, x: an.x, y: an.y, prog, lives: s.lives });
            break;
          }
        }
      }
      if (c.state === 'grow' && c.a <= c.t0 && c.b >= c.t1) this.finishCut(c);
    }
    // completion
    if (!s.done && s.an.every((a) => !a.alive) && s.an.length > 0 && s.panels.every((p) => p.state !== 'open')) {
      s.done = true; this.ev('complete', { inked: this.inkedFrac() });
    }
  }

  finishCut(c) {
    const s = this.s;
    c.state = 'done'; c.fEnd = s.f;
    const p = s.panels.find((q) => q.id === c.panel);
    if (!p || !(p.state === 'open' || (c.recut && p.state === 'inked'))) return;
    const wasInked = p.state === 'inked';
    const n = [-c.d[1], c.d[0]];
    const P = [c.x, c.y];
    const g = PAGE.G / 2;
    const L = clipHalf(p.poly, P, n, g);
    const R = clipHalf(p.poly, P, [-n[0], -n[1]], g);
    p.state = 'split'; p.splitF = s.f;
    s.panels = s.panels.filter((q) => q !== p);
    const kids = [];
    for (const [poly, sign] of [[L, 1], [R, -1]]) {
      if (poly.length < 3 || Math.abs(area(poly)) < 50) continue;
      const k = { id: s.nextId++, poly, state: 'open', born: s.f, depth: (p.depth || 0) + 1, parent: p.id, cutId: c.id, side: sign };
      s.panels.push(k);
      kids.push(k);
      for (const an of s.an) {
        if (!an.alive || an.panel !== p.id) continue;
        const sd = (an.x - P[0]) * n[0] + (an.y - P[1]) * n[1];
        if (Math.sign(sd) === sign || (sd === 0 && sign === 1)) {
          an.panel = k.id;
          const need = g + an.r + 0.5;
          if (Math.abs(sd) < need) { an.x += n[0] * sign * (need - Math.abs(sd)); an.y += n[1] * sign * (need - Math.abs(sd)); }
        }
      }
    }
    this.ev('split', { id: c.id, panel: p.id, kids: kids.map((k) => k.id), hero: c.hero, burst: c.burst, recut: !!c.recut });
    if (wasInked) {
      for (const k of kids) { k.state = 'inked'; k.fillF = s.f; k.hero = c.hero; k.recut = true; }
      this.ev('reink', { kids: kids.map((k) => k.id) });
      return;
    }
    for (const k of kids) this.classify(k, c);
  }

  classify(k, c) {
    const s = this.s;
    const inside = s.an.filter((a) => a.alive && a.panel === k.id);
    const frac = Math.abs(area(k.poly)) / s.innerArea;
    if (inside.length === 0) {
      k.state = 'inked'; k.fillF = s.f; k.hero = c.hero;
      s.res = Math.min(100, s.res + 4);
      this.ev('ink', { panel: k.id, frac });
    } else if (inside.length === 1 && (frac <= SEAL_AREA || c.burst)) {
      const an = inside[0];
      an.alive = false; an.sealF = s.f;
      k.state = 'sealed'; k.fillF = s.f; k.hero = c.hero; k.sealKind = an.kind; k.anId = an.id; k.sealAt = [an.x, an.y];
      s.combo = s.f - s.lastSealF < 2.6 * FPS ? s.combo + 1 : 1;
      s.lastSealF = s.f;
      s.res = Math.min(100, s.res + (an.kind === 'nero' ? 30 : 16));
      const card = { n: s.cards.length + 1, kind: an.kind, f: s.f, panel: k.id, hero: c.hero, x: an.x, y: an.y };
      s.cards.push(card);
      this.ev('seal', { panel: k.id, kind: an.kind, combo: s.combo, card: card.n, x: an.x, y: an.y, hero: c.hero });
    }
  }

  snapshot() {
    const s = this.s;
    return {
      f: s.f,
      panels: s.panels.map((p) => ({ id: p.id, poly: p.poly.map(([x, y]) => [+x.toFixed(2), +y.toFixed(2)]), state: p.state, born: p.born,
        fillF: p.fillF, hero: p.hero, sealKind: p.sealKind, cutId: p.cutId, depth: p.depth, sealAt: p.sealAt, recut: p.recut })),
      an: s.an.filter((a) => a.alive || s.f - a.sealF < 2).map((a) => ({ id: a.id, kind: a.kind, x: +a.x.toFixed(2), y: +a.y.toFixed(2), vx: +a.vx.toFixed(1), vy: +a.vy.toFixed(1), r: a.r,
        born: a.born, frozen: a.frozenUntil > s.f, pinF: a.pinF, frozenUntil: a.frozenUntil, alive: a.alive })),
      cuts: s.cuts.filter((c) => c.state === 'grow' || s.f - c.fEnd < 40).map((c) => ({ id: c.id, x: c.x, y: c.y, d: c.d, a: +c.a.toFixed(2), b: +c.b.toFixed(2), t0: c.t0, t1: c.t1,
        state: c.state, f0: c.f0, fEnd: c.fEnd, hero: c.hero, hit: c.hit, burst: c.burst, recut: c.recut })),
      lives: s.lives, combo: s.combo, lastSealF: s.lastSealF, res: Math.round(s.res), hero: s.hero, rift: s.rift,
      cards: s.cards.length, inked: +this.inkedFrac().toFixed(4), done: s.done,
    };
  }
}
