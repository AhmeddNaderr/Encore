# Zenko — research brief

**Identity.** "Where digital manga meets collectible cards. 3,000 anime NFTs featuring a Shonen, a Shojo & the adorable Nero 🎴" (X bio, @Zenko_NFT, joined Oct 2026, 18 posts, ~1.8K followers at time of research).

**Lore (pinned article "ZENKO: A Digital Anime Project", Nov 24 2026).** In the neon-drenched borderland of **Kurokawa**, the boundary between the waking city and the spirit realm has fractured. The city runs on **Resonance**, an unseen energy shaped by human ambition, memory and rebellion. Anomalies spill through the rift and rewrite the rules of the streets. Three archetypes step in:
- **Shonen** — the vanguards (2,000)
- **Shojo** — the catalysts (800)
- **Nero** — the anomalies (200)

**Roadmap / utility (stated, not promised Day 1).** A digital-native manga built for vertical-scroll reading with animated panel transitions and seasonal drops; holder polls decide plot forks. **Zenko Digital TCG (soon)**: beta access, exclusive Genesis card backs, cosmetic variants tied to traits. The team states plainly: "None of this is happening right after mint." So the trailer must not imply a live game, mint date or allocation.

**Five core motifs.** (1) Manga panels and the page itself. (2) Collectible cards. (3) The rift: a broken boundary between the city and the spirit realm. (4) Resonance: red-black energy (the banner's claw flames). (5) Three archetypes: vanguard, catalyst, anomaly.

**Tone and voice.** Short, cool captions with one symbol: "Classic never fades. ☯︎" · "Nerooooo. 🀄" · "Ready to blow you away. 🫧" (bubble-gum kunoichi) · "Are we late for Halloween? ⛧" (masked scythe wielder). Art-first, honest, anime/street culture. Replies: "Clean one ⛩️", "Sick art".

**Art (downloaded at full resolution, see art/sources.csv).** Heavy black ink outlines, two-tone cel shading with hard shadow shapes, glossy hair highlights, all portraits in left-facing profile on one flat colour field. The banner shows the Shonen (white/black hair, spiked red-lined vest, red-black Resonance claws) over a purple-grey manga-page background. Logo: ZENKO brush-cut wordmark, black with a coral slash through the N.

**Sampled palette (real pixels).** Zenko coral `#F4575E` (logo), Nero red `#E16162`, ink `#040304`, Nero fur `#383240`, manga haze `#665A72` / `#403748`, Kurokawa navy `#344771`, sakura hair `#EF9BCC`, paper `#EFF4F0`, skin `#E0B1A9`, cloak teal `#2F4E49`, steel grey `#9E9D99`.

**Things to avoid.** Promising a playable game, mint dates or WL allocation; inventing new hero characters; redrawing faces; physical-merch angles (Zenko is "staying completely on the screen").

**Encore brand (current, checked Nov 2026).** Black stage, chrome ghost-arch mascot with two pill eyes and an echo outline, a rounded lowercase "encore" wordmark with small "STUDIO", Inter Display headlines, letter-spaced mono labels, red accent. Slogan: **"Every launch deserves an encore."** ("an encore." in red). Secondary line: "One crew for your whole launch." Contact: encorestudio.xyz · @EncoreStudiohq · free 30-minute call.

**Sources opened**
- https://x.com/Zenko_NFT
- https://x.com/Zenko_NFT/status/2125243684107276325 (pinned article)
- https://x.com/Zenko_NFT/status/2123770263720587565
- https://x.com/Zenko_NFT/status/2123438370408038869
- https://x.com/Zenko_NFT/status/2123059227820503072
- https://x.com/Zenko_NFT/status/2122702651469218213
- https://encorestudio.xyz
- https://x.com/EncoreStudiohq
