# ZENKO: PANEL CUT — storyboard (main cut, 1920×1080, 60 fps, ~46 s)

Source: G = deterministic gameplay simulation rendered with the official art. M = motion graphics. No AI-generated imagery.

| Time | On screen | Src | Motion / FX | Text | Audio |
|---|---|---|---|---|---|
| 0.0–3.0 | HOOK, mid-run: a red Resonance cut races across the page as an anomaly lunges. The cut finishes a hair before contact, the panel slams shut, an inverted impact frame hits, the 封 stamp lands and a card flips to the rack. | G (flash-forward) | Screen shake, hit-pause, ink burst, katakana SFX ザシュッ | — | Taiko hit + slash, the beat drops |
| 3.0–5.2 | TITLE: the page tears along a diagonal slash to reveal the ZENKO wordmark and PANEL CUT. | M | Slash wipe, logo stamp | "CUT THE PAGE. TRAP THE ANOMALY." | Riser into a hit |
| 5.2–14.0 | LOOP: a blank page. The rift cracks open and anomalies spill out. Cuts ink empty panels with Zenko manga art. A small panel with one anomaly seals into card #1. One cut **breaks** (バキッ), costing a life. A clean cut seals card #2. | G | Line growth, ink-wipe reveals, card flip | Small labels: "CUT A PANEL" · "TRAP ONE" · "IT BECOMES A CARD" | Koto plucks on cuts |
| 14.0–23.0 | ESCALATION: rift LV.2. **Shojo cut-in** (catalyst), and kunai pin two anomalies for a double seal (combo ×2, ×3). **"NEROOOOO."** Nero emerges from the rift golden-eyed and gets sealed for the legendary card. The Resonance meter fills and the **Shonen cut-in** triggers RESONANCE BURST: five claw cuts at once. | G + M cut-ins | Diagonal cut-in bands with real art, speed lines, red flames | "SHOJO · KUNAI PIN" · "NEROOOOO." · "RESONANCE BURST" | Build, then the drop |
| 23.0–28.5 | PAGE COMPLETE: the camera pulls back and every panel holds Zenko art, so the run reads as a real manga page. The sealed cards fan out as a hand in the official card frame. | G + M | Push-out, card fan, holo sheen | "YOUR PAGE · CH.01 P.07" | Sustained chord |
| 28.5–33.5 | WL LEADERBOARD (sample handles) climbing | M | Row slides, rank tick | "Bots can like a post. They can't draw the line." | Hats + bass |
| 33.5–38.0 | Result card flies into an X post mock-up | M | Card flight, post build | "Share your page" | Whoosh, UI ticks |
| 38.0–40.5 | ZENKO wordmark + game title | M | Ink stamp | "ZENKO: PANEL CUT — a game concept for Zenko" | Final hit |
| 40.5–46.0 | ENCORE END CARD: chrome mascot, encore wordmark, slogan, CTA, disclaimer | M | Chrome sheen, eye blink | "Every launch deserves an encore." · "Book a free 30-min call · encorestudio.xyz · @EncoreStudiohq" | Tail and fade |

## 15 s vertical (1080×1920)
0–2 hook seal · 2–9 loop → Shojo pin → Nero → burst · 9–11.5 page reveal + leaderboard line · 11.5–15 result + Encore end card. Must read with the sound off.
