// Usage:
//   node capture.mjs stills <layout> <outDir> <t1,t2,...>
//   node capture.mjs cues   <layout> <out.json>
//   node capture.mjs video  <layout> <out.mp4> [startFrame endFrame]
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const [mode, layout = 'main', out, arg4, arg5] = process.argv.slice(2);
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.css': 'text/css', '.woff2': 'font/woff2', '.woff': 'font/woff' };
const server = http.createServer((req, res) => {
  const p = path.join(ROOT, decodeURIComponent(req.url.split('?')[0]));
  if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(p)] || 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const VERT = layout === 'vertical';
const W = VERT ? 1080 : 1920, H = VERT ? 1920 : 1080;

const browser = await chromium.launch({ args: ['--disable-gpu-vsync', '--force-color-profile=srgb'] });
const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
page.on('console', (m) => { if (m.type() === 'error') console.error('[page]', m.text()); });
page.on('pageerror', (e) => console.error('[pageerror]', e.message));
await page.goto(`http://127.0.0.1:${port}/game/render.html?layout=${layout}`);
await page.waitForFunction(() => window.ready || window.initError, null, { timeout: 120000 });
const err = await page.evaluate(() => window.initError);
if (err) { console.error(err); process.exit(1); }
const total = await page.evaluate(() => window.TOTAL_FRAMES);

const grab = async (n) => {
  const url = await page.evaluate((k) => window.frameData(k, 'image/png'), n);
  return Buffer.from(url.slice(url.indexOf(',') + 1), 'base64');
};

if (mode === 'stills') {
  fs.mkdirSync(out, { recursive: true });
  for (const t of arg4.split(',').map(Number)) {
    const n = Math.round(t * 60);
    fs.writeFileSync(path.join(out, `${layout}-${t.toFixed(2).padStart(6, '0')}.png`), await grab(n));
  }
  console.log('stills done');
} else if (mode === 'cues') {
  const cues = await page.evaluate(() => window.cues());
  fs.writeFileSync(out, JSON.stringify(cues, null, 1));
  console.log('cues', cues.length);
} else if (mode === 'video') {
  const f0 = arg4 ? +arg4 : 0, f1 = arg5 ? +arg5 : total;
  const ff = spawn('ffmpeg', ['-y', '-v', 'error', '-f', 'image2pipe', '-framerate', '60', '-c:v', 'png', '-i', '-',
    '-c:v', 'libx264', '-preset', 'slow', '-crf', '15', '-pix_fmt', 'yuv420p', '-profile:v', 'high',
    '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-color_range', 'tv',
    '-x264-params', 'keyint=120:min-keyint=60', out], { stdio: ['pipe', 'inherit', 'inherit'] });
  const t0 = Date.now();
  for (let n = f0; n < f1; n++) {
    const buf = await grab(n);
    if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
    if (n % 120 === 0) console.log(`frame ${n}/${f1} ${((Date.now() - t0) / 1000).toFixed(0)}s`);
  }
  ff.stdin.end();
  await new Promise((r) => ff.on('close', r));
  console.log('video done', out, ((Date.now() - t0) / 1000).toFixed(0) + 's');
}
await browser.close();
server.close();
