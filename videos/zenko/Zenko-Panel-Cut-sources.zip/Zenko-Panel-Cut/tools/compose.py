"""Original score + SFX for ZENKO: PANEL CUT (all synthesized from oscillators and seeded noise).

Usage: python compose.py <cues.json> <layout main|vertical> <out.wav>
Music: 140 BPM anime-trap / taiko hybrid in A "In" scale (A Bb D E F), koto + shamisen
(Karplus-Strong), taiko, 808, hats, pads. Sections restart on scene cuts so hits land on picture.
"""
import json
import sys
import wave

import numpy as np
from scipy.signal import fftconvolve, butter, sosfilt

SR = 48000
rng = np.random.default_rng(7)
cues = json.load(open(sys.argv[1]))
LAYOUT = sys.argv[2]
OUT = sys.argv[3]
DUR = 44.0 if LAYOUT == 'main' else 15.0
N = int(DUR * SR) + SR
mus = np.zeros((N, 2))
fx = np.zeros((N, 2))


def note(n):  # midi -> Hz
    return 440.0 * 2 ** ((n - 69) / 12)


def env(n, a=0.002, d=0.2, s=0.0, r=0.05, hold=None):
    t = np.arange(n) / SR
    e = np.minimum(1, t / max(a, 1e-4))
    dec = s + (1 - s) * np.exp(-(t - a) / max(d, 1e-4))
    e = np.where(t < a, e, dec)
    if hold is not None:
        rel = np.clip(1 - (t - hold) / r, 0, 1)
        e = e * np.where(t > hold, rel, 1)
    return e


def lp(x, fc, order=2):
    return sosfilt(butter(order, min(fc, SR / 2 - 100) / (SR / 2), 'low', output='sos'), x, axis=0)


def hp(x, fc, order=2):
    return sosfilt(butter(order, fc / (SR / 2), 'high', output='sos'), x, axis=0)


def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo / (SR / 2), min(hi, SR / 2 - 100) / (SR / 2)], 'band', output='sos'), x, axis=0)


def put(buf, t, sig, gain=1.0, pan=0.0):
    i = int(t * SR)
    if i >= len(buf) or i + len(sig) <= 0:
        return
    if sig.ndim == 1:
        l, r = np.cos((pan + 1) * np.pi / 4), np.sin((pan + 1) * np.pi / 4)
        sig = np.stack([sig * l * 1.414, sig * r * 1.414], 1)
    j0 = max(0, -i)
    n = min(len(sig) - j0, len(buf) - i - j0)
    buf[i + j0:i + j0 + n] += sig[j0:j0 + n] * gain


# ---------------- instruments ----------------
def kick(dur=0.45):
    n = int(dur * SR); t = np.arange(n) / SR
    f = 45 + 95 * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) * np.exp(-t / 0.22)
    s += 0.25 * rng.standard_normal(n) * np.exp(-t / 0.004)
    return np.tanh(s * 1.6)


def sub808(freq, dur):
    n = int(dur * SR); t = np.arange(n) / SR
    f = freq * (1 + 0.5 * np.exp(-t / 0.02))
    s = np.sin(2 * np.pi * np.cumsum(f) / SR)
    return np.tanh(1.8 * s) * env(n, 0.003, dur * 0.8, 0.5, 0.06, hold=dur - 0.06)


def taiko(big=True):
    dur = 1.1 if big else 0.35
    n = int(dur * SR); t = np.arange(n) / SR
    f0 = 62 if big else 190
    f = f0 * (1 + 0.6 * np.exp(-t / 0.03))
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / (0.32 if big else 0.08))
    skin = bp(rng.standard_normal(n), 150, 900) * np.exp(-t / 0.05)
    over = np.sin(2 * np.pi * np.cumsum(f * 2.3) / SR) * np.exp(-t / 0.06) * 0.3
    return np.tanh((body + 0.5 * skin + over) * 1.3)


def snare():
    n = int(0.3 * SR); t = np.arange(n) / SR
    nz = bp(rng.standard_normal(n), 1200, 9000) * np.exp(-t / 0.07)
    tone = np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.04)
    clap = np.zeros(n)
    for k, dt in enumerate([0, 0.011, 0.022]):
        i = int(dt * SR); m = int(0.02 * SR)
        clap[i:i + m] += bp(rng.standard_normal(m), 900, 5000) * np.exp(-np.arange(m) / SR / 0.006)
    return 0.6 * nz + 0.4 * tone + 0.6 * clap


def hat(open_=False):
    dur = 0.28 if open_ else 0.05
    n = int(dur * SR); t = np.arange(n) / SR
    return hp(rng.standard_normal(n), 7000) * np.exp(-t / (0.09 if open_ else 0.012))


def ks(freq, dur, bright=0.6, decay=0.996, buzz=0.0):
    """Karplus-Strong plucked string (koto / shamisen)."""
    n = int(dur * SR)
    L = max(2, int(SR / freq))
    buf = rng.uniform(-1, 1, L) * np.hanning(L) ** 0.3
    buf = lp(buf, 2000 + 9000 * bright)
    out = np.zeros(n)
    idx = 0
    b = buf.copy()
    for i in range(n):
        v = b[idx]
        out[i] = v
        nxt = b[(idx + 1) % L]
        b[idx] = decay * 0.5 * (v + nxt)
        idx = (idx + 1) % L
    if buzz > 0:  # shamisen "sawari" buzz
        out = np.tanh(out * (1 + buzz * 6)) * 0.8
    att = np.minimum(1, np.arange(n) / (0.002 * SR))
    return out * att


KS_CACHE = {}


def pluck(n_midi, dur, kind='koto'):
    key = (n_midi, round(dur, 3), kind)
    if key not in KS_CACHE:
        if kind == 'koto':
            KS_CACHE[key] = ks(note(n_midi), dur, 0.75, 0.9975)
        else:
            KS_CACHE[key] = ks(note(n_midi), dur, 0.95, 0.993, buzz=0.35)
    return KS_CACHE[key]


def saw_stack(freq, dur, voices=5, detune=0.012):
    n = int(dur * SR); t = np.arange(n) / SR
    s = np.zeros(n)
    for v in range(voices):
        d = 1 + detune * (v - (voices - 1) / 2) / (voices / 2)
        ph = (t * freq * d + rng.random()) % 1
        s += 2 * ph - 1
    return s / voices


def pad(freqs, dur, cutoff=1800, a=0.6, r=1.2):
    n = int(dur * SR)
    s = sum(saw_stack(f, dur) for f in freqs) / len(freqs)
    s = lp(s, cutoff, 2)
    e = env(n, a, 10, 1.0, r, hold=dur - r)
    L = s * e
    R = np.roll(s, int(0.011 * SR)) * e
    return np.stack([L, R], 1)


def stab(freqs, dur=0.5):
    n = int(dur * SR); t = np.arange(n) / SR
    s = sum(saw_stack(f, dur, 3, 0.008) for f in freqs) / len(freqs)
    # filter envelope approximation: blend bright->dark
    bright = hp(s, 300) * np.exp(-t / 0.08)
    dark = lp(s, 900)
    return (0.7 * bright + 0.5 * dark) * env(n, 0.003, 0.18, 0.15, 0.08, hold=dur - 0.08)


def riser(dur):
    n = int(dur * SR); t = np.arange(n) / SR
    nz = rng.standard_normal(n)
    out = np.zeros(n)
    seg = 2400
    for i in range(0, n, seg):
        fc = 300 + 9000 * (i / n) ** 2
        out[i:i + seg] = bp(nz[i:i + seg], fc * 0.7, fc * 1.4, 1)
    sweep = np.sin(2 * np.pi * np.cumsum(200 + 1600 * (t / dur) ** 2) / SR) * 0.25
    return (out + sweep) * (t / dur) ** 2


def boom(dur=2.2):
    n = int(dur * SR); t = np.arange(n) / SR
    f = 30 + 50 * np.exp(-t / 0.12)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.7)
    s += lp(rng.standard_normal(n), 400) * np.exp(-t / 0.25) * 0.6
    return np.tanh(s * 1.5)


def whoosh(dur=0.45, lo=500, hi=6000):
    n = int(dur * SR); t = np.arange(n) / SR
    nz = rng.standard_normal(n)
    out = np.zeros(n); seg = 1200
    for i in range(0, n, seg):
        u = i / n; fc = lo + (hi - lo) * np.sin(np.pi * u)
        out[i:i + seg] = bp(nz[i:i + seg], fc * 0.6, fc * 1.6, 1)
    return out * np.sin(np.pi * t / dur) ** 2


def shing(bright=1.0):
    n = int(0.5 * SR); t = np.arange(n) / SR
    nz = hp(rng.standard_normal(n), 3000) * np.exp(-t / 0.05)
    ring = sum(np.sin(2 * np.pi * f * t + rng.random() * 6) * np.exp(-t / (0.12 + 0.05 * k)) for k, f in enumerate([2900 * bright, 4370 * bright, 6150 * bright]))
    sweep = np.sin(2 * np.pi * np.cumsum(1500 + 5000 * np.minimum(1, t / 0.08)) / SR) * np.exp(-t / 0.06)
    return 0.6 * nz + 0.25 * ring + 0.35 * sweep


def stamp():
    n = int(0.25 * SR); t = np.arange(n) / SR
    thud = np.sin(2 * np.pi * np.cumsum(140 * (1 + np.exp(-t / 0.01))) / SR) * np.exp(-t / 0.05)
    wood = bp(rng.standard_normal(n), 600, 2500) * np.exp(-t / 0.02)
    return thud + 0.6 * wood


def sparkle(base=1800):
    n = int(0.8 * SR); t = np.arange(n) / SR
    s = np.zeros(n)
    for k, f in enumerate([base, base * 1.5, base * 2, base * 2.67, base * 3]):
        st = int(k * 0.045 * SR)
        tt = t[:n - st]
        s[st:] += np.sin(2 * np.pi * f * tt) * np.exp(-tt / 0.18) * 0.3
    return s


def crack():
    n = int(0.6 * SR); t = np.arange(n) / SR
    s = np.zeros(n)
    for k in range(18):
        i = int(rng.uniform(0, 0.18) * SR); m = int(0.006 * SR)
        s[i:i + m] += hp(rng.standard_normal(m), 2500) * rng.uniform(0.4, 1)
    drop = np.sin(2 * np.pi * np.cumsum(900 * np.exp(-t / 0.08) + 80) / SR) * np.exp(-t / 0.12)
    return s + 0.6 * drop + 0.5 * bp(rng.standard_normal(n), 200, 2000) * np.exp(-t / 0.08)


def gong(dur=3.0):
    n = int(dur * SR); t = np.arange(n) / SR
    s = sum(np.sin(2 * np.pi * f * t + rng.random() * 6) * np.exp(-t / d) * a for f, d, a in
            [(110, 1.6, 1), (163, 1.3, .7), (227, 1.0, .5), (319, .8, .4), (447, .6, .3), (612, .45, .2)])
    return s * np.minimum(1, t / 0.01) * 0.6


def bloop():
    n = int(0.18 * SR); t = np.arange(n) / SR
    return np.sin(2 * np.pi * np.cumsum(300 + 900 * t / 0.18) / SR) * np.exp(-t / 0.05)


def rumble(dur=1.4):
    n = int(dur * SR); t = np.arange(n) / SR
    return lp(rng.standard_normal(n), 140) * 3 * np.sin(np.pi * t / dur) * (1 + 0.4 * np.sin(2 * np.pi * 7 * t))


def tick():
    n = int(0.03 * SR); t = np.arange(n) / SR
    return np.sin(2 * np.pi * 2400 * t) * np.exp(-t / 0.006)


def chime(freqs, dur=2.5):
    n = int(dur * SR); t = np.arange(n) / SR
    return sum(np.sin(2 * np.pi * f * t) * np.exp(-t / 0.9) * (0.5 ** k) for k, f in enumerate(freqs))


# ---------------- score ----------------
BPM = 140
B = 60 / BPM
# A "In" scale: A Bb D E F (midi 57 58 62 64 65)
SC = [57, 58, 62, 64, 65]


def sc(i, octave=0):
    return SC[i % 5] + 12 * (i // 5) + 12 * octave


K = kick(); SN_ = snare(); HC = hat(); HO = hat(True); TB = taiko(True); TS = taiko(False)
RIFF = [0, 2, 3, 4, 3, 2, 1, 0, 2, 4, 5, 4, 3, 2, 3, 1]  # koto line over two bars (eighths)


def groove(t0, t1, energy=1.0, koto=True, sham=False, bass=True, half=False):
    beats = int((t1 - t0) / B + 0.001)
    roots = [57, 57, 53, 55]  # A A F G under the In scale (dark, cinematic)
    for b in range(beats):
        t = t0 + b * B
        bar, beat = divmod(b, 4)
        if half:
            if beat == 0: put(mus, t, K, 0.9)
            if beat == 2: put(mus, t, SN_, 0.35 * energy)
        else:
            if beat in (0,) or (beat == 2 and bar % 2 == 1) or (energy > 1.1 and beat == 3 and b % 8 == 7):
                put(mus, t, K, 0.95)
            if beat == 2 or (energy > 1.1 and beat == 0 and bar % 2 == 1 and False):
                put(mus, t, SN_, 0.5 * energy, 0.05)
            # trap hats: 8ths, with 16th/triplet rolls
            for k in range(2):
                put(mus, t + k * B / 2, HC, 0.18 * energy, 0.3 * (1 if k else -1))
            if energy > 0.9 and b % 8 == 6:
                for k in range(3):
                    put(mus, t + B / 2 + k * B / 6, HC, 0.15, 0.4)
            if beat == 3 and bar % 2 == 0:
                put(mus, t + B / 2, HO, 0.12 * energy, -0.3)
        if beat == 0 and bass:
            put(mus, t, sub808(note(roots[bar % 4] - 24), 4 * B * 0.95), 0.34 * energy)
        if b % 8 == 0:
            put(mus, t, TB, 0.55 * energy, -0.15)
        if energy > 1.0 and beat in (1, 3):
            put(mus, t + B / 2, TS, 0.2, 0.25)
        if koto:
            for k in range(2):
                idx = RIFF[(b * 2 + k) % 16]
                put(mus, t + k * B / 2, pluck(sc(idx, 1), 0.9), 0.30 * min(1.2, energy), 0.25 if k else -0.2)
        if sham and beat in (0, 2):
            put(mus, t, pluck(sc(RIFF[b % 16] + 5, 0), 0.4, 'sham'), 0.18, -0.35)


def pad_chord(t0, dur, root=57, gain=0.16, cutoff=1600):
    ch = [note(root - 12), note(root - 5), note(root), note(root + 3)]  # minor-ish open voicing
    put(mus, t0, pad(ch, dur, cutoff), gain)


def hit(t, big=1.0):
    put(mus, t, TB, 0.9 * big); put(mus, t, K, 0.8 * big); put(mus, t, boom(1.6), 0.45 * big)
    put(mus, t, stab([note(57), note(62), note(64)], 0.45), 0.22 * big)


FIRST_SEAL = next(c['t'] for c in cues if c['type'] == 'seal')
FIRST_CUT = next(c['t'] for c in cues if c['type'] == 'cut')


def build_main():
    # 0-3.0 hook (slow-mo after the swipe) — energy in, dip during slow-mo, hit on the seal
    groove(0.0, FIRST_CUT, 1.1, sham=True)
    put(mus, 0.0, TB, 0.8); put(mus, 0.0, boom(1.2), 0.3)
    pad_chord(FIRST_CUT, FIRST_SEAL - FIRST_CUT + 0.3, 57, 0.18, 900)
    put(mus, FIRST_CUT + 0.05, riser(FIRST_SEAL - FIRST_CUT - 0.05), 0.22)
    hit(FIRST_SEAL, 1.1)
    groove(FIRST_SEAL, 3.0, 1.0)
    # 3.0-5.2 title
    hit(3.0, 1.2); pad_chord(3.0, 2.3, 57, 0.2, 2200)
    for k in range(8): put(mus, 3.0 + 1.2 + k * B / 4, TS, 0.12 + 0.03 * k, (-1) ** k * 0.3)
    put(mus, 4.2, riser(1.0), 0.25)
    # 5.2-12.45 loop
    groove(5.2, 12.45, 0.9)
    pad_chord(5.2, 7.3, 57, 0.08, 1200)
    # 12.45-13.55 shojo cut-in: drop-out, stab, sakura chime
    put(mus, 12.45, stab([note(62), note(65), note(69)], 0.6), 0.3); put(mus, 12.45, TB, 0.6)
    put(mus, 12.5, chime([note(81), note(86), note(88)], 1.2), 0.08)
    # 13.55-15.94
    groove(13.55, 15.94, 1.1, sham=True)
    # 15.94-17.0 nero cut-in: gong
    put(mus, 15.94, gong(2.4), 0.45); put(mus, 15.94, TB, 0.7)
    # 17.0-20.35 build
    groove(17.0, 20.35, 1.15, sham=True)
    pad_chord(17.0, 3.4, 53, 0.08, 1500)
    # 20.35-21.45 shonen cut-in: riser
    put(mus, 20.35, riser(1.1), 0.4); put(mus, 20.35, stab([note(57), note(60), note(64)], 0.5), 0.25)
    # 21.45-23.7 drop
    hit(21.45, 1.3)
    groove(21.45, 23.7, 1.35, sham=True)
    pad_chord(21.45, 2.3, 57, 0.12, 3000)
    # 23.7-27.9 page reveal: half-time, big pad, koto arps
    hit(23.7, 0.9)
    pad_chord(23.7, 4.3, 57, 0.18, 2400)
    groove(23.7, 27.9, 0.7, koto=False, half=True)
    for k in range(16): put(mus, 23.7 + 0.6 + k * B / 2, pluck(sc([0, 2, 3, 4, 5, 4, 3, 2][k % 8], 1), 1.2), 0.22, (-1) ** k * 0.4)
    # 27.9-32.1 leaderboard
    groove(27.9, 32.1, 0.85, koto=True)
    # 32.1-35.9 share
    groove(32.1, 35.9, 0.95, sham=True)
    # 35.9-38.3 zenko title
    hit(35.9, 1.2); pad_chord(35.9, 2.5, 57, 0.16, 2000)
    put(mus, 37.3, riser(1.0), 0.15)
    # 38.3-44 encore: resolve to D (In scale) with soft koto + chime, long tail
    put(mus, 38.3, boom(2.5), 0.3); put(mus, 38.3, TB, 0.5)
    pad_chord(38.3, 5.5, 62, 0.14, 1400)
    for k, (dt, i) in enumerate([(0.4, 2), (0.8, 4), (1.2, 5), (1.8, 7), (2.6, 9)]):
        put(mus, 38.3 + dt, pluck(sc(i, 1), 2.4), 0.24, (-1) ** k * 0.3)
    put(mus, 39.9, chime([note(86), note(93), note(98)], 3.5), 0.06)


def build_vertical():
    groove(0.0, FIRST_CUT, 1.1, sham=True)
    put(mus, 0.0, TB, 0.8)
    pad_chord(FIRST_CUT, FIRST_SEAL - FIRST_CUT + 0.2, 57, 0.15, 900); put(mus, FIRST_CUT, riser(FIRST_SEAL - FIRST_CUT), 0.2)
    hit(FIRST_SEAL, 1.1)
    groove(FIRST_SEAL, 3.3, 1.1, sham=True)
    put(mus, 3.3, gong(2.0), 0.4); put(mus, 3.3, TB, 0.6)
    groove(4.1, 5.5, 1.15, sham=True)
    put(mus, 5.5, riser(0.8), 0.4)
    hit(6.3, 1.3); groove(6.3, 8.1, 1.35, sham=True)
    hit(8.1, 0.9); pad_chord(8.1, 2.3, 57, 0.18, 2400); groove(8.1, 10.3, 0.7, koto=False, half=True)
    groove(10.3, 12.0, 0.85)
    put(mus, 12.0, boom(2.5), 0.3); put(mus, 12.0, TB, 0.5); pad_chord(12.0, 3.0, 62, 0.14, 1400)
    for k, (dt, i) in enumerate([(0.3, 2), (0.6, 4), (0.9, 5), (1.4, 7)]):
        put(mus, 12.0 + dt, pluck(sc(i, 1), 2.0), 0.24, (-1) ** k * 0.3)
    put(mus, 13.0, chime([note(86), note(93), note(98)], 2.0), 0.06)


# ---------------- event SFX ----------------
SH = shing(); SH2 = shing(1.3); ST = stamp(); CR = crack(); SPK = sparkle(); BL = bloop()


def build_fx():
    shot_t = {}
    for c in cues:
        t, ty = c['t'], c['type']
        if ty == 'cut':
            if c.get('burst'):
                put(fx, t, SH, 0.55, rng.uniform(-0.5, 0.5)); put(fx, t, whoosh(0.3, 800, 8000), 0.4)
            elif c.get('hero') == 'shojo':
                put(fx, t, SH2, 0.42, 0.2); put(fx, t, whoosh(0.35, 1500, 9000), 0.25)
            else:
                put(fx, t, SH, 0.45, -0.1); put(fx, t, whoosh(0.35, 600, 6000), 0.3)
        elif ty == 'split':
            put(fx, t, TS, 0.25); put(fx, t, ST, 0.12)
        elif ty == 'ink':
            put(fx, t, whoosh(0.6, 300, 2500), 0.22); put(fx, t, TS, 0.15)
        elif ty == 'reink':
            put(fx, t, whoosh(0.4, 400, 3000), 0.15)
        elif ty == 'seal':
            nero = c.get('kind') == 'nero'
            put(fx, t, TB, 0.55 if not nero else 0.8)
            put(fx, t, SH, 0.3)
            put(fx, t + 0.05, ST, 0.55)
            put(fx, t + 0.06, SPK if not nero else sparkle(1300), 0.25 + 0.04 * (c.get('combo') or 1))
            put(fx, t + 0.12, whoosh(0.5, 800, 5000), 0.18, 0.6)  # card flies to the rack
            if nero:
                put(fx, t, gong(2.5), 0.35); put(fx, t, boom(1.8), 0.4)
        elif ty == 'break':
            put(fx, t, CR, 0.7); put(fx, t, boom(0.8), 0.25)
        elif ty == 'pin':
            put(fx, t, whoosh(0.25, 2000, 9000), 0.35, -0.3); put(fx, t + 0.08, SH2, 0.25); put(fx, t + 0.12, BL, 0.3); put(fx, t + 0.2, BL, 0.25, 0.3)
        elif ty == 'spawn':
            put(fx, t, whoosh(0.4, 150, 1200), 0.18)
        elif ty == 'rift':
            put(fx, t, rumble(1.2), 0.35)
        elif ty == 'burst':
            put(fx, t, boom(2.0), 0.55); put(fx, t, whoosh(0.6, 300, 9000), 0.4)
        elif ty == 'hero':
            put(fx, t, whoosh(0.3, 1000, 7000), 0.18, -0.7)
        elif ty == 'shot':
            shot_t[c['shot'] + (c.get('cutin') or '')] = t
            if c.get('cutin'):
                put(fx, t, whoosh(0.35, 400, 8000), 0.45, -0.6)
            elif c['shot'] in ('title', 'page', 'leader', 'share', 'zenko'):
                put(fx, t, whoosh(0.5, 300, 7000), 0.3)
    # motion-graphics scenes
    if 'page' in shot_t:
        t0 = shot_t['page']
        for i in range(8):
            put(fx, t0 + 1.0 + i * 0.09, whoosh(0.22, 1500, 8000), 0.14, -0.4 + i * 0.1)
            put(fx, t0 + 1.05 + i * 0.09, tick(), 0.12)
    if 'leader' in shot_t:
        t0 = shot_t['leader']
        for i in range(10):
            put(fx, t0 + 0.2 + i * 0.05, tick(), 0.1, 0.2)
        put(fx, t0 + 1.4, chime([note(76), note(81)], 1.0), 0.06)
    if 'share' in shot_t:
        t0 = shot_t['share']
        put(fx, t0 + 0.3, whoosh(0.5, 400, 6000), 0.3, 0.5)
        put(fx, t0 + 1.3, tick(), 0.3); put(fx, t0 + 1.32, BL, 0.15)
        put(fx, t0 + 1.7, sparkle(2200), 0.12)
    if 'encore' in shot_t:
        t0 = shot_t['encore']
        put(fx, t0 + 1.6, tick(), 0.08)  # mascot blink


build_main() if LAYOUT == 'main' else build_vertical()
build_fx()

# ---------------- mix ----------------
# reverb: synthetic stereo IR (exponential decay noise)
ir_n = int(2.2 * SR); t = np.arange(ir_n) / SR
ir = np.stack([rng.standard_normal(ir_n), rng.standard_normal(ir_n)], 1) * np.exp(-t / 0.55)[:, None]
ir = lp(ir, 6000); ir /= np.sqrt((ir ** 2).sum(0))
wet_m = np.stack([fftconvolve(mus[:, c], ir[:, c])[:N] for c in range(2)], 1)
wet_f = np.stack([fftconvolve(fx[:, c], ir[:, c])[:N] for c in range(2)], 1)
mix = 0.85 * mus + 0.22 * wet_m + 0.9 * fx + 0.16 * wet_f
mix = hp(mix, 28)
mix = mix[:int(DUR * SR)]
fade = int(0.9 * SR)
mix[-fade:] *= np.linspace(1, 0, fade)[:, None] ** 1.5
mix = np.tanh(mix / (np.abs(mix).max() + 1e-9) * 1.3) * 0.9
pcm = (np.clip(mix, -1, 1) * 32767).astype('<i2')
with wave.open(OUT, 'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
print('wrote', OUT, mix.shape[0] / SR, 's')
