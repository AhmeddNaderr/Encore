"""Prepare art assets from the official Zenko / Encore files.

- Background-removed cutouts of the flat-background portraits (flood fill from the
  border with a colour-distance tolerance; the heavy black ink outline stops leaks).
- Alpha versions of the ZENKO wordmark (ink and light variants).
- Alpha version of the Encore wordmark from the official X banner.
Original pixels are never repainted; only alpha is computed.
"""
import sys
from collections import deque
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage

ROOT = Path(sys.argv[1])
RAW = ROOT / "raw"
OUT = ROOT / "assets"
OUT.mkdir(exist_ok=True)


def cutout(src, name, tol=26, soft=18, extra_seeds=(), max_side=1500):
    im = Image.open(RAW / src).convert("RGB")
    a = np.asarray(im).astype(np.float32)
    h, w, _ = a.shape
    bg = np.median(np.concatenate([a[0, :], a[:, 0], a[0:4, -1]]), axis=0)
    dist = np.sqrt(((a - bg) ** 2).sum(2))
    near = dist < tol
    # connected components of near-bg pixels; keep the ones touching the border
    lab, n = ndimage.label(near)
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    for (sx, sy) in extra_seeds:
        if lab[sy, sx]:
            border.add(lab[sy, sx])
    bgmask = np.isin(lab, list(border))
    # soft edge: grow the bg region by a couple of pixels using the distance ramp
    grown = ndimage.binary_dilation(bgmask, iterations=3)
    ramp = np.clip((dist - tol * 0.6) / soft, 0, 1)
    alpha = np.where(bgmask, 0.0, 1.0)
    edge = grown & ~bgmask
    alpha[edge] = ramp[edge]
    # de-fringe: unmix bg colour from semi-transparent edge pixels
    rgb = a.copy()
    sel = (alpha > 0.02) & (alpha < 0.98)
    al = alpha[sel][:, None]
    rgb[sel] = np.clip((a[sel] - (1 - al) * bg) / np.maximum(al, 0.05), 0, 255)
    rgba = np.dstack([rgb, alpha * 255]).astype(np.uint8)
    out = Image.fromarray(rgba, "RGBA")
    if max(out.size) > max_side:
        s = max_side / max(out.size)
        out = out.resize((round(w * s), round(h * s)), Image.LANCZOS)
    out.save(OUT / f"{name}.png")
    print(name, out.size, "bg", bg.astype(int), "kept %.1f%%" % (100 * (alpha > 0.5).mean()))


def zenko_logo():
    im = np.asarray(Image.open(RAW / "pfp-orig.jpg").convert("RGB")).astype(np.float32)
    crop = im[420:900, 110:1215]
    r, g, b = crop[..., 0], crop[..., 1], crop[..., 2]
    coral = np.array([244, 87, 94], np.float32)
    is_red = (r - g) > 40
    a_black = np.clip(1 - (crop.mean(2) / 255.0), 0, 1)
    a_red = np.clip((255 - g) / (255 - coral[1]), 0, 1)
    alpha = np.where(is_red, a_red, a_black)
    alpha = np.clip((alpha - 0.04) / 0.92, 0, 1)
    redness = np.clip(((r - g) - 20) / 120, 0, 1)
    redness = np.where(alpha > 0.05, redness, 0)
    # upscale 2x for crisp large display
    H, W = alpha.shape
    A = Image.fromarray((alpha * 255).astype(np.uint8)).resize((W * 2, H * 2), Image.LANCZOS)
    R = Image.fromarray((redness * 255).astype(np.uint8)).resize((W * 2, H * 2), Image.LANCZOS)
    A = np.asarray(A).astype(np.float32) / 255
    A = np.clip((A - 0.5) * 1.6 + 0.5, 0, 1)  # tighten edges after upscale
    R = np.asarray(R).astype(np.float32) / 255
    for variant, base in (("ink", (12, 9, 12)), ("light", (242, 240, 236))):
        col = np.zeros(A.shape + (3,), np.float32)
        for i in range(3):
            col[..., i] = base[i] * (1 - R) + coral[i] * R
        out = np.dstack([col, A * 255]).astype(np.uint8)
        Image.fromarray(out, "RGBA").save(OUT / f"zenko-logo-{variant}.png")
    print("zenko logo", A.shape[::-1])


def encore_wordmark():
    im = np.asarray(Image.open(ROOT / "encore" / "banner.jpg").convert("L")).astype(np.float32)
    for name, (x0, y0, x1, y1), scale in (("encore-wordmark", (92, 92, 560, 182), 5),
                                          ("encore-studio", (564, 148, 642, 172), 5)):
        c = im[y0:y1, x0:x1]
        bgv = np.percentile(c, 20)
        a = np.clip((c - bgv - 8) / (235 - bgv - 8), 0, 1)
        H, W = a.shape
        A = Image.fromarray((a * 255).astype(np.uint8)).resize((W * scale, H * scale), Image.BICUBIC)
        A = A.filter(ImageFilter.GaussianBlur(scale * 0.35))
        A = np.asarray(A).astype(np.float32) / 255
        A = np.clip((A - 0.42) / 0.22, 0, 1)  # re-threshold for crisp, anti-aliased edges
        out = np.dstack([np.full(A.shape + (3,), 255, np.float32), A * 255]).astype(np.uint8)
        Image.fromarray(out, "RGBA").save(OUT / f"{name}.png")
        print(name, A.shape[::-1])


def card_textures():
    src = Image.open(RAW / "article-HX5gSxsaAAEPKNY.png")
    src.crop((2565, 640, 2935, 935)).save(OUT / "cardback-texture.png")      # ink-swirl card back
    src.crop((760, 1530, 1300, 1990)).save(OUT / "redhalftone-texture.png")  # (unused in final cut)
    L = np.asarray(Image.open(OUT / "zenko-logo-light.png")).astype(float)
    a = L[..., 3]; red = np.clip((L[..., 0] - L[..., 1] - 20) / 100, 0, 1)
    coral, white = np.array([228, 103, 98.]), np.array([246, 244, 240.])
    col = coral * (1 - red[..., None]) + white * red[..., None]           # coral letters, white N
    Image.fromarray(np.dstack([col, a]).astype(np.uint8), "RGBA").save(OUT / "zenko-logo-cardback.png")


if __name__ == "__main__":
    cutout("x-HXf342bbgAACWJr.png", "nero", tol=30)
    cutout("x-HXVarTyasAEhHsN.png", "shojo", tol=30)
    cutout("x-HXae84Ta4AALN3w.png", "katana", tol=14, soft=10)
    cutout("x-HXklmjraIAAWuqX.png", "scythe", tol=16, soft=10)
    zenko_logo()
    encore_wordmark()
    card_textures()
