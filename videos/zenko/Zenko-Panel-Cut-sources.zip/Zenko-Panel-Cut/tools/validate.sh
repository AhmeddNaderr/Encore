#!/usr/bin/env bash
# Validate a delivered MP4: streams, exact duration/frames, full decode, freezes, contact sheet.
set -euo pipefail
f="$1"; sheet="$2"
echo "== $f"
ffprobe -v error -show_entries format=duration,size:stream=codec_name,profile,width,height,r_frame_rate,pix_fmt,color_primaries,channels,sample_rate,nb_frames -of compact "$f"
echo "-- decoded frames:"
ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 "$f"
echo "-- full decode errors (blank = none):"
ffmpeg -v error -i "$f" -f null - 2>&1 | head -5
echo "-- freezes >= 0.6s (blank = none):"
ffmpeg -hide_banner -nostats -i "$f" -vf "freezedetect=n=0.0008:d=0.6" -an -f null - 2>&1 | grep -E "freeze_(start|duration)" | head -20 || true
echo "-- faststart (moov before mdat):"
python3 - "$f" <<'EOF'
import sys
d = open(sys.argv[1], 'rb').read(200000)
print('moov first' if 0 <= d.find(b'moov') < (d.find(b'mdat') if d.find(b'mdat') >= 0 else 10**9) else 'moov NOT first')
EOF
ffmpeg -v error -y -i "$f" -vf "fps=2,scale=320:-1,tile=8x12" -frames:v 1 "$sheet"
echo "sheet -> $sheet"
